"""Read-only: do the stuck orders' quotes have quoted jobsites (NF_Quoted_Jobsite__c) like the succeeded ones?"""
import json, sys, collections
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

B = 'aFOVD0000001Swj4AE'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = {o['id'][:15] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']}
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
orders = sf.query("SELECT Id, SBQQ__Quote__c, Shipping_Address__c FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)
js = sf.query("SELECT NF_Quote__c, NF_USF_Address__c, NF_Quote_Line__c FROM NF_Quoted_Jobsite__c "
              "WHERE NF_Quote__r.USS_Migration_Batch__c = '%s'" % B)
by_quote = collections.defaultdict(list)
for j in js:
    by_quote[j['NF_Quote__c']].append(j)
out = collections.defaultdict(collections.Counter)
example = {}
for o in orders:
    g = 'stuck' if o['Id'][:15] in stuck else 'succeeded'
    jl = by_quote.get(o['SBQQ__Quote__c'], [])
    out[g]['orders'] += 1
    out[g]['no jobsite at all'] += not jl
    out[g]['jobsite address != order shipping address'] += bool(jl) and all(j['NF_USF_Address__c'] != o['Shipping_Address__c'] for j in jl)
    if g == 'stuck' and not jl and 'none' not in example:
        example['none'] = o['Id']
for g in ('stuck', 'succeeded'):
    print(g, dict(out[g]))
print('total jobsites in batch:', len(js), '| example stuck order with no jobsite:', example.get('none'))
