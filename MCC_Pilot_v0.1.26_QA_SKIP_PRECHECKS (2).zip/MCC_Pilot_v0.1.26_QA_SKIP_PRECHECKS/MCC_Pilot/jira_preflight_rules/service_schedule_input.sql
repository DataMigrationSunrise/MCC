-- PWSTM-322. Staging schedule presence only, not proof of generated Salesforce service dates.
SELECT TOP (1001) S.ID AS SourceRecordId,
       CASE WHEN EXISTS
         (SELECT 1 FROM dbo.STG_OrderLineItemServiceSchedule SC
          WHERE SC.OrderLineItemServiceID = S.ID AND SC.TransformationID = S.TransformationID
            AND COALESCE(SC.SFDC_Goose_ExclusionReason, '') = '')
          THEN 'SOURCE_INPUT_PASS' ELSE 'SOURCE_RISK' END AS TestResult,
       CASE WHEN EXISTS
         (SELECT 1 FROM dbo.STG_OrderLineItemServiceSchedule SC
          WHERE SC.OrderLineItemServiceID = S.ID AND SC.TransformationID = S.TransformationID
            AND COALESCE(SC.SFDC_Goose_ExclusionReason, '') = '')
          THEN 'At least one staged schedule row' ELSE 'Service has no eligible scheduled day in staging' END AS Reason,
       S.PreStgID AS SourceKey, S.TransformationID AS TransformationId
FROM dbo.STG_OrderLineItemService S
JOIN dbo.TRFM_Transformation T ON T.ID = S.TransformationID
WHERE T.MigrationBatchID = {{GOOSE_BATCH_ID}}
  AND COALESCE(S.SFDC_Goose_ExclusionReason, '') = ''
  AND S.ServiceFrequency > 0
