# v0.23.3 - audit: every number on screen is in one unit and counted once

The headline said "10,039 failing records". It was a sum of different things: ~671 real Salesforce
records, plus 482 polygons counted twice (flagged by two checks), 7,910 staged-data issues, 47 async
jobs and one marker row. Fixed so each number means one thing:

- **Units.** Each check now declares what it counts: records, staged rows, async jobs, log entries,
  batches, fields, or "steps that produced nothing". Only RECORD checks add to a failing-records
  total, a run book step's failing count, or an object tile.
- **Distinct.** A record flagged by two checks counts once (by Salesforce Id) in the headline and on
  tiles. The All issues line now reads "N distinct record(s) need a fix ... plus, counted
  separately: 47 async jobs, 7,910 staged rows".
- **Everywhere it was shown:** All issues, run book count cells ("47 async jobs", not "47 failing"),
  "held back by a blocker", the object page's failing column and its total, the records page
  header, the Excel export, and the snapshot picker (now "N failing check(s)", since it has no way
  to say records).
- **Tiles.** A tile with more failing than loaded gets a warning mark and a tooltip instead of
  looking like a share.

Not changed: counts that come from a check whose rows have no Id (a few summary checks) are still
added, not de-duplicated. Nothing in the stored data changed; old runs show the new counting.
