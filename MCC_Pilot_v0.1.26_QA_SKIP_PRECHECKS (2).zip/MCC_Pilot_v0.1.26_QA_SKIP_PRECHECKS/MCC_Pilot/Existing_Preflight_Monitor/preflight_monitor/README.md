# Preflight Monitor

A standalone, **read-only** preflight gate and live monitor. Separate from the migration tool
by design: a checker that shares a spec with the thing it checks can only verify intent, never
correctness.

~2,400 lines. Needs Python 3.9+ and `openpyxl`. Nothing else.

---

## The question it answers

Not "are there errors" but:

> **Can I advance past Run Order N, and if not, what exactly is holding me and how do I clear it?**

Results are expressed in the run book, because that is the operator's mental model. Every failing
record is placed at the Run Order where it is **detected** and the Run Order that **fixes** it, with
the script, whether that script writes, who approves, and the ordered steps.

A real UMB-0116 run reads:

```
RO 38  TF_90A.08_Check_Active_MPs...     BLOCKED    5 rec
         ! Active MPs generating no Work Orders -- 5 rows
           FIX AT RO 38: TP-129. The documented cause was falsified -- investigate.
RO 39  TF_55.01_Create_Pre_Snapshot      BLOCKED    5 rec
         > blocked by RO 38
RO 51  TF_60.06_Verify_FSC_BIQs_Created  BLOCKED  750 rec
RO 52  TF_60.04_Check_FSC_BIQs_Missing.. BLOCKED   18 rec
           FIX AT RO 54: confirm WHICH rule first. RO 53 gates RO 54.
RO 54  TF_60.05_Fix_FSC_BIQs...          BLOCKED   18 rec   > blocked by RO 52
RO 55  TF_75_Update_BIQ_Effectivedates   BLOCKED  769 rec   > blocked by RO 51, RO 52
RO 57  DOUBLE CHECK EVERYTHING           BLOCKED  769 rec   > blocked by RO 51, 52, 55
```

The cascade is the point: RO 57 is not independently broken, it is downstream of three things.

A check that can FAIL **must** carry a remediation, or the registry rejects it at startup. A
finding without a fix is a complaint.

## Start here

1. Edit `config.json` — set `OrgAlias` to your QA sandbox alias.
2. Double-click **`START.bat`**.

The browser opens. One page, four buttons:

| Button | What it does |
|---|---|
| **Run checks** | all checks against the selected batch, then shows the run book |
| **Load all batches** | backfills every batch and builds the cross-batch baseline |
| **Self-test** | proves the tool works before you trust anything it says |
| **Spreadsheet** | writes the workbook next to the tool |

Work runs in the background with a live log; the page refreshes itself while a job is
running. Nothing else to learn, and no command line.

A CLI exists if you want it (`python monitor.py gate --batch UMB-0117`), but the browser
is the interface.

---

## Why cross-batch history is the centre of this tool

**`4.7%` is not a finding. `4.7%` against `97.4%` and `100%` is a finding.**

UMB-0116 having 750 of 786 Activated Contracts with no BIQs only became alarming once it was
measured against prior batches. Alone it is a number nobody can act on — and it sat there,
visible, for days.

So every check emits a **metric**, not just a verdict, and history accumulates in SQLite.
`populate` backfills every batch it can find; a check added later gets a full retroactive
history the next time you run it.

---

## The rule that matters most

**The runner assigns verdicts. Checks only return evidence.**

```
rows > 0                                -> FAIL
rows == 0  AND the canary found rows    -> PASS
rows == 0  AND the canary found nothing -> UNPROVEN   <- the scope is broken
required field missing / query errored  -> UNPROVEN
```

Zero rows can **never** become PASS on its own. It becomes PASS only when a canary proves the
query could have found something.

That single rule kills the failure mode behind this whole engagement: an innocent-looking zero
that meant *"my scope is broken"*, not *"the data is clean."* Every batch-scoped query reaches
its batch through a relationship chain, and a null link removes records from the population
instead of flagging them.

---

## Predicting load failures

`PREDICT.LOAD_FAILURES` reads staged rows from the Goose views named in `config.json`
(`PredictTargets`) and validates each one against the **live target schema** — active picklist
values, field lengths, types, createable flags, formula fields, lookup Id shape, required
fields. You learn which records Salesforce will reject **before** you load them.

Schema-driven on purpose: a mapping-driven predictor only catches what the mapping author
anticipated, and it shares a specification with the thing it is checking. The describe is ground
truth.

**It reports the PATTERN, not the record list**, because that is where the decision is:

```
610 of 700 record(s) will fail to load. 610 issue(s), but only 1 distinct pattern --
the top one is 100% of them and is a SINGLE VALUE, so one decision clears it.
```

On the 2026-09-18 Sunrise baseline, 1,459 predicted errors were **84% one inactive picklist
value**. Not 1,459 problems — one decision.

Limits, stated plainly: it predicts **platform** rejections only. It cannot predict trigger or
validation-rule rejections, and it does not judge whether a value is business-correct.

## Logic gaps, not just errors

Records that are structurally valid and load cleanly, but are logically dead:

| Check | What it catches |
|---|---|
| `LOGIC.FSC_CONTRACT_NO_FLAGGED_SUB` | Contract with `Fuel_Surcharge_Percent__c > 0` but no Subscription flagged — `FuelSurchargeBatch` produces nothing for it |
| `LOGIC.ACTIVATED_NO_STARTDATE` | Activated Contract with no StartDate — every derived billing date is unresolvable |
| `LOGIC.MP_ACTIVE_NO_FREQUENCY` | Active MP that cannot generate a schedule |
| `LOGIC.FSC_BIQ_BEFORE_GOLIVE` | FSC BIQ dated before the 2022-08-01 clamp — bills for a period before fuel surcharge existed |

Nothing rejects these. They surface three weeks later as a billing problem.

## The monitoring ratios

Almost every real finding this week was **a ratio compared against prior batches, or a null
nobody tested**. These are the ratios:

`BIQ.COVERAGE` · `ORDER.ACTIVATION_RATE` · `WO.SERVICE_COVERAGE` · `SUB.FSC_FLAG_COVERAGE` ·
`WO.MP_NO_GENERATION` · `QUOTE.NOT_ORDERED` · `GOOSE.BIQ_PARITY` · `BIQ.ERROR_STATUS`

Each emits a metric, so each gets a cross-batch baseline automatically.

## How it self-checks

| | Mechanism |
|---|---|
| 1 | **Evidence invariant** — above, enforced centrally rather than per check author |
| 2 | **Schema preconditions** — each check declares its fields; absent or FLS-hidden ⇒ UNPROVEN, field named |
| 3 | **Canaries** — "could this query have found anything?" |
| 4 | **Known-defect fixtures** — if a proven defect stops being found, the tool says *either it was fixed or I broke* and refuses to guess |
| 5 | **Rule contradictions** — two documented rules on one field are reported, not silently resolved |
| 6 | **Cross-source disagreement** — Salesforce vs Goose vs Sunrise, as a finding |
| 7 | **Coverage self-audit** — reports which of the 20 spine objects have *no* check |
| 8 | **Startup self-test** — six stages; refuses to report if its own fixtures fail |
| 9 | **Remediation required** — a FAIL-capable check with no fix is rejected at registry load |

Mechanism 5 is the only one that can catch a **wrong specification**. Salesforce and Goose
agreeing with each other proves nothing when the documented rule is the defect — which is
exactly what happened with `LastBillingDate__c` (UMB-0065 says `today`, Run Book steps 154-158
say `StartDate - 1`, AF160 writes `today`). Both rules ship registered, so the tool reports the
contradiction on first run.

Mechanism 7 is the audit done by hand against `preflight_pipeline.py` this week — zero
`FROM Contract` in 1,398 lines, four checkpoints with no query at all — made automatic.
**Right now it reports 14 of 20 objects uncovered. That is honest, not a defect.**

---

## Boundary with Sunrise

`connections.py` is the only file that imports Sunrise. It reuses `goose_live.invoke_query` and
`goose_live.validate_readonly_sql` (SELECT-only, banned-token scan) and the `sf` CLI pattern.

Connection code has no opinion about correctness, so it cannot carry a spec defect, and when it
breaks it breaks **loudly**. Check logic is never shared. If Sunrise moves, one file changes and
the error says so; Goose checks report UNPROVEN rather than returning a wrong number.

Sunrise is optional. Without it, Goose checks are UNPROVEN and Salesforce checks run normally.

---

## Adding a check

A registry entry in `checks.py`. No runner, dashboard or report changes — it appears in the
coverage audit, the baseline matrix and the spreadsheet automatically.

`rule_source`, `proves` and `cannot_prove` are **required**. A check that cannot state its own
boundary is rejected at startup, not at runtime.

```python
Check(id="BIQ.FSC_NULL_EFFECTIVE_DATE",
      name="FSC BIQs with a null Effective Date",
      stage="tf_60", sequence=200, sobject="Billing_Impacts_Queue__c", severity=BLOCKER,
      rule="Effective_Date__c must be non-null on every FSC BIQ",
      rule_source="TP-160 requirement; 21 of 21 such rows org-wide are in Error",
      requires=("Billing_Impacts_Queue__c.Effective_Date__c",),
      canary=lambda c: c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE ..."),
      run=...,
      proves="No FSC BIQ will be rejected downstream for a missing Effective Date",
      cannot_prove="That non-null dates are CORRECT -- two rules compete")
```

---

## Proof of concept

Not "it runs." Seed **no** fixtures, run `populate`, and check whether the baseline independently
rediscovers what took two days to find by hand:

| Expected rediscovery | Check |
|---|---|
| UMB-0116 BIQ coverage 4.7% vs 97–100% | `BIQ.COVERAGE` OUTLIER |
| 18 FSC BIQs with null Effective Date | `BIQ.FSC_NULL_EFFECTIVE_DATE` |
| 501 dead ServiceTerritory polygons | `WO.DEAD_POLYGON` |
| 5 Active MPs generating no Work Orders | `WO.MP_NO_GENERATION` |
| Salesforce 163 BIQs vs Goose 124 | `GOOSE.BIQ_PARITY` |
| Salesforce/Goose batch status disagreement | `populate` discovery step |

If it misses one, that check's canary or scoping is wrong — found now rather than in Production.
Known-expensive answers make a far better test than synthetic fixtures.

Then `seed-fixtures` records them, and from that point the tool notices if any stops being found.

---

## Status

**Tested offline, not yet run against a live org.** `test_offline.py` covers the evidence
invariant, baseline classification, fixture state transitions, contradiction detection and the
store round-trip — all passing. Nothing touching Salesforce or Goose has been executed, so expect
the first real run to shake out field names and relationship paths. That is what `selftest`
is for.

Two bugs were found by running the demo and are fixed: a `None` fill crashing the spreadsheet
writer, and a thin-history baseline flagging 100% coverage as an outlier.

**Open: fixture ownership.** When a defect is genuinely fixed, somebody must update the fixture.
Unowned, the regression suite becomes noise within two batches and mechanism 4 turns from an
asset into a liability. That needs a person, not a process.
