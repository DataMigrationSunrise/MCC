# v0.25.2 - the Sunrise self-test line no longer cries wolf

"No Sunrise preflight output found; cross-check checks report UNPROVEN" was shown as DEGRADED, but
no check declares it needs that output, so it cost nothing. It now reads OK ("not used: no current
check depends on it"), and only turns DEGRADED, naming the checks, if a check ever does depend on it.
