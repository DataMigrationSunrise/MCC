@echo off
title Bulk Preflight Monitor
rem Pre-cut preflight: every rule over ALL staged rows of a Goose transformation. Read-only.
rem Usage: CHECK PRECUT.bat            (latest GoForLaunch transformation, project 10)
rem        CHECK PRECUT.bat 549        (a specific TransformationID)
cd /d "%~dp0"
set ARGS=
if not "%~1"=="" set ARGS=--transformation %~1
where py >nul 2>nul
if %errorlevel%==0 (py -3 -X utf8 -m pilot.scope_preflight %ARGS%) else (python -X utf8 -m pilot.scope_preflight %ARGS%)
echo.
pause
