import sys
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems

c = systems.build(app.CFG, 'dry', lambda m: None)
rows = [r for s in c.goose.result_sets(
    "SELECT Name, SBQQ__Account__c, Primary_Contact__c, Ship_To_Contact__c, PrimarySiteContact__c, "
    "ZSB__BillToContact__c, SBQQ__Opportunity2__c FROM dbo.vw_SFDC_OpenBatch_Quote "
    "WHERE ISNULL(SalesforceQuoteID,'')=''") for r in s]
for r in rows:
    print(r)
