"""
Background job runner for the browser UI.

The work (selftest, populate, gate) takes minutes, so the page cannot block on it.
One job at a time, by design -- two concurrent populates against the same SQLite file
would interleave runs and corrupt the baseline.
"""
from __future__ import annotations
import threading
import traceback
from datetime import datetime, timezone

_LOCK = threading.Lock()


class Job:
    def __init__(self):
        self.name = ""
        self.state = "IDLE"          # IDLE | RUNNING | DONE | FAILED
        self.started = ""
        self.finished = ""
        self.percent = 0
        self.message = ""
        self.log: list[str] = []
        self.error = ""
        self.result = None
        self._thread = None

    # -- called from the worker
    def say(self, msg, percent=None):
        stamp = datetime.now(timezone.utc).strftime("%H:%M:%S")
        self.log.append("%s  %s" % (stamp, msg))
        if len(self.log) > 400:
            del self.log[:-400]
        self.message = msg
        if percent is not None:
            self.percent = max(0, min(100, int(percent)))

    def as_dict(self):
        return dict(name=self.name, state=self.state, percent=self.percent,
                    message=self.message, started=self.started, finished=self.finished,
                    error=self.error, log=self.log[-60:])


JOB = Job()


def running() -> bool:
    return JOB.state == "RUNNING"


def start(name: str, fn) -> tuple[bool, str]:
    """
    fn(job) runs on a worker thread. Returns (started, message).
    Refuses to start a second job -- concurrent writes to one SQLite history would
    interleave runs and make the baseline meaningless.
    """
    global JOB
    with _LOCK:
        if JOB.state == "RUNNING":
            return False, "%s is already running. Wait for it to finish." % JOB.name
        JOB = Job()
        JOB.name = name
        JOB.state = "RUNNING"
        JOB.started = datetime.now(timezone.utc).isoformat(timespec="seconds")
        JOB.say("started", 0)

        def wrap():
            try:
                JOB.result = fn(JOB)
                JOB.state = "DONE"
                JOB.percent = 100
                JOB.say("finished")
            except Exception as e:                           # noqa: BLE001
                JOB.state = "FAILED"
                JOB.error = "%s: %s" % (type(e).__name__, e)
                JOB.say("FAILED -- %s" % JOB.error)
                JOB.log.append(traceback.format_exc()[-2500:])
            finally:
                JOB.finished = datetime.now(timezone.utc).isoformat(timespec="seconds")

        JOB._thread = threading.Thread(target=wrap, daemon=True)
        JOB._thread.start()
        return True, "started"
