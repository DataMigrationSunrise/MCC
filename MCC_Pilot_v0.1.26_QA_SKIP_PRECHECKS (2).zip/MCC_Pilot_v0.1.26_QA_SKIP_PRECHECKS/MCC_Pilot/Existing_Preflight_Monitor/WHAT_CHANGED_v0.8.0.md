# Preflight Monitor v0.8.0

## Snapshots — stop re-querying to see what you already measured

Every run was always stored in `preflight_history.db`. There was simply no way to ask for
one, so the tool re-queried Salesforce to show you something already on disk.

- **Snapshot dropdown** (header, right) — every stored run, newest first, with its date,
  batch, error count and unproven count. Pick one, press **View**. No Salesforce, no
  Goose, no network: it is a database read.
- **Save** — writes the selected run to `Application/snapshots/` as one `.json` file.
  Portable: attach it to a ticket, or send it to someone who cannot reach the org.
- **Load file** — drop any snapshot `.json` into `Application/snapshots/` and press it.
  Each one is imported and appears in the dropdown.

A stored run is never shown as if it were current. Whenever you are looking at one, the
page says so, and an **imported** run is flagged even when it is the newest run on your
machine — newest here says nothing about how old it is or which org produced it.
Re-importing the same file replaces rather than duplicates, and a snapshot written by a
different build still loads (unknown columns are ignored rather than failing).

## Run Order 15 is now a real gate — seven new checks

`TF_25.02_Verify_Jobsite_Order_Readiness.apex` had **no check at all**. TF_30 converted,
TF_35 activated and TF_90A cleaned up afterwards with nothing standing in front. Every
field name below came from the org's own snapshot `salesforce_field_constraints.csv`, not
from guessing, and each check declares the fields it needs — a wrong or hidden name
reports UNPROVEN instead of a silent zero.

| Check | Finds |
|---|---|
| `JOBSITE.NO_GEOCODE` | address with no coordinates, or no address at all |
| `JOBSITE.ADDRESS_NOT_VALIDATED` | `Address_Validated__c` false — upstream of the geocode |
| `JOBSITE.NOT_ORDER_READY` | `NF_Order_Ready__c` false |
| `JOBSITE.SITE_NAME_MISSING` | blank Site Name — fails the org's validation |
| `JOBSITE.NO_SITE_CONTACT` | no primary site contact |
| `QUOTE.BUSINESS_TYPE_MISSING` | blank Business Type — a **mapping** gap, not a record fix |
| `QUOTE.BILLING_CONFIG_INCOMPLETE` | blank Billing Period / Bill Timing / Payment Terms |

These run **before** TF_30 and block it. Folder 26 recorded the quote-side path as unknown,
which is why the step could only report after conversion; `NF_Quoted_Jobsite__c` carries
both `NF_Quote__c` → `SBQQ__Quote__c` (which holds the batch) and `NF_USF_Address__c` →
`USF_Address__c`, so the gate is buildable and is now built.

**Fix address validation first.** An unvalidated address is what fails to geocode, so the
geocode gap usually clears with it. An ungeocoded address and a dead polygon both end as a
null `ServiceTerritoryId` and are indistinguishable — split the two populations (RO 28)
before remediating either.

**Open scope question, still unanswered:** is a migrated Order expected to be immediately
Order Ready, or are these validations intentionally completed post-migration? Until that is
answered, "not Order Ready" is reported as a measurement and does not block on its own.

## CJ's WorkOrder error now has an answer path

`SCHEMA.WORKORDER_BUNDLE_FLAGS` at Run Order 2 checks `Is_NHLW__c`, `Is_Power__c`,
`Is_Storage__c`, `Is_Hydroflow__c` and blocks RO 19, 25, 27 and 30. None of the four appear
in the org field snapshot of 2026-09-21, which lists 217 WorkOrder fields — comprehensive
enough that their absence is meaningful, but it predates the error by eleven days.

A describe **cannot** separate *absent from the org* (a deployment gap — no permission
fixes it) from *hidden by FLS* (a permission gap — no deployment needed), because a
restricted profile's describe simply omits an FLS-hidden field. The check says exactly that
and hands over the Apex that settles it in one execution. It does not guess.

## Blind-spot fix: eleven records, with their Ids

Your 2026-10-02 run proved the windowing works — 22,027 WorkOrders, 10,095 BIQs and 2,322
Maintenance Plans all dropped to **zero** in-window. Contracts found a real finding: **11**
Activated Contracts written 2026-10-01→10-03 with a null batch link.

But it displayed as **"1 error"**, because the check returned a one-row summary. It now
returns the actual records, so the count is 11 and you get the Contract Ids to go and look
at. Capped at 200 with the exact count always taken from the aggregate.

## Also

- `runbook.json` re-synced from run book **v42**; it had drifted from the workbook at Run
  Orders 2, 7, 9, 15, 37, 49, 51, 55, 56 and 57.
- The spreadsheet export can build from any stored run, not only the latest.
- ~110 regression tests. `python test_offline.py`.
