﻿import sys
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems

c = systems.build(app.CFG, 'dry', lambda m: None)
sql = """
SELECT Q.ID AS QuoteRow, Q.SalesforceQuoteID, A.Name,
  (SELECT COUNT(*) FROM dbo.SFDC_Quote_Line L WHERE L.SFDC_QuoteId_SBQQ__Quote__c = Q.ID) AS goose_lines,
  (SELECT COUNT(*) FROM dbo.SFDC_Quote_Line L WHERE L.SFDC_QuoteId_SBQQ__Quote__c = Q.ID AND ISNULL(L.SalesforceQuoteLineID,'') = '') AS unsynced_lines
FROM dbo.SFDC_Quote Q LEFT JOIN dbo.SFDC_Account A ON A.ID = Q.SFDC_AccountID_SBQQ__Account__c
WHERE Q.MigrationBatchID = 468 AND A.Name IN ('PAVILION CONSTRUCTION CA INC', 'WALMART INC')
"""
for s in c.goose.result_sets(sql):
    for r in s:
        print(r)
for s in c.goose.result_sets("SELECT TOP 0 * FROM dbo.SFDC_Quote_Line"):
    pass

