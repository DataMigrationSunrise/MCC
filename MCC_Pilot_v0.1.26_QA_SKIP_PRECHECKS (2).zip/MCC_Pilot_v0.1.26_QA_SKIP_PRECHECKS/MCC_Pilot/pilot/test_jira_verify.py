"""Offline test: python -m pilot.test_jira_verify"""
from . import jira_verify as jv


class FakeSF:
    alias = "Sunrise-QA"

    def __init__(self):
        self.q = []

    def query(self, soql, timeout=180):
        self.q.append(soql)
        assert soql.upper().startswith("SELECT")
        if "NF_Placement__c" in soql:
            return [{"Id": "a1"}, {"Id": "a2"}, {"Id": "a3"}, {"Id": "a4"}]
        if "Site_Name__c" in soql:
            return []
        return [{"Id": "x"}]


FIELDS = {
    "NF_Quoted_Jobsite__c": {"NF_Quote__c", "NF_USF_Address__c"},
    "USF_Address__c": {"NF_Placement__c", "NF_Order_Ready__c", "Site_Name__c"},
    "SBQQ__QuoteLine__c": {"SBQQ__OptionType__c"},          # SBQQ__ProductOption__c missing on purpose
}


def describe(obj):
    return {"fields": [{"name": f} for f in FIELDS.get(obj, set())]}


def test_verify_counts_only_loaded_steps_and_gates_on_describe():
    sf = FakeSF()
    steps = [{"id": "TF_20", "status": "DONE"}, {"id": "TF_35", "status": "PENDING"}]
    rep = jv.run(sf, "aFOVD0000001Swj4AE", steps, describe_fn=describe)
    r = rep["results"]
    assert r["PWSTM-401"]["status"] == "CHECKED" and r["PWSTM-401"]["count"] == 4 and r["PWSTM-401"]["examples"] == ["a1", "a2", "a3"]
    assert r["PWSTM-363"]["count"] == 0 and r["PWSTM-318"] is r["PWSTM-363"]
    assert r["PWSTM-356"]["status"] == "NOT_CONFIGURED" and "SBQQ__ProductOption__c" in r["PWSTM-356"]["note"]
    assert r["PWSTM-311"]["status"] == "NOT_LOADED" and r["PWSTM-320"]["status"] == "NOT_LOADED"
    assert all("aFOVD0000001Swj4AE" in q for q in sf.q) and len(sf.q) == 2


if __name__ == "__main__":
    test_verify_counts_only_loaded_steps_and_gates_on_describe()
    print("ok  test_verify_counts_only_loaded_steps_and_gates_on_describe")
