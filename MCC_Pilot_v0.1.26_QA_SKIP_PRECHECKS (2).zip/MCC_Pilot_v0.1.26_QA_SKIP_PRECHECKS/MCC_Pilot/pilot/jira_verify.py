"""Verify in Salesforce: one read-only count per Jira ticket, for steps the batch has already loaded.

Every check names the fields it needs. Before a query runs, those fields are confirmed with a
Salesforce describe; if any is missing the check reports NOT_CONFIGURED instead of guessing.
Nothing here writes to any system.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from . import adapters as ad

LOADED = {"DONE", "PASS", "FIXED", "INFO", "WARNING"}

# where: SOQL filter body (no WHERE). {b} = Salesforce batch Id.
CHECKS = [
    dict(keys=["PWSTM-401"], after="TF_20", obj="NF_Quoted_Jobsite__c",
         label="jobsites with blank Placement or not Order Ready",
         where="NF_Quote__r.USS_Migration_Batch__c = '{b}' AND (NF_USF_Address__r.NF_Placement__c = null "
               "OR NF_USF_Address__r.NF_Order_Ready__c = false)",
         needs=[("NF_Quoted_Jobsite__c", "NF_Quote__c"), ("NF_Quoted_Jobsite__c", "NF_USF_Address__c"),
                ("USF_Address__c", "NF_Placement__c"), ("USF_Address__c", "NF_Order_Ready__c")]),
    dict(keys=["PWSTM-363", "PWSTM-318"], after="TF_20", obj="NF_Quoted_Jobsite__c",
         label="jobsites whose address has a blank Site Name",
         where="NF_Quote__r.USS_Migration_Batch__c = '{b}' AND NF_USF_Address__r.Site_Name__c = null",
         needs=[("NF_Quoted_Jobsite__c", "NF_Quote__c"), ("NF_Quoted_Jobsite__c", "NF_USF_Address__c"),
                ("USF_Address__c", "Site_Name__c")]),
    dict(keys=["PWSTM-356"], after="TF_20", obj="SBQQ__QuoteLine__c",
         label="quote lines loaded as Component whose catalog option is Accessory",
         where="SBQQ__Quote__r.USS_Migration_Batch__c = '{b}' AND SBQQ__OptionType__c = 'Component' "
               "AND SBQQ__ProductOption__r.SBQQ__Type__c = 'Accessory'",
         needs=[("SBQQ__QuoteLine__c", "SBQQ__OptionType__c"), ("SBQQ__QuoteLine__c", "SBQQ__ProductOption__c"),
                ("SBQQ__ProductOption__c", "SBQQ__Type__c")]),
    dict(keys=["PWSTM-311"], after="TF_35", obj="Contract", group_by="Legacy_ID__c",
         label="Legacy IDs with more than one Contract",
         where="SBQQ__Order__r.SBQQ__Quote__r.USS_Migration_Batch__c = '{b}' AND Legacy_ID__c != null",
         needs=[("Contract", "Legacy_ID__c"), ("Contract", "SBQQ__Order__c")]),
    dict(keys=["PWSTM-310"], after="TF_35", obj="Order",
         label="orders with a Delivery work order but no Pickup work order",
         where="SBQQ__Quote__r.USS_Migration_Batch__c = '{b}' "
               "AND Id IN (SELECT Order__c FROM WorkOrder WHERE WorkType.Name LIKE '%Delivery%') "
               "AND Id NOT IN (SELECT Order__c FROM WorkOrder WHERE WorkType.Name LIKE '%Pickup%')",
         needs=[("Order", "SBQQ__Quote__c"), ("WorkOrder", "Order__c"), ("WorkOrder", "WorkTypeId")]),
    dict(keys=["PWSTM-314"], after="TF_60", obj="Contract",
         label="contracts with a blank fuel surcharge %",
         where="SBQQ__Order__r.SBQQ__Quote__r.USS_Migration_Batch__c = '{b}' AND Fuel_Surcharge_Percent__c = null",
         needs=[("Contract", "Fuel_Surcharge_Percent__c"), ("Contract", "SBQQ__Order__c")]),
    dict(keys=["PWSTM-320"], after="TF_60", obj="WorkOrder",
         label="work orders still New whose service appointments are Canceled",
         where="Order__r.SBQQ__Quote__r.USS_Migration_Batch__c = '{b}' AND Status = 'New' "
               "AND Id IN (SELECT ParentRecordId FROM ServiceAppointment WHERE Status = 'Canceled')",
         needs=[("WorkOrder", "Order__c"), ("ServiceAppointment", "ParentRecordId")]),
]


def loaded_steps(steps: list[dict]) -> set:
    return {s.get("id") for s in steps if s.get("status") in LOADED}


class _Describe:
    def __init__(self, sf, describe_fn=None):
        self.sf, self.cache = sf, {}
        self.fn = describe_fn or (lambda obj: ad._sf_json(["sobject", "describe", "--sobject", obj,
                                                           "--target-org", sf.alias], 180))

    def fields(self, obj: str) -> set:
        if obj not in self.cache:
            try:
                self.cache[obj] = {f["name"] for f in (self.fn(obj).get("fields") or [])}
            except Exception:  # noqa: BLE001
                self.cache[obj] = set()
        return self.cache[obj]


def run(sf, batch_sf_id: str, steps: list[dict], describe_fn=None, out_dir: Path | None = None) -> dict:
    if not batch_sf_id:
        raise ValueError("No Salesforce batch Id; start or resume a run first.")
    done = loaded_steps(steps)
    desc = _Describe(sf, describe_fn)
    results = {}
    for chk in CHECKS:
        r = dict(after=chk["after"], label=chk["label"])
        if chk["after"] not in done:
            r.update(status="NOT_LOADED", note="%s has not run for this batch yet" % chk["after"])
        else:
            missing = ["%s.%s" % (o, f) for o, f in chk["needs"] if f not in desc.fields(o)]
            if missing:
                r.update(status="NOT_CONFIGURED", note="Field not found in QA describe: " + ", ".join(missing))
            else:
                where = chk["where"].format(b=batch_sf_id)
                try:
                    if chk.get("group_by"):
                        g = chk["group_by"]
                        soql = "SELECT %s, COUNT(Id) n FROM %s WHERE %s GROUP BY %s HAVING COUNT(Id) > 1" % (
                            g, chk["obj"], where, g)
                        rows = sf.query(soql)
                        r.update(status="CHECKED", count=len(rows), examples=[str(x.get(g)) for x in rows[:3]], soql=soql)
                    else:
                        soql = "SELECT Id FROM %s WHERE %s" % (chk["obj"], where)
                        rows = sf.query(soql + " LIMIT 2000")
                        r.update(status="CHECKED", count=len(rows), examples=[x.get("Id") for x in rows[:3]],
                                 capped=len(rows) >= 2000, soql=soql)
                except Exception as e:  # noqa: BLE001
                    r.update(status="QUERY_FAILED", note=str(e)[:300])
        for k in chk["keys"]:
            results[k] = r
    report = dict(time=datetime.now().isoformat(timespec="seconds"), batch_sf_id=batch_sf_id,
                  loaded=sorted(x for x in done if x), results=results)
    if out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / ("jira_verify_%s.json" % datetime.now().strftime("%Y%m%d_%H%M%S"))).write_text(
            json.dumps(report, indent=1), encoding="utf-8")
    return report
