"""
One page. Buttons at the top, the run book below. Nothing else.

Everything runs from the browser -- no CLI needed.
"""
from __future__ import annotations
import csv, html, io, json, threading, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, quote

import actions
import jobs
import runbook as rbk
import terms
import jobruns
import snapshot as snap
import tally as tal
from runner import TOOL_VERSION

VERSION = TOOL_VERSION


CSS = """
*{box-sizing:border-box}
body{font:13px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#f6f7f9;color:#1a1d21}
header{background:#1F3864;color:#fff;padding:11px 18px;display:flex;align-items:center;gap:14px;
flex-wrap:wrap;position:sticky;top:0;z-index:30}
header h1{font-size:14px;margin:0;font-weight:600;letter-spacing:.2px}
header form{display:flex;gap:7px;align-items:center;margin:0}
select,button{font:12.5px -apple-system,Segoe UI,Roboto,sans-serif}
select{padding:5px 8px;border-radius:6px;border:1px solid #4a6193;background:#fff;min-width:122px}
button{padding:6px 12px;border-radius:6px;border:0;background:#4a7ddb;color:#fff;cursor:pointer;
font-weight:600}
button:hover{background:#5d8ce8}
button.ghost{background:#2c4a7c}
a.btnlink{display:inline-block;background:#2c4a7c;color:#fff;text-decoration:none;font-size:13px;
  font-weight:600;padding:6px 12px;border-radius:6px;margin-left:6px}
a.btnlink:hover{background:#3a5c96}
button[disabled]{background:#5a6b85;cursor:not-allowed}
details.moremenu{position:relative}
details.moremenu>summary{list-style:none;cursor:pointer;background:#2c4a7c;color:#fff;font-size:13px;
  font-weight:600;padding:6px 12px;border-radius:6px}
details.moremenu>summary::-webkit-details-marker{display:none}
a.mmlink{color:#fff;text-decoration:none;font-size:13px;font-weight:600;padding:6px 12px;border-radius:6px;background:#2c4a7c;text-align:center}
details.moremenu .mm{position:absolute;top:34px;left:0;background:#1f3560;padding:8px;border-radius:8px;
  display:flex;flex-direction:column;gap:6px;z-index:40;min-width:150px}
.headline{background:#fff;border:1px solid #e3e6ea;border-left:4px solid #2c4a7c;border-radius:8px;
  padding:11px 15px;margin:0 0 10px;font-size:14px;color:#1a1d21}
.headline.bad{border-left-color:#c0392b}.headline.ok{border-left-color:#2e8b57}
.stp .sub{color:#44505f;font-size:12px;margin:2px 0 10px}
.stp h3{margin:18px 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:.7px;color:#44505f}
details.stg{border:1px solid #e3e6ea;border-left:4px solid #9aa5b1;border-radius:8px;background:#fff;margin:8px 0;padding:0}
details.stg.ok{border-left-color:#2e8b57}details.stg.bad{border-left-color:#c0392b}details.stg.warn{border-left-color:#d9a400}
details.stg>summary{cursor:pointer;padding:9px 13px;list-style:none}
details.stg .st{display:inline-block;min-width:74px;font-size:11px;font-weight:700}
details.stg .sd,details.stg .todo,details.stg .cfgbox{padding:4px 13px 10px;font-size:12.5px;white-space:pre-wrap}
.cfgbox{background:#f6f8fb;border-radius:6px;margin:4px 13px 10px;padding:8px 12px!important}
.cfgform{display:grid;gap:8px;margin-top:6px}
label.sf{display:grid;gap:2px;font-size:12px}label.sf input,label.sf select,label.sf textarea{padding:5px 8px;border:1px solid #c9d1dc;border-radius:6px;font:12.5px inherit}
label.sf small{color:#6b7787}
.headline .hs{font-size:12px;color:#44505f;margin-top:3px}
main{padding:14px 18px 60px}
.hero{background:#fff;border:1px solid #e3e6ea;border-left:5px solid #9C0006;border-radius:8px;
padding:13px 17px;margin-bottom:13px}
.hero.ok{border-left-color:#375623}.hero.idle{border-left-color:#9aa3ad}
.hero .q{font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:.7px}
.hero .a{font-size:18px;font-weight:700;margin-top:3px}
.hero .s{color:#6b7280;font-size:12.5px;margin-top:5px}

/* ---- the run book table: same ten columns as the workbook ---- */
/* The table is its own scrollport, vertically AND horizontally. A sticky <th> is
   positioned against its nearest scroll container, so with overflow-x:auto on this
   wrapper a viewport-relative offset is simply ignored -- which is what put the
   header on top of Run Order 1. top:0 against this scrollport is the correct form. */
.wrap{overflow-y:auto;overflow-x:hidden;max-height:calc(100vh - 196px);background:#fff;
border:1px solid #d5d9df;border-radius:8px}
/* Fixed layout with percentage widths: the table fits ANY viewport instead of forcing a
   1740px horizontal scroll. Every cell wraps or scrolls internally rather than widening. */
table.rb{border-collapse:separate;border-spacing:0;width:100%;table-layout:fixed}
table.rb thead th{background:#1F3864;color:#fff;text-align:left;padding:8px 7px;font-size:11px;
font-weight:600;text-transform:uppercase;letter-spacing:.4px;position:sticky;top:0;z-index:20;
border-right:1px solid #35507e;overflow-wrap:break-word;word-break:normal;
hyphens:none}
table.rb td{padding:8px 7px;border-top:1px solid #e8eaee;border-right:1px solid #f0f2f5;
vertical-align:top;font-size:12.5px}
table.rb tr:hover td{background:#fafbfc}
table.rb tr.blk td{background:#fff8f6}
table.rb tr.blk:hover td{background:#fff1ed}
.c-ro{width:5%;font-weight:700;color:#1F3864;text-align:center}
.c-stage{width:7%;color:#44505f}
.c-act{width:7%}
.c-step{width:14%}
.c-purp{width:18%}
.c-stat{width:7%}
.c-cnt{width:11%}
.c-time{width:10%}
.c-ver{width:10%}
.c-next{width:11%}
table.rb td,table.rb th{overflow-wrap:anywhere;word-break:break-word}
.act{font-size:10px;font-weight:700;letter-spacing:.4px;padding:2px 6px;border-radius:4px;
display:inline-block;background:#eef1f5;color:#44505f;overflow-wrap:anywhere}
.act.VALIDATION{background:#E7EEF9;color:#1F3864}
.act.RUN{background:#EAF3E6;color:#375623}
.act.AUTOMATION{background:#FFF4E0;color:#7a4e00}
.act.FIX{background:#FDE7E7;color:#9C0006}
.act.MANUAL{background:#F1EAF8;color:#53348a}
.stepname{font-weight:600;color:#17212f;word-break:break-word}
.st{font-weight:700;font-size:10.5px;padding:2px 8px;border-radius:11px;display:inline-block;
overflow-wrap:anywhere}
.st.READY{background:#E2EFDA;color:#375623}
.st.BLOCKED{background:#FCE4D6;color:#9C0006}
.st.HELD{background:#FDF0E6;color:#8a4b12}
.st.REVIEW{background:#FFF2CC;color:#7a5c00}
.st small{display:block;font-weight:600;font-size:9.5px;opacity:.8;letter-spacing:.2px}
.gloss{margin:10px 0 0;font-size:12px}
.gloss summary{cursor:pointer;font-weight:700;color:#17212f}
.gloss .gb{padding:8px 2px 2px}
.gloss .gh{margin:9px 0 3px;font-weight:700;color:#55606d;font-size:11px;text-transform:uppercase;
letter-spacing:.4px}
.gloss .gi{display:flex;gap:10px;padding:2px 0}
.gloss .gt{flex:0 0 118px;font-weight:700;color:#17212f}
.st.UNPROVEN{background:#FFF2CC;color:#7a5c00}
.st.NOT{background:#eef1f5;color:#8a919a}
.muted{color:#6b7280;font-size:11.5px}
.tiny{color:#8a919a;font-size:11px}
.num{font-variant-numeric:tabular-nums}
/* One block per check, each number on its own line. Previously several checks' figures
   ran together in one paragraph and could not be read apart. */
.cblk{padding:3px 0}
.cblk + .cblk{border-top:1px dashed #e3e6ea;margin-top:4px;padding-top:5px}
.cblk .ln{display:block;line-height:1.35;font-variant-numeric:tabular-nums}
.cblk .n{font-weight:700}
.cblk .n.ex{color:#1F3864}
.cblk .n.er{color:#9C0006}
.cblk .n.ok{color:#375623}
.cblk .lb{color:#6b7280;font-size:11px}
.cblk .meta{display:block;color:#8a919a;font-size:10.5px;line-height:1.3;margin-top:2px}
.ex{font-weight:700;color:#1F3864}
.er{font-weight:700;color:#9C0006}
.okn{font-weight:700;color:#375623}
.cl{display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;
color:#44505f;font-size:11.5px;line-height:1.45}
details.more>summary{cursor:pointer;color:#4a7ddb;font-size:11px;list-style:none;margin-top:3px}
details.more>summary::-webkit-details-marker{display:none}
details.more[open]>summary{color:#6b7280}
details.more .full{color:#44505f;font-size:11.5px;line-height:1.45;margin-top:4px}
.vpanel{border-left:3px solid #9aa5b1;background:#f7f8fa;padding:6px 9px;margin-top:6px;font-size:13px}
.vpanel.vok{border-color:#2e8b57;background:#f1faf4}.vpanel.vsus{border-color:#d9822b;background:#fff7ee}
.vflag{margin-top:3px}
.isum{font-size:14px;margin:4px 0 8px}
.must{font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;background:#FCE4D6;color:#9C0006}
.rev{font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;background:#FFF2CC;color:#7a5c00}
details.fold{margin-top:10px;border-top:1px solid #eef1f5;padding-top:6px}
details.fold summary{cursor:pointer;font-size:13px;font-weight:600;color:#44505e}
.foldnote{font-size:12px;color:#6b7480;margin:4px 0}
.fl{padding:4px 0;font-size:12.5px}
.eff{font-size:11px;margin-top:3px;font-weight:600}
.eff.und{color:#9a5410}.eff.unk{color:#6b7480}.eff.don{color:#1f6b3f}
a.vb{display:inline-block;padding:1px 7px;border-radius:10px;font-size:12px;font-weight:600;text-decoration:none}
a.vb.ok{background:#e4f5ea;color:#1f6b3f}a.vb.sus{background:#ffecd6;color:#9a5410}
.vstrip{padding:6px 10px;margin:6px 0;border-radius:6px;font-size:13px;background:#f1faf4;border:1px solid #cfe8d8}
.vstrip.vsus{background:#fff7ee;border-color:#f0d3b0}
.fix{background:#f3f7ff;border-left:3px solid #4a7ddb;padding:6px 9px;margin-top:5px;
border-radius:0 5px 5px 0;font-size:11.5px}
.fix b{color:#1F3864}
.up{background:#fff6f4;border-left:3px solid #d98b7a;padding:6px 9px;margin-top:5px;
border-radius:0 5px 5px 0;font-size:11.5px}
.log{background:#11161d;color:#d6e2f0;font:12px/1.5 Consolas,Monaco,monospace;padding:12px 15px;
border-radius:8px;max-height:250px;overflow:auto;white-space:pre-wrap;margin-bottom:13px}
.bar{height:5px;background:#e3e6ea;border-radius:3px;overflow:hidden;margin-top:9px}
.bar i{display:block;height:100%;background:#4a7ddb;transition:width .4s}
.legend{color:#6b7280;font-size:11.5px;margin:9px 2px 0}
.legend b{color:#1a1d21}
header form.snap{margin-left:auto}
header .sl{font-size:11px;text-transform:uppercase;letter-spacing:.6px;opacity:.75}
header form.snap select{min-width:300px}
/* collapsible sections */
details.sec,details.band{border:1px solid #e3e6ea;border-radius:8px;background:#fff;
margin-bottom:12px}
details.sec>summary,details.band>summary{cursor:pointer;list-style:none;padding:11px 15px;
display:flex;align-items:center;gap:10px;flex-wrap:wrap;user-select:none;border-radius:8px}
details.sec>summary::-webkit-details-marker,
details.band>summary::-webkit-details-marker{display:none}
details.sec>summary:hover,details.band>summary:hover{background:#fafbfc}
summary .caret{color:#9aa3ad;font-size:11px;transition:transform .15s;display:inline-block}
details[open]>summary .caret{transform:rotate(90deg)}
summary .ttl{font-size:11px;text-transform:uppercase;letter-spacing:.7px;color:#6b7280;
font-weight:700}
summary .sum{color:#44505f;font-size:12.5px;margin-left:auto;text-align:right}
summary .sum b{color:#1a1d21}
.secbody{padding:0 15px 13px}
/* object band */
.band{background:#fff;border:1px solid #e3e6ea;border-radius:8px;padding:12px 15px 6px;
margin-bottom:12px}
.band h3,.sec h3{margin:0 0 9px;font-size:11px;text-transform:uppercase;letter-spacing:.7px;
color:#6b7280;font-weight:700}
.objs{display:flex;flex-wrap:wrap;gap:7px}
.obj{border:1px solid #e3e6ea;border-radius:7px;padding:7px 10px;min-width:132px;
background:#fcfdfe}
.obj.has{border-color:#e8b9ad;background:#fff8f6}
.fbar{margin:0 0 10px;padding:9px 12px;background:#fff;border:1px solid #e3e6ea;border-radius:8px;
font-size:12px}
.fbar .fg{display:flex;flex-wrap:wrap;align-items:center;gap:5px;margin:3px 0}
.fbar .fl{flex:0 0 62px;font-weight:700;color:#55606d;font-size:11px;text-transform:uppercase;
letter-spacing:.3px}
.fbar button{font:inherit;font-size:12px;padding:3px 10px;border:1px solid #cfd6df;border-radius:14px;
background:#fff;color:#2b3645;cursor:pointer}
.fbar button:hover{border-color:#1F3864}
.fbar button.on{background:#1F3864;border-color:#1F3864;color:#fff;font-weight:600}
.fbar button i{font-style:normal;opacity:.7;margin-left:4px;font-size:11px}
.fbar .fcount{margin-left:auto;color:#55606d}
.fbar .freset{border-style:dashed}
#rbnone{display:none;padding:14px;color:#6b7280;font-size:13px}
a.obj{display:block;text-decoration:none;color:inherit;cursor:pointer}
a.obj:hover{border-color:#1F3864;box-shadow:0 1px 4px rgba(31,56,100,.18)}
.ob-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:12px 0}
.ob-grid .k{font-size:11px;color:#6b7280}
.ob-grid .v{font-size:19px;font-weight:700;color:#1F3864;font-variant-numeric:tabular-nums}
.ob-grid .v.er{color:#9C0006}
.ob-grid>div{border:1px solid #e3e6ea;border-radius:7px;padding:8px 11px}
.cancan{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:10px}
@media(max-width:800px){.cancan{grid-template-columns:1fr}}
.cancan h3{margin:0 0 4px;font-size:13px}
.cancan ul{margin:0;padding-left:18px;font-size:12.5px;line-height:1.5}
.qlabel{font-size:11.5px;font-weight:700;color:#44505f;margin:10px 0 3px}
pre.q{background:#f4f6f9;border:1px solid #e3e6ea;border-radius:6px;padding:8px 10px;
font-size:11.5px;white-space:pre-wrap;word-break:break-word;margin:0}
.obj.pend{opacity:.55;background:#f7f8fa}
.obj .on{font-size:11px;color:#44505f;font-weight:600;white-space:nowrap}
.obj .ov{font-size:17px;font-weight:700;color:#1F3864;font-variant-numeric:tabular-nums;
margin-top:1px}
.obj .oe{font-size:11px;font-weight:700;color:#9C0006}
.obj .ok2{font-size:11px;color:#6b7280}
.band .tot{margin-top:9px;font-size:12px;color:#44505f}
.band .tot b{color:#1a1d21}
/* issue summary */
.sec{background:#fff;border:1px solid #e3e6ea;border-radius:8px;padding:12px 15px;
margin-bottom:12px}
.pill{display:inline-block;padding:2px 9px;border-radius:11px;font-size:11px;font-weight:700;
margin-right:6px}
.pill.b{background:#FCE4D6;color:#9C0006}
.pill.w{background:#FFF2CC;color:#7a5c00}
.pill.u{background:#eef1f5;color:#55606d}
table.iss{border-collapse:collapse;width:100%;margin-top:9px}
table.iss th{text-align:left;font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;
color:#6b7280;padding:5px 8px;border-bottom:1px solid #e3e6ea}
table.iss td{padding:6px 8px;border-bottom:1px solid #f2f4f6;font-size:12.5px;
vertical-align:top}
table.iss tr:last-child td{border-bottom:0}
.sev{font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;white-space:nowrap}
.sev.BLOCKER{background:#FCE4D6;color:#9C0006}
.sev.WARNING{background:#FFF2CC;color:#7a5c00}
.sev.REVIEW{background:#FFF2CC;color:#7a5c00}
.sev.INFO{background:#eef1f5;color:#55606d}
.sev.UNPROVEN{background:#eef1f5;color:#55606d}
/* record drill-down */
.rec{background:#fff;border:1px solid #e3e6ea;border-radius:8px;padding:14px 17px;
margin-bottom:12px}
.rec h2{margin:0 0 3px;font-size:17px;color:#17212f}
.rec .sub{color:#6b7280;font-size:12.5px;margin-bottom:9px}
.rec .why{background:#fff8f6;border-left:3px solid #d98b7a;padding:8px 11px;border-radius:0 5px 5px 0;
margin:8px 0;font-size:12.5px}
.rec .cap{background:#FFF2CC;border:1px solid #e0c97a;color:#5c4600;padding:8px 11px;
border-radius:6px;margin:8px 0;font-size:12.5px}
table.recs{border-collapse:collapse;width:100%;margin-top:10px;font-size:12.5px}
table.recs th{background:#1F3864;color:#fff;text-align:left;padding:7px 9px;font-size:10.5px;
text-transform:uppercase;letter-spacing:.4px;position:sticky;top:0}
table.recs td{padding:6px 9px;border-top:1px solid #eef0f3;vertical-align:top;
font-family:Consolas,Monaco,monospace;font-size:12px;white-space:nowrap}
table.recs tr:hover td{background:#fafbfc}
.recwrap{max-height:62vh;overflow:auto;border:1px solid #e3e6ea;border-radius:7px}
a.back{color:#4a7ddb;text-decoration:none;font-size:12.5px}
a.drill{color:#4a7ddb;text-decoration:none;font-weight:600;white-space:nowrap}
a.sfid{color:#1F3864;text-decoration:none;border-bottom:1px dotted #9fb6dd}
a.sfid:hover{color:#4a7ddb;border-bottom-style:solid}
a.drill:hover{text-decoration:underline}
/* current step */
.cur{background:#1F3864;color:#fff;border-radius:8px;padding:13px 17px;margin-bottom:12px}
.cur .q{font-size:10.5px;text-transform:uppercase;letter-spacing:.8px;opacity:.72}
.cur .a{font-size:17px;font-weight:700;margin-top:3px}
.cur .s{font-size:12.5px;opacity:.82;margin-top:4px}
.cur .ro{display:inline-block;background:#4a7ddb;border-radius:5px;padding:1px 8px;
margin-right:8px;font-weight:700}
.cur .jobs{margin-top:10px;border-top:1px solid rgba(255,255,255,.18);padding-top:9px}
.cur .jl{display:flex;gap:12px;align-items:baseline;font-size:12.5px;padding:2px 0}
.cur .jl .k{opacity:.65;min-width:128px;font-size:11px;text-transform:uppercase;
letter-spacing:.5px}
.cur .jl .v{opacity:.95}
.jbar{display:inline-block;width:120px;height:5px;background:rgba(255,255,255,.22);
border-radius:3px;margin-left:10px;vertical-align:middle;overflow:hidden}
.jbar i{display:block;height:100%;background:#8ab4f8}
.ph{font-size:9.5px;font-weight:700;padding:1px 5px;border-radius:3px;margin-left:6px;
white-space:nowrap}
.ph.PREDICTED{background:#E7EEF9;color:#1F3864}
.ph.NOT{background:#eef1f5;color:#8a919a}
/* No cell may stretch its row. Everything past the cap scrolls inside the cell. */
.clamp{max-height:190px;overflow:auto}
table.rb td{max-width:0}
.stale{background:#FFF2CC;border:1px solid #e0c97a;border-left:5px solid #7a5c00;
color:#5c4600;padding:10px 15px;border-radius:8px;margin-bottom:12px;font-size:13px}
"""


def _esc(x):
    return html.escape(str(x if x is not None else ""))


# Collapse state survives a reload. The page redirects after every button press, so
# without this a section you minimised springs open again on the next action. Wrapped in
# try/catch because a browser with site data blocked throws on access rather than
# returning null, and a dashboard must not go blank over a remembered preference.
KEEP_OPEN_JS = """
<script>
(function () {
  var KEY = 'pm.collapsed.v1';
  function load() {
    try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; }
    catch (e) { return {}; }
  }
  function save(state) {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
  }
  var state = load();
  var secs = document.querySelectorAll('details.sec[id], details.band[id]');
  for (var i = 0; i < secs.length; i++) {
    (function (d) {
      if (state[d.id] === true) { d.removeAttribute('open'); }
      else if (state[d.id] === false) { d.setAttribute('open', ''); }
      d.addEventListener('toggle', function () {
        state = load();
        state[d.id] = !d.open;      // store COLLAPSED, so a new section defaults to open
        save(state);
      });
    })(secs[i]);
  }
})();
</script>
"""


def page(body, refresh=0):
    meta = '<meta http-equiv="refresh" content="%d">' % refresh if refresh else ""
    return ("<!doctype html><html><head><meta charset='utf-8'>%s"
            "<title>MCC - Preflight Monitoring Tool</title><style>%s</style></head><body>%s%s</body></html>"
            % (meta, CSS, body, KEEP_OPEN_JS))


def header(cfg, store, batch, run=""):
    """
    The dropdown ALWAYS shows every known batch. KnownBatches in config.json is the
    offline list; anything discovered from Salesforce is merged in on top. This must not
    depend on a working connection -- you need to pick a batch before you can check one.
    """
    names = list(cfg.get("KnownBatches") or [])
    for b in store.batches():
        if b["name"] not in names:
            names.append(b["name"])
    d = cfg.get("DefaultBatch", "")
    if d and d not in names:
        names.append(d)
    if batch and batch not in names:
        names.append(batch)
    names = sorted({n for n in names if n}, reverse=True)
    opts = "".join('<option%s>%s</option>' % (" selected" if n == batch else "", _esc(n))
                   for n in names if n)
    busy = jobs.running()
    dis = " disabled" if busy else ""
    return (("<header><h1>MCC - 🔅 Preflight Monitoring Tool <span style='opacity:.55;font-weight:400;"
             "font-size:11px'>v%s</span></h1>" % VERSION) +
            "<form method='post' action='/run'>"
            "<select name='batch'>%s</select>"
            "<button name='what' value='gate'%s>Run checks</button>"
            "<details class='moremenu'><summary>More</summary><div class='mm'>"
            "<a class='mmlink' href='/selftest'>Self-test results</a>"
            "<button class='ghost' name='what' value='populate'%s>Load all batches</button>"
            "<button class='ghost' name='what' value='batches'%s>Find batches</button>"
            "<button class='ghost' name='what' value='selftest'%s>Self-test</button>"
            "<button class='ghost' name='what' value='report'%s>Spreadsheet</button>"
            "</div></details>"
            "<a class='btnlink' href='/runbook.xlsx?run=%s&batch=%s' "
            "title='Download the run book for the selected batch: Informatica / SnapLogic steps "
            "on one sheet, your own steps on another'>Export run book</a>"
            "<a class='btnlink' href='/issues.xlsx?run=%s&batch=%s' "
            "title='Every issue found in the selected run: one tab per issue, headed by its run book "
            "step, listing each record that had it'>Export issues</a>"
            "</form>%s</header>" % (opts, dis, dis, dis, dis, dis,
                                    _esc(run or store.latest_run_id(batch) or ""),
                                    _esc(quote(batch or "")),
                                    _esc(run or store.latest_run_id(batch) or ""),
                                    _esc(quote(batch or "")), snapbar(store, batch, run)))


def snapbar(store, batch, run_id=""):
    """
    Pick any run already stored and view it WITHOUT querying anything.

    Every run was always saved; there was just no way to ask for one, so the tool
    re-queried Salesforce to show you something it already had on disk.
    """
    runs = snap.list_runs(store, batch, limit=40)
    if not runs:
        return ""
    cur = run_id or (runs[0]["run_id"] if runs else "")
    opts = []
    for i, r in enumerate(runs):
        when = str(r["started"] or "").replace("T", " ")[:16]
        label = "%s  %s  %d failing check(s) / %d unproven%s%s" % (
            when, r["batch"], r["failed"], r["unproven"],
            "  [imported]" if r["imported"] else "",
            "  (latest)" if i == 0 else "")
        opts.append("<option value='%s'%s>%s</option>"
                    % (_esc(r["run_id"]), " selected" if r["run_id"] == cur else "",
                       _esc(label)))
    return ("<form method='post' action='/run' class='snap'>"
            "<span class='sl'>Snapshot</span>"
            "<select name='run'>%s</select>"
            "<button name='what' value='view'>View</button>"
            "<button class='ghost' name='what' value='save_snap'>Save</button>"
            "<button class='ghost' name='what' value='load_snap'>Load file</button>"
            "<input type='hidden' name='batch' value='%s'>"
            "</form>" % ("".join(opts), _esc(batch)))


def _run_age_hours(store, run_id):
    """How long ago this run finished, in hours. None when it cannot be established."""
    if not run_id:
        return None
    info = snap.describe(store, run_id) or {}
    stamp = str(info.get("finished") or info.get("started") or "")
    if not stamp:
        return None
    from datetime import datetime, timezone
    try:
        t = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    except ValueError:
        return None
    if t.tzinfo is None:
        t = t.replace(tzinfo=timezone.utc)
    return max(0.0, (datetime.now(timezone.utc) - t).total_seconds() / 3600.0)


def _age_words(h):
    if h < 1:
        return "%d minutes" % max(1, int(h * 60))
    if h < 48:
        return "%d hour%s" % (int(h), "" if int(h) == 1 else "s")
    return "%d days" % int(h / 24)


def hero_and_log(store, batch, run_id=""):
    j = jobs.JOB
    out = []
    if j.state == "RUNNING":
        out.append("<div class='hero idle'><div class='q'>%s</div><div class='a'>%s</div>"
                   "<div class='bar'><i style='width:%d%%'></i></div></div>"
                   % (_esc(j.name), _esc(j.message)[:120], j.percent))
        out.append("<div class='log'>%s</div>" % _esc("\n".join(j.log[-25:])))
        return "".join(out), True, 0

    if j.state == "FAILED":
        out.append("<div class='hero'><div class='q'>%s failed</div><div class='a'>%s</div></div>"
                   % (_esc(j.name), _esc(j.error)[:200]))
        out.append("<div class='log'>%s</div>" % _esc("\n".join(j.log[-25:])))

    rows = rbk.readiness(store, batch, run_id)
    if not (run_id or store.latest_run_id(batch)):
        out.append("<div class='hero idle'><div class='q'>No results yet</div>"
                   "<div class='a'>Pick a batch and press Run checks</div>"
                   "<div class='s'>New environment? Open More &gt; Self-test results first.</div></div>")
        return "".join(out), False, 0

    s = rbk.summary(rows)

    # Compute the issue list ONCE, up front. The headline and the issue table below it
    # must quote the same number -- two panels on one screen disagreeing by two records is
    # exactly how a dashboard stops being believed.
    rid = run_id or store.latest_run_id(batch)
    trows = store.tally(rid) if rid else []
    pending = {r["sobject"] for r in trows if r.get("pending")}
    items = rbk.issues(store, batch, run_id, rows, pending)
    ism = rbk.issue_summary(items, rbk.ids_of_factory(store, rid) if rid else None)

    # A stored run is never presented as the current state of the org. An IMPORTED run is
    # flagged even when it is the newest run HERE, because newest on this machine says
    # nothing about how old it is or which org produced it.
    # A run only describes the org AT THE MOMENT IT RAN. On 2026-10-02 a 13:11 run reported
    # clean zeros on Service Appointments that did not exist until 14:16 -- the run was not
    # wrong, it was OLD, and nothing on screen said so. Age is now stated whenever it
    # matters, because a stale clean result is the most dangerous thing this tool can show.
    latest_id = store.latest_run_id(batch)
    age_h = _run_age_hours(store, run_id or latest_id)
    if age_h is not None and age_h >= 0.5 and (not run_id or run_id == latest_id):
        out.append("<div class='stale'><b>These results are %s old.</b> They describe the org "
                   "as it was when the checks ran, not as it is now. Anything created or "
                   "changed since is not reflected &mdash; a clean result here is only as "
                   "current as the run. Press <b>Run checks</b> to measure the org now.</div>"
                   % _esc(_age_words(age_h)))

    if run_id:
        info = snap.describe(store, run_id) or {}
        imported = str(info.get("mode") or "").startswith("IMPORT")
        if run_id != latest_id or imported:
            out.append("<div class='stale'><b>Viewing a stored snapshot</b> from %s &mdash; "
                       "nothing was queried to show this. It is evidence of that moment, not "
                       "the current state of the org.%s Press <b>Run checks</b> to measure "
                       "the org now.</div>"
                       % (_esc(str(info.get("started") or "").replace("T", " ")[:16]),
                          " <b>Imported from another machine</b> &mdash; it did not come from "
                          "this org or this session." if imported else ""))
    # The "How far can X advance / Blocked at Run Order N" banner used to sit here. It
    # restated what the Current step section and the All issues counts already say, and
    # its "Blocked at Run Order 2" headline put a pre-flight validation in front of a
    # batch whose work had reached Run Order 40.

    # Order matters: what landed, then where we are, then every issue in one list,
    # then the run book itself.
    cur_html, cur = current_step(rows)
    out.append(headline(rows, ism))
    out.append(object_band(store, rid, ism))
    out.append(cur_html)
    out.append(issues_section(store, batch, run_id, rows, pending, items, ism))
    return "".join(out), False, cur


def _clamp(text, limit=240):
    """Long run-book prose, clamped to four lines with the full text one click away."""
    t = str(text or "").strip()
    if not t:
        return "<span class='tiny'>&mdash;</span>"
    if len(t) <= limit:
        return "<div class='cl'>%s</div>" % _esc(t)
    return ("<div class='cl'>%s</div><details class='more'><summary>show all</summary>"
            "<div class='full'>%s</div></details>" % (_esc(t[:limit].rstrip() + "\u2026"), _esc(t)))


def _action_cls(action):
    a = str(action or "").upper()
    for key in ("AUTOMATION", "VALIDATION", "MANUAL", "FIX"):
        if key in a:
            return key
    return "RUN" if "RUN" in a else ""


def _count_cell(r):
    """
    Record Count / Result -- one block per check, each number on its own line.

    EXAMINED and ERRORS are shown separately, always, because the single "Records" column
    they replace could not say which it meant. Several checks on one step each get their
    own block with a divider; previously their figures ran together in one paragraph and
    could not be told apart.
    """
    if r["state"] in ("NOT CHECKED", "NOT RUN") and not r["counts"]:
        return "<span class='tiny'>&mdash;</span>"
    blocks = []
    for c in r["counts"]:
        ex, er = c["examined"], c["errors"]
        lines = []
        if c["verdict"] == "UNPROVEN":
            lines.append("<span class='ln lb'>not established</span>")
        elif c["inverted"]:
            # presence check: the rows ARE the population, so "errors" is meaningless
            lines.append("<span class='ln'><span class='n %s'>%s</span> "
                         "<span class='lb'>found</span></span>"
                         % ("ok" if ex else "er", "{:,}".format(ex)))
        else:
            if ex:
                lines.append("<span class='ln'><span class='n ex'>%s</span> "
                             "<span class='lb'>examined</span></span>" % "{:,}".format(ex))
            if er:
                lines.append("<span class='ln'><span class='n er'>%s</span> "
                             "<span class='lb'>%s</span></span>"
                             % ("{:,}".format(er),
                                "failing" if c.get("record", True) else _esc(c.get("unit_many", "items"))))
            elif ex:
                lines.append("<span class='ln'><span class='n ok'>0</span> "
                             "<span class='lb'>failing</span></span>")
            elif not lines:
                lines.append("<span class='ln lb'>no population</span>")
        if c["metric_unit"] == "ratio" and c["metric_den"]:
            lines.append("<span class='meta'>%.0f%% %s</span>"
                         % (float(c["metric_value"] or 0) * 100, _esc(str(c["metric"])[:40])))
        blocks.append("<div class='cblk'>%s</div>" % "".join(lines))
    if r["held"] > r["errors"]:
        blocks.append("<div class='cblk'><span class='ln lb'>+%s held back by a blocker "
                      "elsewhere</span></div>" % "{:,}".format(r["held"] - r["errors"]))
    return "".join(blocks)


def _time_cell(r):
    """
    When the work RAN -- not when we checked it.

    An orchestrator's own start/end/status is authoritative and labelled with the system
    that reported it. Record stamps are a proxy and say so, because a step that ran and
    wrote nothing leaves no stamps at all.
    """
    if not r["times"]:
        return "<span class='tiny'>&mdash;</span>"
    seen, bits = set(), []
    for t in r["times"]:
        win = jobruns.pretty(t["frm"], t["to"])
        key = (win, t["status"], t["source"][:28])
        if key in seen:
            continue
        seen.add(key)
        line = "<span class='num'>%s</span>" % _esc(win or "\u2014")
        if t["status"]:
            line += " <b class='tiny'>%s</b>" % _esc(t["status"])
        if t["source"]:
            line += "<br><span class='tiny'>%s</span>" % _esc(t["source"][:70])
        bits.append(line)
    return "<br>".join(bits)


def _next_cell(r):
    """Next Action / Blocker: what is live right now, then the run book's own note."""
    bits = []
    for f in r["failing"]:
        link = ("" if not f["rows"] else
                " <a class='drill' href='/records?check=%s&run=%s&batch=%s'>see records &rsaquo;</a>"
                % (_esc(f["check"]), _esc(_RUN.get("id", "")), _esc(_RUN.get("batch", ""))))
        absent = (str(f["check"]).startswith("RAN.") and not f["examined"]
                  and f["rows"] <= 2 and not f["inverted"])
        head = ("<b>%s</b> &mdash; %s%s"
                % (_esc(f["name"]),
                   "none produced" if absent else
                   ("found none" if f["inverted"] else
                    ("%d failing record(s)" % f["rows"]) if f.get("record", True)
                    else ("%d %s" % (f["rows"], _esc(f.get("unit_many", "items"))))), link))
        bits.append(head + "<br><span class='muted'>%s</span>" % _esc(f["reason"][:220]))
        if f["fix"]:
            bits.append("<div class='fix'><b>Fix at RO %s:</b> %s</div>"
                        % (f["fix_order"] or "?", _esc(f["fix"])))
    for b in r["blocked_by"]:
        bits.append("<div class='up'>Held by <b>RO %s</b> &mdash; %s (%d row(s))</div>"
                    % (b["at"], _esc(b["name"]), b["rows"]))
    # Several checks on one step often fail for the identical reason. Printing it four
    # times is noise -- collapse to one line that says how many.
    seen = {}
    for u in r["unproven"]:
        key = u["reason"][:200]
        seen[key] = seen.get(key, 0) + 1
    for reason, n in seen.items():
        bits.append("<span class='muted'>unproven%s &mdash; %s</span>"
                    % ((" (%d checks)" % n) if n > 1 else "", _esc(reason)))
    if r["blocker"]:
        bits.append("<details class='more'><summary>run book note</summary>"
                    "<div class='full'>%s</div></details>" % _esc(r["blocker"]))
    if not bits:
        return "<span class='tiny'>&mdash;</span>"
    # Capped, with the rest one click away. Uncapped, a single long run-book note stretched
    # its row to several hundred pixels of mostly whitespace and pushed the table apart.
    body = "<br>".join(bits)
    return "<div class='clamp'>%s</div>" % body


def object_band(store, run_id, ism=None):
    """
    What actually landed, per Salesforce object, in migration order.

    Two numbers that are NOT the same thing: how many records of that object belong to
    this batch, and how many of them a check found wrong. An object whose load step has
    not run yet is dimmed and contributes ZERO errors -- counting an unstarted load as a
    failure made every early run look like a disaster.
    """
    rows = store.tally(run_id) if run_id else []
    if not rows:
        return ""
    t = tal.totals(rows)
    cards = []
    for r in rows:
        if r["state"] == "UNSCOPED":
            cards.append("<a class='obj pend' href='%s'><div class='on'>%s</div>"
                         "<div class='ok2'>no batch path</div></a>"
                         % (_obj_href(r, store, run_id), _esc(r["label"])))
            continue
        if r["state"] == "ERROR":
            cards.append("<a class='obj pend' href='%s'><div class='on'>%s</div>"
                         "<div class='ok2'>query failed</div></a>"
                         % (_obj_href(r, store, run_id), _esc(r["label"])))
            continue
        pend = bool(r.get("pending"))
        err = int(r["errors"] or 0)
        cls = "obj pend" if pend else ("obj has" if err else "obj")
        over = (not pend) and err > int(r["loaded"] or 0)
        tailtxt = ("<div class='ok2'>not loaded yet</div>" if pend else
                   ("<div class='oe' %s>%s failing%s</div>"
                    % (("title='More failing than loaded: some of these records are outside this "
                        "batch&#39;s count, so this number cannot be read as a share of the tile.'"
                        if over else ""), "{:,}".format(err), " &#9888;" if over else "") if err
                    else "<div class='ok2'>0 failing</div>"))
        cards.append("<a class='%s' href='%s' title='Click for what is behind this number'>"
                     "<div class='on'>%s</div><div class='ov'>%s</div>%s</a>"
                     % (cls, _obj_href(r, store, run_id), _esc(r["label"]),
                        "{:,}".format(int(r["loaded"] or 0)), tailtxt))
    # The band's error figure must match the headline. Checks on objects that are not
    # migration RECORDS -- dead map polygons live on ServiceTerritory -- have no card here,
    # so counting only the cards under-reported by exactly those. Report the authoritative
    # total and say how many sit outside the cards, rather than quietly disagreeing.
    total_err = int((ism or {}).get("records", t["errors"]))
    off_card = max(0, total_err - t["errors"])
    return ("<details class='band' id='sec-band'><summary>"
            "<span class='caret'>&#9654;</span>"
            "<span class='ttl'>Records in Salesforce for this batch</span>"
            "<span class='sum'><b>%s</b> record(s) &middot; <b>%s</b> failing record(s)</span>"
            "</summary><div class='secbody'>"
            "<div class='objs'>%s</div>"
            "<div class='tot'><b>%s</b> record(s) across <b>%d</b> object(s) &middot; "
            "<b>%s</b> failing record(s)%s%s%s. Objects whose load step has not run are dimmed "
            "and count zero failing records.</div></div></details>"
            % ("{:,}".format(t["loaded"]), "{:,}".format(total_err),
               "".join(cards), "{:,}".format(t["loaded"]), t["objects"],
               "{:,}".format(total_err),
               " &middot; %s of them on org-wide infrastructure with no card above "
               "(dead map polygons)" % "{:,}".format(off_card) if off_card else "",
               " &middot; %d object(s) not loaded yet" % t["pending"] if t["pending"] else "",
               " &middot; %d loaded but empty" % t["empty_but_due"] if t["empty_but_due"] else ""))


def _vbadge(v, run_id, batch, check_id):
    """One small tag per issue: was this number checked against Salesforce, and did it hold up."""
    if not v:
        return "<span class='muted'>&mdash;</span>"
    import verify
    flags = [f for f in (v.get("flags") or []) if f["code"] in verify.SUSPECT_CODES]
    href = "/records?check=%s&run=%s&batch=%s" % (_esc(check_id), _esc(run_id or ""), _esc(batch))
    if flags:
        tip = _esc(" | ".join(verify.LABEL.get(f["code"], f["code"]) for f in flags))
        return ("<a class='vb sus' href='%s' title='%s'>&#9888; caution</a><div class='muted'>%s</div>"
                % (href, tip, _esc(verify.LABEL.get(flags[0]["code"], ""))
                   + (" +%d more" % (len(flags) - 1) if len(flags) > 1 else "")))
    if v.get("status") == "VERIFIED":
        n = sum(1 for x in v.get("samples") or [] if x.get("found"))
        return ("<a class='vb ok' href='%s' title='%d sample record(s) re-read from Salesforce'>"
                "&#10003; verified</a>" % (href, n))
    return "<span class='muted' title='Checked: nothing wrong found, nothing to confirm'>checked</span>"


def issues_section(store, batch, run_id, rows, pending_objects, items=None, sm=None):
    """
    REAL ISSUES FOR THIS BATCH, and nothing else in the main list.

    A row appears here only if it is (1) a finding about Salesforce RECORDS, (2) about this
    batch (not an org-wide count), (3) on a step the load has reached, and (4) not contradicted
    by the verification pass. Everything that failed one of those tests is still available, but
    folded away under a plain heading that says why it is not in the main list. The same record
    flagged by two checks is one row.
    """
    import verify
    items = items if items is not None else rbk.issues(store, batch, run_id, rows, pending_objects)
    rid = run_id or store.latest_run_id(batch)
    try:
        vs = store.verification(rid) if rid else {}
    except Exception:                                        # noqa: BLE001
        vs = {}
    ids_of = rbk.ids_of_factory(store, rid) if rid else None
    real, unsure, other, later, unproven = [], [], [], [], []
    for i in items:
        if i["kind"] == "UNPROVEN":
            unproven.append(i); continue
        if i.get("phase") in (rbk.PHASE_PREDICTED, rbk.PHASE_NOT_YET):
            later.append(i); continue
        if not i.get("is_record", True) or i["severity"] == "INFO":
            other.append(i); continue
        v = vs.get(i["check"]) or {}
        why = [f for f in (v.get("flags") or []) if f["code"] in verify.SUSPECT_CODES]
        if why:
            i = dict(i, why=why); unsure.append(i); continue
        real.append(i)

    # one row per set of records: a record flagged by two checks is one problem
    kept = []
    for i in real:
        ids = ids_of(i["check"]) if ids_of else None
        dup = next((k for k in kept if ids and k["_ids"] and ids <= k["_ids"]), None)
        if dup is not None:
            dup["also"].append(i["name"]); continue
        kept.append(dict(i, _ids=ids, also=[]))
    real = kept

    if not (real or unsure or other or later or unproven):
        return ("<details class='sec' id='sec-issues' open><summary>"
                "<span class='caret'>&#9654;</span><span class='ttl'>Issues</span>"
                "<span class='sum'><b>none</b></span></summary>"
                "<div class='secbody'><span class='muted'>No issues and nothing "
                "unproven.</span></div></details>")

    sm_real = rbk.issue_summary(real, ids_of)
    must = len([i for i in real if i["severity"] == "BLOCKER"])
    if real:
        head = ("<div class='isum'><b>%d</b> real issue%s in %s &mdash; <b>%s</b> record%s need a fix"
                "%s.</div>" % (len(real), "" if len(real) == 1 else "s", _esc(batch),
                               "{:,}".format(sm_real["records"]), "" if sm_real["records"] == 1 else "s",
                               (" (<b>%d</b> must be fixed before moving on)" % must) if must else ""))
    else:
        head = "<div class='isum'><b>No confirmed issues</b> in %s.</div>" % _esc(batch)

    tr = ["<table class='iss'><tr><th style='width:52px'>Step</th><th>What is wrong</th>"
          "<th style='width:104px'>Records</th>%s<th>What to do</th></tr>"
          % ("<th style='width:104px' title='Checked against Salesforce'>Checked</th>" if vs else "")]
    for i in real:
        rec = ("%s of %s" % ("{:,}".format(i["records"]), "{:,}".format(i["examined"]))
               if i["examined"] else "{:,}".format(i["records"]))
        if i["inverted"]:
            rec = "none found"
        if i["records"]:
            rec = ("<a class='drill' href='/records?check=%s&run=%s&batch=%s'>%s &rsaquo;</a>"
                   % (_esc(i["check"]), _esc(rid or ""), _esc(batch), rec))
        fix = ("%s" % _esc(i["fix"])) if i["fix"] else "<span class='muted'>%s</span>" % _esc(i["reason"][:150])
        tag = ("<span class='must'>MUST FIX</span> " if i["severity"] == "BLOCKER"
               else "<span class='rev'>REVIEW</span> ")
        also = ("<div class='muted'>same records also flagged by: %s</div>"
                % _esc("; ".join(i["also"]))) if i["also"] else ""
        tr.append("<tr><td class='ro'>RO %d</td><td>%s<b>%s</b>%s</td><td class='num'>%s</td>%s"
                  "<td>%s</td></tr>"
                  % (i["order"], tag, _esc(i["name"]), also, rec,
                     ("<td>%s</td>" % _vbadge(vs.get(i["check"]), rid, batch, i["check"])) if vs else "",
                     fix))
    tr.append("</table>")
    body = [head, "".join(tr) if real else ""]

    def fold(title, note, lines):
        if not lines:
            return ""
        return ("<details class='fold'><summary>%s <span class='muted'>(%d)</span></summary>"
                "<div class='foldnote'>%s</div>%s</details>" % (title, len(lines), note, "".join(lines)))

    def line(i, extra=""):
        gone = (str(i["check"]).startswith("RAN.") and not i["examined"] and i["records"] <= 2
                and not i["inverted"])
        n = ("produced nothing" if gone else
             ("%s %s" % ("{:,}".format(i["records"]), _esc(i.get("unit_many", "items")))
              if i["records"] else ""))
        return ("<div class='fl'><b>%s</b> <span class='muted'>RO %d%s</span>%s</div>"
                % (_esc(i["name"]), i["order"], (" &middot; " + n) if n else "", extra))

    body.append(fold("Not about this batch, or not confirmed",
        "The tool found something, but it could not be tied to this batch or did not hold up when "
        "re-checked against Salesforce, so it is not counted above.",
        [line(i, "<div class='muted'>%s</div>" % _esc("; ".join(
            "%s: %s" % (verify.LABEL.get(f["code"], f["code"]), f.get("text", "")[:170]) for f in i["why"][:2])))
         for i in unsure]))
    body.append(fold("Other signals",
        "Jobs, log entries and staged rows. These are not Salesforce records, so they are not counted as issues.",
        [line(i, "<div class='muted'>%s</div>" % _esc(i["reason"][:200])) for i in other]))
    body.append(fold("Will matter later",
        "Found in data that is loaded, but on a step the load has not reached yet. Free to fix now.",
        [line(i) for i in later]))
    seen = {}
    for i in unproven:
        seen.setdefault(i["reason"][:150], []).append(i["name"])
    body.append(fold("Could not be checked",
        "These checks could not run, so nothing is known either way. Not a pass.",
        ["<div class='fl'><b>%s</b><div class='muted'>%s</div></div>"
         % (_esc("; ".join(names)), _esc(r)) for r, names in seen.items()]))
    return ("<details class='sec' id='sec-issues' open><summary>"
            "<span class='caret'>&#9654;</span><span class='ttl'>Issues in this batch</span>"
            "<span class='sum'><b>%d</b> real &middot; <b>%d</b> must fix</span></summary>"
            "<div class='secbody'>%s</div></details>" % (len(real), must, "".join(body)))



def _state_note(r) -> str:
    """Say WHY a step cannot be passed, and whether it has already run.

    BLOCKED and HELD both mean 'stop', but they send you to different places: a blocked step
    is fixed where it is, a held one is fixed at the step named under it. A step that has
    already run and is stopped is a finding about work that happened, not a gate in front of
    work that has not.
    """
    eff = (r.get("effect") or {}).get("state", "")
    etag = ""
    if eff == "UNDONE":
        etag = ("<div class='eff und' title='%s'>work still undone &mdash; step skipped or not "
                "finished</div>" % _esc("Checked by: " + ", ".join(c for c, _ in r["effect"]["checks"])))
    elif eff == "UNKNOWN":
        etag = ("<div class='eff unk' title='%s'>cannot confirm the work was done</div>"
                % _esc("Checked by: " + ", ".join(c for c, _ in r["effect"]["checks"])))
    elif eff == "DONE":
        etag = ("<div class='eff don' title='%s'>nothing left for this step to do</div>"
                % _esc("Checked by: " + ", ".join(c for c, _ in r["effect"]["checks"])))
    if r["state"] not in ("BLOCKED", "HELD"):
        return etag
    bits = []
    if r["state"] == "HELD":
        bits.append("fix elsewhere")
    if r.get("ran"):
        bits.append("job already ran")
    return ("<small>%s</small>" % " &middot; ".join(bits) if bits else "") + etag


def headline(rows, ism=None):
    """One plain sentence: where the batch stopped (or that it is clear), and how many real
    problems. Everything it summarises is still shown below; this only says it first."""
    pr = rbk.progress(rows)
    if not pr.get("current"):
        return ""
    recs = int((ism or {}).get("records", 0) or 0)
    ba = pr.get("blocked_at")
    if ba:
        first = "Stopped at <b>RO %d</b>" % ba
        cls = "bad"
    elif recs:
        first = "No step is blocked, but records are failing"
        cls = "bad"
    else:
        first = "Clear through <b>RO %d</b>" % pr["current"]
        cls = "ok"
    second = ("<b>%s</b> failing record(s) in this batch" % "{:,}".format(recs)) if recs else \
        "no failing records found"
    return ("<div class='headline %s'>%s &middot; %s<div class='hs'>Next: <b>RO %d</b> %s &middot; "
            "%d of %d load jobs confirmed run</div></div>"
            % (cls, first, second, pr["current"], _esc(pr["current_step"][:72]),
               pr["jobs_done"], pr["jobs_total"]))


def current_step(rows):
    """
    Where the LOAD is, from the orchestrator steps -- not from whichever check happened to
    measure something. Informatica and SnapLogic RUN steps are what actually move data;
    everything else validates or fixes. How far they have got decides whether a finding
    further down the book is a defect or just data that has not arrived yet.
    """
    pr = rbk.progress(rows)
    if not pr["current"]:
        return "", 0
    bits = []
    if pr["last_job"]:
        t = ""
        for r in rows:
            if r["order"] == pr["last_job"] and r["times"]:
                t = jobruns.pretty(r["times"][0]["frm"], r["times"][0]["to"])
                break
        bits.append("<div class='jl'><span class='k'>Last job that ran</span>"
                    "<span class='v'><b>RO %d</b> %s%s</span></div>"
                    % (pr["last_job"], _esc(pr["last_job_step"][:54]),
                       (" &middot; %s" % _esc(t)) if t else ""))
    else:
        bits.append("<div class='jl'><span class='k'>Last job that ran</span>"
                    "<span class='v'>none confirmed yet</span></div>")
    if pr["next_job"]:
        bits.append("<div class='jl'><span class='k'>Next job</span>"
                    "<span class='v'><b>RO %d</b> %s &middot; %s</span></div>"
                    % (pr["next_job"], _esc(pr["next_job_step"][:54]),
                       _esc(pr["next_job_stage"])))
    else:
        bits.append("<div class='jl'><span class='k'>Next job</span>"
                    "<span class='v'>none left</span></div>")
    pct = int(100 * pr["jobs_done"] / pr["jobs_total"]) if pr["jobs_total"] else 0
    bits.append("<div class='jl'><span class='k'>Load jobs</span><span class='v'>"
                "<b>%d</b> of <b>%d</b> confirmed run &middot; <b>%d</b> left"
                "<span class='jbar'><i style='width:%d%%'></i></span></span></div>"
                % (pr["jobs_done"], pr["jobs_total"], pr["jobs_left"], pct))
    if pr["jobs_unconfirmable"]:
        bits.append("<div class='jl'><span class='k'>Cannot confirm</span><span class='v'>"
                    "RO %s &mdash; no output check exists for %s, so whether they ran is "
                    "unknown, not assumed</span></div>"
                    % (", ".join(str(x) for x in pr["jobs_unconfirmable"]),
                       "them" if len(pr["jobs_unconfirmable"]) > 1 else "it"))
    blk = ("" if not pr.get("blocked_at") else
           " &middot; stopped at <b>RO %d</b>" % pr["blocked_at"])
    return ("<div class='cur'><div class='q'>Where this batch is</div>"
            "<div class='a'><span class='ro'>RO %d</span>%s</div>"
            "<div class='s'>Next step &middot; %s%s</div>"
            "<div class='jobs'>%s</div></div>"
            % (pr["current"], _esc(pr["current_step"][:72]),
               _esc(pr["current_stage"]), blk, "".join(bits))), pr["current"]


_RUN = {"id": "", "batch": ""}


# Salesforce record links. The instance URL is config, not hardcoded, because the same
# tool is pointed at different sandboxes -- and a link to the WRONG org is worse than no
# link: it opens a real record that is not the one you are looking at.
_SF_ID = __import__("re").compile(r"^[a-zA-Z0-9]{15}([a-zA-Z0-9]{3})?$")

# Standard-object key prefixes, so a link can name its object. A custom object's prefix
# cannot be mapped without a describe, so those fall back to the id-only URL, which
# Lightning resolves on its own.
_PREFIX = {
    "001": "Account", "003": "Contact", "006": "Opportunity", "500": "Case",
    "800": "Contract", "801": "Order", "802": "OrderItem",
    "0WO": "WorkOrder", "0WL": "WorkOrderLineItem", "08p": "ServiceAppointment",
    "0Hh": "ServiceTerritory", "0Hn": "ServiceTerritoryMember",
    "01t": "Product2", "01u": "PricebookEntry", "01s": "Pricebook2",
    "707": "AsyncApexJob", "01p": "ApexClass", "0XB": "MaintenancePlan",
}


def _looks_like_id(v) -> bool:
    t = str(v or "")
    return bool(_SF_ID.match(t)) and len(t) in (15, 18) and any(ch.isdigit() for ch in t[:3])


def _sf_link(cfg, value, sobject="") -> str:
    """A clickable Lightning link for a Salesforce Id, or the plain value if it is not one."""
    base = str((cfg or {}).get("InstanceUrl") or "").rstrip("/")
    v = str(value or "")
    if not base or not _looks_like_id(v):
        return _esc(v)
    obj = _PREFIX.get(v[:3]) or (sobject if sobject and not sobject.startswith("__") else "")
    path = ("/lightning/r/%s/%s/view" % (quote(obj), quote(v))) if obj \
        else ("/lightning/r/%s/view" % quote(v))
    return ("<a class='sfid' href='%s%s' target='_blank' rel='noopener'>%s</a>"
            % (_esc(base), path, _esc(v)))



def _obj_href(r, store, run_id) -> str:
    rid = run_id or ""
    return "/object?object=%s&run=%s" % (quote(str(r["sobject"] or "")), quote(rid))


def _list_query(soql: str, batch: str) -> str:
    """The tally's COUNT() query turned into a query that LISTS the same records."""
    q = soql.replace("{BATCH}", batch)
    if q.startswith("SELECT COUNT() FROM"):
        q = "SELECT Id FROM" + q[len("SELECT COUNT() FROM"):]
    return q


def object_page(store, batch, run_id, sobject, cfg=None):
    """
    WHAT IS BEHIND ONE TILE.

    Everything here comes from what the run already stored, so it works on a snapshot with no
    Salesforce, no Goose and no network. It also says, plainly, what the tool does NOT keep:
    a tile that implies a record browser it does not have is worse than no tile.
    """
    import registry
    rid = run_id or store.latest_run_id(batch)
    rows = store.tally(rid) if rid else []
    row = next((r for r in rows if r["sobject"] == sobject), None)
    back = ("<a class='back' href='/?batch=%s&run=%s'>&lsaquo; back to the run book</a>"
            % (_esc(batch), _esc(rid or "")))
    if row is None:
        return ("<div class='rec'>%s<h2>%s</h2><div class='muted'>This run stored no tally for "
                "that object.</div></div>" % (back, _esc(sobject or "Unknown object")))

    state = row["state"]
    pend = bool(row.get("pending"))
    loaded = row.get("loaded")
    produced = int(row.get("produced_at") or 0)
    produced_step = (rbk.step(produced) or {}).get("step", "") if produced else ""
    scope = next((q for (_s, o, _l, q) in tal.TALLY if o == sobject), "")

    # ---- the checks that cover this object, with this run's verdict for each
    res = {r["check_id"]: r for r in (store.results_for_run(rid) if rid else [])}
    covering = [c for c in registry.all_checks() if c.sobject == sobject]
    covering.sort(key=lambda c: (c.runbook_order or 999, c.id))
    failing_n = 0
    trs = []
    previews = []
    for c in covering:
        r = res.get(c.id)
        if r is None:
            verdict, ex, fl, why = "NOT RUN", None, None, ""
        else:
            ex = int((r["processed"] if rbk._has(r, "processed") else 0) or 0)
            fl = int(r["evidence_count"] or 0) if r["verdict"] == "FAIL" else 0
            verdict = {"PASS": "CLEAR", "FAIL": "ISSUE", "UNPROVEN": "UNPROVEN"}.get(
                r["verdict"], r["verdict"])
            why = str(r["reason"] or "")
        if fl and terms.is_record(c.id):
            failing_n += fl
        link = ""
        if fl:
            link = (" <a class='drill' href='/records?check=%s&run=%s&batch=%s'>"
                    "see records &rsaquo;</a>" % (_esc(c.id), _esc(rid or ""), _esc(batch)))
            ev = store.evidence(rid, c.id)[:5]
            ids = []
            for e in ev:
                for k, v in e.items():
                    if str(k).lower() in ("id", "recordid", "sfid") and _looks_like_id(v):
                        ids.append(_sf_link(cfg, v, sobject)); break
            if ids:
                previews.append("<div class='muted' style='margin:2px 0'><b>%s</b> &mdash; first %d "
                                "of %s: %s</div>" % (_esc(c.name), len(ids), "{:,}".format(fl),
                                                     " &middot; ".join(ids)))
        trs.append("<tr><td class='ro'>%s</td><td><b>%s</b><br><span class='muted'>%s</span></td>"
                   "<td><span class='sev %s'>%s</span></td><td><span class='st %s'>%s</span></td>"
                   "<td class='num'>%s</td><td class='num'>%s</td><td>%s%s</td></tr>"
                   % (c.runbook_order or "", _esc(c.name), _esc(c.id),
                      c.severity, terms.sev(c.severity),
                      {"CLEAR": "READY", "ISSUE": "BLOCKED" if c.severity == "BLOCKER" else "REVIEW",
                       "UNPROVEN": "UNPROVEN"}.get(verdict, "NOT"),
                      verdict,
                      "{:,}".format(ex) if ex is not None else "&mdash;",
                      (("{:,}".format(fl) + ("" if terms.is_record(c.id) or not fl
                                             else " " + _esc(terms.unit_of(c.id)[1])))
                       if fl is not None else "&mdash;"),
                      _esc(why[:140]), link))

    out = ["<div class='rec'>", back, "<h2>%s</h2>" % _esc(row["label"]),
           "<div class='sub'>%s &middot; run %s</div>" % (_esc(sobject), _esc(rid or ""))]

    # ---- the numbers
    if state == "UNSCOPED":
        shown = "no batch path"
    elif state == "ERROR":
        shown = "query failed"
    elif pend:
        shown = "not loaded yet"
    else:
        shown = "{:,}".format(int(loaded or 0))
    fail_total = int(row.get("errors") or 0)
    out.append("<div class='ob-grid'>"
               "<div><div class='k'>Loaded for this batch</div><div class='v'>%s</div></div>"
               "<div><div class='k'>Failing records</div><div class='v %s'>%s</div></div>"
               "<div><div class='k'>First created</div><div class='v' style='font-size:13px'>%s</div></div>"
               "<div><div class='k'>Last created</div><div class='v' style='font-size:13px'>%s</div></div>"
               "<div><div class='k'>Last modified</div><div class='v' style='font-size:13px'>%s</div></div>"
               "<div><div class='k'>Made by run book step</div><div class='v' style='font-size:13px'>%s</div></div>"
               "</div>"
               % (shown, "er" if fail_total else "", "{:,}".format(fail_total),
                  _esc((row.get("first") or "")[:19].replace("T", " ") or "—"),
                  _esc((row.get("last") or "")[:19].replace("T", " ") or "—"),
                  _esc((row.get("modified") or "")[:19].replace("T", " ") or "—"),
                  ("RO %d &middot; %s" % (produced, _esc(produced_step[:40]))) if produced
                  else "pre-existing, not created by the run book"))
    if row.get("note"):
        out.append("<div class='why'>%s</div>" % _esc(row["note"]))
    if pend:
        out.append("<div class='cap'>This object is dimmed because the step that creates it has "
                   "not run. Its failing records are held at zero so an unstarted load is not "
                   "counted as a defect.</div>")

    # ---- checks
    out.append("<h3 style='margin:16px 0 4px;font-size:14px'>Checks on this object</h3>")
    if trs:
        out.append("<div class='recwrap'><table class='iss'><thead><tr><th>RO</th><th>Check</th>"
                   "<th>Impact</th><th>This run</th><th>Examined</th><th>Failing</th>"
                   "<th>Why / records</th></tr></thead><tbody>%s</tbody></table></div>"
                   % "".join(trs))
        out.extend(previews)
        if pend and failing_n:
            out.append("<div class='muted'>These %s failing record(s) are not counted in the tile "
                       "because the object has not loaded yet.</div>" % "{:,}".format(failing_n))
    else:
        out.append("<div class='muted'>No check is attached to this object, so the tile is a "
                   "count only: nothing was tested for correctness.</div>")

    # ---- how it was counted, and a query to list the same records
    if scope:
        out.append("<h3 style='margin:16px 0 4px;font-size:14px'>How the number was counted</h3>")
        out.append("<div class='qlabel'>Tool: Workbench &rarr; Queries &rarr; SOQL Query &nbsp;"
                   "&middot;&nbsp; READ ONLY (no DML). The count, as the tool ran it:</div>"
                   "<pre class='q'>%s</pre>" % _esc(scope.replace("{BATCH}", batch)))
        out.append("<div class='qlabel'>Tool: Workbench &rarr; Queries &rarr; SOQL Query &nbsp;"
                   "&middot;&nbsp; READ ONLY (no DML). The same records, listed (first 200):</div>"
                   "<pre class='q'>%s</pre>" % _esc(_list_query(scope, batch)))

    # ---- this object across the batch's recent runs
    hist = []
    for rr in snap.list_runs(store, batch, limit=8):
        t = next((x for x in store.tally(rr["run_id"]) if x["sobject"] == sobject), None)
        if t is None:
            continue
        hist.append("<tr><td>%s</td><td class='num'>%s</td><td class='num'>%s</td></tr>"
                    % (_esc(str(rr["started"] or "").replace("T", " ")[:16]),
                       "&mdash;" if t.get("loaded") is None else "{:,}".format(int(t["loaded"])),
                       "{:,}".format(int(t.get("errors") or 0))))
    if len(hist) > 1:
        out.append("<h3 style='margin:16px 0 4px;font-size:14px'>This object over recent runs</h3>"
                   "<div class='recwrap'><table class='iss'><thead><tr><th>Run</th><th>Loaded</th>"
                   "<th>Failing</th></tr></thead><tbody>%s</tbody></table></div>" % "".join(hist))

    # ---- what we can and cannot show. The honest part.
    can = ["How many records of this object belong to this batch, and the window they were "
           "created and last changed in.",
           "Every check that covers it, with this run's result, examined and failing counts.",
           "The failing records themselves (Salesforce Ids as links, plus the fields the check "
           "kept), up to <code>EvidenceCap</code> per check, and a CSV of them.",
           "The rule, its source, and the fix for each failing check.",
           "The exact query behind the count, to run yourself.",
           "How the object changed across runs."]
    cannot = ["The full list of records that loaded. The tool counts them and keeps only the "
              "failing ones. Use the second query above for a list.",
              "Field values of records that passed. A clean record is not stored.",
              "Anything newer than the run. This page reads what was stored, so it is as old "
              "as the run.",
              "Informatica or SnapLogic job status by object. That lives per step in the run "
              "book's Time column."]
    if sobject in tal.UPDATED_NOT_CREATED:
        cannot.insert(0, "Which records the batch created: these existed already and were "
                         "UPDATED, so 'loaded' means touched by this batch.")
    if state == "UNSCOPED":
        cannot.insert(0, "Any count. There is no reliable batch path for this object, so the "
                         "tool reports none rather than a zero that would mean 'could not ask'.")
    if state == "ERROR":
        cannot.insert(0, "A count. The query for this tile failed in this run; re-run the checks.")
    out.append("<div class='cancan'><div><h3>What this page can show</h3><ul>%s</ul></div>"
               "<div><h3>What it cannot show</h3><ul>%s</ul></div></div>"
               % ("".join("<li>%s</li>" % x for x in can),
                  "".join("<li>%s</li>" % x for x in cannot)))
    out.append("</div>")
    return "".join(out)


def _verification_panel(v):
    """What the second look at this check found. Plain words, one line per flag."""
    if not v:
        return ""
    import verify
    lines = []
    st = v.get("status") or ""
    scope = v.get("scope") or ""
    head = {"VERIFIED": "Verified against Salesforce",
            "SUSPECT": "Treat this number with caution"}.get(st, "Checked against Salesforce")
    cls = "vsus" if st == "SUSPECT" else ("vok" if st == "VERIFIED" else "vnone")
    lines.append("<div class='vpanel %s'><b>%s</b>" % (cls, _esc(head)))
    s_ = v.get("samples") or []
    if s_:
        ok = sum(1 for x in s_ if x.get("found"))
        lines.append("<div>Sample re-read from Salesforce: %d of %d records exist.</div>" % (ok, len(s_)))
    if scope:
        lines.append("<div>Scope: %s.</div>" % (
            "tied to this batch" if scope == "BATCH" else
            "<b>not tied to this batch</b> (counts more than this batch's records)"))
    for f in v.get("flags") or []:
        lines.append("<div class='vflag'>&bull; <b>%s.</b> %s</div>"
                     % (_esc(verify.LABEL.get(f["code"], f["code"])), _esc(f.get("text", ""))))
    lines.append("</div>")
    return "".join(lines)


def verify_page(store, batch, run_id):
    """Every check's second opinion in one place, suspect ones first. Database read only."""
    import registry, verify
    rid = run_id or store.latest_run_id(batch)
    vs = store.verification(rid) if rid else {}
    if not vs:
        return ("<div class='rec'><a class='back' href='/?batch=%s&run=%s'>&lsaquo; back to the run book</a>"
                "<h2>Verification</h2><div class='cap'>This run has no verification. It was made "
                "before v0.23.0, imported without it, or verification could not run. Re-run the "
                "checks to produce it.</div></div>" % (_esc(batch), _esc(rid or "")))
    res = {r["check_id"]: r for r in store.results_for_run(rid)}
    order = {"SUSPECT": 0, "VERIFIED": 1, "": 2}
    ids = sorted(vs, key=lambda c: (order.get(vs[c].get("status", ""), 2), c))
    n = {k: sum(1 for c in vs if (vs[c].get("status") or "") == k) for k in ("SUSPECT", "VERIFIED", "")}
    out = ["<div class='rec'><a class='back' href='/?batch=%s&run=%s'>&lsaquo; back to the run book</a>"
           % (_esc(batch), _esc(rid)),
           "<h2>Verified against Salesforce</h2>",
           "<div class='sub'>%d suspect &middot; %d verified &middot; %d with nothing to verify. "
           "This never changes a verdict &mdash; it says how far to trust each number.</div>"
           % (n["SUSPECT"], n["VERIFIED"], n[""])]
    out.append("<div class='muted'>Verified = the check failed, and sample records were re-read "
               "from Salesforce and exist. Suspect = a flag below. Scope comes from what each "
               "check actually queried, not from its description.</div>")
    for cid in ids:
        v, r = vs[cid], res.get(cid)
        chk = registry.by_id(cid)
        st = v.get("status") or ""
        if not st and not (v.get("flags")):
            continue
        out.append("<h3>%s <span class='muted'>%s &middot; %s</span></h3>"
                   % (_esc(chk.name if chk else cid), _esc(cid), _esc(r["verdict"] if r else "")))
        out.append(_verification_panel(v))
        qs = v.get("queries") or []
        if qs:
            out.append("<details><summary>%d queries this check sent</summary><table class='recs'>"
                       "<tr><th>kind</th><th>batch?</th><th>rows</th><th>ms</th><th>query</th></tr>" % len(qs))
            for q in qs:
                out.append("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                           % (_esc(q.get("kind")), "yes" if q.get("scoped") else "no",
                              _esc(q.get("rows") if q.get("rows") is not None else "err"),
                              _esc(q.get("ms")), _esc(q.get("sql", ""))))
            out.append("</table></details>")
    out.append("<h3>Scope of every check</h3><table class='recs'><tr><th>check</th><th>verdict</th>"
               "<th>scope</th><th>queries</th></tr>")
    for cid in sorted(vs):
        v, r = vs[cid], res.get(cid)
        out.append("<tr><td>%s</td><td>%s</td><td>%s</td><td>%d</td></tr>"
                   % (_esc(cid), _esc(r["verdict"] if r else ""),
                      _esc({"BATCH": "this batch", "ORG-WIDE": "ORG-WIDE"}.get(v.get("scope"), "n/a")),
                      len(v.get("queries") or [])))
    out.append("</table></div>")
    return "".join(out)


def verify_strip(store, batch, run_id):
    rid = run_id or store.latest_run_id(batch)
    vs = store.verification(rid) if rid else {}
    if not vs:
        return ""
    sus = sum(1 for v in vs.values() if v.get("status") == "SUSPECT")
    ok = sum(1 for v in vs.values() if v.get("status") == "VERIFIED")
    return ("<div class='vstrip %s'>Verified against Salesforce: <b>%d</b> failing check(s) confirmed "
            "with real records &middot; <b>%d</b> to treat with caution &middot; "
            "<a href='/verify?run=%s&batch=%s'>see why</a></div>"
            % ("vsus" if sus else "vok", ok, sus, _esc(rid), _esc(batch)))


def records_page(store, batch, run_id, check_id, cfg=None):
    """
    THE RECORDS THEMSELVES. Which ones failed, and why.

    The count in `result` is always exact. The retained sample is capped, so when the two
    disagree this page says so plainly and gives the Salesforce Ids it does have -- a page
    that quietly shows 200 of 906 and calls it the answer is worse than one that admits it.
    """
    import registry
    rid = run_id or store.latest_run_id(batch)
    chk = registry.by_id(check_id)
    rows = store.evidence(rid, check_id) if rid else []
    res = None
    for r in (store.results_for_run(rid) if rid else []):
        if r["check_id"] == check_id:
            res = r
            break
    found = int((res["evidence_count"] if res else 0) or 0)
    examined = int((res["processed"] if res and rbk._has(res, "processed") else 0) or 0)

    name = chk.name if chk else check_id
    out = ["<div class='rec'>",
           "<a class='back' href='/?batch=%s&run=%s'>&lsaquo; back to the run book</a>"
           % (_esc(batch), _esc(run_id or "")),
           "<h2>%s</h2>" % _esc(name),
           "<div class='sub'>%s &middot; Run Order %s &middot; %s %s found%s</div>"
           % (_esc(check_id), (chk.runbook_order if chk else "?"),
              "{:,}".format(found), _esc(terms.unit_of(check_id)[1] if found != 1 else terms.unit_of(check_id)[0]),
              " of %s examined" % "{:,}".format(examined) if examined else "")]

    if res is not None and res["reason"]:
        out.append("<div class='why'><b>Why these failed:</b> %s</div>" % _esc(res["reason"]))
    try:
        out.append(_verification_panel((store.verification(rid) or {}).get(check_id)))
    except Exception:                                        # noqa: BLE001
        pass
    if chk is not None:
        out.append("<div class='muted'>Rule: %s<br>Source: %s</div>"
                   % (_esc(chk.rule), _esc(chk.rule_source)))
        if chk.remediation:
            out.append("<div class='fix'><b>Fix at RO %s:</b> %s</div>"
                       % (chk.remediation.runbook_order or "?",
                          _esc(chk.remediation.summary)))

    if not rows:
        out.append("<div class='cap'>No individual records were retained for this check. "
                   "Either it reports a summary rather than rows, or this run predates "
                   "record retention. Re-run the checks to capture them.</div></div>")
        return "".join(out)

    # ---- Some findings are an ABSENCE, not a list of records.
    # "TF_35 produced NOTHING" has no failing records by definition -- nothing was created.
    # Rendering its marker row as a one-row table promised records and delivered a
    # restatement of the headline. A record row carries an Id; a marker does not.
    ID_KEYS = ("id", "recordid", "sfid")
    is_records = any(any(str(k).lower() in ID_KEYS for k in r.keys()) for r in rows)
    if not is_records:
        out.append("<div class='cap'><b>There are no failing records to show, and that is "
                   "the finding.</b> This check reports an ABSENCE: the step produced "
                   "nothing for this batch, so no records exist to list. What follows is "
                   "what the check observed, not a record list.</div>")
        up = _upstream_pointer(check_id, chk)
        if up:
            out.append("<div class='fix'>%s</div>" % up)

    if len(rows) < found:
        out.append("<div class='cap'><b>Showing %s of %s.</b> The count is exact; the "
                   "retained sample is capped. Raise <code>EvidenceCap</code> in "
                   "config.json and re-run to keep them all.</div>"
                   % ("{:,}".format(len(rows)), "{:,}".format(found)))

    cols, seen = [], set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k); cols.append(k)
    out.append("<div style='margin-top:8px'>"
               "<a class='drill' href='/records.csv?check=%s&run=%s&batch=%s'>"
               "Download CSV (%s row(s))</a></div>"
               % (_esc(check_id), _esc(run_id or ""), _esc(batch), "{:,}".format(len(rows))))
    out.append("<div class='recwrap'><table class='recs'><thead><tr>")
    out += ["<th>%s</th>" % _esc(c) for c in cols]
    out.append("</tr></thead><tbody>")
    for r in rows:
        cells = []
        for c in cols:
            raw = "" if r.get(c) is None else str(r.get(c))
            cells.append("<td>%s</td>"
                         % (_sf_link(cfg, raw, chk.sobject if chk else "")
                            if _looks_like_id(raw) else _esc(raw[:120])))
        out.append("<tr>" + "".join(cells) + "</tr>")
    out.append("</tbody></table></div></div>")
    return "".join(out)


# Where the ACTUAL records live when a "produced nothing" finding has none of its own.
# A step that produced nothing failed on some upstream population -- those records exist,
# just under a different check.
_UPSTREAM = {
    "RAN.TF_35_CONTRACTS":  ("ORDER.ACTIVATION_RATE", 16,
                             "the Orders that did not reach Activated/Contracted"),
    "RAN.TF_30_ORDERS":     ("QUOTE.MISSING_PRICEBOOK_ENTRY", 16,
                             "the Quote Lines that cannot convert"),
    "RAN.TF_55_WORKORDERS": ("WO.ORDERS_MISSING_WOS", 28,
                             "the Orders with no Work Orders"),
    "RAN.TF_55_WOLIS":      ("WO.ORDERS_MISSING_WOS", 28,
                             "the Orders with no Work Orders"),
    "RAN.TF_40_MPS":        ("WO.MP_NO_GENERATION", 41,
                             "the Active Maintenance Plans generating no Work Orders"),
    "RAN.TF_60_BIQS":       ("BIQ.COVERAGE", 54,
                             "the Contracts with no BIQs"),
    "RAN.TF_60_APPOINTMENTS": ("WO.SERVICE_COVERAGE", 40,
                               "the Orders with no Service Work Order"),
    "RAN.TF_15_QUOTES":     ("", 10, "nothing upstream of this -- TF_15 is the first load"),
    "RAN.TF_20_QUOTELINES": ("QUOTE.NO_LINES", 12, "the Quotes with no lines"),
}


def _upstream_pointer(check_id, chk):
    """Name the check that DOES hold records, so the drill-down is not a dead end."""
    hit = _UPSTREAM.get(check_id)
    if hit:
        other, ro, what = hit
        if not other:
            return ("<b>Where to look instead:</b> %s. Start from the job's own log in "
                    "Informatica or SnapLogic, and from GOOSE_ErrorLog (Run Order 4)."
                    % _esc(what))
        return ("<b>The records are at Run Order %d:</b> <code>%s</code> &mdash; %s."
                % (ro, _esc(other), _esc(what)))
    if chk is not None and chk.remediation and chk.remediation.runbook_order:
        return ("<b>Next step:</b> Run Order %s &mdash; %s"
                % (chk.remediation.runbook_order, _esc(chk.remediation.summary)))
    return ""


def records_csv(store, batch, run_id, check_id) -> str:
    rid = run_id or store.latest_run_id(batch)
    rows = store.evidence(rid, check_id) if rid else []
    if not rows:
        return "no records retained for %s\n" % check_id
    cols, seen = [], set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k); cols.append(k)
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow({c: r.get(c, "") for c in cols})
    return buf.getvalue()


HEADS = [("Run Order", "c-ro"), ("Stage", "c-stage"), ("Action", "c-act"), ("Step", "c-step"),
         ("Script Purpose", "c-purp"), ("Status", "c-stat"),
         ("Record Count / Result", "c-cnt"), ("Time", "c-time"),
         ("Verification Method", "c-ver"), ("Next Action / What's in the way", "c-next")]



# ---------------------------------------------------------------------------------- run book filters
# Filtering is done in the browser over rows the server already drew, so it needs no query,
# works on a snapshot, and changes nothing about what is stored or counted.
_SYSTEMS = (("informatica", "Informatica"), ("snaplogic", "SnapLogic"),
            ("goose", "Goose"), ("salesforce", "Salesforce"))
_ACTION_ORDER = ("RUN", "RUN AUTOMATION", "VALIDATION", "AUTO-FIX", "MANUAL REVIEW")


def _slug(text) -> str:
    import re as _re
    return _re.sub(r"[^a-z0-9]+", "-", str(text or "").lower()).strip("-")


def _row_systems(stage) -> str:
    """'Goose + Salesforce' -> 'goose salesforce'. Multi / All systems belong to none of them."""
    toks = [t for t in (_slug(x) for x in str(stage or "").split("+")) if t]
    keep = [t for t, _ in _SYSTEMS if t in toks]
    return " ".join(keep) if keep else "multi"


def _is_job(r) -> bool:
    """The steps that actually MOVE DATA: Informatica and SnapLogic RUN rows."""
    return rbk.is_job(r)


def _row_attrs(r) -> str:
    return (" data-sys='%s' data-act='%s' data-st='%s' data-job='%d'"
            % (_row_systems(r.get("stage")), _slug(r.get("action")),
               _slug(r.get("state")).replace("-", ""), 1 if _is_job(r) else 0))


FILTER_JS = """
<script>
(function () {
  var bar = document.getElementById('rbfilter');
  if (!bar) return;
  var KEY = 'pm.rbfilter.v1';
  var st = {show: 'all', act: 'all', st: 'all'};
  try {
    var saved = JSON.parse(localStorage.getItem(KEY) || '{}') || {};
    for (var k in st) { if (saved[k]) st[k] = saved[k]; }
  } catch (e) {}
  var rows = document.querySelectorAll('table.rb tbody tr');
  var NEED = ['blocked', 'held', 'review', 'unproven'];
  function ok(tr) {
    var sys = ' ' + (tr.getAttribute('data-sys') || '') + ' ';
    var job = tr.getAttribute('data-job') === '1';
    var act = tr.getAttribute('data-act');
    var s = tr.getAttribute('data-st');
    if (st.show === 'jobs' && !job) return false;
    if (st.show !== 'all' && st.show !== 'jobs' && sys.indexOf(' ' + st.show + ' ') < 0) return false;
    if (st.act !== 'all' && act !== st.act) return false;
    if (st.st === 'attention') { if (NEED.indexOf(s) < 0) return false; }
    else if (st.st === 'notrun') { if (s !== 'notrun' && s !== 'notchecked') return false; }
    else if (st.st !== 'all' && s !== st.st) return false;
    return true;
  }
  function apply() {
    var shown = 0;
    for (var i = 0; i < rows.length; i++) {
      var v = ok(rows[i]);
      rows[i].style.display = v ? '' : 'none';
      if (v) shown++;
    }
    var chips = bar.querySelectorAll('button[data-g]');
    for (var j = 0; j < chips.length; j++) {
      var on = st[chips[j].getAttribute('data-g')] === chips[j].getAttribute('data-v');
      chips[j].className = (chips[j].className.replace(/\\bon\\b/g, '').trim() + (on ? ' on' : '')).trim();
    }
    var c = document.getElementById('rbcount');
    if (c) c.textContent = 'Showing ' + shown + ' of ' + rows.length + ' steps';
    var none = document.getElementById('rbnone');
    if (none) none.style.display = shown ? 'none' : 'block';
    try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {}
  }
  bar.addEventListener('click', function (e) {
    var b = e.target;
    while (b && b !== bar && !(b.tagName === 'BUTTON')) b = b.parentNode;
    if (!b || b === bar) return;
    if (b.getAttribute('data-reset')) { st = {show: 'all', act: 'all', st: 'all'}; }
    else if (b.getAttribute('data-g')) { st[b.getAttribute('data-g')] = b.getAttribute('data-v'); }
    else return;
    apply();
  });
  apply();
})();
</script>
"""


def _filter_bar(rows, run_id="", batch="") -> str:
    """Three independent filters over the run book: which steps, what kind of step, what status."""
    def chip(g, v, label, n=None):
        return ("<button type='button' data-g='%s' data-v='%s'>%s%s</button>"
                % (g, v, label, "<i>%d</i>" % n if n is not None else ""))

    n_sys = {k: sum(1 for r in rows if k in _row_systems(r["stage"]).split()) for k, _ in _SYSTEMS}
    show = [chip("show", "all", "Full process", len(rows)),
            chip("show", "jobs", "Data-moving jobs", sum(1 for r in rows if _is_job(r)))]
    show += [chip("show", k, lbl, n_sys[k]) for k, lbl in _SYSTEMS]

    present = {}
    for r in rows:
        a = (r.get("action") or "").strip().upper()
        if a:
            present[a] = present.get(a, 0) + 1
    order = [a for a in _ACTION_ORDER if a in present] + sorted(a for a in present if a not in _ACTION_ORDER)
    acts = [chip("act", "all", "Any")] + [chip("act", _slug(a), a.title(), present[a]) for a in order]

    def n_state(*names):
        return sum(1 for r in rows if _slug(r["state"]).replace("-", "") in names)
    sts = [chip("st", "all", "Any"),
           chip("st", "attention", "Needs attention", n_state("blocked", "held", "review", "unproven")),
           chip("st", "blocked", "Blocked", n_state("blocked")),
           chip("st", "held", "Held", n_state("held")),
           chip("st", "review", "Review", n_state("review")),
           chip("st", "unproven", "Unproven", n_state("unproven")),
           chip("st", "ready", "Ready", n_state("ready")),
           chip("st", "notrun", "Not run / not checked", n_state("notrun", "notchecked"))]
    return ("<div class='fbar' id='rbfilter'>"
            "<div class='fg'><span class='fl'>Show</span>%s"
            "<span class='fcount' id='rbcount'></span>"
            "<a class='drill' style='margin-left:auto' href='/runbook.xlsx?run=%s&batch=%s' "
            "title='Informatica / SnapLogic steps on one sheet, the team&#39;s own steps on another'>"
            "&#8681; Export run book (Excel)</a></div>"
            "<div class='fg'><span class='fl'>Type</span>%s</div>"
            "<div class='fg'><span class='fl'>Status</span>%s"
            "<button type='button' class='freset' data-reset='1'>Reset</button></div></div>"
            % ("".join(show), _esc(run_id or ""), _esc(quote(batch or "")), "".join(acts), "".join(sts)))


def table(store, batch, run_id=""):
    """The run book, with the three live columns filled in. Same ten columns, same order."""
    rows = rbk.readiness(store, batch, run_id)
    if not (run_id or store.latest_run_id(batch)):
        return ""
    _RUN["id"], _RUN["batch"] = run_id or "", batch
    # thead/tbody, not a bare <tr>: a sticky <th> in an implicit tbody leaves the flow and
    # lands on top of the first data row, which hid Run Order 1 completely.
    out = [verify_strip(store, batch, run_id), _filter_bar(rows, run_id or store.latest_run_id(batch), batch)]
    out.append("<div class='wrap'><table class='rb'><thead><tr>")
    out += ["<th class='%s'>%s</th>" % (cls, h) for h, cls in HEADS]
    out.append("</tr></thead><tbody>")
    for r in rows:
        cls = r["state"].split()[0] if r["state"] != "NOT CHECKED" else "NOT"
        out.append(
            "<tr class='%s'%s>"
            "<td class='c-ro num'>%d</td>"
            "<td class='c-stage'>%s</td>"
            "<td class='c-act'><span class='act %s'>%s</span></td>"
            "<td class='c-step'><span class='stepname'>%s</span></td>"
            "<td class='c-purp'>%s</td>"
            "<td class='c-stat'><span class='st %s'>%s</span></td>"
            "<td class='c-cnt'>%s</td>"
            "<td class='c-time'>%s</td>"
            "<td class='c-ver'>%s</td>"
            "<td class='c-next'>%s</td>"
            "</tr>"
            % ("blk" if r["state"] == "BLOCKED" else ("held" if r["state"] == "HELD" else ""),
               _row_attrs(r),
               r["order"], _esc(r["stage"]),
               _action_cls(r["action"]), _esc(r["action"] or "\u2014"),
               _esc(r["step"]), _clamp(r["purpose"]),
               cls, _esc(r["state"]) + _state_note(r),
               _count_cell(r), _time_cell(r),
               _clamp(r["verify"], 200), _next_cell(r)))
    out.append("</tbody></table></div><div id='rbnone'>No steps match these filters.</div>")
    # The script must come AFTER the table: it reads the rows when it runs. Placed with the bar
    # (above the table) it found zero rows and every button silently did nothing.
    out.append(FILTER_JS)
    out.append("<div class='legend'><b>Record Count / Result</b> shows two numbers: "
               "<b>examined</b> is how many records the check looked at, <b>failing</b> is how "
               "many of them are wrong. Neither is &ldquo;records loaded&rdquo;. "
               "<b>Time</b> is when the step RAN &mdash; from the Informatica or SnapLogic API "
               "where Sunrise captured it, otherwise from record timestamps, which are a proxy "
               "and labelled as one. <b>UNPROVEN is not a pass.</b></div>")
    out.append(terms.glossary_html())
    return "".join(out)


SNAP_DIR = Path(__file__).resolve().parent.parent / "snapshots"


def _save_snap(store, run_id, say):
    if not run_id:
        raise RuntimeError("No run to save. Run the checks first.")
    SNAP_DIR.mkdir(parents=True, exist_ok=True)
    p = snap.export_run(store, run_id, SNAP_DIR)
    say("saved %s" % p.name)
    say("Folder: %s" % SNAP_DIR, 100)
    return str(p)


def _load_snaps(store, say):
    """
    Import every snapshot file sitting in the snapshots folder.

    A browser cannot hand a server a file path, and a tool that runs on one machine does
    not need an upload form -- dropping the .json in the folder is the whole workflow.
    """
    SNAP_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(SNAP_DIR.glob("*.json"))
    if not files:
        raise RuntimeError("No .json snapshot files in %s . Put a snapshot there and press "
                           "Load file again." % SNAP_DIR)
    n = 0
    for f in files:
        try:
            r = snap.import_run(store, f)
            say("loaded %s -- %s, %d result(s)" % (f.name, r["batch"], r["results"]))
            n += 1
        except Exception as e:                               # noqa: BLE001
            say("skipped %s: %s" % (f.name, str(e)[:140]))
    if not n:
        raise RuntimeError("Nothing could be loaded from %s" % SNAP_DIR)
    say("%d snapshot(s) now in the Snapshot list" % n, 100)
    return n


def serve(cfg, store, port=8899, cfg_path=None):
    state = {"batch": cfg.get("DefaultBatch", ""), "run": ""}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, body, ctype="text/html; charset=utf-8", code=200):
            data = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _redirect(self):
            self.send_response(303)
            self.send_header("Location", "/?batch=%s&run=%s"
                             % (quote(state["batch"]), quote(state.get("run") or "")))
            self.end_headers()

        def do_GET(self):
            u = urlparse(self.path)
            qs = parse_qs(u.query)
            if "batch" in qs:
                state["batch"] = qs["batch"][0]
                state["run"] = ""          # a different batch invalidates the chosen run
            if "run" in qs:
                state["run"] = qs["run"][0]
            batch, run = state["batch"], state["run"]
            if u.path == "/api/job":
                self._send(json.dumps(jobs.JOB.as_dict()), "application/json"); return

            # ---- the records behind a finding. Pure database read, no query.
            if u.path in ("/records", "/records.csv"):
                cid = (qs.get("check") or [""])[0]
                rrun = (qs.get("run") or [""])[0]
                rbatch = (qs.get("batch") or [batch])[0] or batch
                if u.path == "/records.csv":
                    body = records_csv(store, rbatch, rrun, cid)
                    data = body.encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/csv; charset=utf-8")
                    self.send_header("Content-Disposition",
                                     'attachment; filename="%s_%s.csv"'
                                     % (rbatch.replace(" ", "_"), cid.replace(".", "_")))
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers(); self.wfile.write(data); return
                try:
                    self._send(page(header(cfg, store, rbatch, rrun) + "<main>"
                                    + records_page(store, rbatch, rrun, cid, cfg) + "</main>"))
                except Exception as e:                       # noqa: BLE001
                    self._send(page("<main><div class='rec'><h2>Could not show those "
                                    "records</h2><div class='muted'>%s</div></div></main>"
                                    % _esc(e)))
                return
            if u.path == "/selftest":
                import selfpage
                msg = (qs.get("msg") or [""])[0]
                try:
                    body = ("<div class='headline ok'>%s</div>" % _esc(msg) if msg else "") + \
                        selfpage.render(cfg, store, bool(jobs.running()))
                    self._send(page(header(cfg, store, batch, run) + "<main>" + body + "</main>",
                                    3 if jobs.running() else 0))
                except Exception as e:                       # noqa: BLE001
                    self._send(page("<main><div class='rec'><h2>Could not show the self-test</h2>"
                                    "<div class='muted'>%s</div></div></main>" % _esc(e)))
                return
            if u.path == "/verify":
                try:
                    self._send(page(header(cfg, store, batch, run) + "<main>"
                                    + verify_page(store, batch, run) + "</main>"))
                except Exception as e:                       # noqa: BLE001
                    self._send(page("<main><div class='rec'><h2>Could not show verification</h2>"
                                    "<div class='muted'>%s</div></div></main>" % _esc(e)))
                return
            # ---- the run book as a workbook. Pure database read; the browser downloads it.
            if u.path == "/runbook.xlsx":
                import tempfile, report as _rep
                rrun = (qs.get("run") or [""])[0] or run
                try:
                    with tempfile.TemporaryDirectory() as td:
                        p = _rep.build_runbook(store, batch, Path(td), rrun)
                        data = Path(p).read_bytes()
                        name = Path(p).name
                except Exception as e:                       # noqa: BLE001
                    self._send(page("<main><div class='rec'><h2>Could not export the run book</h2>"
                                    "<div class='muted'>%s</div></div></main>" % _esc(e)))
                    return
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument."
                                                 "spreadsheetml.sheet")
                self.send_header("Content-Disposition", 'attachment; filename="%s"' % name)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers(); self.wfile.write(data); return
            if u.path == "/issues.xlsx":
                import tempfile, report as _rep
                rrun = (qs.get("run") or [""])[0] or run
                try:
                    with tempfile.TemporaryDirectory() as td:
                        cn = None
                        try:
                            import connections as _cx, actions as _ac
                            _ac.bind(cfg, lambda *a, **k: None)
                            cn = _cx.Conn(cfg, batch)
                        except Exception:                    # noqa: BLE001
                            cn = None          # no connection: Ids still listed, legacy Ids left out
                        p = _rep.build_issues(store, batch, Path(td), rrun, cfg, cn)
                        data = Path(p).read_bytes()
                        name = Path(p).name
                except Exception as e:                       # noqa: BLE001
                    self._send(page("<main><div class='rec'><h2>Could not export the issues</h2>"
                                    "<div class='muted'>%s</div></div></main>" % _esc(e)))
                    return
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument."
                                                 "spreadsheetml.sheet")
                self.send_header("Content-Disposition", 'attachment; filename="%s"' % name)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers(); self.wfile.write(data); return
            # ---- what is behind one tile. Pure database read, no query.
            if u.path == "/object":
                obj = (qs.get("object") or [""])[0]
                orun = (qs.get("run") or [""])[0] or run
                try:
                    self._send(page(header(cfg, store, batch, orun) + "<main>"
                                    + object_page(store, batch, orun, obj, cfg) + "</main>"))
                except Exception as e:                       # noqa: BLE001
                    self._send(page("<main><div class='rec'><h2>Could not show that "
                                    "object</h2><div class='muted'>%s</div></div></main>"
                                    % _esc(e)))
                return
            try:
                hero, busy, cur = hero_and_log(store, batch, run)
                body = (header(cfg, store, batch, run) + "<main>" + hero
                        + table(store, batch, run) + "</main>")
                self._send(page(body, refresh=2 if busy else 0))
            except Exception as e:                               # noqa: BLE001
                self._send(page("<main><div class='hero'><div class='a'>%s</div></div></main>"
                                % _esc(e)))

        def do_POST(self):
            ln = int(self.headers.get("Content-Length") or 0)
            form = parse_qs(self.rfile.read(ln).decode("utf-8"))
            what = (form.get("what") or [""])[0]
            batch = (form.get("batch") or [""])[0] or state["batch"]
            state["batch"] = batch

            # ---- snapshots: no Salesforce, no Goose, no network at all
            if what == "view":
                state["run"] = (form.get("run") or [""])[0]
                self._redirect(); return
            if what == "save_snap":
                rid = (form.get("run") or [""])[0] or store.latest_run_id(batch)
                jobs.start("Saving snapshot",
                           lambda j, _r=rid: _save_snap(store, _r, j.say))
                self._redirect(); return
            if what == "load_snap":
                jobs.start("Loading snapshots", lambda j: _load_snaps(store, j.say))
                self._redirect(); return

            if what == "saveconfig":
                import selfpage
                changed, errs = selfpage.apply_config(cfg, cfg_path or "config.json", form)
                msg = ("Not saved: " + " ".join(errs)) if errs else \
                    ("Saved: %s. Takes effect on the next run." % ", ".join(changed) if changed else "Nothing changed.")
                self.send_response(303)
                self.send_header("Location", "/selftest?msg=%s" % quote(msg))
                self.end_headers(); return

            # ---- everything below queries the org
            if what == "batches":
                jobs.start("Finding batches", lambda j: actions.refresh_batches(cfg, store, j.say))
            elif what == "selftest":
                jobs.start("Self-test", lambda j: actions.run_selftest(cfg, store, batch, j.say))
                self.send_response(303)
                self.send_header("Location", "/selftest")
                self.end_headers(); return
            elif what == "populate":
                jobs.start("Loading all batches",
                           lambda j: actions.run_populate(cfg, store, None, j.say))
            elif what == "gate":
                state["run"] = ""
                jobs.start("Checking %s" % batch,
                           lambda j: actions.run_gate(cfg, store, batch, "", j.say))
            elif what == "report":
                jobs.start("Building spreadsheet",
                           lambda j: actions.run_report(cfg, store, batch, ".", j.say))
            self._redirect()

    # An older instance left running holds the port, the new one cannot bind, and the
    # browser then shows the OLD code -- which looks exactly like "the fix did not work".
    # Find a free port instead of failing, and say plainly which one is being used.
    import socket
    srv = None
    first = port
    for p_try in range(port, port + 12):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p_try), H)
            port = p_try
            break
        except OSError:
            continue
    if srv is None:
        raise SystemExit("Ports %d-%d are all in use. Close the other MCC - Preflight Monitoring Tool "
                         "windows and try again." % (first, first + 11))

    url = "http://127.0.0.1:%d/" % port
    print()
    print("=" * 62)
    print("  MCC - Preflight Monitoring Tool  v%s" % VERSION)
    print("  %s" % url)
    if port != first:
        print()
        print("  NOTE: port %d was busy -- another MCC - Preflight Monitoring Tool is still" % first)
        print("  running in a different window. THIS window is serving the")
        print("  current version on port %d. Close the older window to avoid" % port)
        print("  looking at stale results.")
    print("=" * 62)
    print()
    threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
