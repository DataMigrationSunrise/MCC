"""
The runner owns the verdict. Checks return evidence; they never decide PASS.

THE EVIDENCE INVARIANT
    rows > 0                                     -> FAIL   (problem-finding check)
    rows == 0  AND canary returned rows          -> PASS
    rows == 0  AND canary returned nothing       -> UNPROVEN   <- the scope is broken
    required field missing / query errored       -> UNPROVEN

Zero rows can never become PASS on its own. That single rule is the structural form of the
discipline the Sunrise preflight applies by hand per checkpoint -- and applies inconsistently,
since four of its thirteen checkpoints emit a fixed status without running a query at all.
"""
from __future__ import annotations
import threading
import time
import traceback
from datetime import datetime, timezone

import baseline as bl
import connections as cx
from model import (Check, Evidence, Result, PASS, FAIL, UNPROVEN, BLOCKER)

TOOL_VERSION = "0.32.0"   # single source: server.py reads this; test_offline checks it matches the newest WHAT_CHANGED file


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def run_check(chk: Check, conn: cx.Conn, store=None) -> Result:
    t0 = time.time()
    res = Result(check_id=chk.id, batch=conn.batch, verdict=UNPROVEN, ran_at=_now())

    # --- precondition: required systems
    if chk.needs_goose and not conn.goose_ok:
        res.reason = "GOOSE UNAVAILABLE -- not skipped, not passed. This check needs Goose."
        res.duration_ms = int((time.time() - t0) * 1000)
        return res
    if chk.needs_sunrise and not conn.sunrise_run:
        res.reason = ("No Sunrise preflight output found to cross-check against. "
                      "Run the Sunrise preflight first, or accept this as unproven.")
        res.duration_ms = int((time.time() - t0) * 1000)
        return res

    # --- precondition: required fields must exist AND be visible (FLS applies)
    missing = [f for f in chk.requires if not conn.has_field(f)]
    if missing:
        # "absent or FLS-hidden" is where most people stop, and it is a dead end: the two
        # causes need opposite fixes and a describe cannot tell them apart, because a
        # restricted profile's describe simply omits a hidden field. Where the SAME concept
        # is visible on a related object, that is strong evidence the field exists and is
        # merely hidden here -- which turns "this check cannot run" into "grant read on
        # these and re-run".
        res.reason = ("Required field(s) absent or hidden by field-level security: %s. "
                      "Reporting UNPROVEN rather than a silent zero.%s"
                      % (", ".join(missing), _fls_hint(conn, missing)))
        res.duration_ms = int((time.time() - t0) * 1000)
        return res

    # --- the check itself
    begin = getattr(conn, "audit_begin", None)
    if begin:
        begin(chk.id)                       # keep every query it sends, for verify.py
    try:
        ev: Evidence = chk.run(conn)
    except Exception as e:                                  # noqa: BLE001
        res.reason = "Check raised %s: %s" % (type(e).__name__, str(e)[:600])
        res.duration_ms = int((time.time() - t0) * 1000)
        return res
    finally:
        end = getattr(conn, "audit_end", None)
        if end:
            end()

    if ev.unprovable:
        res.reason = ev.unprovable
        res.metric = ev.metric
        # A check can fail to PROVE something and still have established how many records
        # it looked at. Keeping that is the difference between "unproven" and "no idea".
        res.processed = ev.examined
        _carry_window(res, ev)
        res.duration_ms = int((time.time() - t0) * 1000)
        return res

    res.evidence_count = ev.count          # ERRORS
    res.processed = ev.examined            # records EXAMINED
    res.evidence_sample = ev.rows           # every offending record is kept
    res.metric = ev.metric
    _carry_window(res, ev)

    # --- THE EVIDENCE INVARIANT
    if chk.finds_problems:
        if ev.count > 0:
            res.verdict = FAIL
            res.reason = ev.note or "%d row(s) found." % ev.count
        else:
            canary_n, canary_err = _canary(chk, conn)
            if canary_err:
                res.reason = "Zero rows, and the canary could not run (%s). Scope unverified." % canary_err
            elif canary_n > 0:
                res.verdict = PASS
                res.reason = ev.note or ("Zero rows, and the canary found %d record(s), so the "
                                         "query could have found something." % canary_n)
            else:
                res.reason = ("Zero rows AND the canary found nothing. The scope is almost certainly "
                              "broken -- this is NOT a clean result.")
    else:
        # healthy-population check: emptiness is the problem. Its rows are the HEALTHY
        # records, so "0 row(s) found" reads as a clean result when it is the opposite --
        # which is why this branch never reports a bare row count.
        if ev.count > 0:
            res.verdict = PASS
            res.reason = ev.note or "%d record(s) present." % ev.count
        else:
            res.verdict = FAIL
            res.reason = ev.note or ("Expected a population here and found NONE. This check "
                                     "measures presence, so empty is the failure.")

    # --- baseline
    if store is not None and res.metric is not None and res.verdict != UNPROVEN:
        hist = store.metric_history(chk.id, exclude_batch=conn.batch)
        res.baseline = bl.compare(res.metric, hist, higher_is_better=not chk.finds_problems)

    res.duration_ms = int((time.time() - t0) * 1000)
    return res


# Objects to look at when a field is not visible, in the order a person would try them.
_SIBLINGS = ("Account", "Contract", "Order", "SBQQ__Quote__c")


def _fls_hint(conn, missing) -> str:
    """
    If the same field name is visible on a RELATED object, say so.

    A field present on Account and Contract but not on Quote is far more likely to be
    hidden by field-level security on one object than to be genuinely absent from the org.
    Saying which sibling carries it turns an unanswerable message into a next step.
    """
    found = []
    for dotted in missing:
        obj, _, fld = str(dotted).partition(".")
        for other in _SIBLINGS:
            if other == obj:
                continue
            try:
                if conn.has_field("%s.%s" % (other, fld)):
                    found.append("%s is visible on %s" % (fld, other))
                    break
            except Exception:                                # noqa: BLE001
                continue
    if not found:
        return (" None of these is visible on a related object either, so they may genuinely "
                "be absent from this org rather than hidden.")
    return (" BUT: %s. The same field on a sibling object means this is very likely "
            "FIELD-LEVEL SECURITY on your profile, not a missing field -- grant read and "
            "re-run. To settle it, run in anonymous Apex: "
            "Schema.SObjectType.<Object>.fields.getMap().get('<Field>') -- null means NOT IN "
            "THIS ORG, non-null means it exists and isAccessible() tells you about FLS."
            % "; ".join(found[:4]))


def _carry_window(res: Result, ev: Evidence):
    """When the validated work ran, as opposed to when we checked it."""
    res.ran_from, res.ran_to = ev.ran_from, ev.ran_to
    res.run_status, res.run_source = ev.run_status, ev.run_source


def _canary(chk: Check, conn: cx.Conn):
    if chk.canary is None:
        return 0, "no canary defined"
    # The self-test already ran every canary this run. Same query, same connection, same
    # moment -- running it again just costs another `sf` process.
    cache = getattr(conn, "canary_cache", None)
    if cache is not None and chk.id in cache:
        return int(cache[chk.id] or 0), ""
    try:
        n = int(chk.canary(conn) or 0)
        if cache is not None:
            cache[chk.id] = n
        return n, ""
    except Exception as e:                                  # noqa: BLE001
        return 0, "%s: %s" % (type(e).__name__, str(e)[:200])


def run_pack(checks: list[Check], conn: cx.Conn, store, run_id: str,
             progress=None) -> list[Result]:
    """
    Run every check and persist each result.

    Checks are independent and spend nearly all their time waiting on a `sf` subprocess, so
    they run on a small pool. Results come back in REGISTRY order regardless of completion
    order, because the run book is read in order and a shuffled list would be unreadable.
    Set "Workers": 1 in config.json to go back to strictly serial.
    """
    n = max(1, int(getattr(conn, "workers", 1) or 1))
    if n == 1:
        results = []
        for i, chk in enumerate(checks, 1):
            if progress:
                progress(i, len(checks), chk)
            r = run_check(chk, conn, store)
            store.save_result(run_id, r)
            results.append(r)
        return results

    done = [0]
    lock = threading.Lock()

    def one(chk):
        r = run_check(chk, conn, store)
        store.save_result(run_id, r)          # Store serialises its own writes
        with lock:
            done[0] += 1
            if progress:
                progress(done[0], len(checks), chk)
        return r

    out = cx.parallel(one, checks, n)
    results = []
    for chk, r in zip(checks, out):
        if isinstance(r, Exception):
            r = Result(check_id=chk.id, batch=conn.batch, verdict=UNPROVEN,
                       reason="Check runner raised %s: %s" % (type(r).__name__, str(r)[:300]),
                       ran_at=_now())
            store.save_result(run_id, r)
        results.append(r)
    return results


def check_fixtures(store, batch: str, results: list[Result]) -> list[dict]:
    """
    A checker with no regression suite rots silently. If a known defect stops being found,
    the tool says so and asks -- it never decides on its own that it was fixed.
    """
    by_id = {r.check_id: r for r in results}
    out = []
    for f in store.fixtures():
        if f["batch"] != batch:
            continue
        r = by_id.get(f["check_id"])
        if r is None:
            out.append(dict(check_id=f["check_id"], batch=batch, state="NOT_RUN",
                            message="Fixture exists but the check did not run this time."))
            continue
        exp, got = int(f["expected_count"] or 0), r.evidence_count
        if r.verdict == UNPROVEN:
            state, msg = "UNPROVEN", "Check could not run: %s" % r.reason
        elif got == exp:
            state, msg = "PRESENT", "Still %d, as recorded. The check works; the defect is unfixed." % got
        elif got == 0:
            state, msg = ("FIXED_OR_BROKEN",
                          "Expected %d and found 0. EITHER the defect was fixed OR this check "
                          "broke. The tool will not guess -- confirm which, then update the "
                          "fixture." % exp)
        else:
            state, msg = "CHANGED", "Expected %d, found %d (delta %+d)." % (exp, got, got - exp)
        store.set_fixture_state(f["check_id"], batch, state)
        out.append(dict(check_id=f["check_id"], batch=batch, state=state, message=msg,
                        expected=exp, actual=got))
    return out


def coverage_audit(checks: list[Check], spine: list[tuple[int, str]]) -> list[dict]:
    """
    'What am I not looking at?' -- mechanism 7. A tool that cannot name its blind spots
    will eventually be trusted for something it never checked.
    """
    by_obj = {}
    for c in checks:
        by_obj.setdefault(c.sobject, []).append(c)
    out = []
    for seq, obj in spine:
        lst = by_obj.get(obj, [])
        out.append(dict(sequence=seq, sobject=obj, checks=len(lst),
                        ids=[c.id for c in lst],
                        gap=(len(lst) == 0)))
    return out


def verdict_summary(results: list[Result]) -> dict:
    """
    Deliberately NOT a single health score. A single number invites exactly the
    'LIVE CLEAN' failure this tool exists to prevent.
    """
    blockers = [r for r in results if r.verdict == FAIL]
    unproven = [r for r in results if r.verdict == UNPROVEN]
    passed = [r for r in results if r.verdict == PASS]
    outliers = [r for r in results if r.baseline and r.baseline.cls == "OUTLIER"]
    return dict(
        total=len(results),
        failed=len(blockers), unproven=len(unproven), passed=len(passed),
        outliers=len(outliers),
        failed_ids=[r.check_id for r in blockers],
        unproven_ids=[r.check_id for r in unproven],
        outlier_ids=[r.check_id for r in outliers],
    )
