"""Link batch Accounts/Contacts that already exist in Salesforce from an earlier batch.

PL_07 can skip a customer that an earlier batch already created (e.g. UMB-0119) without
writing the existing Salesforce Id back to Goose. Those rows keep a blank SalesforceAccountID /
SalesforceContactID, the quote views drop them, and tf_30_Quotes loops forever on
"quotes not synced".

Rule: only an exact, unique match is linked.
    Account  = Name + BillingStreet + BillingPostalCode (exactly one Salesforce Account)
    Contact  = linked AccountId + FirstName + LastName + Email (exactly one Salesforce Contact)
Every link is journalled before the write and logged MCC_FIXED in GOOSE_ErrorLog. Anything
ambiguous is left alone and reported.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from . import fixlog


def _q(v) -> str:
    return "'" + str(v or "").replace("\\", "\\\\").replace("'", "\\'") + "'"


def _norm(v) -> str:
    return " ".join(str(v or "").upper().split())


def _rows(goose, sql):
    return [r for s in goose.result_sets(sql) for r in s if isinstance(r, dict)]


def _journal(path: Path, **kw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(dict(time=datetime.now().isoformat(), **kw), default=str) + "\n")


def unsynced_quotes(goose, batch_id: int) -> list[dict]:
    return _rows(goose, "SELECT Q.ID, A.Name FROM dbo.SFDC_Quote Q LEFT JOIN dbo.SFDC_Account A "
                        "ON A.ID = Q.SFDC_AccountID_SBQQ__Account__c WHERE Q.MigrationBatchID = %d "
                        "AND ISNULL(Q.SalesforceQuoteID,'') = ''" % int(batch_id))


def unsynced(goose, batch_id: int, table: str, id_col: str) -> tuple[list[int], int]:
    """(unsynced row IDs, synced row count) for one SFDC_ staging table in the batch."""
    t, col = _ident(table), _ident(id_col)
    rows = _rows(goose, "SELECT ID FROM dbo.%s WHERE MigrationBatchID = %d AND ISNULL(%s,'') = ''"
                        % (t, int(batch_id), col))
    done = _rows(goose, "SELECT COUNT(*) AS n FROM dbo.%s WHERE MigrationBatchID = %d AND ISNULL(%s,'') <> ''"
                        % (t, int(batch_id), col))
    return [int(r["ID"]) for r in rows], int(done[0]["n"]) if done else 0


def _ident(name: str) -> str:
    if not name.replace("_", "").isalnum():
        raise ValueError("Unsafe identifier %r" % name)
    return name


def pull_rows(goose, batch_id: int, folder: Path, step: str, table: str, id_col: str, ids: list[int],
              reason: str) -> int:
    """Remove stuck rows of one SFDC_ table from the batch (MigrationBatchID -> NULL), log MCC_EXCLUDED."""
    batch_id, t, col = int(batch_id), _ident(table), _ident(id_col)
    if not ids:
        return 0
    journal = folder / "preflight" / "link_existing.jsonl"
    _journal(journal, status="PULL_ATTEMPT", batch_id=batch_id, table=t, ids=ids, reason=reason)
    goose.result_sets("SET XACT_ABORT ON; BEGIN TRANSACTION; UPDATE dbo.%s SET MigrationBatchID = NULL "
                      "WHERE MigrationBatchID = %d AND ID IN (%s) AND ISNULL(%s,'') = ''; "
                      "SELECT 1 AS Done; COMMIT TRANSACTION;" % (t, batch_id, ",".join(map(str, ids)), col))
    _journal(journal, status="PULLED", table=t, ids=ids)
    fixlog.write(goose, batch_id, [fixlog.entry(
        "MCC_EXCLUDED", step, t, i,
        "MCC EXCLUDED %s row from batch %d: %s; restore by setting MigrationBatchID = %d"
        % (t, batch_id, reason, batch_id), t.replace("SFDC_", "")) for i in ids],
        folder / "preflight" / "goose_fixlog.jsonl")
    return len(ids)


def pull_empty_quotes(goose, sf, batch_id: int, sf_batch_id: str, folder: Path, step: str, say=print) -> int:
    """Untag (Salesforce) and pull (Goose) batch quotes that have zero lines in BOTH systems."""
    batch_id = int(batch_id)
    sf_quotes = sf.query("SELECT Id, Name FROM SBQQ__Quote__c WHERE USS_Migration_Batch__c = '%s' "
                         "AND Id NOT IN (SELECT SBQQ__Quote__c FROM SBQQ__QuoteLine__c "
                         "WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s')" % (sf_batch_id, sf_batch_id))
    if not sf_quotes:
        return 0
    by_sf = {q["Id"]: q["Name"] for q in sf_quotes}
    rows = _rows(goose, "SELECT Q.ID, Q.SalesforceQuoteID FROM dbo.SFDC_Quote Q WHERE Q.MigrationBatchID = %d "
                        "AND Q.SalesforceQuoteID IN (%s) AND NOT EXISTS (SELECT 1 FROM dbo.SFDC_Quote_Line L "
                        "WHERE L.SFDC_QuoteId_SBQQ__Quote__c = Q.ID)"
                 % (batch_id, ",".join("'%s'" % i for i in by_sf)))
    # Only quotes empty in Goose too; a quote with Goose lines that did not load is a real failure.
    target = {r["SalesforceQuoteID"]: int(r["ID"]) for r in rows}
    if not target:
        return 0
    journal = folder / "preflight" / "link_existing.jsonl"
    _journal(journal, status="EMPTYQ_ATTEMPT", batch_id=batch_id, quotes=target)
    ids = "', '".join(target)
    res = sf.run_apex(
        "List<SBQQ__Quote__c> qs = [SELECT Id, USS_Migration_Batch__c, (SELECT Id FROM SBQQ__LineItems__r LIMIT 1) "
        "FROM SBQQ__Quote__c WHERE Id IN ('%s')]; Integer ok = 0; "
        "for (SBQQ__Quote__c q : qs) if (q.USS_Migration_Batch__c == '%s' && q.SBQQ__LineItems__r.isEmpty()) "
        "{ q.USS_Migration_Batch__c = null; ok++; } "
        "if (ok != %d) { System.debug(LoggingLevel.ERROR, 'EMPTYQ STOP ' + ok); return; } "
        "update qs; System.debug(LoggingLevel.ERROR, 'EMPTYQ COMMITTED untagged=' + ok);"
        % (ids, sf_batch_id, len(target)))
    if "EMPTYQ COMMITTED" not in "\n".join(res.get("debug") or []):
        say("      Empty-quote pull not committed in Salesforce; nothing changed")
        return 0
    goose.result_sets("SET XACT_ABORT ON; BEGIN TRANSACTION; UPDATE dbo.SFDC_Quote SET MigrationBatchID = NULL "
                      "WHERE MigrationBatchID = %d AND ID IN (%s); SELECT 1 AS Done; COMMIT TRANSACTION;"
                      % (batch_id, ",".join(map(str, target.values()))))
    _journal(journal, status="EMPTYQ_PULLED", quotes=target)
    fixlog.write(goose, batch_id, [fixlog.entry(
        "MCC_EXCLUDED", step, "SFDC_Quote", row,
        "MCC EXCLUDED %s (%s) from batch %d: zero quote lines in source; USS_Migration_Batch__c cleared in "
        "Salesforce. Restore: MigrationBatchID = %d and USS_Migration_Batch__c = %s"
        % (by_sf[sfid], sfid, batch_id, batch_id, sf_batch_id), "Quote") for sfid, row in target.items()],
        folder / "preflight" / "goose_fixlog.jsonl")
    say("      Pulled %d empty quote(s) from the batch (MCC_EXCLUDED): %s"
        % (len(target), ", ".join(by_sf[i] for i in target)))
    return len(target)


def pull_quotes(goose, batch_id: int, folder: Path, step: str, rows: list[dict], reason: str) -> int:
    """Remove unsynced quotes from the batch (MigrationBatchID -> NULL) and log MCC_EXCLUDED."""
    batch_id = int(batch_id)
    ids = [int(r["ID"]) for r in rows]
    if not ids:
        return 0
    journal = folder / "preflight" / "link_existing.jsonl"
    _journal(journal, status="PULL_ATTEMPT", batch_id=batch_id, quotes=ids, reason=reason)
    goose.result_sets("SET XACT_ABORT ON; BEGIN TRANSACTION; UPDATE dbo.SFDC_Quote SET MigrationBatchID = NULL "
                      "WHERE MigrationBatchID = %d AND ID IN (%s) AND ISNULL(SalesforceQuoteID,'') = ''; "
                      "SELECT 1 AS Done; COMMIT TRANSACTION;" % (batch_id, ",".join(map(str, ids))))
    _journal(journal, status="PULLED", quotes=ids)
    fixlog.write(goose, batch_id, [fixlog.entry(
        "MCC_EXCLUDED", step, "SFDC_Quote", r["ID"],
        "MCC EXCLUDED quote from batch %d: %s %s; restore by setting MigrationBatchID = %d"
        % (batch_id, r.get("Name") or "", reason, batch_id), "Quote") for r in rows],
        folder / "preflight" / "goose_fixlog.jsonl")
    return len(ids)


def link(goose, sf, batch_id: int, folder: Path, step: str, apply: bool = True, say=print) -> dict:
    batch_id = int(batch_id)
    journal = folder / "preflight" / "link_existing.jsonl"
    accts = _rows(goose, "SELECT ID, Name, BillingStreet, BillingPostalCode FROM dbo.SFDC_Account "
                         "WHERE MigrationBatchID = %d AND ISNULL(SalesforceAccountID,'') = ''" % batch_id)
    out = dict(accounts_blank=len(accts), accounts_linked=0, contacts_linked=0, ambiguous=[])
    logs = []
    unresolved = []
    for a in accts:
        # Compare street/zip in Python: multi-line streets ("...DR\nSUITE #309") never match a SOQL '='.
        hits = [h for h in sf.query("SELECT Id, BillingStreet, BillingPostalCode FROM Account WHERE Name = %s"
                                    % _q(a["Name"]))
                if _norm(h.get("BillingStreet")) == _norm(a["BillingStreet"])
                and _norm(h.get("BillingPostalCode")) == _norm(a["BillingPostalCode"])]
        if len(hits) != 1:
            out["ambiguous"].append("Account %s %s: %d match(es)" % (a["ID"], a["Name"], len(hits)))
            unresolved.append((int(a["ID"]), a["Name"], len(hits)))
            continue
        sf_acct = hits[0]["Id"]
        contacts = _rows(goose, "SELECT ID, FirstName, LastName, Email FROM dbo.SFDC_Contact "
                                "WHERE MigrationBatchID = %d AND SFDC_AccountID = %d "
                                "AND ISNULL(SalesforceContactID,'') = ''" % (batch_id, int(a["ID"])))
        sf_contacts = sf.query("SELECT Id, FirstName, LastName, Email FROM Contact WHERE AccountId = '%s'" % sf_acct)
        pairs = []
        for c in contacts:
            m = [x for x in sf_contacts
                 if (x.get("FirstName") or "").strip().lower() == (c["FirstName"] or "").strip().lower()
                 and (x.get("LastName") or "").strip().lower() == (c["LastName"] or "").strip().lower()
                 and (x.get("Email") or "").strip().lower() == (c["Email"] or "").strip().lower()]
            if len(m) == 1:
                pairs.append((int(c["ID"]), m[0]["Id"]))
            else:
                out["ambiguous"].append("Contact %s (account %s): %d match(es)" % (c["ID"], a["Name"], len(m)))
        if not apply:
            out["accounts_linked"] += 1
            out["contacts_linked"] += len(pairs)
            continue
        _journal(journal, status="LINK_ATTEMPT", batch_id=batch_id, account=a["ID"], sf_account=sf_acct, contacts=pairs)
        sets = ["UPDATE dbo.SFDC_Account SET SalesforceAccountID = N'%s' WHERE ID = %d AND MigrationBatchID = %d "
                "AND ISNULL(SalesforceAccountID,'') = '';" % (sf_acct, int(a["ID"]), batch_id)]
        sets += ["UPDATE dbo.SFDC_Contact SET SalesforceContactID = N'%s' WHERE ID = %d AND MigrationBatchID = %d "
                 "AND ISNULL(SalesforceContactID,'') = '';" % (sfc, cid, batch_id) for cid, sfc in pairs]
        goose.result_sets("SET XACT_ABORT ON; BEGIN TRANSACTION; " + " ".join(sets) +
                          " SELECT 1 AS Done; COMMIT TRANSACTION;")
        _journal(journal, status="LINKED", account=a["ID"])
        out["accounts_linked"] += 1
        out["contacts_linked"] += len(pairs)
        logs.append(fixlog.entry("MCC_FIXED", step, "SFDC_Account", a["ID"],
                                 "MCC FIX existing account: SalesforceAccountID blank -> %s (matched Name+Street+Zip, "
                                 "created by earlier batch); %d contact(s) linked" % (sf_acct, len(pairs)), "Account"))
        logs += [fixlog.entry("MCC_FIXED", step, "SFDC_Contact", cid,
                              "MCC FIX existing contact: SalesforceContactID blank -> %s (matched Account+Name+Email)" % sfc,
                              "Contact") for cid, sfc in pairs]
    # No unique Salesforce match: pull that account's unsynced quotes out of the batch so the
    # quote loop can finish. Reversible: the original batch is in the journal and GOOSE_ErrorLog.
    out["quotes_pulled"] = 0
    if apply and unresolved:
        for acct_id, name, n in unresolved:
            qs = _rows(goose, "SELECT ID FROM dbo.SFDC_Quote WHERE MigrationBatchID = %d "
                              "AND SFDC_AccountID_SBQQ__Account__c = %d AND ISNULL(SalesforceQuoteID,'') = ''"
                       % (batch_id, acct_id))
            ids = [int(q["ID"]) for q in qs]
            if not ids:
                continue
            _journal(journal, status="PULL_ATTEMPT", batch_id=batch_id, account=acct_id, quotes=ids)
            goose.result_sets("SET XACT_ABORT ON; BEGIN TRANSACTION; UPDATE dbo.SFDC_Quote SET MigrationBatchID = NULL "
                              "WHERE MigrationBatchID = %d AND ID IN (%s) AND ISNULL(SalesforceQuoteID,'') = ''; "
                              "SELECT 1 AS Done; COMMIT TRANSACTION;" % (batch_id, ",".join(map(str, ids))))
            _journal(journal, status="PULLED", account=acct_id, quotes=ids)
            out["quotes_pulled"] += len(ids)
            logs += [fixlog.entry("MCC_EXCLUDED", step, "SFDC_Quote", qid,
                                  "MCC EXCLUDED quote from batch %d: account %s (%s) has %d Salesforce match(es) "
                                  "by Name+Street+Zip; restore by setting MigrationBatchID = %d"
                                  % (batch_id, acct_id, name, n, batch_id), "Quote") for qid in ids]
    if logs:
        fixlog.write(goose, batch_id, logs, folder / "preflight" / "goose_fixlog.jsonl")
    say("      Existing-record link: %(accounts_linked)d of %(accounts_blank)d blank account(s), "
        "%(contacts_linked)d contact(s) linked" % out + ("; %d ambiguous left alone" % len(out["ambiguous"])
                                                          if out["ambiguous"] else ""))
    return out
