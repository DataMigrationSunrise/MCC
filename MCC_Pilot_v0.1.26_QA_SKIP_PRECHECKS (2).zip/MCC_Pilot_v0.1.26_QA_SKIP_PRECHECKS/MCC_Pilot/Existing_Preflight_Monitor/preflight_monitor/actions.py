"""
The actual work, callable from BOTH the CLI and the browser.

Every function takes a `say(msg, percent)` callback so the browser can show progress
without the work knowing anything about HTTP.
"""
from __future__ import annotations
from pathlib import Path

import connections as cx
import registry
import runner
import selftest as st_mod
from store import new_run_id


def _noop(msg, percent=None):
    pass


def bind(cfg, say=_noop):
    ok, msg = cx.bind_sunrise(cfg.get("SunriseAppDir", ""))
    say(("Sunrise: " if ok else "Sunrise (degraded): ") + msg)
    return ok


def run_selftest(cfg, store=None, batch="", say=_noop, quick=False, quiet=False):
    bind(cfg, say)
    say("running %s" % ("connection check" if quick else "self-test"), 10)
    conn = cx.Conn(cfg, batch or "")
    st = st_mod.run(cfg, conn, batch or "", store, quick=quick)
    if store is not None:
        try:
            store.save_last_selftest(st.stages, full=not quick)
        except Exception:                                    # noqa: BLE001
            pass
    if not quiet:
        bad = [s for s in st.stages if s["status"] not in ("OK", "SKIPPED")]
        say("self-test finished: %d stage(s), %d need attention. Open More > Self-test results."
            % (len(st.stages), len(bad)))
    # Fill the batch list whenever SALESFORCE ITSELF is reachable -- not only on a fully
    # passing self-test. Listing batches is one query and has nothing to do with the field
    # describes in stage 4, so a field problem must not hide the batches.
    sf_ok = any(s["stage"].startswith("2 salesforce") and s["status"] == "OK"
                for s in st.stages)
    if sf_ok and store is not None:
        try:
            found = discover_batches(conn, say)
            for b in found:
                store.upsert_batch(b["name"], b["sf_id"], b["goose_id"],
                                   b["sf_status"], b["goose_status"])
            say("%d batch(es) now selectable" % len(found))
        except Exception as e:                               # noqa: BLE001
            say("batch list not refreshed: %s" % str(e)[:120])

    if not quiet:
        say("self-test %s" % ("PASSED" if st.ok else "FAILED"), 100)
    return dict(ok=st.ok, stages=st.stages, conn=conn)


def discover_batches(conn, say=_noop):
    out = {}
    for r in conn.q("SELECT Id, Name, Batch_Status__c FROM USS_Migration_Batch__c ORDER BY Name"):
        out[r["Name"]] = dict(name=r["Name"], sf_id=r.get("Id"),
                              sf_status=r.get("Batch_Status__c"), goose_id="", goose_status="")
    say("Salesforce: %d batch(es)" % len(out))
    if conn.goose_ok:
        try:
            # Goose has no batch name. It links to Salesforce by SalesforceUssMigrationBatchID.
            g_rows = conn.gq("SELECT ID, BatchStatus, SalesforceUssMigrationBatchID "
                             "FROM dbo.MigrationBatch")
            by_sfid = {str(v["sf_id"]): k for k, v in out.items() if v.get("sf_id")}
            for g in g_rows:
                sfid = str(g.get("SalesforceUssMigrationBatchID") or "").strip()
                nm = by_sfid.get(sfid) or next(
                    (k for i, k in by_sfid.items() if sfid and i[:15] == sfid[:15]), "")
                if not nm:
                    continue          # a Goose batch Salesforce does not know has no name to show
                rec = out[nm]
                rec["goose_id"] = str(g.get("ID") or "")
                rec["goose_status"] = str(g.get("BatchStatus") or "")
            say("Goose: %d batch(es)" % len(g_rows))
        except Exception as e:                                   # noqa: BLE001
            say("Goose batch discovery failed: %s" % str(e)[:160])
    return sorted(out.values(), key=lambda x: x["name"])


def run_populate(cfg, store, only=None, say=_noop):
    res = run_selftest(cfg, store, "", say)
    if not res["ok"]:
        raise RuntimeError("Self-test failed -- refusing to populate. See the log above.")
    conn = res["conn"]

    batches = discover_batches(conn, say)
    if only:
        wanted = {b.strip() for b in only if b.strip()}
        batches = [b for b in batches if b["name"] in wanted]
    if not batches:
        raise RuntimeError("No batches found to populate.")
    say("populating %d batch(es): %s" % (len(batches), ", ".join(b["name"] for b in batches)), 5)

    checks = registry.all_checks()
    done = 0
    summary = []
    for b in batches:
        store.upsert_batch(b["name"], b["sf_id"], b["goose_id"], b["sf_status"], b["goose_status"])
        if b["sf_status"] and b["goose_status"] and \
           b["sf_status"].strip().lower() != b["goose_status"].strip().lower():
            say("! %s: Salesforce '%s' vs Goose '%s' -- they disagree"
                % (b["name"], b["sf_status"], b["goose_status"]))

        conn.batch = b["name"]
        rid = new_run_id()
        store.start_run(rid, b["name"], "POPULATE", runner.TOOL_VERSION, conn.alias,
                        conn.goose_server, conn.goose_ok, conn.sunrise_run)
        for s in res["stages"]:
            store.record_selftest(rid, s["stage"], s["status"], s["detail"])

        def prog(i, n, chk, _b=b):
            pct = 5 + 93 * ((done + i / max(1, n)) / len(batches))
            say("%s  [%d/%d] %s" % (_b["name"], i, n, chk.id), pct)

        results = runner.run_pack(checks, conn, store, rid, prog)
        store.finish_run(rid, res["ok"])
        s = runner.verdict_summary(results)
        summary.append(dict(batch=b["name"], **s))
        say("%s -- fail %d, unproven %d, pass %d, outliers %d"
            % (b["name"], s["failed"], s["unproven"], s["passed"], s["outliers"]))
        done += 1

    say("baseline built across %d batch(es)" % len(batches), 100)
    return summary


def run_gate(cfg, store, batch, stage="", say=_noop):
    if not batch:
        raise RuntimeError("A batch is required.")
    # The full self-test (every field describe, every canary) runs only when you press Self-test,
    # or when config.json sets "FullSelfTestOnRun": true. A run still confirms Salesforce, Goose,
    # the batch and the rules first -- the parts that would make every result meaningless.
    full = bool(cfg.get("FullSelfTestOnRun"))
    res = run_selftest(cfg, store, batch, say, quick=not full, quiet=True)
    if not res["ok"]:
        why = "; ".join("%s: %s" % (x["stage"], x["detail"][:160]) for x in res["stages"]
                        if x["status"] == "FAIL")
        raise RuntimeError("Not running: %s. Fix it under More > Self-test results." % why)
    conn = res["conn"]

    rid = new_run_id()
    store.start_run(rid, batch, "GATE", runner.TOOL_VERSION, conn.alias,
                    conn.goose_server, conn.goose_ok, conn.sunrise_run)
    for s in res["stages"]:
        store.record_selftest(rid, s["stage"], s["status"], s["detail"])
    if not full:
        taken, old = store.last_selftest()
        carried = [x for x in old if x["stage"][:1] in ("4", "6")]
        if carried:
            for x in carried:
                store.record_selftest(rid, x["stage"], x["status"],
                                      "(from the full self-test at %s) %s" % (taken[:16].replace("T", " "), x["detail"]))
        else:
            store.record_selftest(rid, "4 schema / 6 canaries", "SKIPPED",
                                  "Full self-test not run yet. Press Self-test (More menu) to run it.")

    checks = registry.by_stage(stage) if stage else registry.all_checks()
    say("running %d check(s) against %s" % (len(checks), batch), 20)
    results = runner.run_pack(
        checks, conn, store, rid,
        lambda i, n, c: say("[%d/%d] %s" % (i, n, c.id), 20 + 75 * i / max(1, n)))
    store.finish_run(rid, res["ok"])

    # A second opinion on every result: scope, query limits, duplicates, sample records
    # re-read from Salesforce, and whether the fields each check names exist. Never changes a
    # verdict and never blocks the run -- if it cannot run, the run book still stands.
    try:
        import verify as _verify
        say("verifying results against Salesforce", 95)
        store.save_verification(rid, _verify.verify_run(
            conn, checks, results, evidence_of=lambda cid: store.evidence(rid, cid)))
    except Exception as e:                                   # noqa: BLE001
        say("verification not run: %s" % str(e)[:160])

    # What actually landed, per object. Errors are summed from the results above rather
    # than re-queried, so the band can never disagree with the run book below it. The
    # furthest Run Order reached is passed in so an unstarted load is reported as PENDING
    # rather than counted as a failure.
    try:
        import tally as _tally
        import runbook as _rbk
        say("counting records per object", 96)
        reached = _rbk.progress(_rbk.readiness(store, batch, rid)).get("reached", 0)
        store.save_tally(rid, _tally.collect(conn, results, say, reached))
    except Exception as e:                                   # noqa: BLE001
        say("object tally not built: %s" % str(e)[:160])

    s = runner.verdict_summary(results)
    say("FAILED %d | UNPROVEN %d | PASSED %d | OUTLIERS %d"
        % (s["failed"], s["unproven"], s["passed"], s["outliers"]), 97)
    fx = runner.check_fixtures(store, batch, results)
    for f in fx:
        say("fixture %s %s -- %s" % (f["check_id"], f["state"], f["message"][:90]))
    say("done", 100)
    return dict(run_id=rid, summary=s, fixtures=fx)


def run_report(cfg, store, batch, out_dir=".", say=_noop):
    import report
    say("building workbook for %s" % batch, 30)
    p = report.build(store, batch, Path(out_dir))
    say("wrote %s" % p, 100)
    return str(p)


def run_runbook_export(cfg, store, batch, out_dir=".", say=_noop, run_id=""):
    import report
    say("building run book workbook for %s" % batch, 30)
    p = report.build_runbook(store, batch, Path(out_dir), run_id)
    say("wrote %s" % p, 100)
    return str(p)


def run_issues_export(cfg, store, batch, out_dir=".", say=_noop, run_id=""):
    import report
    say("building issues workbook for %s" % batch, 30)
    try:
        bind(cfg, say)
        conn = cx.Conn(cfg, batch)
    except Exception:                                        # noqa: BLE001
        conn = None
    p = report.build_issues(store, batch, Path(out_dir), run_id, cfg, conn)
    say("wrote %s" % p, 100)
    return str(p)


def seed_fixtures(store, say=_noop):
    n = 0
    for cid, batch, count, note in registry.fixtures():
        store.upsert_fixture(cid, batch, count, "PRESENT", note)
        say("seeded %s / %s = %d" % (cid, batch, count))
        n += 1
    say("%d fixture(s) seeded. When one is genuinely fixed, somebody must update it." % n, 100)
    return n


def refresh_batches(cfg, store, say=_noop):
    """Just list the batches. One query, no field describes, no self-test gate."""
    bind(cfg, say)
    conn = cx.Conn(cfg, "")
    ok, msg = cx.sf_test(conn.alias)
    say(msg)
    if not ok:
        raise RuntimeError(msg)
    try:
        conn.goose_ok, gmsg = cx.goose_test(conn.goose_server, conn.goose_db)
        say(gmsg)
    except Exception:                                        # noqa: BLE001
        conn.goose_ok = False
    found = discover_batches(conn, say)
    for b in found:
        store.upsert_batch(b["name"], b["sf_id"], b["goose_id"], b["sf_status"], b["goose_status"])
        if b["sf_status"] and b["goose_status"] and \
           b["sf_status"].strip().lower() != b["goose_status"].strip().lower():
            say("! %s: Salesforce '%s' vs Goose '%s'"
                % (b["name"], b["sf_status"], b["goose_status"]))
    say("%d batch(es) now in the dropdown" % len(found), 100)
    return found
