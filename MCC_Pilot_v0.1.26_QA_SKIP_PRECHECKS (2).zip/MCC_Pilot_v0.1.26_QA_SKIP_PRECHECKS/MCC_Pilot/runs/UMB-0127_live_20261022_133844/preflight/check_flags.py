"""Read-only: Has_Delivery/Has_Pickup flags and customer-owned lines, stuck vs succeeded orders."""
import json, sys, collections
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

B = 'aFOVD0000001Swj4AE'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = {o['id'][:15] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']}
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
rows = sf.query("SELECT Id, Has_Delivery__c, Has_Pickup__c, Order_Type__c, "
                "(SELECT CustomerOwned__c, Is_Power_Ancillary_Asset__c, Product_Type__c FROM OrderItems) "
                "FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)
groups = collections.defaultdict(collections.Counter)
for r in rows:
    g = 'stuck' if r['Id'][:15] in stuck else 'succeeded'
    items = (r.get('OrderItems') or {}).get('records') or []
    usable = [i for i in items if not i.get('CustomerOwned__c') or i.get('Is_Power_Ancillary_Asset__c')]
    groups[g]['orders'] += 1
    groups[g]['Has_Delivery=true'] += bool(r.get('Has_Delivery__c'))
    groups[g]['Has_Pickup=true'] += bool(r.get('Has_Pickup__c'))
    groups[g]['all lines customer-owned (no usable lines)'] += (len(items) > 0 and not usable)
    groups[g]['type ' + str(r.get('Order_Type__c'))] += 1
for g in ('stuck', 'succeeded'):
    print(g, dict(groups[g]))
