# Preflight Monitor v0.11.0 — dead map polygons

## New check: `FSL.DEAD_POLYGONS`, Run Order 2

A polygon pointing at a **deleted** ServiceTerritory silently blocks Work Order creation for
every site inside it, on **every batch**. The insert fails with
`INVALID_CROSS_REFERENCE_KEY`, `BatchContractOrders.finish()` swallows the error into
`Log__c`, and `Log__c` purges hourly — so TF_35, Script 5 and the Has_Service toggle all
report success and create nothing.

The 2026-10-01 reconciliation found **502** of them across **80 branch prefixes**. 501 are
still unfixed.

The check counts them and splits them three ways, the same way the handoff file does:

- **mechanical** — exact live name match, which RO 29 applies automatically (486)
- **inactive target** — the territory exists but `IsActive = false`. Repointing at it looks
  like a fix and solves nothing, so it is reported, never applied.
- **no match** — needs a person. The 12 legacy `Rt1`–`Rt14` route polygons belong here and
  should be retired, not repointed.

It declares the field it depends on, so a wrong or FLS-hidden API name reports UNPROVEN
instead of a silent zero. It blocks Run Orders 19, 25, 27 and 30.

**This is org-wide, not batch-specific** — which is why it sits at the pre-flight. UMB-0117
inherits it; so will UMB-0118.

## RO 29 script: progress reporting

`TF_90A.05_Repoint_Dead_Service_Territory_Polygons.apex`

- `MAX_UPDATES` raised from **50 to 200**. 486 mechanical fixes at 50 a run was ten passes
  with no way to tell a capped run from a finished one.
- Now reports **FIXABLE NOW / THIS RUN WILL WRITE / STILL BROKEN AFTER THIS RUN**, and says
  outright when more runs are needed. Re-run until `FIXABLE NOW` reaches 0.
- `MANUAL_OVERRIDES` for `TAC-D` and `GNV-B_2` are documented inline and verified against
  the handoff file — same polygon Ids, same targets. Still commented out; `TAC-D` is a
  structural inference and needs confirming first.
- The cases that need a decision rather than a repoint (`LKC-E`, `Rt1`–`Rt14`) are named in
  the header so nobody has to rediscover them.

## Why it matters right now

Dead polygons are **one of two** causes of a null `WorkOrder.ServiceTerritoryId`. The other
is an address that never geocoded (Run Order 15, added in v0.8.0).

**Once the territory is null the two are indistinguishable.** So RO 28 (`TF_90A.04`) must
split the populations *before* either is remediated — otherwise the polygon fix is applied
to records whose problem is a missing geocode, and appears to fail for no reason.

The Service Appointments created 2026-10-02 with no territory inherit it from their Work
Orders, and that null is what makes FSL optimization throw:

> *"These service territories aren't using Enhanced Scheduling and Optimization: {null}"*

The `{null}` is not a misconfigured territory. It is a missing one.

## Proof the mechanism is real

`SJO-P` was repointed on 2026-10-01. Orders **00753996** and **00754184** regenerated, and
their Work Orders came back on territory `SJO-P`. One polygon, two orders recovered.

## Also

- Run book **v43**; `runbook.json` re-synced from it.
- 49 checks. ~150 regression tests.
