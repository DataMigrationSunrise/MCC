"""Offline test: a resumed Informatica step reattaches to its saved run instead of starting a new one."""
import tempfile
from pathlib import Path
from types import SimpleNamespace

from . import app
from .engine import Run
from . import systems


class FakeInf:
    def __init__(self, known):
        self.known, self.started, self.watched = known, [], []

    def run(self, tf, timeout, say, on_run_id=None):
        self.started.append(tf)
        on_run_id("RUN-NEW")
        return dict(done=True, ok=True, status="SUCCESS", run_id="RUN-NEW")

    def watch(self, run_id, timeout, say):
        self.watched.append(run_id)
        return dict(done=True, ok=True, status="SUCCESS", run_id=run_id) if run_id in self.known else None


class FakeGoose:
    def result_sets(self, sql, timeout=600):
        return [[]]


def _run(folder, inf):
    cfg = dict(app.CFG)
    cfg["Informatica"] = dict(cfg.get("Informatica", {}), Mode="sunrise", Taskflows={"TF_25": "tf_25_test"})
    r = Run(cfg, "live", systems.build)
    r.folder, r.batch, r.say = folder, dict(name="UMB-TEST", goose_id=1, sf_id="aFO000000000000AAA"), lambda m: None
    c = SimpleNamespace(inf=inf, goose=FakeGoose(), sf=None)
    return r, c


def test_reattach():
    with tempfile.TemporaryDirectory() as td:
        folder = Path(td)
        (folder / "logs").mkdir()
        # 1. Fresh start: launches, checkpoints the run id, clears it once the outcome is known.
        inf = FakeInf(known={"RUN-OLD"})
        r, c = _run(folder, inf)
        s = dict(id="TF_25", name="test", ro="13", kind="informatica")
        status, _ = r._k_informatica(c, s)
        assert inf.started == ["tf_25_test"] and status == "DONE" and "inflight_run_id" not in s

        # 2. Resume with a saved in-flight run: reattaches, does NOT start a second copy.
        inf = FakeInf(known={"RUN-OLD"})
        r, c = _run(folder, inf)
        s = dict(id="TF_25", name="test", ro="13", kind="informatica", inflight_run_id="RUN-OLD")
        status, _ = r._k_informatica(c, s)
        assert inf.watched == ["RUN-OLD"] and inf.started == [] and status == "DONE"

        # 3. Saved run unknown to Informatica: falls back to starting a new run.
        inf = FakeInf(known=set())
        r, c = _run(folder, inf)
        s = dict(id="TF_25", name="test", ro="13", kind="informatica", inflight_run_id="RUN-GONE")
        status, _ = r._k_informatica(c, s)
        assert inf.watched == ["RUN-GONE"] and inf.started == ["tf_25_test"] and status == "DONE"
    print("reattach test: PASS (fresh start, reattach, fallback)")


if __name__ == "__main__":
    test_reattach()
