"""Spreadsheet output. Mirrors the dashboard, so a run can be mailed to someone without the tool."""
from __future__ import annotations
import json
from pathlib import Path

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import baseline as bl
import registry
import runbook as rbk
import terms
import jobruns

HDR = Font(name="Arial", bold=True, color="FFFFFF", size=10)
HFILL = PatternFill("solid", fgColor="1F3864")
BODY = Font(name="Arial", size=10)
BOLD = Font(name="Arial", bold=True, size=10)
RED = Font(name="Arial", bold=True, size=10, color="9C0006")
GRNF = Font(name="Arial", bold=True, size=10, color="375623")
WRAP = Alignment(vertical="top", wrap_text=True)
THIN = Border(*[Side(style="thin", color="BFBFBF")] * 4)
AMB = PatternFill("solid", fgColor="FFF2CC")
REDF = PatternFill("solid", fgColor="FCE4D6")
GRN = PatternFill("solid", fgColor="E2EFDA")

VFILL = {"FAIL": REDF, "UNPROVEN": AMB, "PASS": GRN}


def _sheet(wb, name, widths, headers, banner=""):
    ws = wb.create_sheet(name[:31])
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    r = 1
    if banner:
        c = ws.cell(row=1, column=1, value=banner)
        c.font = RED; c.fill = AMB
        c.alignment = Alignment(vertical="center", wrap_text=True)
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(1, len(headers)))
        ws.row_dimensions[1].height = 40
        r = 2
    for i, h in enumerate(headers, 1):
        c = ws.cell(row=r, column=i, value=h)
        c.font = HDR; c.fill = HFILL; c.alignment = WRAP; c.border = THIN
    ws.freeze_panes = ws.cell(row=r + 1, column=1).coordinate
    ws.auto_filter.ref = "A%d:%s%d" % (r, get_column_letter(len(headers)), r)
    return ws, r


def _put(ws, r, vals, fills=None):
    for i, v in enumerate(vals, 1):
        c = ws.cell(row=r, column=i, value=v)
        c.font = BODY; c.alignment = WRAP; c.border = THIN
        # a None fill must be skipped, not assigned -- openpyxl rejects it at save time,
        # which surfaces as an unrelated-looking stylesheet error much later
        if fills and fills.get(i) is not None:
            c.fill = fills[i]
    return r + 1


def build(store, batch: str, out_dir: Path, run_id: str = "") -> Path:
    run_id = run_id or store.latest_run_id(batch)
    if not run_id:
        raise SystemExit("No completed run for batch %s. Run `gate` or `populate` first." % batch)
    rows = store.results_for_run(run_id)
    wb = openpyxl.Workbook(); wb.remove(wb.active)

    # ---- verdict
    fail = [r for r in rows if r["verdict"] == "FAIL"]
    unp = [r for r in rows if r["verdict"] == "UNPROVEN"]
    out = [r for r in rows if r["baseline_class"] == "OUTLIER"]
    ws, hr = _sheet(wb, "Verdict", [44, 96], ["", ""],
                    banner="Deliberately NOT a single health score. A single number invites "
                           "exactly the 'LIVE CLEAN' failure this tool exists to prevent.")
    r = hr + 1
    for k, v, f in (("Batch", batch, None),
                    ("Run", run_id, None),
                    ("Checks run", len(rows), None),
                    ("FAILED", len(fail), REDF if fail else GRN),
                    ("UNPROVEN", len(unp), AMB if unp else GRN),
                    ("PASSED", len([x for x in rows if x["verdict"] == "PASS"]), None),
                    ("Cross-batch OUTLIERS", len(out), AMB if out else GRN)):
        c1 = ws.cell(row=r, column=1, value=k); c1.font = BOLD; c1.border = THIN
        c2 = ws.cell(row=r, column=2, value=v); c2.font = BODY; c2.border = THIN
        if f:
            c2.fill = f
        r += 1

    # ---- OBJECTS: what landed, and how much of it is wrong
    trows = store.tally(run_id)
    if trows:
        import tally as _tal
        tt = _tal.totals(trows)
        ws, hr = _sheet(wb, "Objects Loaded", [26, 14, 12, 13, 20, 20, 30, 46],
                        ["Object", "Loaded", "Failing", "State", "First created",
                         "Last modified", "Failing checks", "Note"],
                        banner=("%s record(s) across %d object(s), %s failing record(s). "
                                "Objects whose load step has not run are PENDING and count "
                                "ZERO failing -- an unstarted load is not a defect. "
                                "Accounts/Contacts/ACRs/Addresses are reached through this "
                                "batch's Quotes and are UPDATED, not created, so their "
                                "CreatedDate is old by design."
                                % ("{:,}".format(tt["loaded"]), tt["objects"],
                                   "{:,}".format(tt["errors"]))))
        r = hr + 1
        for x in trows:
            r = _put(ws, r, [x["label"], x["loaded"], x["errors"] or "", x["state"],
                             (x.get("first") or "")[:19], (x.get("modified") or "")[:19],
                             x.get("error_checks") or "", x.get("note") or ""],
                     {3: REDF if (x["errors"] or 0) else None,
                      4: AMB if x["state"] != "OK" else None})

    # ---- ALL ISSUES, worst first
    _rows_rb = rbk.readiness(store, batch, run_id)
    _pending = {x["sobject"] for x in trows if x.get("pending")}
    _items = rbk.issues(store, batch, run_id, _rows_rb, _pending)
    if _items:
        _ism = rbk.issue_summary(_items, rbk.ids_of_factory(store, run_id))
        ws, hr = _sheet(wb, "All Issues", [8, 11, 12, 34, 42, 12, 12, 58],
                        ["RO", "Type", "Severity", "Issue", "Step", "Records",
                         "Examined", "What to do"],
                        banner=("%d blocker(s), %d review, %d unproven. %s distinct record(s) "
                                "need a fix across %d step(s) and %d object(s)%s. Issues on "
                                "objects whose load step has not run are EXCLUDED."
                                % (_ism["blockers"], _ism["review"], _ism["unproven"],
                                   "{:,}".format(_ism["records"]), _ism["steps"],
                                   _ism["objects"],
                                   ("; counted separately: " + ", ".join(
                                       "%s %s" % ("{:,}".format(v), k)
                                       for k, v in _ism["other_units"].items()))
                                   if _ism.get("other_units") else "")))
        r = hr + 1
        for i in _items:
            r = _put(ws, r, [i["order"], i["kind"].title(), terms.sev(i["severity"]).title(), i["name"],
                             i["step"][:90],
                             "found none" if i["inverted"] else
                             (("%s %s" % ("{:,}".format(i["records"]), i.get("unit_many", "items")))
                              if (i["records"] and not i.get("is_record", True)) else (i["records"] or "")),
                             i["examined"] or "",
                             (("FIX AT RO %s: %s" % (i["fix_order"], i["fix"])) if i["fix"]
                              else i["reason"])[:600]],
                     {2: REDF if i["kind"] == "ISSUE" else AMB})

    # ---- FAILED RECORDS: one row per actual record, not a JSON sample
    import registry as _reg
    _by = {c.id: c for c in _reg.all_checks()}
    _recs = []
    for _r in rows:
        if _r["verdict"] != "FAIL":
            continue
        _c = _by.get(_r["check_id"])
        _ev = store.evidence(run_id, _r["check_id"])
        for _e in _ev:
            _recs.append((_r, _c, _e))
    if _recs:
        _keys, _seen = [], set()
        for _, _, _e in _recs:
            for k in _e.keys():
                if k not in _seen and len(_keys) < 10:
                    _seen.add(k); _keys.append(k)
        ws, hr = _sheet(wb, "Failed Records",
                        [9, 30, 34] + [22] * len(_keys) + [50],
                        ["RO", "Check", "Why it failed"] + _keys + ["Fix"],
                        banner=("Every individual record a check flagged, with the reason and "
                                "the fix. Counts in 'All Issues' are EXACT; this sheet holds "
                                "the retained sample, which is capped by EvidenceCap in "
                                "config.json. Where the two differ, the count is right and "
                                "this list is short."))
        r = hr + 1
        for _res, _c, _e in _recs:
            _rem = _c.remediation if _c else None
            r = _put(ws, r, [(_c.runbook_order if _c else ""), _res["check_id"],
                             (_res["reason"] or "")[:300]]
                            # columns are the union across every check, so a key that does
                            # not apply here must be BLANK, not the string "None"
                            + [("" if _e.get(k) is None else str(_e.get(k)))[:120]
                               for k in _keys]
                            + [(("RO %s: %s" % (_rem.runbook_order, _rem.summary))
                                if _rem else "")[:300]])

    # ---- RUN BOOK READINESS (first substantive tab: the operator's mental model)
    rows_rb = rbk.readiness(store, batch, run_id)
    sm = rbk.summary(rows_rb)
    ws, hr = _sheet(
        wb, "Runbook Readiness",
        [9, 14, 16, 44, 60, 12, 26, 26, 44, 60],
        ["Run Order", "Stage", "Action", "Step", "Script Purpose", "Status",
         "Record Count / Result", "Time", "Verification Method", "Next Action / What's in the way"],
        banner=("Stopped at Run Order %s -- %s.  %s failing record(s) across %d step(s); "
                "%d blocked, %d held (fix elsewhere), %d to review, %d of %d ready, "
                "%d UNPROVEN. UNPROVEN is not a pass.  "
                "'Examined' is how many records a check looked at; 'failing' is how many are "
                "wrong. Neither is records loaded.  'Time' is when the step RAN -- from the "
                "Informatica/SnapLogic API where captured, otherwise record timestamps, which "
                "are a proxy."
                % (sm["first_blocked_order"], sm["first_blocked_step"][:70],
                   "{:,}".format(sm["errors_total"]), sm["steps_with_errors"],
                   sm["blocked"], sm["held"], sm["review"],
                   sm["ready"], sm["total"], sm["unproven"]))
        if sm["first_blocked_order"] else
        ("No blocking step. %d ready, %d UNPROVEN, %d never checked. UNPROVEN is not a pass."
         % (sm["ready"], sm["unproven"], sm["not_checked"])))
    r = hr + 1
    SFILL = {"BLOCKED": REDF, "HELD": AMB, "REVIEW": AMB, "UNPROVEN": AMB, "READY": GRN}
    for x in rows_rb:
        bits = []
        for f in x["failing"]:
            bits.append("%s - %s. FIX AT RO %s: %s"
                        % (f["name"],
                           "found NONE (presence check)" if f["inverted"]
                           else "%d failing record(s) of %d examined" % (f["rows"], f["examined"]),
                           f["fix_order"], f["fix"]))
        for b in x["blocked_by"]:
            bits.append("HELD - fix at RO %s (%s, %d rows): %s" % (b["at"], b["name"], b["rows"], b["fix"]))
        for u in x["unproven"]:
            bits.append("UNPROVEN: %s" % u["reason"][:200])
        if x["blocker"]:
            bits.append("RUN BOOK NOTE: %s" % x["blocker"])

        cnt = []
        for c in x["counts"]:
            if c["verdict"] == "UNPROVEN":
                cnt.append("%s: not established" % c["check"])
            elif c["inverted"]:
                cnt.append("%s: %d found" % (c["check"], c["examined"]))
            else:
                cnt.append("%s: %d examined, %d failing" % (c["check"], c["examined"], c["errors"]))
        if x["held"] > x["errors"]:
            cnt.append("+%d held back by a blocker elsewhere" % (x["held"] - x["errors"]))

        tm = []
        for t in x["times"]:
            tm.append("%s%s%s" % (jobruns.pretty(t["frm"], t["to"]),
                                  "  %s" % t["status"] if t["status"] else "",
                                  "\n(%s)" % t["source"] if t["source"] else ""))

        r = _put(ws, r, [x["order"], x["stage"], x["action"], x["step"][:120],
                         (x["purpose"] or "")[:900], x["state"],
                         "\n".join(cnt)[:400] or "", "\n".join(dict.fromkeys(tm))[:260],
                         (x["verify"] or "")[:600], "\n".join(bits)[:900]],
                 {6: SFILL.get(x["state"])})

    # ---- BLOCKED RECORDS routed to their run book position
    routes = rbk.record_routing(store, batch, run_id)
    ws, hr = _sheet(wb, "Records Needing a Fix", [8, 34, 10, 8, 40, 10, 16, 64, 50],
                    ["Detected RO", "Check", "Records", "Fix RO", "Fix", "Writes",
                     "Approval", "Operator steps", "Sample"],
                    banner="Every failing record placed where it is DETECTED and where it gets "
                           "FIXED. A finding without a fix is a complaint.")
    r = hr + 1
    for x in routes:
        r = _put(ws, r, [x["detected_at"], x["check"], x["records"], x["fix_at"] or "",
                         x["fix_summary"], "YES" if x["fix_writes"] else "",
                         x["fix_approval"],
                         "\n".join("%d. %s" % (i, t) for i, t in enumerate(x["fix_steps"], 1))[:900],
                         json.dumps(x["sample"][:4], default=str)[:400]],
                 {6: REDF if x["fix_writes"] else None})

    # ---- results
    ws, hr = _sheet(wb, "Checks", [30, 34, 10, 10, 12, 22, 14, 46, 46, 46],
                    ["Check", "Name", "Stage", "Verdict", "Rows", "Metric", "Baseline",
                     "Why", "Proves", "Cannot prove"])
    r = hr + 1
    for row in rows:
        chk = registry.by_id(row["check_id"])
        metric = ""
        if row["metric_value"] is not None:
            metric = ("%.1f%% (%s/%s)" % (row["metric_value"] * 100, row["metric_num"],
                                          row["metric_den"])
                      if row["metric_unit"] == "ratio" else "%g" % row["metric_value"])
        r = _put(ws, r, [row["check_id"], chk.name if chk else "", row["batch"] and
                         (chk.stage if chk else ""), row["verdict"], row["evidence_count"],
                         metric, row["baseline_class"] or "",
                         (row["reason"] or "")[:900],
                         chk.proves if chk else "", chk.cannot_prove if chk else ""],
                 {4: VFILL.get(row["verdict"])})

    # ---- baseline matrix
    batches = [b["name"] for b in store.batches()]
    cids = [c.id for c in registry.all_checks()]
    mx = bl.matrix(store, cids, batches)
    ws, hr = _sheet(wb, "Baseline", [34] + [14] * len(batches), ["Check"] + batches,
                    banner="4.7%% is not a finding. 4.7%% against 97.4%% and 100%% is. "
                           "Blank = that batch has no result for that check.")
    r = hr + 1
    for cid in cids:
        vals = [cid]
        fills = {}
        for i, b in enumerate(batches, 2):
            cell = mx[cid].get(b)
            if not cell:
                vals.append("")
                continue
            if cell["metric"] is not None and cell["unit"] == "ratio":
                vals.append("%.1f%%" % (cell["metric"] * 100))
            elif cell["metric"] is not None:
                vals.append("%g" % cell["metric"])
            else:
                vals.append(cell["verdict"])
            if cell["baseline"] == "OUTLIER":
                fills[i] = AMB
            elif cell["verdict"] == "FAIL":
                fills[i] = REDF
        r = _put(ws, r, vals, fills)

    # ---- evidence
    ws, hr = _sheet(wb, "Evidence", [30, 8, 110], ["Check", "#", "Row"])
    r = hr + 1
    for row in rows:
        if row["verdict"] != "FAIL":
            continue
        ev = store.db.execute(
            "SELECT seq,payload FROM evidence WHERE run_id=? AND check_id=? ORDER BY seq",
            (run_id, row["check_id"])).fetchall()
        for e in ev:
            r = _put(ws, r, [row["check_id"], e["seq"], e["payload"][:1000]])

    # ---- fixtures + coverage + rules
    ws, hr = _sheet(wb, "Fixtures", [34, 12, 10, 10, 18, 60],
                    ["Check", "Batch", "Expected", "State", "Confirmed", "Note"],
                    banner="A checker with no regression suite rots silently. FIXED_OR_BROKEN "
                           "means the tool will not guess which -- confirm, then update.")
    r = hr + 1
    for f in store.fixtures():
        r = _put(ws, r, [f["check_id"], f["batch"], f["expected_count"], f["state"],
                         f["last_confirmed"], f["note"] or ""],
                 {4: REDF if f["state"] in ("FIXED_OR_BROKEN", "BROKEN_CHECK") else None})

    cov = {}
    for c in registry.all_checks():
        cov.setdefault(c.sobject, []).append(c.id)
    ws, hr = _sheet(wb, "Coverage", [10, 34, 10, 90], ["Seq", "Object", "Checks", "Check ids"],
                    banner="What the tool is NOT looking at. A tool that cannot name its blind "
                           "spots gets trusted for something it never checked.")
    r = hr + 1
    for seq, obj in registry.spine():
        ids = cov.get(obj, [])
        r = _put(ws, r, [seq, obj, len(ids), ", ".join(ids)],
                 {3: REDF if not ids else GRN})

    con = store.contradictions()
    ws, hr = _sheet(wb, "Rules", [30, 24, 30, 40, 50, 12],
                    ["Rule", "Object", "Field", "Assertion", "Source", "Conflict"],
                    banner="%d field(s) carry conflicting documented rules. This is the only "
                           "mechanism that catches a WRONG SPEC." % len(con))
    r = hr + 1
    conflict_fields = {(c["sobject"], c["field"]) for c in con}
    for rule in store.db.execute("SELECT * FROM rule ORDER BY sobject, rule_field").fetchall():
        bad = (rule["sobject"], rule["rule_field"]) in conflict_fields
        r = _put(ws, r, [rule["rule_id"], rule["sobject"], rule["rule_field"],
                         rule["assertion"], rule["source"], "CONTRADICTION" if bad else ""],
                 {6: REDF if bad else None})

    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / ("Preflight_%s_%s.xlsx" % (batch or "all", run_id))
    wb.save(path)
    return path


# ----------------------------------------------------------------------------- run book export
def _rb_cells(r, vs):
    """One run book row flattened to the plain-text cells the export needs."""
    ex = ["%s examined" % "{:,}".format(c["examined"]) for c in r["counts"] if c["examined"]]
    fails = []
    for c in r["counts"]:
        if c["verdict"] == "FAIL" and c["errors"]:
            fails.append("%s %s (%s)" % ("{:,}".format(c["errors"]),
                                        "failing" if c.get("record", True) else c.get("unit_many", "items"),
                                        c["name"]))
    unp = sorted({u["reason"][:140] for u in r["unproven"]})
    way = []
    for f in r["failing"]:
        way.append("%s: %s%s" % (f["name"], (f["reason"] or "")[:200],
                                 ("  FIX AT RO %s: %s" % (f["fix_order"], f["fix"])) if f["fix"] else ""))
    for b in r["blocked_by"]:
        way.append("Held by RO %s: %s" % (b["at"], b["name"]))
    for u in unp:
        way.append("Could not check: " + u)
    times = []
    for t in r["times"]:
        times.append("%s%s" % (jobruns.pretty(t["frm"], t["to"]), ("  " + t["status"]) if t["status"] else ""))
    eff = (r.get("effect") or {}).get("state", "")
    effect = {"UNDONE": "Work still undone (step skipped or not finished)",
              "UNKNOWN": "Cannot confirm the work was done",
              "DONE": "Nothing left for this step to do"}.get(eff, "")
    trust = ""
    for f in r["failing"]:
        v = vs.get(f["check"]) or {}
        if v.get("status") == "SUSPECT":
            trust = "Treat with caution: " + "; ".join(x.get("text", "")[:80] for x in (v.get("flags") or [])[:2])
            break
        if v.get("status") == "VERIFIED":
            trust = "Verified against Salesforce"
    return dict(examined="; ".join(ex), failing="; ".join(fails), way="\n".join(way),
                time="\n".join(times), effect=effect, trust=trust)


def build_runbook(store, batch: str, out_dir: Path, run_id: str = "") -> Path:
    """
    The run book as a workbook, with the Informatica / SnapLogic jobs on their own sheet and the
    team's own steps (scripts, queries, manual steps) on another, then the full list in order.
    Same statuses the screen shows; nothing is re-queried.
    """
    run_id = run_id or store.latest_run_id(batch)
    if not run_id:
        raise SystemExit("No completed run for batch %s. Run `gate` first." % batch)
    rows = rbk.readiness(store, batch, run_id)
    try:
        vs = store.verification(run_id) or {}
    except Exception:                                        # noqa: BLE001
        vs = {}
    jobs_ = [r for r in rows if rbk.is_job(r)]
    ours = [r for r in rows if not rbk.is_job(r)]
    sfill = {"BLOCKED": REDF, "HELD": REDF, "REVIEW": AMB, "UNPROVEN": AMB, "READY": GRN}
    wb = openpyxl.Workbook(); wb.remove(wb.active)

    def counts(rs):
        out = {}
        for r in rs:
            out[r["state"]] = out.get(r["state"], 0) + 1
        return ", ".join("%d %s" % (n, k.lower()) for k, n in sorted(out.items(), key=lambda x: -x[1]))

    ws, hr = _sheet(wb, "Summary", [40, 100], ["", ""],
                    banner="Run book for %s -- run %s. Informatica / SnapLogic jobs are separated from "
                           "the team's own steps. Statuses are as of that run, not now." % (batch, run_id))
    r_ = hr + 1
    for k, v in (("Batch", batch), ("Run", run_id),
                 ("Informatica / SnapLogic steps", "%d  (%s)" % (len(jobs_), counts(jobs_))),
                 ("Team steps (scripts, queries, manual)", "%d  (%s)" % (len(ours), counts(ours))),
                 ("All steps", len(rows))):
        c1 = ws.cell(row=r_, column=1, value=k); c1.font = BOLD; c1.border = THIN
        c2 = ws.cell(row=r_, column=2, value=v); c2.font = BODY; c2.border = THIN
        r_ += 1

    # ---- Informatica / SnapLogic
    ws, hr = _sheet(wb, "Informatica & SnapLogic", [7, 14, 40, 52, 14, 20, 30, 34, 60],
                    ["RO", "System", "Job / step", "Purpose", "Status", "Records examined",
                     "Failing", "Ran (job clock or record stamps)", "What is in the way"],
                    banner="%d data-moving job(s). 'Ran' is the job's own run time where Sunrise captured "
                           "it; otherwise record timestamps, which are a proxy." % len(jobs_))
    r_ = hr + 1
    for x in jobs_:
        c = _rb_cells(x, vs)
        r_ = _put(ws, r_, [x["order"], x["stage"], x["step"], x["purpose"], x["state"],
                           c["examined"], c["failing"], c["time"], c["way"]],
                  {5: sfill.get(x["state"])})

    # ---- the team's own steps
    ws, hr = _sheet(wb, "Our Steps", [7, 16, 18, 46, 52, 12, 20, 30, 34, 34, 60],
                    ["RO", "Type", "System", "Step / script", "Purpose", "Status", "Records examined",
                     "Failing", "Is the work done?", "Can the number be trusted?", "What is in the way"],
                    banner="%d step(s) the team wrote or runs by hand: scripts, queries, validations, fixes "
                           "and manual reviews. 'Is the work done?' is judged from the data, not from "
                           "whether anyone ran the script." % len(ours))
    r_ = hr + 1
    for x in ours:
        c = _rb_cells(x, vs)
        r_ = _put(ws, r_, [x["order"], x["action"], x["stage"], x["step"], x["purpose"], x["state"],
                           c["examined"], c["failing"], c["effect"], c["trust"], c["way"]],
                  {6: sfill.get(x["state"])})

    # ---- everything, in run order
    ws, hr = _sheet(wb, "Full Run Book", [7, 22, 16, 18, 46, 12, 20, 30, 60],
                    ["RO", "Group", "Type", "System", "Step", "Status", "Records examined",
                     "Failing", "What is in the way"],
                    banner="Every step in run order. Group says which sheet it is detailed on.")
    r_ = hr + 1
    for x in rows:
        c = _rb_cells(x, vs)
        r_ = _put(ws, r_, [x["order"], "Informatica / SnapLogic" if rbk.is_job(x) else "Team step",
                           x["action"], x["stage"], x["step"], x["state"], c["examined"],
                           c["failing"], c["way"]], {6: sfill.get(x["state"])})

    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / ("RunBook_%s_%s.xlsx" % (batch or "all", run_id))
    wb.save(path)
    return path


_BAD_SHEET = set('[]:*?/\\')
_ROW_CAP = 1000000


def _tab_name(ro, name, used):
    base = "RO %s %s" % (ro if ro else "-", "".join(ch for ch in str(name) if ch not in _BAD_SHEET))
    base = base[:28].rstrip()
    out, n = base, 2
    while out.lower() in used:
        out = "%s %d" % (base[:28 - len(str(n))].rstrip(), n); n += 1
    used.add(out.lower())
    return out


def _sf_url(cfg, v):
    base = str((cfg or {}).get("InstanceUrl") or "").rstrip("/")
    s = str(v or "")
    import re as _re
    if base and _re.match(r"^[a-zA-Z0-9]{15}([a-zA-Z0-9]{3})?$", s) and any(ch.isdigit() for ch in s[:3]):
        return "%s/lightning/r/%s/view" % (base, s)
    return ""


_LEGACY_HINTS = ("legacy", "external_id", "externalid", "source_system_id", "sourceid", "source_id")


def legacy_fields(conn, sobject, cfg=None):
    """Which field(s) hold the legacy / source-system Id on this object.
    config.json LegacyIdFields {"Account": "Legacy_Id__c"} wins; otherwise any visible field whose
    name looks like one (at most three, so a sheet does not fill with look-alikes)."""
    conf = ((cfg or {}).get("LegacyIdFields") or {}).get(sobject)
    if conf:
        return [conf] if isinstance(conf, str) else list(conf)
    try:
        names = sorted(f for f in conn.fields(sobject) if any(h in f for h in _LEGACY_HINTS))
    except Exception:                                        # noqa: BLE001
        return []
    return names[:3]


def enrich_legacy(conn, sobject, ids, fields, seconds=90):
    """{id15: {field: value}} read from Salesforce for these Ids, in chunks, within a time budget."""
    import time as _t
    out, t0, done = {}, _t.time(), True
    ids = [i for i in dict.fromkeys(ids) if i]
    for k in range(0, len(ids), 150):
        if _t.time() - t0 > seconds:
            done = False
            break
        chunk = ids[k:k + 150]
        q = "SELECT Id, %s FROM %s WHERE Id IN (%s)" % (
            ", ".join(fields), sobject, ", ".join("'%s'" % i for i in chunk))
        try:
            for r in conn.q(q):
                out[str(r.get("Id") or "")[:15]] = {f: r.get(f) for f in fields}
        except Exception:                                    # noqa: BLE001
            done = False
            break
    return out, done


def build_issues(store, batch: str, out_dir: Path, run_id: str = "", cfg=None, conn=None) -> Path:
    """
    Every issue found in the selected run, ONE TAB PER ISSUE, each headed by the run book step it
    belongs to and listing every record (or staged row) that had that issue, with the details the
    run stored. Plus an index tab. A tab per FAILING check; nothing is re-queried.
    """
    run_id = run_id or store.latest_run_id(batch)
    if not run_id:
        raise SystemExit("No completed run for batch %s. Run `gate` first." % batch)
    try:
        vs = store.verification(run_id) or {}
    except Exception:                                        # noqa: BLE001
        vs = {}
    res = [r for r in store.results_for_run(run_id) if r["verdict"] == "FAIL"]
    unproven = [r for r in store.results_for_run(run_id) if r["verdict"] == "UNPROVEN"]
    items = []
    for r in res:
        chk = registry.by_id(r["check_id"])
        items.append((int(getattr(chk, "runbook_order", 0) or 0) if chk else 0, r["check_id"], r, chk))
    items.sort(key=lambda x: (x[0] or 9999, x[1]))

    wb = openpyxl.Workbook(); wb.remove(wb.active)
    used = {"summary"}
    index = []
    tabs = []
    for ro, cid, r, chk in items:
        tab = _tab_name(ro, chk.name if chk else cid, used)
        tabs.append(tab)
        one, many = terms.unit_of(cid)
        found = int(r["evidence_count"] or 0)
        rows = store.evidence(run_id, cid)
        cols = []
        for e in rows:
            for k in e:
                if k not in cols:
                    cols.append(k)
        idcol = next((k for k in cols if str(k).lower() in ("id", "recordid", "sfid")), None)
        legacy_note = ""
        if idcol and conn is not None and rows and chk is not None and chk.sobject \
                and not str(chk.sobject).startswith("__") and terms.is_record(cid):
            lf = legacy_fields(conn, chk.sobject, cfg)
            if lf:
                got, whole = enrich_legacy(conn, chk.sobject,
                                           [str(e.get(idcol) or "") for e in rows], lf)
                for e in rows:
                    for f in lf:
                        e["Legacy: %s" % f] = (got.get(str(e.get(idcol) or "")[:15]) or {}).get(f)
                lcols = ["Legacy: %s" % f for f in lf]
                cols = [idcol] + lcols + [c for c in cols if c != idcol]
                legacy_note = ("" if whole else "  (legacy Ids incomplete: Salesforce was slow)")
            else:
                legacy_note = "no legacy-Id field found on %s; set LegacyIdFields in config.json" % chk.sobject
        elif idcol:
            cols = [idcol] + [c for c in cols if c != idcol]
        if rows and not any(k in cols for k in ("why", "reason", "message", "reasons")):
            short = str(r["reason"] or "")[:300]
            for e in rows:
                e["Why it failed"] = short
            cols.append("Why it failed")
        step = (rbk.step(ro) or {}) if ro else {}
        v = (vs.get(cid) or {}) if isinstance(vs, dict) else {}
        vtxt = str(v.get("status") or "") if isinstance(v, dict) else ""
        head = [
            ("Run book step", ("RO %s  %s" % (ro, step.get("step", ""))) if ro else "not tied to one step"),
            ("Issue", chk.name if chk else cid),
            ("Check", cid),
            ("Found", "%s %s%s" % ("{:,}".format(found), many if found != 1 else one,
                                   ("  (of %s examined)" % "{:,}".format(int(r["processed"] or 0)))
                                   if int(r["processed"] or 0) else "")),
            ("Priority", terms.sev(chk.severity) if chk else ""),
            ("Why it failed", str(r["reason"] or "")),
            ("Rule (the logic)", str(getattr(chk, "rule", "") or "") if chk else ""),
            ("Rule comes from", str(getattr(chk, "rule_source", "") or "") if chk else ""),
            ("What this proves", str(getattr(chk, "proves", "") or "") if chk else ""),
            ("What it cannot prove", str(getattr(chk, "cannot_prove", "") or "") if chk else ""),
            ("Fix", ("RO %s: %s" % (chk.remediation.runbook_order or "?", chk.remediation.summary))
             if chk and chk.remediation else ""),
            ("Checked against Salesforce", vtxt or "not checked"),
        ] + ([("Legacy Id", legacy_note)] if legacy_note else [])
        ws = wb.create_sheet(tab)
        ws.column_dimensions["A"].width = 26
        for i in range(2, max(len(cols), 1) + 2):
            ws.column_dimensions[get_column_letter(i)].width = 30
        ws.column_dimensions["B"].width = 60
        for i, (k, val) in enumerate(head, 1):
            a = ws.cell(row=i, column=1, value=k); a.font = BOLD; a.fill = AMB; a.border = THIN
            b = ws.cell(row=i, column=2, value=val); b.font = BODY; b.alignment = WRAP; b.border = THIN
        hr = len(head) + 2
        shown = rows[:_ROW_CAP]
        if not shown:
            ws.cell(row=hr, column=1, value="No individual rows were kept for this issue (it reports a "
                    "summary, or the run predates row retention). The count above is exact.").font = RED
        else:
            for i, c in enumerate(cols, 1):
                h = ws.cell(row=hr, column=i, value=str(c)); h.font = HDR; h.fill = HFILL
                h.alignment = WRAP; h.border = THIN
            for j, e in enumerate(shown, hr + 1):
                for i, c in enumerate(cols, 1):
                    val = e.get(c)
                    if isinstance(val, (dict, list)):
                        val = json.dumps(val, default=str)[:3000]
                    cell = ws.cell(row=j, column=i, value=val)
                    cell.font = BODY; cell.border = THIN
                    if _sf_url(cfg, val):
                        cell.hyperlink = _sf_url(cfg, val)
                        cell.font = Font(name="Arial", size=10, color="0563C1", underline="single")
            ws.freeze_panes = ws.cell(row=hr + 1, column=1).coordinate
            ws.auto_filter.ref = "A%d:%s%d" % (hr, get_column_letter(max(len(cols), 1)), hr + len(shown))
            if len(rows) > len(shown):
                ws.cell(row=hr + len(shown) + 1, column=1,
                        value="Stopped at %s rows (spreadsheet limit)." % "{:,}".format(len(shown))).font = RED
        index.append((tab, ro, step.get("step", ""), chk.name if chk else cid, many, found,
                      len(rows), vtxt))

    ws, hr = _sheet(wb, "Summary", [30, 8, 56, 56, 12, 12, 12, 30],
                    ["Tab", "RO", "Run book step", "Issue", "Unit", "Found", "Rows listed",
                     "Checked against Salesforce"],
                    banner="Issues found for %s in run %s -- one tab per issue, each listing every record "
                           "or staged row that had it. As of that run, not now." % (batch, run_id))
    wb.move_sheet("Summary", offset=-len(wb.sheetnames) + 1)
    r_ = hr + 1
    for tab, ro, stp, name, unit, found, listed, vtxt in index:
        r_ = _put(ws, r_, [tab, ro or "", stp, name, unit, found, listed, vtxt or "not checked"], {1: REDF})
        ws.cell(row=r_ - 1, column=1).hyperlink = "#'%s'!A1" % tab
    if not index:
        r_ = _put(ws, r_, ["No failing checks in this run.", "", "", "", "", "", "", ""])
    r_ += 1
    r_ = _put(ws, r_, ["Not exported: %d check(s) could not be proven, so there is nothing true to list "
                       "(an unproven check is not a pass and not a failure)." % len(unproven)])
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / ("Issues_%s_%s.xlsx" % (batch or "all", run_id))
    wb.save(path)
    return path
