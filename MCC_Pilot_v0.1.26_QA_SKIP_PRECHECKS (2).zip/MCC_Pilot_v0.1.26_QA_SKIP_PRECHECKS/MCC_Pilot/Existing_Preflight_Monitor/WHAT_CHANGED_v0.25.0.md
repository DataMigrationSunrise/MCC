# v0.25.0 - export the run book, jobs separated from the team's steps

New **Export run book (Excel)** link at the right of the filter bar above the run book (also
`python monitor.py runbook --batch UMB-0117`). One workbook, four sheets:

- **Summary** - counts of each group and status.
- **Informatica & SnapLogic** - the data-moving jobs only: RO, system, job, purpose, status, records
  examined, failing, when it ran (job clock where Sunrise captured it, otherwise record stamps), and
  what is in the way.
- **Our Steps** - everything the team wrote or runs by hand (scripts, queries, validations, fixes,
  manual reviews): type, system, script, status, examined, failing, "is the work done?" (judged from
  the data), "can the number be trusted?" (from the verification pass), and what is in the way.
- **Full Run Book** - every step in run order, with a Group column.

Every step is on exactly one of the first two. A "job" is the same definition the screen's filter
uses (stage Informatica or SnapLogic with action RUN). Statuses are as of the run, not now; nothing is
re-queried. Failing counts carry their unit (async jobs, staged rows) the same as on screen.

The export is for the batch (and the run, if you picked a stored snapshot) currently selected on
screen: the link carries both, so another tab or batch cannot change what you download.
