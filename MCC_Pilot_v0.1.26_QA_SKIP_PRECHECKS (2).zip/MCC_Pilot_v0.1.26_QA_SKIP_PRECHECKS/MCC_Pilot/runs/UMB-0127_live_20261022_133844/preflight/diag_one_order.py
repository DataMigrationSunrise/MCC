"""Run 03_Regenerate_WorkOrders on ONE stuck order and profile its SOQL by class from the debug log.
A limit exception rolls back the whole transaction, so a failure writes nothing."""
import json, re, subprocess, sys, tempfile, collections
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = [o['id'] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']]
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
ids = "','".join(stuck)
target = [r for r in sf.query("SELECT Id, OrderNumber, Account.Name FROM Order WHERE Id IN ('%s') ORDER BY OrderNumber" % ids)
          if 'TRUMARK' in ((r.get('Account') or {}).get('Name') or '')][0]
print('target:', target['Id'], target['OrderNumber'], target['Account']['Name'])
src = Path(r'C:\Users\VChiraf\Downloads\MCC\DM_Migration_Code_Repository_CORE_2026-10-02_v44\24_umb0116_missing_workorders\03_Regenerate_WorkOrders.apex').read_text(encoding='utf-8')
src = src.replace("Id target = '801VD00000tIKFDYA4';", "Id target = '%s';" % target['Id'])
with tempfile.TemporaryDirectory() as td:
    f = Path(td) / 'diag.apex'
    f.write_text(src, encoding='utf-8')
    cp = subprocess.run([ad._sf(), 'apex', 'run', '--file', str(f), '--target-org', app.CFG['OrgAlias'], '--json'],
                        capture_output=True, text=True, timeout=600)
out = json.loads(cp.stdout or '{}').get('result', {})
logs = out.get('logs') or ''
(folder / 'logs' / 'diag_one_order_debug.log').write_text(logs, encoding='utf-8')
print('success:', out.get('success'), '| exception:', (out.get('exceptionMessage') or '')[:200])
for tag in ('=== WORK ORDERS NOW ON THIS ORDER', '=== VERDICT', 'EXCEPTION MESSAGE', 'LINE:'):
    for m in re.findall(r'\|DEBUG\|(%s[^\n]*)' % re.escape(tag), logs):
        print(m[:200])
# Profile SOQL by calling class/method from the log.
stack, counts, rows = [], collections.Counter(), collections.Counter()
last_rows = None
for line in logs.splitlines():
    if '|METHOD_ENTRY|' in line or '|CODE_UNIT_STARTED|' in line:
        stack.append(line.rsplit('|', 1)[-1][:80])
    elif ('|METHOD_EXIT|' in line or '|CODE_UNIT_FINISHED|' in line) and stack:
        stack.pop()
    elif '|SOQL_EXECUTE_BEGIN|' in line:
        where = stack[-1] if stack else '?'
        counts[where] += 1
        last_q = (where, line.rsplit('|', 1)[-1][:160])
    elif '|SOQL_EXECUTE_END|' in line:
        m = re.search(r'Rows:(\d+)', line)
        if m:
            rows[last_q] += int(m.group(1))
print('total SOQL in log:', sum(counts.values()))
print('top callers by SOQL count:')
for k, v in counts.most_common(8):
    print('  %4d  %s' % (v, k))
print('top queries by rows returned:')
for (where, q), v in rows.most_common(5):
    print('  %6d rows  %s :: %s' % (v, where, q))
