# v0.1.16 — Exclusion outcome reconciliation guard

- The engine now recognizes **NOT_CHANGED_OR_UNVERIFIED** as an uncertain exclusion write rather than treating it as a nonblocking preflight warning.
- Exception scanning labels database exclusion exceptions **WRITE_OUTCOME_UNKNOWN** to prevent continuing without reconciling possible committed changes.
- Preserves all existing stage exclusions, append-only audit, run history, and preflight evidence.

## Full-run status

This remains a limited execution package. `StopAfter` is `TF_30.01`; seven later taskflows are mapped, but the supplied downstream 43-row inventory has intermediate unmapped actions. Automatic record exclusion rules remain disabled by default because `preflight_rules.json` contains only the batch identity attestation. No live database integration test was possible. Never treat a successful local test as proof of full-run readiness.
