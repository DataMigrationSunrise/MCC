# Preflight Monitor vs Sunrise MCC — gap analysis

**Verdict first: the Preflight Monitor is not a replacement for Sunrise and must not be
positioned as one.** Sunrise is a 37-module migration platform. Mine is one narrow checker,
~2,400 lines, that does a few things Sunrise structurally cannot.

The most important difference is not a feature list:

> **Sunrise is a true PRE-flight. It replays the transformation in memory and predicts what
> *will* happen. The Preflight Monitor is largely a POST-flight — it observes what *has*
> happened in the org.**

You cannot run mine before a migration to predict outcomes. That is Sunrise's job and mine
does not touch it.

---

## Gaps in MY tool — what Sunrise does that mine does not

| # | Sunrise capability | Why it matters | Mine |
|---|---|---|---|
| 1 | **Transformation replay** — executes the recovered SnapLogic/Informatica/Goose field logic in memory over 2,850 staged rows and produces the payload the migration *would* write | This is the entire predictive half. 3,205 candidates, 67,344 field rows on the baseline run | **Nothing** |
| 2 | **Payload validation against field constraints** — field existence, writable flags, lengths, types, restricted picklists | Produced 1,459 predicted errors, 84% of them one picklist value, before any load ran | **Nothing** |
| 3 | **SnapLogic match/route simulation** — the real 07a Account and 08 Contact matching, exact account number + Soundex name, against live Salesforce | Prevents a generic INSERT assumption masking real update-vs-create decisions. Catches duplicate creates | **Nothing** |
| 4 | **Per-field current-state comparison** — proposed value vs live value, SAME/DIFFERENT/UNVERIFIED, per record per field | Mine compares *populations* (how many Contracts have no BIQ). Sunrise compares *values* | **Population only** |
| 5 | **Transformation gap tracking** — which target fields the recovered logic cannot resolve, and why | 8,247 rows; ~6,600 were missing mappings, not missing data | **Nothing** |
| 6 | **Remediation execution** — the 7 AF handlers actually write fixes, with bulk update, resilient chunking, re-query verification | Mine is read-only by design, but that means it cannot close a loop | **By design** |
| 7 | **Source snapshot integrity** — SHA-256 per export, content-addressed immutable copies | A run can be re-audited later against exactly what it saw | **Nothing** |
| 8 | **Record Factory, Pilot Cycle, Exception Workbench, Historical Parity, Engine Benchmarking, AI Advisor, Data Quality, Proof State** | Eight more subsystems | **Nothing** |
| 9 | **Object coverage** | Sunrise queries 12 objects; mine covers 6 of the 20-object spine (its own coverage audit says so) | **Narrower** |
| 10 | **Goose depth** | Sunrise reads many OpenBatch views and the STG_* tables; mine does one BIQ parity count | **Much thinner** |

**Item 1 is the one that matters.** Everything else is scope. Without transformation replay my
tool cannot answer "will this load succeed" — only "did this batch end up healthy."

---

## Gaps in SUNRISE — what mine does that it does not

Verified by reading the source, not assumed.

| # | Capability | Evidence it is absent from Sunrise |
|---|---|---|
| 1 | **Cross-batch metric baselining** | No persistent store exists — `grep` for sqlite across all 37 modules returns nothing. Each preflight writes a timestamped folder and nothing accumulates. "Baseline" in `preflight_pipeline.py` means *a workbook's expected values*, not prior batches. `historical_parity` compares matching *decisions* against ground truth, not metrics across batches |
| 2 | **Canary logic** | `grep -rn "canary\|could have found\|scope is broken"` across the app returns **zero hits**. Nothing distinguishes "zero rows because clean" from "zero rows because the scope is broken" |
| 3 | **Centrally enforced evidence invariant** | Sunrise applies UNPROVEN-not-PASS by hand per checkpoint — and inconsistently: four of thirteen checkpoints emit a fixed status with no query at all |
| 4 | **Rule provenance + contradiction detection** | No rule registry. The `LastBillingDate__c` conflict (UMB-0065 `today` vs steps 154-158 `StartDate-1`) is invisible to it — AF160 simply implements one |
| 5 | **Known-defect regression fixtures** | No mechanism notices a check that stops finding a defect it used to find |
| 6 | **Coverage self-audit** | Nothing reports which objects have no check. Zero `FROM Contract` in 1,398 lines went unnoticed |
| 7 | **Run Book readiness with blocking cascade** | `runbook_results.py` populates a run-book view from *load artifacts* (submitted/succeeded/failed per step). It does not compute "can I advance past RO N" from live state, nor model upstream blocking |
| 8 | **Records routed to a remediation step** | No mapping from a failing record to the Run Order that fixes it, the script, who approves, and ordered steps |
| 9 | **Batch-scope blind spot measurement** | AF60 names the problem in a comment; nothing measures it |

**Items 1 and 2 are why the UMB-0116 defects survived.** `4.7%` with no baseline is a number
nobody acts on, and an innocent zero with no canary reads as clean.

---

## Overlaps — do not duplicate these

| Area | Sunrise | Mine | Keep |
|---|---|---|---|
| Run-book-aligned view | `runbook_results.py` — what the load *did*, from artifacts | Readiness — what you can *advance past*, from live state | **Both.** Different questions |
| Touch points | 5 touch points simulated, with Goose joins | 3 checks in the same territory | **Sunrise.** It is deeper |
| Goose read-only access | `goose_live.invoke_query` + `validate_readonly_sql` | Imports Sunrise's | **Sunrise.** Mine reuses it |
| Spreadsheet output | 20 CSVs + `preflight_to_workbook.py` | Native 9-tab workbook | **Both.** Different inputs |
| BIQ checks | AF160, read-only, treats existing BIQs as proof | Tests null Effective Date directly | **Mine**, for this one case |

---

## Honest recommendation

**Run both. They answer different questions and neither covers the other.**

```
BEFORE a load    Sunrise preflight      will this transformation succeed?
                 + preflight_to_workbook.py   (one readable spreadsheet)

AFTER a load     Preflight Monitor      did it, and can I advance past RO N?
                 gate --batch UMB-0117
```

**The honest framing of my tool:** it is a *regression and readiness checker* that happens to run
preflight-style checks, not a preflight engine. Positioning it as "a replacement preflight" would
be wrong and would eventually get someone hurt, because it cannot predict a load outcome.

### If only two things get built next

1. **Port cross-batch baselining into Sunrise** (gap 1 above) — or point mine at Sunrise's
   `summary.json` history, which already contains the metrics. Highest value per hour of work:
   it is what turns every existing number into a finding.
2. **Add canaries to Sunrise's thirteen checkpoints** (gap 2) — small change, and it closes the
   failure mode that let an innocent zero read as clean.

Both are additive to Sunrise and neither requires my tool to exist.
