# Preflight Monitor v0.10.0 — see the exact records that failed, and why

## Where to click

- **All issues** table — the record count is now a link.
- **Run book**, Next Action / Blocker column — "see records ›" next to each failure.

Either opens a page with:

- **The Salesforce Ids** of the records that failed, one row each, every field the check
  captured (Order Number, Status, Contract, whatever that check selected).
- **Why they failed** — the check's own finding, in its words.
- **The rule it asserts and where that rule came from** — so you can argue with the check,
  not just the data.
- **The fix**, with the Run Order that owns it.
- **Download CSV** — the same rows, for Excel or Data Loader.

**No query is run.** It reads what the check already stored, so it works on a snapshot and
on a run from last week.

## The cap was the real problem

Records were always stored — capped at **200** per check per run. A 906-record failure kept
200 and silently lost 706, which is why "show me the records that failed" could not be
answered from history.

The cap is now **2000**, configurable as `EvidenceCap` in `config.json`.

**The count has always been exact** regardless of the cap — only the retained list was
short. Where the two differ the page says so outright: *"Showing 200 of 906. The count is
exact; the retained sample is capped."* It does not quietly show you 200 rows and let you
believe that is all of them.

A check that stores a summary rather than rows says that too, instead of rendering an empty
table.

## Spreadsheet

New **Failed Records** sheet: one row per individual record, with the check, the reason, the
record's own fields and the fix. On the UMB-0117 run that is 657 rows with real Order Ids —
previously this existed only as a four-row JSON sample inside one cell.

## Note on what this does and does not tell you

It shows records that a **check** flagged. It is not a log of what Informatica or SnapLogic
rejected at load time — those failures never reach Salesforce and are in the job's own logs
and `GOOSE_ErrorLog` (Run Orders 4 and 59). The one place this tool predicts a load-time
rejection before it happens is `PREDICT.LOAD_FAILURES`, which needs `SunriseAppDir` set.
