param(
    [Parameter(Mandatory=$true)][string]$Server,
    [string]$Database = "Goose",
    [Parameter(Mandatory=$true)][string]$SqlFile,
    [Parameter(Mandatory=$true)][string]$OutputFile,
    [int]$CommandTimeoutSeconds = 600,
    [switch]$ReadOnly
)
# MCC Goose runner: SQL comes from a file (no command-line length limit) and EVERY result set is
# returned, as a JSON array of row arrays. Windows integrated authentication.
$ErrorActionPreference = 'Stop'
$connection = $null; $reader = $null
try {
    $sql = [IO.File]::ReadAllText($SqlFile, [Text.Encoding]::UTF8)
    $cs = "Server=$Server;Database=$Database;Integrated Security=True;TrustServerCertificate=True"
    if ($ReadOnly) { $cs += ";ApplicationIntent=ReadOnly" }
    $connection = New-Object System.Data.SqlClient.SqlConnection ($cs)
    $connection.Open()
    $command = $connection.CreateCommand()
    $command.CommandText = $sql
    $command.CommandTimeout = $CommandTimeoutSeconds
    $reader = $command.ExecuteReader()
    $sets = [System.Collections.Generic.List[object]]::new()
    do {
        if ($reader.FieldCount -gt 0) {
            $rows = [System.Collections.Generic.List[object]]::new()
            while ($reader.Read()) {
                $record = [ordered]@{}
                for ($i = 0; $i -lt $reader.FieldCount; $i++) {
                    $value = $reader.GetValue($i)
                    $record[$reader.GetName($i)] = if ($value -is [DBNull]) { $null } else { $value }
                }
                $rows.Add([pscustomobject]$record)
            }
            # Serialize each set now; -InputObject keeps a one-row set as [{...}], not {...}.
            $sets.Add((ConvertTo-Json -InputObject @($rows.ToArray()) -Depth 8 -Compress))
        }
    } while ($reader.NextResult())
    $reader.Close(); $reader = $null
    $json = '[' + ($sets -join ',') + ']'
    [IO.File]::WriteAllText($OutputFile, $json, (New-Object System.Text.UTF8Encoding($false)))
    exit 0
} catch {
    [Console]::Error.WriteLine("GOOSE_QUERY_FAILED: " + $_.Exception.Message)
    exit 20
} finally {
    try { if ($reader) { $reader.Close() } } catch {}
    try { if ($connection) { $connection.Close() } } catch {}
}
