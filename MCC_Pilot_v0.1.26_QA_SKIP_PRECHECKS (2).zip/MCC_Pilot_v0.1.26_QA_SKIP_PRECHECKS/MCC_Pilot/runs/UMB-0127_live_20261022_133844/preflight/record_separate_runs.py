"""Record in UMB-0127's checkpoint the steps that were run separately from the MCC run (real results)."""
import json, shutil
from pathlib import Path

run = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844\run.json')
shutil.copy(run, run.with_suffix('.json.before_separate_results'))
d = json.loads(run.read_text(encoding='utf-8'))
results = {
    'PL_05': ('DONE', 'Run separately at 13:55 (SnapLogic PL_05 Pre-Process, triggered before this run resumed)'),
    'TF_15.G': ('FIXED', 'Run separately: 1,115 blank address coordinates filled in Goose; log rows backfilled '
                         '(GOOSE_ErrorLog MCC_FIXED 1,115)'),
    'TF_15.01': ('FIXED', 'Run separately at 16:59: 58 parent addresses fixed and re-verified (GOOSE_ErrorLog MCC_FIXED)'),
    'TF_25.06': ('PASS', 'Run separately (read-only): 20 chunks, every line found in Salesforce, 0 qty / 0 bundled-qty '
                         'diffs; parent-line price diffs flagged INFO'),
}
for s in d['steps']:
    if s['id'] in results:
        s['status'], s['detail'] = results[s['id']]
run.write_text(json.dumps(d, indent=1, default=str), encoding='utf-8')
print([(s['id'], s['status']) for s in d['steps'] if s['id'] in results])
