# Preflight Monitor v0.7.0 — what changed

## The UI is now the run book
Same ten columns, same order, same wording as `UMB_Master_Run_Book`:

> Run Order · Stage · Action · Step · Script Purpose · Status · Record Count / Result · Time · Verification Method · Next Action / Blocker

Seven of the ten come straight from the run book. Three are filled in live:
**Status**, **Record Count / Result**, **Time**.

## "Records" is gone, replaced by two numbers
The old single **Records** column could not say which number it held. On a
problem-finding check it held *errors*, which reads as though it meant *records
loaded* — the opposite. Every cell now shows both, always labelled:

```
906 examined · 447 errors
```

- **examined** — how many records the check looked at
- **errors** — how many of them are wrong
- Neither is "records loaded".

A presence check (one where emptiness *is* the failure) shows `0 found` instead,
because "0 error rows" on such a check reads as a clean result when it is the
opposite. That is what made Run Order 18 report **BLOCKED — 0 row(s)**.

## Time: when the step actually ran
From the orchestrator's own record, read out of the snapshots the Sunrise MCC app
already captures — `test_run_history\informatica_live\*_result_*.json` and
`test_run_history\snaplogic_live\<stamp>\executions.csv`. That gives the real start,
end, duration and job status. **No credentials are read and no API is called** by this
tool; it only reads files Sunrise wrote.

Set `SunriseAppDir` in `config.json` to switch it on. Without it, the column falls
back to first/last record `CreatedDate` and says so — stamps are a proxy for the run
window, not the run window, and a step that ran and wrote nothing leaves no stamps at
all, which is exactly the case being detected.

Three combinations are now distinguished, because they mean different things:

| Produced | Orchestrator says | Meaning |
|---|---|---|
| 0 | nothing captured | nobody knows whether it ran |
| 0 | SUCCESS | it ran clean **against a different batch** |
| some | FAILED | partial output — the worst case, every downstream count looks plausible |

## Three defects fixed

**1. The 22,027-record false blocker.** `TF_00.02` counted records org-wide with a null
batch link. In a sandbox holding ordinary USS business records, that returns the
ordinary business records — 22,027 WorkOrders, 10,095 BIQs, 2,322 Maintenance Plans,
414 Contracts. They were never migration rows, so they cannot be *missing* from a
migration population. The check now derives the window this batch actually wrote in
(from its Quotes, padded a day each side) and fails only on records written *inside*
it. The org-wide number is still reported, as context, explicitly labelled *not a
finding*. With no derivable window it reports UNPROVEN rather than a blocker.

**2. PL_07 / PL_10 reported "produced NOTHING" on a batch where they were fine.**
They scoped through `Account.USS_Migration_Batch__c`. In an acquisition onboarding the
Accounts already exist and are never tagged with the batch, so that field is null on
every one and the count was always 0. They now reach Accounts through the batch's
Quotes, which do carry `USS_Migration_Batch__c` — the path documented in repo folder 08.
Note the knock-on: PL_07 *updates* pre-existing Accounts rather than creating them, so
`CreatedDate` is old and meaningless here and `LastModifiedDate` is the evidence. The
Time cell reports that separately.

**3. "BLOCKED — 0 row(s)".** See the presence-check note above.

## Also
- Existing `preflight_history.db` files are migrated in place; history is kept.
- The spreadsheet export carries the same ten columns.
- The headline no longer sums "examined" across steps — the same 906 Orders are
  examined at a dozen steps, so a sum reported tens of thousands of records that do
  not exist.
- 50+ new regression tests cover all of the above. `python test_offline.py`.
