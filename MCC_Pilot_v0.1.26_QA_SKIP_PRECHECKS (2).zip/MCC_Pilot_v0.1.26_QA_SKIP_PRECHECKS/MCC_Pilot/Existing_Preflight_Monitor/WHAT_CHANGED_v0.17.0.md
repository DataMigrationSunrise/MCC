# MCC - Preflight Monitoring Tool — v0.17.0

## 1. Record Ids are now links into QA Salesforce

Every Salesforce Id in a "what failed" table is a link that opens the record in a new tab:

    https://ussprod--qa.sandbox.lightning.force.com/lightning/r/FSL__Polygon__c/a1Z6O000005VUzEUAW/view

The object name comes from the Id's own key prefix, so it is right without being told.

**This is driven by one config value — `InstanceUrl` in `config.json`.** It must point at the
same org as `OrgAlias`. If it points at a different sandbox, the links will open real records
that are *not* the ones the check examined, and nothing in the tool can detect that. If
`InstanceUrl` is blank, Ids render as plain text rather than as broken links.

Values that only look like Ids are deliberately left alone: Order numbers (`00758836`),
statuses, dates.

## 2. "Where this batch is" now reads the job pipeline

The section no longer just names a Run Order. It reports:

- the last Informatica/SnapLogic job that actually ran, and its step
- the next job due
- **N of M load jobs confirmed** — and how many it cannot confirm either way

Only orchestrator RUN steps count as jobs. Apex, manual and verification steps are excluded,
so the count means "loads done", not "rows ticked off".

On your UMB-0117 data: last job RO 17 `TF_30_Convert_Quote_to_Order`, next RO 19
`TF_35_Activate_FSL_Order`, **5 of 15 confirmed, 10 left**, 6 jobs unconfirmable.

## 3. Findings are classified against how far the load actually got

This is the fix for counting not-yet-loaded objects as errors — now stated per finding:

| Phase | Meaning |
|---|---|
| **CURRENT** | In data the load has already produced. A real error, now. |
| **PREDICTED** | In data already loaded, already wrong, and it breaks a step *still ahead*. Names the step. |
| **NOT YET** | Beyond the last job that ran. Not an error — there is nothing there to be wrong. |

PREDICTED is the valuable one: it is a failure you can fix before the job that would hit it
ever runs. On your data, `ORDER.ACTIVATION_RATE` at RO 16 is PREDICTED, breaking RO 25.

## 4. Three new read-only checks

RO 21 Contract field blanks · RO 22 branch codes · RO 24 single-batch processing. All three
read only — no DML anywhere in them.

## What this version does NOT do

- **Only 3 of 18 read-only verification candidates are built.** Still to do: RO 1, 7, 14, 23,
  31, 32, 34, 38, 44, 46, 47, 56, 59, 60.
- My first pass at sorting steps into read-only vs writes **got three wrong**: RO 42 creates a
  Salesforce File, so it writes; RO 36 and RO 38 only read, despite "Remediate" and "Updates"
  in their names. The three built here were re-checked by hand. Treat the unbuilt list as
  unverified.
- `PREDICT.LOAD_FAILURES` is still dead — Goose (`D1DVSQL16`) is unreachable from here.
- Two RO 15 checks are still inert: `Business_Type__c`, `Bill_Timing__c` and
  `Billing_Period__c` are not visible to your user on Quote. They are visible on Account and
  Contract, so this is almost certainly FLS, not a missing deployment.

## Still true of every version

The tool has **no write path to Salesforce**. It invokes exactly two commands —
`sf data query` and `sf sobject describe`. There is no code in it that could update a record,
and it will not execute `.apex` files.
