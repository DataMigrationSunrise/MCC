# MCC - Preflight Monitoring Tool — design

**Status:** design only. No code written yet.

Two directives shape everything below: **flexible** (new checks without rewriting, any batch, any
org, degrades gracefully when a system is unavailable) and **self-checking** (the tool validates
itself before it validates anything else, and knows what it is not looking at).

---

## The problem this is solving

Tonight's investigation found a defect that hid for three months behind six independent layers. The
most important thing about it is not any single layer — it is that **every layer was individually
reasonable** and the whole was blind.

| Layer | Why it missed |
|---|---|
| Run Book UMB-0065 step 2 | Scoped the fix to `Billing_Period__c = 'Monthly Bill Period'` |
| AF160 automation | Implemented that scope faithfully — correct against its spec |
| `FuelSurchargeBatch` | 28-Day `else` branch has no `.toStartOfMonth()`, so a null saves silently |
| AF160's BIQ check | Reads `Effective_Date__c`, tags it `PROOF_NOT_DEFECT`, never tests it |
| Folder 03 Apex check | Compares two possibly-null values; `null != null` is FALSE in Apex |
| TF_75 / Goose views | Filter `BatchStatus='Open'`; the batch was `Canceled` |

**A checker that shares a spec with the thing it checks can only verify intent, never correctness.**
That is the single design constraint everything else follows from.

---

## Self-checking — the eight mechanisms

### 1. The evidence invariant (enforced by the runner, not by check authors)

A check may not return `PASS`. It returns **evidence**, and the runner assigns the verdict:

```
evidence rows > 0  and  check is "find the bad ones"   ->  FAIL
evidence rows == 0 and  canary for this check passed   ->  PASS
evidence rows == 0 and  canary did NOT pass            ->  UNPROVEN
field/schema precondition unmet                        ->  UNPROVEN
query errored                                          ->  UNPROVEN
```

**Zero rows can never become `PASS` on its own.** It becomes `PASS` only when a canary proves the
query could have found something. This is the structural version of the discipline
`preflight_pipeline.py` applies by hand per checkpoint — and applies inconsistently, since four of
its thirteen checkpoints emit a fixed status with no query at all.

### 2. Schema preconditions, declared and verified

Every check declares the fields it depends on. The runner describes them against the live org
*before* running the check.

```python
requires_fields = ["Contract.LastBillingDate__c", "Contract.Billing_Period__c"]
```

A missing or FLS-hidden field makes the check `UNPROVEN` with the field named — never a silent zero.

This is the `WorkOrder.ContractId` vs `WorkOrder.Contract__c` problem made impossible: the tool
reports which exists, and a check written against the wrong one fails loudly instead of returning a
different population than the check sitting next to it.

### 3. Canaries — "could this query have found anything?"

Each check carries a canary: a query that **must** return rows if the check's scoping is sound.

| Check | Canary |
|---|---|
| FSC BIQs with null Effective Date | FSC BIQs exist at all in this batch |
| Contracts with no BIQs | Activated Contracts exist in this batch |
| Orders missing Work Orders | Orders exist in this batch |

A canary returning zero means **the scope is broken, not that the data is clean.** This is the
generalised form of the batch-scope blind spot: a relationship chain with a null link removes
records from the population rather than flagging them, and the symptom is always an innocent-looking
zero.

### 4. Known-defect regression fixtures

The tool carries the defects already proven, as fixtures with their expected populations:

```
UMB-0116 : 18 FSC BIQs with null Effective_Date__c, all Status = Error
UMB-0116 : 750 of 786 Activated Contracts with zero BIQs
org-wide : 501 of 502 ServiceTerritory polygons pointing at deleted territories
UMB-0116 : 5 of 1,027 active MPs generating no Work Orders
```

On every run, each fixture lands in one of three states, and **the tool never decides which on its
own**:

- **Still present** — the check works, the defect is unfixed
- **Gone** — either it was fixed, or the check broke. The tool says so and asks.
- **Changed** — the count moved; show the delta

A checker with no regression suite rots silently. This is how it notices.

### 5. Rule provenance and contradiction detection

Every check cites the rule it asserts and where that rule came from:

```python
rule   = "Contract.LastBillingDate__c = StartDate - 1 day"
source = "Run Book steps 154-158 (via preflight_pipeline.py checkpoint '154-158')"
```

When two registered rules contradict each other on the same field, **the tool reports the
contradiction instead of silently picking one**:

```
CONTRADICTION  Contract.LastBillingDate__c
  Rule A  = today            source: UMB-0065 "Adding FSC BIQs" step 2
  Rule B  = StartDate - 1    source: Run Book steps 154-158
  AF160 writes Rule A. No check may assert PASS on this field until resolved.
```

This is the only mechanism that can catch a **wrong specification**. Salesforce and Goose agreeing
with each other proves nothing when the documented rule is the defect.

### 6. Cross-source disagreement is an output, not an error

Three sources, none authoritative:

| | Salesforce | Goose | Sunrise outputs |
|---|---|---|---|
| **tells you** | what exists now | what should have arrived | what the tool believes it did |
| **lies by** | can't show absence | goes stale; status disagrees | reports on its own homework |

Disagreement is reported as a finding with all three values shown. Tonight: Salesforce 163 BIQs,
Goose 124 — the 39-row gap *was* the finding. And AF160 reporting `LIVE CLEAN` while 21 rows sat in
`Error` is exactly the Sunrise-vs-reality comparison this makes standing rather than accidental.

### 7. Coverage self-audit — "what am I not looking at?"

The tool holds the 20-object migration sequence (10–200) and, on every run, reports which objects
and stages have **no check at all**.

This is the audit performed by hand against `preflight_pipeline.py` tonight — zero `FROM Contract`
in 1,398 lines, four checkpoints with no query, one BIQ query that declines to judge, eight of
twenty objects never touched — made automatic.

The output is a first-class panel, not a footnote:

```
COVERAGE SELF-AUDIT
  seq 130  Contract                 0 checks   *** the object 786 records of this batch live in
  seq 200  Billing_Impacts_Queue__c 4 checks
  seq 050  USF_Address__c           1 check    (no proven batch-scope path - results unscoped)
```

A tool that cannot say what it is blind to will eventually be trusted for something it never
checked.

### 8. Startup self-test, before any check runs

In order, refusing to report if any stage fails:

1. **Connections** — Salesforce reachable, Goose reachable (or explicitly degraded)
2. **Batch scope resolution** — exactly one batch resolves; ambiguous or zero aborts
3. **Schema describe** — every declared field across all registered checks
4. **Canaries** — every canary query
5. **Contradiction scan** — the rule registry
6. **Fixtures** — known-defect regression

Only then does it run real checks. A tool that reports results while its own fixtures fail is worse
than no tool.

---

## Flexibility

### Checks are data

```python
Check(
    id          = "BIQ.FSC_NULL_EFFECTIVE_DATE",
    name        = "FSC BIQs created with a null Effective Date",
    stage       = "tf_60",
    sequence    = 200,
    severity    = BLOCKER,
    rule        = "FSC BIQ Effective_Date__c comes from the parent BIQ "
                  "(strip ' FSC|' from BIQ_Key__c)",
    rule_source = "Run Book UMB-0065 'Fix the Effective Dates' steps 3-5; "
                  "TP-160 requirement text",
    requires    = ["Billing_Impacts_Queue__c.Effective_Date__c",
                   "Billing_Impacts_Queue__c.Charge_Type__c"],
    canary      = "FSC BIQs exist in this batch",
    query       = ...,
    proves      = "No FSC BIQ in this batch will be rejected for a null Effective Date",
    cannot_prove= "That the non-null dates are CORRECT. See BIQ.EFFECTIVE_DATE_RULE_MATCH.",
)
```

Adding a check is adding a registry entry. No runner changes, no dashboard changes — it appears in
the coverage audit, the dashboard, and the spreadsheet automatically.

`proves` / `cannot_prove` are **required fields**. A check that cannot state its own boundary does
not get registered.

### Everything else that must not be hardcoded

- **Batch, org alias, Goose server/database** — parameters, never literals
- **Thresholds** — config, not code (`biq_coverage_warn: 0.95`)
- **Check packs by stage** — run only `tf_60`'s checks, or all
- **Graceful degradation** — no Goose: Salesforce-only checks run, Goose-dependent ones report
  `UNPROVEN — GOOSE UNAVAILABLE`, never skipped silently. Same for absent Sunrise outputs.
- **Severity is configurable per deployment** — QA may warn where Production blocks

### Boundary with Sunrise

One file, `connections.py`, imports Sunrise — `goose_live.invoke_query`,
`goose_live.validate_readonly_sql`, the `sf` CLI pattern. It is the only file that knows Sunrise
exists.

Connection code has no opinion about correctness, so it cannot carry a spec defect, and when it
breaks it breaks **loudly**. Check logic is the tool's own and is never shared. If Sunrise moves,
one file changes and the failure message says so.

---

## Two views, one engine

- **Gate** — run before a stage, get a verdict, a spreadsheet, and an exit code
- **Monitor** — same checks on a timer, with deltas since the last pass and a running timeline

The monitor is the gate with a clock. No duplicated logic.

Both are served by a local `ThreadingHTTPServer` to the browser, matching the existing Command
Center's approach — no framework, no install beyond `openpyxl`.

---

## What this deliberately does not do

- **No writes. Ever.** SELECT-only, enforced through `validate_readonly_sql` for Goose and by
  construction for Salesforce. Remediation stays in the Run Book scripts where a human approves it.
- **No "overall health score."** A single number invites exactly the `LIVE CLEAN` failure this is
  built to prevent. The verdict is a count of BLOCKERS, a count of UNPROVEN, and a named list.
- **No silent skips.** Every registered check appears in the output every run, including the ones
  that could not run and why.

---

## Open questions before building

1. **Where does it run** — alongside Sunrise on the same Windows box, or somewhere it can reach the
   org and Goose independently? Affects whether the `connections.py` shim can import Sunrise at all
   or needs the standalone fallback path.
2. **Fixture maintenance** — when a known defect is genuinely fixed, who updates the fixture? If
   nobody owns it, the regression suite degrades into noise within two batches.
3. **Production severity** — should the same check BLOCK in Production and WARN in QA, or is a
   blocker a blocker everywhere?
