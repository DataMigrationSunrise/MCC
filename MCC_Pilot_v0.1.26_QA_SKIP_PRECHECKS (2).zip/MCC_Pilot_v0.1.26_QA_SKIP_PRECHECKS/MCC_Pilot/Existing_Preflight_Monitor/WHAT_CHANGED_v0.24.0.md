# v0.24.0 - the issue list now shows only real issues in THIS batch

The old list mixed everything the tool found: org-wide counts, jobs, staged-data issues, a record
flagged by two checks, things the load had not reached, and checks that could not run. It is now
"Issues in this batch", and a row is in the main list only if it is:
1. a finding about Salesforce RECORDS,
2. about this batch (not an org-wide count),
3. on a step the load has reached, and
4. not contradicted by the verification pass.

The same records flagged by two checks are one row ("same records also flagged by ...").
Columns are Step, What is wrong, Records, Checked, What to do. Severity is "MUST FIX" or "REVIEW".

Everything else is still there, folded under a plain heading that says why it is not above:
- Not about this batch, or not confirmed (with the reason)
- Other signals (async jobs, log entries, staged rows, steps that produced nothing)
- Will matter later (loaded data on a step the load has not reached)
- Could not be checked (grouped by reason; not a pass)

"Not about this batch" depends on the verification pass (v0.23.0+), which learns a check's scope from
the queries it actually sent. A run made before that has no scope information, so its records
checks are all treated as this batch's.
