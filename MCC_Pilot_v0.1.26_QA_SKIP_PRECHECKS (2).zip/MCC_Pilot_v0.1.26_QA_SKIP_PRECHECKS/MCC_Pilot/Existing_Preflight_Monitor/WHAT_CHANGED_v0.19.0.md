# MCC - Preflight Monitoring Tool — v0.19.0

Adds **live Informatica IDMC reads** by binding to the Sunrise app's own `informatica_live.py`,
the same way `connections.py` already binds to `goose_live.py`. Cumulative over v0.18.0.

## What changed for you

The Time column and "where this batch is" no longer depend on someone having saved a live-ops
capture. When the credential environment variables are set, the tool logs in to IDMC and reads
the activity log directly, so the pipeline reflects what ran minutes ago.

Provenance stays visible: a live row is labelled `live API`, a captured one keeps its filename.
When both describe the same step, **the live row wins** — it is newer by definition, and a
captured file can be days old.

## It cannot start a taskflow, and that is enforced

Your `informatica_live.py` can start taskflows: `start_taskflow`, `run_and_wait`,
`_invoke_advanced_taskflow`. **The adapter names none of them.**

This is not a style preference. `tf_90a_CleanUpFailedOrderActivations` deletes WorkOrders and
MaintenancePlans at steps 8 and 9 of 11, then fails at step 10 on the Teams notification — on
2026-10-02 it destroyed **81 records across 11 runs** because the rebuild never ran. A pre-flight
*monitor* that can launch taskflows is not a monitor, and the one thing this tool guarantees is
that it cannot change anything.

`test_offline` asserts the adapter's source never names those three. **The assertion is
mutation-tested**: adding a single `start_taskflow` call makes the suite fail.

The adapter also has no HTTP stack of its own — it uses your `_json_request`/`_headers` — and
never touches the environment, so there is nowhere for a credential to leak through it.

## Credentials

Never handled by the tool, never stored, never logged. Your `credentials()` reads them from
environment variables only. `config.json` holds the variable **names**, the login URL and the
project/folder — never a secret.

If either variable is unset, **no login is attempted at all**: no delay, no error, the tool falls
back to captured history and the self-test says so. Verified at 0.00s against a machine with no
credentials.

Set these as Windows user variables (the adapter reads `HKCU\Environment`, so no reboot):

    INFORMATICA_USERNAME
    INFORMATICA_PASSWORD

## New in config.json

| Key | Default | What it does |
|---|---|---|
| `InformaticaLive` | `true` | `false` uses captured history only |
| `InformaticaUsernameEnv` | `INFORMATICA_USERNAME` | env var **name** |
| `InformaticaPasswordEnv` | `INFORMATICA_PASSWORD` | env var **name** |
| `InformaticaLoginUrl` | `.../ma/api/v2/user/login` | pod `serverUrl` comes from the response |
| `InformaticaProject` | `_Sunrise - QA Testing` | where to discover taskflows |
| `InformaticaFolder` | `00 Migration Steps` | folder within it |

## One read endpoint is new

Your adapter's `get_run_status` needs a `runId`; the pre-flight needs "when did each step last
run" across all of them. So `recent_runs()` calls `/api/v2/activity/activityLog`, built on your
own request plumbing. It tries `?rowLimit=N` first and falls back to the bare resource if a pod
rejects the parameter — both paths tested.

## Tests
`453` assertions (was `429`), all passing. New coverage: the read-only guard (mutation-tested),
silent degradation with no credentials and no Sunrise folder, the scripted-session live read, the
`rowLimit` fallback, live-beats-stale-captured, one login shared across reads, `reset_session`,
and an activity entry with no readable name being **skipped rather than guessed at**.

## Not verified — read before trusting
- **No live IDMC call has been made.** There are no credentials and no network to Informatica in
  the environment this was built in. Binding to your module is verified against your real
  `informatica_live.py`; the HTTP exchange is tested only against a scripted session.
- **`?rowLimit=` is my reading of the v2 paging parameter, not something I confirmed.** If your pod
  rejects it the fallback handles it, so the cost of being wrong is one wasted request.
- **activityLog field names are read tolerantly** (`taskName`/`assetName`/`objectName`,
  `state`/`status`, `startTime`/`endTime`, `successRows`/`failedRows`). If a pod returns shapes none
  of those cover, entries are skipped, not guessed — you would see a blank Time column, never a
  wrong one.
- **The tool now makes outbound HTTPS to IDMC** where before it only ran the `sf` CLI. Reads only,
  but it is a new network footprint worth knowing about.

## Still true
Salesforce access is unchanged: four subprocess calls in the whole tool, `sf data query` ×2 and
`sf sobject describe` ×2. No DML, no `Database.*`, no `sf apex run`.
