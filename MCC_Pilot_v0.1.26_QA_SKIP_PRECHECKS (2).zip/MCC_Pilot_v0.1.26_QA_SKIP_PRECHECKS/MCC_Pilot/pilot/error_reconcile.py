"""Strict Goose error-to-staging reconciliation.

Only an exact, configured SourceObject + SourceObjectID match in the selected
Goose migration batch may be excluded. No fuzzy matching and no DELETE.
LogType and error codes must both be allowlisted. The existing Goose error log
is append-only: each successfully excluded row receives an MCC resolution entry.
"""
from __future__ import annotations

import csv
import json
import re
from datetime import datetime
from pathlib import Path
from .goose_exclusions import exclude, _lit

KNOWN_STAGES = {
    'STG_Customer': 'Customer',
    'STG_CustomerContact': 'CustomerContact',
    'STG_Order': 'Order',
    'STG_OrderLineItem': 'OrderLineItem',
    'STG_OrderLineItemService': 'OrderLineItemService',
    'STG_OrderLineItemServiceSchedule': 'OrderLineItemServiceSchedule',
}
LOG_FIELDS = ('ErrorLogID', 'LogType', 'ProcessName', 'ProcessStep', 'SourceObject', 'SourceRecordID', 'ErrorMessage')


def _rows(sets):
    return [r for group in sets for r in group if isinstance(r, dict)]


def _log_sql(batch_id, limit):
    return (f"SELECT TOP ({int(limit)}) E.ID AS ErrorLogID, E.LogType, E.ProcessName, "
            "E.ProcessStep, E.SourceObject, E.SourceRecordID, E.ErrorMessage "
            "FROM dbo.GOOSE_ErrorLog E "
            f"WHERE E.MigrationBatchID = {int(batch_id)} "
            "AND ISNULL(E.LogType, '') <> 'MCC_EXCLUDED' ORDER BY E.ID DESC")


def _match_stage(goose, table, source_record_id, batch_id):
    """Use *source* id (never assume SourceRecordID is the staging PK).

    Require exactly one eligible row. If the same source id appears more than
    once in this batch, do not exclude either row.
    """
    if table not in KNOWN_STAGES or not str(source_record_id).strip():
        return []
    q = ("SELECT TOP (2) S.ID, S.TransformationID, S.SourceObjectID "
         f"FROM dbo.{table} S INNER JOIN dbo.TRFM_Transformation T ON T.ID = S.TransformationID "
         f"WHERE T.MigrationBatchID = {int(batch_id)} "
         f"AND S.SourceObjectID = {_lit(str(source_record_id).strip())} "
         "AND ISNULL(S.SFDC_Goose_ExclusionReason,'') = '' ORDER BY S.ID")
    return _rows(goose.result_sets(q))


def _log_resolution(goose, batch_id, stage, source_id, step, error_id):
    """Append only; never erase original Informatica/Goose errors."""
    message = f'MCC excluded source record; original Goose error ID {int(error_id)}'
    q = ("SET XACT_ABORT ON; "
         "INSERT INTO dbo.GOOSE_ErrorLog "
         "(CreatedDate, MigrationBatchID, LogType, ProcessName, ProcessStep, SourceObject, SourceRecordID, ErrorMessage) "
         f"VALUES (GETDATE(), {int(batch_id)}, N'MCC_EXCLUDED', N'MCC_Pilot', "
         f"{_lit(str(step)[:50])}, {_lit(stage[:50])}, {_lit(str(source_id)[:100])}, {_lit(message[:255])}); "
         "SELECT TOP (1) ID AS ResolutionID FROM dbo.GOOSE_ErrorLog "
         f"WHERE MigrationBatchID = {int(batch_id)} AND LogType = 'MCC_EXCLUDED' "
         f"AND SourceObject = {_lit(stage[:50])} AND SourceRecordID = {_lit(str(source_id)[:100])} "
         "ORDER BY ID DESC;")
    matches = [r for r in _rows(goose.result_sets(q)) if r.get('ResolutionID') is not None]
    if len(matches) != 1:
        raise RuntimeError('Goose resolution entry not verified')
    return matches[0]['ResolutionID']


def reconcile(goose, root: Path, output: Path, *, batch_id: int, step: str,
              mode: str, identity_ok: bool = True):
    """Assess bounded Goose errors and optionally exclude exact proven candidates.

    Unapproved, ambiguous and unverified records remain untouched and appear in
    the local reconciliation CSV. Caller decides how to handle uncertain writes.
    """
    cfg_path = root / 'auto_exclusion_rules.json'
    cfg = json.loads(cfg_path.read_text(encoding='utf-8')) if cfg_path.exists() else {}
    cap = min(500, max(1, int(cfg.get('max_errors_per_scan', 100))))
    permitted = set(cfg.get('enabled_stages', [])) & set(KNOWN_STAGES)
    allowed_types = {str(x).upper() for x in cfg.get('allowed_log_types', [])}
    patterns = [re.compile(p, re.I) for p in cfg.get('allowed_error_patterns', [])]
    enabled = bool(cfg.get('enabled')) and mode == 'live' and identity_ok
    results = []
    errors = _rows(goose.result_sets(_log_sql(batch_id, cap))) if mode != 'simulate' else []
    for e in errors:
        item = dict(batch_id=int(batch_id), step=step, error_log_id=e.get('ErrorLogID'),
                    source_object=e.get('SourceObject'), source_record_id=e.get('SourceRecordID'),
                    message=str(e.get('ErrorMessage') or '')[:255], action='REVIEW', stage_id='', resolution_id='')
        stage = str(e.get('SourceObject') or '').strip()
        try:
            if stage not in permitted:
                item['action'] = 'NOT_ALLOWLISTED_STAGE'
            elif str(e.get('LogType') or '').upper() not in allowed_types:
                item['action'] = 'NOT_ALLOWLISTED_LOG_TYPE'
            elif not any(p.search(str(e.get('ErrorMessage') or '')) for p in patterns):
                item['action'] = 'NOT_ALLOWLISTED_ERROR'
            else:
                found = _match_stage(goose, stage, e.get('SourceRecordID'), batch_id)
                if len(found) != 1:
                    item['action'] = 'AMBIGUOUS_OR_ALREADY_EXCLUDED'
                else:
                    item['stage_id'] = int(found[0]['ID'])
                    item['action'] = 'READY_TO_EXCLUDE' if not enabled else 'EXCLUSION_STARTED'
                    if enabled:
                        record = exclude(goose, output.parent / 'goose_exclusions.jsonl',
                                         batch_id=batch_id, stage_table=stage,
                                         record_id=int(found[0]['ID']),
                                         reason=f"Goose error {int(e['ErrorLogID'])}: {item['message'][:65]}",
                                         step=step)
                        if record['status'] != 'EXCLUDED':
                            item['action'] = 'WRITE_UNVERIFIED'
                        else:
                            item['action'] = 'EXCLUDED_LOG_PENDING'
                            item['resolution_id'] = _log_resolution(goose, batch_id, stage,
                                             str(e.get('SourceRecordID')), step, int(e['ErrorLogID']))
                            item['action'] = 'EXCLUDED_AND_LOGGED'
        except Exception as exc:
            # Database writes may have committed before the connection broke.
            # Flag reconciliation instead of triggering another blind attempt.
            item['action'] = 'WRITE_OUTCOME_UNKNOWN' if item['action'] in (
                'EXCLUSION_STARTED', 'EXCLUDED_LOG_PENDING') else 'QUERY_FAILED'
            item['error'] = str(exc)[:300]
        results.append(item)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', newline='', encoding='utf-8') as f:
        cols = ['batch_id', 'step', 'error_log_id', 'source_object', 'source_record_id',
                'message', 'stage_id', 'action', 'resolution_id', 'error']
        writer = csv.DictWriter(f, cols, extrasaction='ignore'); writer.writeheader()
        writer.writerows(results)
    return dict(scanned=len(errors), excluded=sum(x['action'] == 'EXCLUDED_AND_LOGGED' for x in results),
                uncertain=sum(x['action'] in ('WRITE_UNVERIFIED','WRITE_OUTCOME_UNKNOWN') for x in results),
                reviewed=sum(x['action'] not in ('EXCLUDED_AND_LOGGED',) for x in results),
                evidence=str(output), rows=results)
