"""
What actually landed, per Salesforce object.

The run book answers "can I advance past Run Order N". It does NOT answer the first
question anyone actually asks: *how much of this batch is in Salesforce, and how much of
it is wrong?* That needs one row per object, in migration order, and nothing in this tool
produced it -- the counts existed only scattered across individual checks.

TWO NUMBERS PER OBJECT, and they come from different places on purpose:

  LOADED   a COUNT of records attributable to this batch, through the object's own
           documented scoping path. This is the real population in the org right now.
  ERRORS   the sum of evidence counts from every FAILING check whose sobject is this
           object. Not a second query -- it is what the checks already found.

The scoping paths below are the ones already proven by the checks; they are not invented
here. Where an object has no reliable batch path it says so and reports UNSCOPED rather
than a zero, because a zero that means "I could not ask" is the failure mode this whole
tool exists to prevent.

ACCOUNT, CONTACT AND ACR ARE THE SUBTLE ONES. In an acquisition onboarding the Accounts
ALREADY EXIST and are never tagged with the batch, so Account.USS_Migration_Batch__c is
null on every one. They are reached through the batch's Quotes instead. "Loaded" for
these objects therefore means TOUCHED BY THIS BATCH, not created by it -- which is why the
window column matters: a 2019 CreatedDate with a last-modified inside the run window is an
updated pre-existing Account, and that is correct, not suspicious.
"""
from __future__ import annotations

import jobruns

B = "{BATCH}"

# (sequence, object, label, batch-scoped COUNT soql or "" when no reliable path exists)
TALLY = [
 (10, "USS_Migration_Batch__c", "Migration Batch",
      "SELECT COUNT() FROM USS_Migration_Batch__c WHERE Name = '{BATCH}'"),
 (20, "Account", "Accounts",
      "SELECT COUNT() FROM Account WHERE Id IN (SELECT SBQQ__Account__c FROM SBQQ__Quote__c "
      "WHERE USS_Migration_Batch__r.Name = '{BATCH}' AND SBQQ__Account__c != null)"),
 (30, "Contact", "Contacts",
      "SELECT COUNT() FROM Contact WHERE AccountId IN (SELECT SBQQ__Account__c "
      "FROM SBQQ__Quote__c WHERE USS_Migration_Batch__r.Name = '{BATCH}' "
      "AND SBQQ__Account__c != null)"),
 (40, "AccountContactRelation", "Account Contact Relations",
      "SELECT COUNT() FROM AccountContactRelation WHERE AccountId IN "
      "(SELECT SBQQ__Account__c FROM SBQQ__Quote__c "
      "WHERE USS_Migration_Batch__r.Name = '{BATCH}' AND SBQQ__Account__c != null)"),
 (50, "USF_Address__c", "Addresses",
      "SELECT COUNT() FROM USF_Address__c WHERE Id IN (SELECT NF_USF_Address__c "
      "FROM NF_Quoted_Jobsite__c WHERE NF_Quote__r.USS_Migration_Batch__r.Name = '{BATCH}' "
      "AND NF_USF_Address__c != null)"),
 (60, "Opportunity", "Opportunities",
      "SELECT COUNT() FROM Opportunity WHERE USS_Migration_Batch__r.Name = '{BATCH}'"),
 (70, "Purchase_Order__c", "Purchase Orders",
      "SELECT COUNT() FROM Purchase_Order__c WHERE USS_Migration_Batch__r.Name = '{BATCH}'"),
 (80, "SBQQ__Quote__c", "Quotes",
      "SELECT COUNT() FROM SBQQ__Quote__c WHERE USS_Migration_Batch__r.Name = '{BATCH}'"),
 (90, "SBQQ__QuoteLine__c", "Quote Lines",
      "SELECT COUNT() FROM SBQQ__QuoteLine__c "
      "WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '{BATCH}'"),
 (100, "NF_Quoted_Jobsite__c", "Quoted Jobsites",
       "SELECT COUNT() FROM NF_Quoted_Jobsite__c "
       "WHERE NF_Quote__r.USS_Migration_Batch__r.Name = '{BATCH}'"),
 (110, "Order", "Orders",
       "SELECT COUNT() FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '{BATCH}'"),
 (120, "OrderItem", "Order Products",
       "SELECT COUNT() FROM OrderItem WHERE OrderId IN (SELECT Id FROM Order "
       "WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '{BATCH}')"),
 (130, "Contract", "Contracts",
       "SELECT COUNT() FROM Contract WHERE USS_Migration_Batch__r.Name = '{BATCH}'"),
 (140, "SBQQ__Subscription__c", "Subscriptions",
       "SELECT COUNT() FROM SBQQ__Subscription__c WHERE SBQQ__Contract__c IN "
       "(SELECT Id FROM Contract WHERE USS_Migration_Batch__r.Name = '{BATCH}')"),
 (150, "MaintenancePlan", "Maintenance Plans",
       "SELECT COUNT() FROM MaintenancePlan "
       "WHERE Contract__r.USS_Migration_Batch__r.Name = '{BATCH}'"),
 (160, "WorkOrder", "Work Orders",
       "SELECT COUNT() FROM WorkOrder WHERE Contract__r.USS_Migration_Batch__r.Name = '{BATCH}'"),
 (170, "WorkOrderLineItem", "Work Order Line Items",
       "SELECT COUNT() FROM WorkOrderLineItem WHERE WorkOrderId IN "
       "(SELECT Id FROM WorkOrder WHERE Contract__r.USS_Migration_Batch__r.Name = '{BATCH}')"),
 (180, "ServiceAppointment", "Service Appointments",
       "SELECT COUNT() FROM ServiceAppointment WHERE Work_Order__c IN "
       "(SELECT Id FROM WorkOrder WHERE Contract__r.USS_Migration_Batch__r.Name = '{BATCH}')"),
 (190, "AssignedResource", "Assigned Resources", ""),
 (200, "Billing_Impacts_Queue__c", "BIQs",
       "SELECT COUNT() FROM Billing_Impacts_Queue__c "
       "WHERE Parent_USS_Order__r.USS_Migration_Batch__r.Name = '{BATCH}'"),
]

# Which Run Order actually creates each object. This is what separates NOT LOADED YET
# from MISSING: an object whose producing step has not run yet is not a defect, and
# counting its zero as an error makes every early-batch run look catastrophic.
# 0 means "pre-existing / not created by this run book".
PRODUCED_AT = {
    "USS_Migration_Batch__c": 1,  "Account": 6,   "Contact": 6,
    "AccountContactRelation": 8,  "USF_Address__c": 10, "Opportunity": 0,
    "Purchase_Order__c": 0,       "SBQQ__Quote__c": 10, "SBQQ__QuoteLine__c": 11,
    "NF_Quoted_Jobsite__c": 11,   "Order": 17,    "OrderItem": 17,
    "Contract": 19,               "SBQQ__Subscription__c": 19,
    "MaintenancePlan": 35,        "WorkOrder": 19, "WorkOrderLineItem": 19,
    "ServiceAppointment": 48,     "AssignedResource": 48,
    "Billing_Impacts_Queue__c": 48,
}

# Objects whose records this batch UPDATES rather than creates. CreatedDate is therefore
# old and meaningless for them, and only LastModifiedDate shows the batch touched them.
UPDATED_NOT_CREATED = {"Account", "Contact", "AccountContactRelation", "USF_Address__c"}


TALLY_WORKERS = 6
TALLY_SECONDS = 90


def collect(conn, results=None, say=None, reached_ro: int = 0) -> list[dict]:
    """
    One row per object: how many landed, when, and how many are wrong.

    `results` is the list of Result objects from this run; errors are summed from it
    rather than re-queried, so the band can never disagree with the run book below it.
    """
    # Only checks that count Salesforce RECORDS feed a tile, and a record that two checks both
    # flag is one failing record, not two. A job count or a staged-row count is a different
    # unit and has no business on an object tile.
    import terms, verify
    ids, extra, err_checks = {}, {}, {}
    for r in (results or []):
        if r.verdict != "FAIL" or not terms.is_record(r.check_id):
            continue
        obj = getattr(r, "sobject", "") or _obj_of(r.check_id)
        if not obj:
            continue
        rows = list(r.evidence_sample or [])
        rid_ = verify.record_ids(rows)
        if rows and len(rid_) == len(rows):
            ids.setdefault(obj, set()).update(i[:15] for i in rid_)
        else:
            extra[obj] = extra.get(obj, 0) + int(r.evidence_count or 0)
        err_checks.setdefault(obj, []).append(r.check_id)
    errs = {o: len(ids.get(o, ())) + extra.get(o, 0) for o in set(ids) | set(extra)}

    def one(seq, obj, label, soql):
        made_at = PRODUCED_AT.get(obj, 0)
        row = dict(sequence=seq, sobject=obj, label=label, loaded=None, state="",
                   first="", last="", modified="", errors=int(errs.get(obj, 0) or 0),
                   error_checks=", ".join(err_checks.get(obj, [])), note="",
                   produced_at=made_at, pending=False)
        if not soql:
            row["state"] = "UNSCOPED"
            row["note"] = ("No reliable batch-scoping path for this object. Reporting "
                           "UNSCOPED rather than 0 -- a zero here would mean 'could not "
                           "ask', not 'none exist'.")
            return row
        q = soql.replace("{BATCH}", conn.batch)
        try:
            w = jobruns.window_from_stamps(conn, q)
            n = w.get("count")
            if n is None:
                n = conn.n(q)
                w = {}
            n = int(n)
            row.update(loaded=n, state="OK", first=w.get("first", ""),
                       last=w.get("last", ""), modified=w.get("modified", ""))
            # Nothing loaded AND the step that creates it has not been reached yet.
            # That is not a defect, so its errors are not counted as errors.
            if n == 0 and made_at and reached_ro and made_at > reached_ro:
                row.update(state="PENDING", pending=True, errors=0, error_checks="",
                           note="Run Order %d has not run yet, so nothing has been loaded "
                                "here. Not counted as an error." % made_at)
            elif n == 0 and made_at and made_at <= (reached_ro or 0):
                row["note"] = ("Run Order %d has run, and this object is still empty. That "
                               "is a real gap, not a pending load." % made_at)
            if obj in UPDATED_NOT_CREATED:
                row["note"] = ("Reached through this batch's Quotes. These records already "
                               "existed and were UPDATED, so CreatedDate is old by design -- "
                               "last-modified is what shows the batch touched them.")
        except Exception as e:                                   # noqa: BLE001
            row["state"] = "ERROR"
            row["note"] = str(e)[:300]
        return row

    # Objects are counted side by side, and each one gets a time limit. A count on a very
    # large table (Order Products, Work Order Lines) used to hold the whole run for minutes
    # with nothing on screen. A count that does not answer in time is reported as such --
    # never as zero.
    import concurrent.futures as cf
    ex = cf.ThreadPoolExecutor(max_workers=TALLY_WORKERS)
    futs = [(item, ex.submit(one, *item)) for item in TALLY]
    out = []
    for (seq, obj, label, soql), fut in futs:
        try:
            row = fut.result(timeout=TALLY_SECONDS)
        except cf.TimeoutError:
            row = dict(sequence=seq, sobject=obj, label=label, loaded=None, state="ERROR",
                       first="", last="", modified="", errors=int(errs.get(obj, 0) or 0),
                       error_checks=", ".join(err_checks.get(obj, [])),
                       note="Salesforce did not answer the count for %s within %d seconds, so "
                            "the number is unknown -- not zero." % (label, TALLY_SECONDS),
                       produced_at=PRODUCED_AT.get(obj, 0), pending=False)
        out.append(row)
        if say:
            say("%-26s %s" % (label, row["loaded"] if row["state"] == "OK" else row["state"]))
    ex.shutdown(wait=False)
    return out


_OBJ_BY_CHECK = None


def _obj_of(check_id: str) -> str:
    global _OBJ_BY_CHECK
    if _OBJ_BY_CHECK is None:
        import registry
        _OBJ_BY_CHECK = {c.id: c.sobject for c in registry.all_checks()}
    return _OBJ_BY_CHECK.get(check_id, "")


def totals(rows: list[dict]) -> dict:
    """Errors EXCLUDE objects whose load step has not run -- those are pending, not wrong."""
    live = [r for r in rows if not r.get("pending")]
    return dict(
        loaded=sum(int(r["loaded"] or 0) for r in live if r["state"] == "OK"),
        errors=sum(int(r["errors"] or 0) for r in live),
        objects=len([r for r in live if r["state"] == "OK" and (r["loaded"] or 0) > 0]),
        pending=len([r for r in rows if r.get("pending")]),
        unscoped=len([r for r in rows if r["state"] == "UNSCOPED"]),
        empty_but_due=len([r for r in live if r["state"] == "OK" and not (r["loaded"] or 0)
                           and r.get("produced_at")]),
    )
