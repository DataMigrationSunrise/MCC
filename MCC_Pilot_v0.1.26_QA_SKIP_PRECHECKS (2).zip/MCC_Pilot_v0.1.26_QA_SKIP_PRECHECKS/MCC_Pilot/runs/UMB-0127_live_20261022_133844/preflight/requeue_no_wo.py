"""UMB-0127 (Sunrise-QA): MCC work-order requeue for contracted orders with no WOs, then error reconciliation."""
import sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, contract_orders as co

folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
c = systems.build(app.CFG, 'dry', lambda m: None)
c.sf.alias = 'Sunrise-QA'  # UMB-0127 lives in QA; config.json now points at Stage for UMB-0069
c.sf.allowed_hosts = ['ussprod--qa.sandbox.my.salesforce.com']
assert 'ussprod--qa.' in c.sf.verify_sandbox(), 'not QA'
since = co._utc_now()
co.requeue_without_work_orders(c.sf, c.goose, 'aFOVD0000001Swj4AE', 468, folder, 'TF_90A.C')
co.reconcile(c.sf, c.goose, 'aFOVD0000001Swj4AE', 468, folder, 'TF_90A.C', since)
