"""Validated extension loader: unknown/missing work is never treated as success."""
import json
from pathlib import Path

ALLOWED = {"informatica", "snaplogic", "apex", "goose_sql", "goose_gen_check", "goose_gen_fix", "contract_orders"}

def load_extension(path):
    if not path.exists():
        return {"steps": [], "required_milestones": []}
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(obj, dict) or not isinstance(obj.get("steps"), list):
        raise ValueError("Invalid runbook_extension.json: steps must be a list")
    return obj

def validate_extension(extension, scripts, cfg):
    errors = []
    milestones = extension.get("required_milestones") or []
    if not milestones:
        errors.append("No required end-to-end milestones defined")
    seen = set()
    for step in extension.get("steps", []):
        key, kind = step.get("id"), step.get("kind")
        if not key or key in seen:
            errors.append("Missing or duplicate extension step ID: %s" % key)
        seen.add(key)
        if kind not in ALLOWED:
            errors.append("%s unsupported step kind %s" % (key, kind))
        if not step.get("blocking") and not step.get("diagnostic"):
            errors.append("%s must have blocking=true unless it is a read-only diagnostic" % key)
        if kind in {"apex", "goose_sql", "goose_gen_check", "goose_gen_fix"}:
            script = step.get("script", "")
            if not script or Path(script).name != script or not (scripts / script).is_file():
                errors.append("%s requires a real script in scripts/: %s" % (key, script))
        if kind == "informatica" and not cfg.get("Informatica", {}).get("Taskflows", {}).get(key):
            errors.append("%s missing Informatica taskflow mapping" % key)
        if kind == "snaplogic" and not cfg.get("SnapLogic", {}).get("TriggeredTaskUrls", {}).get(key):
            errors.append("%s missing SnapLogic triggered task URL" % key)
        for field in ("id", "ro", "name", "system"):
            if not step.get(field):
                errors.append("%s missing %s" % (key, field))
    available = {s.get("id") for s in extension.get("steps", [])}
    errors.extend("Required milestone %s is not an extension step" % m for m in milestones if m not in available)
    if cfg.get("StopAfter"):
        errors.append("StopAfter is still set to %s" % cfg["StopAfter"])
    return errors
