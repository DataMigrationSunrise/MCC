# v0.30.0 - the Maintenance Plan check says WHY a plan was flagged

Spot checks found plans flagged "generated no Work Orders" that did have services. The check only counts a Work Order
that names the plan AND is marked IsGeneratedFromMaintenancePlan, so services created another way are invisible to it.

- The verdict logic is unchanged. For every flagged plan the check now also looks (two extra queries for the whole batch,
  no per-plan loop) at Work Orders that name the plan whatever their flag, and Work Orders on the plan's Contract.
- Each flagged plan carries: work_orders_naming_the_plan, work_orders_on_its_contract, likely_cause. They show on the
  records page and in Export issues, and the note gives the breakdown, e.g. "30 Work Orders name the plan but are not
  marked generated; 5 no Work Order on the plan or its Contract".
- After one run this tells us whether to drop the flag condition, match on the Contract, or that some plans are real.
