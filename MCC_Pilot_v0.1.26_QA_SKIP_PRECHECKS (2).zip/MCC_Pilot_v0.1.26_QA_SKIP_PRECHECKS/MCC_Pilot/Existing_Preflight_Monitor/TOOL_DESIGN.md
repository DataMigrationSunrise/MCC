# MCC - Preflight Monitoring Tool — the actual tool

**Status:** design. No code written.
Companion to `DESIGN.md` (the eight self-check mechanisms), which this assumes.

---

## The insight that reorganises the whole tool

`4.7%` is not a finding. **`4.7%` against `97.4%` and `100%` is a finding.**

UMB-0116 having 750 of 786 Activated Contracts with no BIQs only became alarming when measured
against UMB-0113 (97.4%) and UMB-0114 (100%). Alone, it is a number nobody can act on — and it sat
there, visible, for days.

So cross-batch baselining is not a proof-of-concept convenience bolted on the side. **It is the
primary feature.** A check that returns a number without a baseline is a check nobody will act on.

That means every check emits a **metric**, not just a verdict, and the tool keeps history.

12 batches are referenced in the repository today — 0059, 0064, 0065, 0067, 0104, 0105, 0112, 0113,
0114, 0115, 0116, 0117 — which is enough population for a real baseline from day one.

---

## Module layout

```
preflight_monitor/
  RUN-PREFLIGHT-MONITOR.bat        launch dashboard
  RUN-POPULATE-HISTORY.bat         backfill all historical batches
  config.json                      org alias, goose server/db, thresholds, severity profile

  connections.py      THE ONLY FILE THAT IMPORTS SUNRISE. ~80 lines.
  store.py            SQLite: schema, migrations, read/write
  model.py            Check, Evidence, Result, Metric, Fixture, Rule  (dataclasses)
  registry.py         every check declared as data; import-time validation
  checks/
    batch_scope.py    blind spot, scope resolution
    contract.py       billing dates, FSC eligibility, activation
    biq.py            coverage, null effective date, rule comparison
    workorders.py     missing service WOs, polygons, MP generation
    quotes.py         serviceable zip, not-ordered, geocode
    goose_parity.py   SF vs Goose counts per object
    sunrise_xcheck.py Sunrise's claims vs live reality
  selftest.py         the six startup stages
  baseline.py         cross-batch metric history, outlier classification
  runner.py           orchestration, verdict assignment, fixtures
  report.py           xlsx output (reuses preflight_to_workbook patterns)
  server.py           ThreadingHTTPServer: gate view, monitor view, baseline view
```

---

## Data model

The addition that makes baselining work: a check returns **evidence plus a metric**.

```python
@dataclass(frozen=True)
class Check:
    id:            str      # "BIQ.COVERAGE"
    name:          str
    stage:         str      # "tf_60"
    sequence:      int      # 200  -> position in the object spine
    sobject:       str      # "Billing_Impacts_Queue__c"
    severity:      str      # BLOCKER | WARNING | INFO
    rule:          str      # the assertion
    rule_source:   str      # where the rule comes from  (REQUIRED)
    requires:      list     # ["Contract.LastBillingDate__c", ...]
    canary:        Callable # must return rows if scoping is sound
    run:           Callable # -> Evidence
    metric:        Callable # -> Metric | None    <- enables baselining
    proves:        str      # REQUIRED
    cannot_prove:  str      # REQUIRED
    goose:         bool = False    # needs Goose
    sunrise:       bool = False    # needs Sunrise outputs

@dataclass
class Metric:
    name:  str     # "BIQ coverage"
    value: float   # 0.047
    unit:  str     # "ratio" | "count" | "days"
    numerator: int
    denominator: int

@dataclass
class Result:
    check_id: str
    batch: str
    verdict: str          # PASS | FAIL | UNPROVEN   (assigned by the runner)
    reason: str           # why UNPROVEN, when it is
    evidence_count: int
    evidence_sample: list
    metric: Metric | None
    baseline: BaselineComparison | None
    ran_at: str
    duration_ms: int
```

`registry.py` validates at import: every check has `rule_source`, `proves`, `cannot_prove`, a canary,
and a unique id. **A check missing any of those raises at startup, not at runtime.**

---

## Storage — SQLite, one file

`preflight_history.db`. No server, queryable by hand, and it accumulates.

```sql
batch(name PK, sf_batch_id, goose_batch_id, sf_status, goose_status,
      activated_contracts, first_seen, last_seen, is_test)

run(run_id PK, batch, mode, started, finished, tool_version,
    sf_alias, goose_server, source_mode)        -- mode: POPULATE|GATE|MONITOR

result(run_id, check_id, verdict, reason, evidence_count,
       metric_value, metric_num, metric_den, duration_ms,
       PRIMARY KEY(run_id, check_id))

evidence(run_id, check_id, record_id, payload_json)     -- sampled, capped

fixture(check_id, batch, expected_count, state, last_confirmed, note)
        -- state: PRESENT | FIXED | BROKEN_CHECK | CHANGED

rule(rule_id PK, sobject, field, assertion, source, registered_by)

selftest(run_id, stage, status, detail)
```

Why SQLite rather than CSVs: the baseline question — *"how does this batch's BIQ coverage compare to
every prior batch"* — is one `GROUP BY` away, and becomes a pile of glue code against files.

---

## Populating previous batches

`RUN-POPULATE-HISTORY.bat` → `runner.populate()`

1. **Discover batches.** `SELECT Id, Name, Batch_Status__c, CreatedDate FROM USS_Migration_Batch__c`,
   plus the Goose `MigrationBatch` table, plus any batch name appearing in the repo. Reconcile the
   three into the `batch` table, recording **where each one disagrees** — Salesforce and Goose
   already disagree on status today, and that disagreement is itself a finding worth storing.

2. **For each batch, oldest first:** run the full check pack read-only. Store results and metrics.

3. **Build the baseline.** For each check with a metric, the distribution across all batches.

4. **Report.** Which batches are outliers, on which checks, by how much.

Entirely read-only. A closed or cancelled batch is read exactly like an open one — the queries do
not care, and historical batches are the more valuable data precisely because their outcomes are
already known.

**Expected runtime:** 12 batches × ~25 checks × ~2 queries ≈ 600 SOQL calls. Minutes, not hours.
This is cheap enough to re-run whenever a check is added, which matters — a new check should
retroactively gain a full history.

---

## Baseline comparison

For each check with a metric, across batches:

```
BIQ.COVERAGE
  UMB-0112  0.981   UMB-0113  0.974   UMB-0114  1.000
  UMB-0116  0.047   <-- OUTLIER: 20.7 sigma below the mean of prior batches
```

Classification, in order:

| Class | Meaning |
|---|---|
| `NORMAL` | within tolerance of the prior-batch distribution |
| `OUTLIER` | outside it — the number and the direction are both reported |
| `FIRST_OF_KIND` | no prior batch has a value for this check; **no judgement offered** |
| `REGRESSION` | this batch is worse than the immediately preceding one |
| `IMPROVED` | better — reported, because a check silently starting to pass needs a reason |

`FIRST_OF_KIND` matters: when a check is new, the honest answer is "no basis for comparison yet,"
not a fabricated threshold. The tool says so and offers nothing more.

---

## Proof of concept — what success looks like

The PoC is not "it runs." It is: **point it at history and it independently rediscovers the defects
we spent two days finding — without being told they exist.**

Run `populate` with the fixture table **empty**, then check whether the baseline report surfaces, on
its own:

| Should be rediscovered | How |
|---|---|
| UMB-0116 BIQ coverage 4.7% vs 97–100% | `BIQ.COVERAGE` outlier |
| 18 FSC BIQs with null Effective Date | `BIQ.FSC_NULL_EFFECTIVE_DATE` FAIL, plus UMB-0104/0105 |
| 501 dead ServiceTerritory polygons | `WO.DEAD_POLYGON` FAIL, org-wide |
| 5 active MPs generating no Work Orders | `WO.MP_NO_GENERATION` FAIL |
| Salesforce 163 BIQs vs Goose 124 | `GOOSE.BIQ_PARITY` disagreement |
| Salesforce / Goose batch status disagreement | populate step 1 |

**Every one of these was found manually this week. If the tool does not find them from a cold start,
the PoC failed** — and that is a far better test than any synthetic fixture, because the answers are
already known and were expensive to get.

Two outcomes are both informative:
- It finds them → the design works, and the fixtures can now be populated from its own output
- It misses one → that check's canary or scoping is wrong, discovered now rather than in Production

### Milestones

| | Scope | Proves |
|---|---|---|
| **M1** | `connections.py`, `store.py`, `model.py`, `selftest.py`, 3 checks, populate across 12 batches | The spine works; schema and canaries behave against real orgs |
| **M2** | `baseline.py` + the full ~25-check registry | The rediscovery test above |
| **M3** | `server.py` gate + monitor views, `report.py` | Usable by someone who did not build it |
| **M4** | Fixtures, rule contradiction detection, coverage self-audit | The self-checking half of `DESIGN.md` |

M1 and M2 are the proof of concept. M3 and M4 make it a tool.

---

## The dashboard

**Gate view** — one batch, now.
Verdict banner (BLOCKERS / UNPROVEN counts — never a single health score), check list grouped by
stage with verdict, metric and baseline class, and a "cannot prove" column that is always visible
rather than hidden behind a click.

**Monitor view** — same checks on a timer. Delta since last pass, a running timeline, and newly
failing checks surfaced at the top.

**Baseline view** — the cross-batch matrix. Checks as rows, batches as columns, metric in each cell,
outliers marked. This is the view that makes `4.7%` legible, and it is the one most likely to be
screenshotted into a status update.

**Coverage view** — the 20-object spine with check counts per object, so the gaps are visible by
default. Mechanism 7 of `DESIGN.md`.

---

## Decisions still open

1. **Where it runs.** On the Sunrise box, `connections.py` imports `goose_live` directly. Anywhere
   else needs the standalone PowerShell path — same ~80 lines, different import guard. This decides
   the shape of one file, so it is worth settling before M1.
2. **Fixture ownership.** When a defect is genuinely fixed, somebody updates the fixture. Without an
   owner the regression suite becomes noise within two batches, and mechanism 4 is worse than
   useless. Nominate a person, not a process.
3. **Severity profile.** Same check BLOCKING in Production and WARNING in QA, or a blocker
   everywhere? Config supports either; the default matters.
4. **Baseline tolerance.** Sigma-based, or an explicit per-check floor? Sigma is self-tuning but
   needs ~5 batches to mean anything; with 12 the mean is defensible, but it is worth stating the
   rule rather than letting a default decide.
