SELECT CC.ID AS SourceRecordId,
       'Contact missing required LastName' AS Reason,
       ISNULL(CC.SFDC_Goose_ExclusionReason, '') AS ExclusionReason,
       CAST(NULL AS int) AS Phase,
       CC.SourceObjectID AS SourceKey,
       CC.CustomerID AS ParentId
FROM dbo.STG_CustomerContact CC
WHERE CC.TransformationID = {{TRANSFORMATION_ID}}
  AND (CC.LastName IS NULL OR LTRIM(RTRIM(CC.LastName)) = '')
