# v0.21.0 - the object tiles open

Every tile under "Records in Salesforce for this batch" is now a link. It opens a page that
says what is behind that number and, just as plainly, what the tool does not have.

## The page shows
- Loaded for this batch, failing records, first/last created, last modified, and which run book
  step makes the object.
- Every check that covers the object, with this run's result (Clear / Issue / Unproven),
  examined, failing, impact (Blocker / Review), and a "see records" link. The first five failing
  Ids appear as Salesforce links.
- The exact count query the tool ran, and a second query that LISTS the same records (first 200),
  each labelled with the tool to run it in and READ ONLY.
- The object across the batch's recent runs.
- Two short lists: what this page can show, and what it cannot.

## It also tells you where the tool is blind
Where no check covers an object (for example Opportunities, Purchase Orders, Quoted Jobsites,
Order Products, Assigned Resources) the page says the tile is **a count only: nothing was tested**.
A tile with a number on it does not mean the objects were checked.

## What it cannot show (stated on the page)
The full list of loaded records (only failing ones are kept), field values of passing records,
anything newer than the run, and job status per object. Objects with no batch path show no count,
not a zero.

Read from stored data only: works on a snapshot, no Salesforce, Goose or network.

## Not verified
Seen only through the offline tests. Click a tile in your browser to confirm the layout.
