"""Contract activated orders that Salesforce left un-contracted (run book row 21, Script 5a).

TF_35 can activate every order while Salesforce generates contracts (USS Orders) for only some of
them (UMB-0127: 1,014 activated, 334 contracted). This queues BatchContractOrders, one order per
job, for the batch's Activated + not-contracted orders, waits for the jobs, re-counts, and repeats.

Scoped by the batch Id (never by Batch_Status = 'Processing', which spans every Processing batch).
Stops when 0 remain, or with a failure when a pass makes no progress.
"""
from __future__ import annotations

import json
import re
import time
from datetime import datetime
from pathlib import Path

from . import fixlog

ACTIVE_JOB = ("Holding", "Queued", "Preparing", "Processing")


def _ident(sf_id: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9]{15,18}", sf_id or ""):
        raise ValueError("Bad Salesforce batch Id %r" % sf_id)
    return sf_id


def remaining(sf, batch_sf_id: str) -> int:
    return int(sf.query("SELECT COUNT(Id) n FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s' "
                        "AND Status = 'Activated' AND SBQQ__Contracted__c = false" % _ident(batch_sf_id))[0]["n"])


def contracted(sf, batch_sf_id: str) -> int:
    return int(sf.query("SELECT COUNT(Id) n FROM Contract WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s'"
                        % _ident(batch_sf_id))[0]["n"])


def _jobs_active(sf) -> int:
    return int(sf.query("SELECT COUNT(Id) n FROM AsyncApexJob WHERE ApexClass.Name = 'BatchContractOrders' "
                        "AND Status IN ('%s')" % "','".join(ACTIVE_JOB))[0]["n"])


def _queue_pass(sf, batch_sf_id: str) -> int:
    apex = ("Id b = '%s'; Integer used = [SELECT COUNT() FROM FlexQueueItem WHERE JobType = 'BatchApex']; "
            "Integer slots = 95 - used; Integer n = 0; if (slots <= 0) { System.debug(LoggingLevel.ERROR, 'CONTRACT queued=0 flex_full'); return; } "
            "for (Order o : [SELECT Id FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = :b AND Status = 'Activated' "
            "AND SBQQ__Contracted__c = false ORDER BY Id LIMIT :slots]) { "
            "Database.executeBatch(new BatchContractOrders(new Set<Id>{o.Id}, null), 1); n++; } "
            "System.debug(LoggingLevel.ERROR, 'CONTRACT queued=' + n);" % _ident(batch_sf_id))
    res = sf.run_apex(apex)
    m = re.search(r"CONTRACT queued=(\d+)", "\n".join(res.get("debug") or []))
    if not res.get("ok") or not m:
        raise RuntimeError("Contract pass did not queue: %s" % (res.get("error") or res.get("raw", ""))[:300])
    return int(m.group(1))


# Copy of production_console\order_pipeline kept inside MCC (PS 5.1 fixes: BOM-less Apex temp file,
# UTF-8 BOM on the .ps1), so TF_35's follow-through does not depend on an outside folder.
def reconcile(sf, goose, batch_sf_id: str, batch_goose_id: int, folder: Path, step: str, since_iso: str,
              say=print) -> dict:
    """Error reconciliation: failed BatchContractOrders jobs since the step started, grouped by Salesforce
    error, plus the batch orders still not contracted or without work orders (each logged MCC_SF_ERROR)."""
    b = _ident(batch_sf_id)
    # Reconcile only once Salesforce has finished every queued contract job; otherwise orders from the
    # last pass that are still processing would be reported as stuck.
    t0 = time.time()
    while _jobs_active(sf) and time.time() - t0 < 1800:
        time.sleep(30)
    jobs = sf.query("SELECT Id, Status, NumberOfErrors, ExtendedStatus FROM AsyncApexJob "
                    "WHERE ApexClass.Name = 'BatchContractOrders' AND CreatedDate >= %s "
                    "AND (Status = 'Failed' OR NumberOfErrors > 0)" % since_iso)
    errors = {}
    for j in jobs:
        msg = (j.get("ExtendedStatus") or j.get("Status") or "unknown error").strip()[:160]
        errors[msg] = errors.get(msg, 0) + 1
    # SOQL allows a semi-join only at the top level (not inside OR), so query the two cases separately.
    base = "SELECT Id, OrderNumber, SBQQ__Contracted__c FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s' AND " % b
    found = {o["Id"]: o for o in sf.query(base + "SBQQ__Contracted__c = false")}
    found.update({o["Id"]: o for o in sf.query(base + "Id NOT IN (SELECT Order__c FROM WorkOrder WHERE Order__c != null)")})
    stuck = list(found.values())
    top = "; ".join("%s x%d" % (m, n) for m, n in sorted(errors.items(), key=lambda kv: -kv[1])[:3]) or "no failed jobs recorded"
    report = dict(time=datetime.now().isoformat(), since=since_iso, failed_jobs=len(jobs), errors=errors,
                  stuck=[dict(id=o["Id"], number=o.get("OrderNumber"), contracted=o.get("SBQQ__Contracted__c")) for o in stuck])
    (folder / "logs").mkdir(parents=True, exist_ok=True)
    (folder / "logs" / ("%s_error_reconciliation.json" % step)).write_text(json.dumps(report, indent=1), encoding="utf-8")
    if stuck:
        fixlog.write(goose, batch_goose_id, [fixlog.entry(
            "MCC_SF_ERROR", step, "Order", o["Id"],
            "MCC %s: order %s still %s after contract/recovery passes. BatchContractOrders errors: %s"
            % (step, o.get("OrderNumber") or o["Id"],
               "not contracted" if not o.get("SBQQ__Contracted__c") else "without work orders", top), "Order")
            for o in stuck], folder / "preflight" / "goose_fixlog.jsonl")
    # Only stuck orders decide the outcome; job errors from passes whose orders later succeeded are context.
    summary = ("0 stuck orders" + (" (%d earlier job error(s) self-resolved)" % len(jobs) if jobs else "")
               if not stuck else "%d stuck order(s); BatchContractOrders errors: %s" % (len(stuck), top))
    say("      Error reconciliation: " + summary)
    return dict(stuck=len(stuck), failed_jobs=len(jobs), summary=summary)


def requeue_without_work_orders(sf, goose, batch_sf_id: str, batch_goose_id: int, folder: Path, step: str,
                                say=print, wait_s: int = 1800) -> int:
    """Contracted orders with no work orders: BatchContractOrders.finish() built nothing for them (UMB-0127: 4
    large Power orders hit 101 SOQL synchronously). Re-run the batch job, one order per job, so finish() runs
    async (200 SOQL). Only orders with zero WOs are queued, so it cannot duplicate. Returns orders fixed."""
    b = _ident(batch_sf_id)
    soql = ("SELECT Id, OrderNumber FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s' AND Status = 'Activated' "
            "AND SBQQ__Contracted__c = true AND Id NOT IN (SELECT Order__c FROM WorkOrder WHERE Order__c != null)" % b)
    todo = sf.query(soql)
    if not todo:
        return 0
    apex = ("Integer n = 0; for (Order o : [%s LIMIT 90]) { "
            "Database.executeBatch(new BatchContractOrders(new Set<Id>{o.Id}, null), 1); n++; } "
            "System.debug(LoggingLevel.ERROR, 'NOWO queued=' + n);" % soql.replace("SELECT Id, OrderNumber", "SELECT Id"))
    res = sf.run_apex(apex)
    if not re.search(r"NOWO queued=\d+", "\n".join(res.get("debug") or [])):
        raise RuntimeError("Work-order requeue did not queue: %s" % (res.get("error") or res.get("raw", ""))[:300])
    say("      Requeued BatchContractOrders for %d contracted order(s) without work orders" % len(todo))
    t0 = time.time()
    time.sleep(20)
    while _jobs_active(sf) and time.time() - t0 < wait_s:
        time.sleep(30)
    left = {o["Id"] for o in sf.query(soql)}
    fixed = [o for o in todo if o["Id"] not in left]
    if fixed:
        fixlog.write(goose, batch_goose_id, [fixlog.entry(
            "MCC_FIXED", step, "Order", o["Id"],
            "MCC FIX %s: work orders built by re-running BatchContractOrders (async) for order %s that had none"
            % (step, o.get("OrderNumber")), "WorkOrder") for o in fixed], folder / "preflight" / "goose_fixlog.jsonl")
    say("      Work-order requeue: %d fixed, %d still without work orders" % (len(fixed), len(left)))
    return len(fixed)


def _utc_now() -> str:
    from datetime import timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


RECOVERY_PS1 =Path(__file__).resolve().parent.parent / "order_pipeline" / "RUN-ORDER-ACTIVATION-RECOVERY.ps1"


def run_recovery(sf, goose, org_alias: str, batch_sf_id: str, batch_goose_id: int, folder: Path, step: str,
                 say=print, script: Path = RECOVERY_PS1, timeout_s: int = 3 * 3600) -> tuple[str, str]:
    """Run book row 21 via the existing order_pipeline: contract non-contracted orders, recover orders with
    no work orders, and exit 0 only when NotActivated, NonContracted and WithoutWorkOrder are all 0."""
    import subprocess
    if not script.is_file():
        return "FAIL", "Order recovery script not found: %s" % script
    since = _utc_now()
    before = (remaining(sf, batch_sf_id), contracted(sf, batch_sf_id))
    say("      Order recovery (%s): %d not contracted, %d contract(s)" % (script.name, before[0], before[1]))
    log = folder / "logs" / ("%s_order_recovery.txt" % step)
    log.parent.mkdir(parents=True, exist_ok=True)
    import os
    # The script runs with ErrorActionPreference=Stop and 2>&1, so the sf CLI's "update available"
    # stderr warning aborts it on the first call. Suppress the version check for this child only.
    env = dict(os.environ, SF_SKIP_NEW_VERSION_CHECK="true", SF_AUTOUPDATE_DISABLE="true",
               SF_DISABLE_AUTOUPDATE="true")
    with log.open("w", encoding="utf-8") as out:
        cp = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script),
                             "-OrgAlias", org_alias, "-BatchId", _ident(batch_sf_id)],
                            stdout=out, stderr=subprocess.STDOUT, text=True, timeout=timeout_s, env=env)
    text = log.read_text(encoding="utf-8", errors="replace")
    m = re.findall(r"NotActivated=(\d+) NonContracted=(\d+) WithoutWorkOrder=(\d+)", text)
    final = m[-1] if m else ("?", "?", "?")
    after = (remaining(sf, batch_sf_id), contracted(sf, batch_sf_id))
    detail = ("NotActivated=%s NonContracted=%s WithoutWorkOrder=%s; contracts %d -> %d; evidence %s"
              % (final[0], final[1], final[2], before[1], after[1], log))
    if after[1] > before[1] or cp.returncode == 0:
        fixlog.write(goose, batch_goose_id, [fixlog.entry(
            "MCC_FIXED", step, "RUN", step, "MCC FIX %s order recovery: %s" % (step, detail[:200]), "Order")],
            folder / "preflight" / "goose_fixlog.jsonl")
    say("      Order recovery finished (exit %d): %s" % (cp.returncode, detail))
    try:
        n = requeue_without_work_orders(sf, goose, batch_sf_id, batch_goose_id, folder, step, say)
        if n:
            detail += "; work orders built for %d order(s) by requeue" % n
    except Exception as exc:  # noqa: BLE001
        detail += "; work-order requeue failed: %s" % str(exc)[:200]
    try:
        rec = reconcile(sf, goose, batch_sf_id, batch_goose_id, folder, step, since, say)
        detail += "; reconciliation: " + rec["summary"]
        if rec["stuck"]:
            return "FAIL", detail
    except Exception as exc:  # noqa: BLE001
        detail += "; reconciliation failed: %s" % str(exc)[:200]
    return ("FIXED" if after[1] > before[1] else "PASS") if cp.returncode == 0 else "FAIL", detail


def run(sf, goose, batch_sf_id: str, batch_goose_id: int, folder: Path, step: str, say=print,
        wait_s: int = 1800, max_passes: int = 30) -> tuple[str, str]:
    journal = folder / "preflight" / "contract_orders.jsonl"
    journal.parent.mkdir(parents=True, exist_ok=True)
    start_left, start_contracts = remaining(sf, batch_sf_id), contracted(sf, batch_sf_id)
    say("      Contract orders: %d activated order(s) not contracted, %d contract(s) so far"
        % (start_left, start_contracts))
    left, passes = start_left, 0
    while left > 0 and passes < max_passes:
        passes += 1
        queued = _queue_pass(sf, batch_sf_id)
        with journal.open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(time=datetime.now().isoformat(), pass_no=passes, left=left, queued=queued)) + "\n")
        say("      Pass %d: queued %d BatchContractOrders job(s)" % (passes, queued))
        t0 = time.time()
        time.sleep(20)
        while _jobs_active(sf) and time.time() - t0 < wait_s:
            time.sleep(30)
        now = remaining(sf, batch_sf_id)
        say("      Pass %d done: %d not contracted (was %d)" % (passes, now, left))
        if now >= left and queued > 0:
            left = now
            break
        left = now
    end_contracts = contracted(sf, batch_sf_id)
    fixed = start_left - left
    if fixed:
        fixlog.write(goose, batch_goose_id, [fixlog.entry(
            "MCC_FIXED", step, "RUN", step,
            "MCC FIX %s: contracted %d activated order(s) via BatchContractOrders (%d pass(es)); contracts %d -> %d; "
            "%d still not contracted" % (step, fixed, passes, start_contracts, end_contracts, left), "Contract")],
            folder / "preflight" / "goose_fixlog.jsonl")
    detail = "%d order(s) contracted in %d pass(es); contracts %d -> %d; %d not contracted" % (
        fixed, passes, start_contracts, end_contracts, left)
    return ("FIXED" if fixed else "PASS") if left == 0 else "FAIL", detail
