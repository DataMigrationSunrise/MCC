"""Build work orders for UMB-0127 orders that have none, one order per Apex run (CPQOrders, no duplicates).
Usage: gen_wo_missing.py [first|all]"""
import sys, json
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, fixlog

mode = sys.argv[1] if len(sys.argv) > 1 else 'first'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
tpl = (folder / 'preflight' / 'gen_wo_one.apex').read_text(encoding='utf-8')
c = systems.build(app.CFG, 'dry', lambda m: None)
c.sf.alias = 'Sunrise-QA'  # UMB-0127 lives in QA; config.json now points at Stage for UMB-0069
c.sf.allowed_hosts = ['ussprod--qa.sandbox.my.salesforce.com']
assert 'ussprod--qa.' in c.sf.verify_sandbox(), 'not QA'
B = 'aFOVD0000001Swj4AE'
orders = {o['Id'] for o in c.sf.query("SELECT Id FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s' AND Status = 'Activated'" % B)}
with_wo = {w['Order__c'] for w in c.sf.query("SELECT Order__c FROM WorkOrder WHERE Order__r.SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)}
todo = sorted(orders - with_wo)
print('activated orders without work orders:', len(todo))
if mode == 'first':
    todo = todo[:1]
done, failed, journal = [], [], folder / 'preflight' / 'gen_wo_missing.jsonl'
for o in todo:
    res = c.sf.run_apex(tpl.replace('{ORDER}', o))
    lines = [l[l.find('MCCWO'):] for l in (res.get('debug') or []) if 'MCCWO' in l]
    msg = ' | '.join(lines) or (res.get('error') or 'no output')
    print(o, '|', msg[:600])
    with journal.open('a', encoding='utf-8') as f:
        f.write(json.dumps(dict(order=o, out=lines, error=res.get('error'))) + '\n')
    (done if any('COMMITTED' in l for l in lines) else failed).append((o, msg))
entries = [fixlog.entry('MCC_FIXED', 'TF_90A.C', 'Order', o,
           'MCC FIX work orders built with CPQOrders for order that had none (no duplicates)', 'WorkOrder') for o, _ in done]
entries += [fixlog.entry('MCC_SF_ERROR', 'TF_90A.C', 'Order', o, ('Work orders not built: ' + m)[:900], 'WorkOrder')
            for o, m in failed if 'SKIP' not in m]
if entries:
    fixlog.write(c.goose, 468, entries, folder / 'preflight' / 'goose_fixlog.jsonl')
print('fixed:', len(done), '| not fixed:', len(failed))
