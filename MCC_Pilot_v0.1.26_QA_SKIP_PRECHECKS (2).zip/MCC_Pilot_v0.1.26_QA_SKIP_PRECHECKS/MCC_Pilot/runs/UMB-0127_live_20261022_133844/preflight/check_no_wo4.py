"""Read-only: why the 4 UMB-0127 orders have no work orders (Sunrise-QA)."""
import sys
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems

c = systems.build(app.CFG, 'dry', lambda m: None)
c.sf.alias = 'Sunrise-QA'
ids = ['801VD00000v8q3qYAA', '801VD00000v9J94YAE', '801VD00000v9KWZYA2', '801VD00000v9OWvYAM']
inn = ",".join("'%s'" % i for i in ids)
for o in c.sf.query("SELECT Id, OrderNumber, Status, SBQQ__Contracted__c, ContractId, EffectiveDate, EndDate, Type, "
                    "SBQQ__Quote__r.Name, Account.Name FROM Order WHERE Id IN (%s)" % inn):
    print('\nORDER', o['Id'], o['OrderNumber'], o['Status'], 'contracted=%s' % o['SBQQ__Contracted__c'], 'contract=%s' % o['ContractId'],
          o['EffectiveDate'], o['EndDate'], (o.get('SBQQ__Quote__r') or {}).get('Name'), (o.get('Account') or {}).get('Name'))
    for i in c.sf.query("SELECT Product2.Name, Product2.ProductCode, Product2.Family, Quantity, CustomerOwned__c, "
                        "Is_Power_Ancillary_Asset__c, SBQQ__RequiredBy__c, ServiceDate, EndDate, SBQQ__Status__c "
                        "FROM OrderItem WHERE OrderId = '%s' ORDER BY Product2.ProductCode" % o['Id']):
        p = i.get('Product2') or {}
        print('   %-10s %-40s %-12s qty=%-5s co=%-5s anc=%-5s child=%s %s-%s %s' % (
            p.get('ProductCode'), (p.get('Name') or '')[:40], (p.get('Family') or '')[:12], i['Quantity'],
            i['CustomerOwned__c'], i['Is_Power_Ancillary_Asset__c'], bool(i['SBQQ__RequiredBy__c']),
            i['ServiceDate'], i['EndDate'], i['SBQQ__Status__c']))
