-- PWSTM-356. Source quantity input sanity, NOT an end-to-end Salesforce WOLI quantity check.
SELECT TOP (1001) L.ID AS SourceRecordId,
       CASE WHEN L.Quantity IS NULL OR L.Quantity <= 0 THEN 'SOURCE_RISK' ELSE 'SOURCE_INPUT_PASS' END AS TestResult,
       CASE WHEN L.Quantity IS NULL OR L.Quantity <= 0 THEN 'Staged quantity is null or nonpositive' ELSE 'Staged quantity is positive (Salesforce WO equality not yet tested)' END AS Reason,
       L.PreStgID AS SourceKey, L.TransformationID AS TransformationId
FROM dbo.STG_OrderLineItem L
JOIN dbo.TRFM_Transformation T ON T.ID = L.TransformationID
WHERE T.MigrationBatchID = {{GOOSE_BATCH_ID}}
  AND COALESCE(L.SFDC_Goose_ExclusionReason, '') = ''
