"""
MCC Pilot: run to a selected migration step and resume from saved checkpoints.

    python -m pilot            opens the browser at http://localhost:8765
    python -m pilot --simulate runs a simulated batch in the console and exits
"""
from __future__ import annotations

import json
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import environments, systems
from .engine import ROOT, RUNS, Run, Stop
from .readiness import inspect
from .targets import all_steps, validate_target, target_readiness
from .jira_preflight import registry as jira_registry, predict as predict_jira_preflight

CFG = environments.load()  # config.json + environments/<Environment>.json; switched in place by switch_env
UI = (Path(__file__).parent / "ui.html").read_text(encoding="utf-8")
CURRENT: dict = {"run": None}


def switch_env(env: str) -> str:
    r = CURRENT["run"]
    if r and r.state in ("RUNNING", "WAITING"):
        return "Finish or stop the active run before switching environment."
    try:
        new = environments.load(env)
        environments.set_default(env)
    except (ValueError, OSError) as exc:
        return "Cannot switch: %s" % exc
    CFG.clear()
    CFG.update(new)
    return "New runs now load into %s (%s)." % (env, CFG.get("OrgAlias"))


def start(mode: str, confirm: str = "", stop_after=None, skip_prechecks=False) -> str:
    r = CURRENT["run"]
    if r and r.state in ("RUNNING", "WAITING"):
        return "A run is already in progress."
    try:
        steps = all_steps(ROOT)
        target = validate_target(steps, CFG.get("StopAfter", "") if stop_after is None else stop_after)
        run = Run(json.loads(json.dumps(CFG)), mode, systems.build, target)  # own copy: a later switch can't move it
    except (ValueError, KeyError) as exc:
        return "Invalid stop target: %s" % exc
    run.skip_prechecks = bool(skip_prechecks)
    CURRENT["run"] = run
    threading.Thread(target=run.execute, args=(confirm,), daemon=True).start()
    return "Started %s run through %s." % (mode, run.stop_after or "all configured steps")


def list_checkpoints():
    out = []
    for f in sorted(RUNS.glob("*/run.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:50]:
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            out.append(dict(folder=f.parent.name, state=d.get("state"),
                            mode=d.get("mode"), batch=d.get("batch", {}).get("name", ""),
                            stop_after=d.get("stop_after", ""),
                            environment=environments.for_run(f.parent),
                            steps_complete=sum(x.get("status") in ("PASS", "FIXED", "DONE", "INFO", "SKIPPED", "WOULD_FIX") for x in d.get("steps", [])),
                            total=len(d.get("steps", [])),
                            steps=[dict(id=x.get("id"), status=x.get("status")) for x in d.get("steps", [])],
                            resume_from=d.get("resume_from", "")))
        except (OSError, ValueError, TypeError):
            continue
    return out


def resume(folder: str, confirm: str = "", stop_after=None, start_from=None,
           skip_intermediate=False, replay_completed=False, skip_prechecks=False) -> str:
    current = CURRENT["run"]
    if current and current.state in ("RUNNING", "WAITING"):
        return "Another run is active."
    try:
        # A saved run resumes in the environment it was loaded into, not the current switch.
        env = environments.for_run(RUNS / folder)
        if not env:
            raise Stop("Cannot tell whether this run was loaded into QA or Stage; refusing to guess")
        cfg = environments.load(env)
        run = Run.from_checkpoint(cfg, systems.build, RUNS / folder, stop_after=stop_after,
                                  start_from=start_from, skip_intermediate=skip_intermediate,
                                  replay_completed=replay_completed)
        if run.mode == "live" and confirm.strip().upper() != run.batch["name"].upper():
            return "To resume live, confirm batch name %s" % run.batch["name"]
    except (Stop, ValueError, OSError, KeyError) as exc:
        return "Cannot resume: %s" % exc
    run.skip_prechecks = bool(skip_prechecks)
    CURRENT["run"] = run
    threading.Thread(target=run.execute, args=(confirm,), daemon=True).start()
    return "Resuming %s in %s FROM %s THROUGH %s; earlier successful steps preserved." % (
        run.batch["name"], env, run.resume_from, run.stop_after or "all steps")


def scan_only() -> dict:
    run = Run(CFG, "dry", systems.build)
    c = systems.build(CFG, "dry", run.say)
    c.sf.verify_sandbox()
    report = run.discover(c)
    selected = report["selected"]
    batch = (dict(name=selected["name"], sf_id=selected["sf_id"],
                  goose_id=int(selected["goose_id"]), sf_status=selected["sf_status"],
                  goose_status=selected["goose_status"], is_test=selected["is_test"]) if selected else None)
    return dict(batch=batch, diagnostics=report)


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            return self._send(200, UI, "text/html")
        if self.path.startswith("/api/targets"):
            steps = all_steps(ROOT)
            return self._send(200, json.dumps(dict(targets=[dict(id=s["id"], name=s["name"], ro=s["ro"]) for s in steps],
                                                  default=CFG.get("StopAfter", ""))))
        if self.path.startswith("/api/state"):
            r = CURRENT["run"]
            snap = r.snapshot() if r else dict(state="IDLE", steps=[], log=[], batch={}, mode="")
            if not r:
                # Nothing running: show the most recent saved run read-only, so the step table and
                # log never go blank after a restart. Starting or resuming a run replaces it.
                latest = sorted(RUNS.glob("*_live_*/run.json"), key=lambda q: q.stat().st_mtime, reverse=True)
                if latest:
                    try:
                        d = json.loads(latest[0].read_text(encoding="utf-8"))
                        ev = latest[0].parent / "events.log"
                        snap.update(steps=d.get("steps") or [], batch=d.get("batch") or {}, mode="saved",
                                    log=(ev.read_text(encoding="utf-8").splitlines()[-200:] if ev.exists()
                                         else d.get("log", [])[-200:]),
                                    saved_run=latest[0].parent.name)
                    except Exception:  # noqa: BLE001
                        pass
            snap["config"] = dict(org=CFG.get("OrgAlias"), stop_after=CFG.get("StopAfter"),
                                  environment=CFG.get("Environment"), environments=environments.names(),
                                  snaplogic=CFG.get("SnapLogic", {}).get("Mode"),
                                  informatica=CFG.get("Informatica", {}).get("Mode"))
            return self._send(200, json.dumps(snap, default=str))
        if self.path.startswith("/api/jira-registry"):
            return self._send(200, json.dumps(jira_registry(ROOT)))
        if self.path.startswith("/api/checkpoints"):
            return self._send(200, json.dumps(dict(runs=list_checkpoints())))
        if self.path.startswith("/api/readiness"):
            return self._send(200, json.dumps(inspect(CFG, ROOT)))
        if self.path.startswith("/api/scan"):
            try:
                result = scan_only()
                return self._send(200, json.dumps(dict(ok=bool(result["batch"]), **result,
                    error="No eligible batch; details below." if not result["batch"] else ""), default=str))
            except (Stop, Exception) as e:  # noqa: BLE001
                return self._send(200, json.dumps(dict(ok=False, error=str(e))))
        self._send(404, "{}")

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n) or b"{}")
        r = CURRENT["run"]
        if self.path == "/api/jira-verify":
            try:
                from . import adapters as _ad, jira_verify
                run_ = CURRENT["run"]
                batch, steps = (run_.batch, run_.steps) if run_ and getattr(run_, "batch", None) else ({}, [])
                if not batch:
                    latest = sorted(RUNS.glob("*_live_*/run.json"), key=lambda q: q.stat().st_mtime, reverse=True)
                    if latest:
                        d = json.loads(latest[0].read_text(encoding="utf-8"))
                        batch, steps = d.get("batch") or {}, d.get("steps") or []
                sf = _ad.Salesforce(CFG["OrgAlias"], CFG.get("AllowedOrgHosts") or [])
                rep = jira_verify.run(sf, batch.get("sf_id", ""), steps, out_dir=RUNS / "jira_verify")
                return self._send(200, json.dumps(dict(ok=True, batch=batch.get("name"), **rep), default=str))
            except Exception as e:  # noqa: BLE001
                return self._send(200, json.dumps(dict(ok=False, error=str(e)[:400])))
        if self.path == "/api/jira-preflight":
            try:
                # Dedicated read-only action. It never triggers a migration or write.
                check = scan_only()
                if not check.get('batch'):
                    return self._send(200, json.dumps(dict(ok=False, error='No eligible batch')))
                run = Run(CFG, 'dry', systems.build)
                c = systems.build(CFG, 'dry', run.say)
                c.sf.verify_sandbox()
                bid = int(check['batch']['goose_id'])
                folder = RUNS / 'jira_preflight' / ('batch_%s' % bid)
                reports = [predict_jira_preflight(c.goose, ROOT, bid, step, folder)
                           for step in ('PREFLIGHT', 'TF_20', 'TF_35', 'TF_40')]
                statuses = {issue['key']: dict(issue) for issue in reports[0]['issues']}
                for report in reports:
                    for issue in report['issues']:
                        if issue['prediction'] not in ('NOT_CHECKED_THIS_STEP', 'NO_EXECUTABLE_CHECK'):
                            statuses[issue['key']]['prediction'] = issue['prediction']
                            statuses[issue['key']]['checked_tests'] = issue['checked_tests']
                return self._send(200, json.dumps(dict(ok=True, batch=check['batch'],
                    issues=list(statuses.values()), tests=[t for r in reports for t in r['tests']],
                    evidence=[r.get('evidence') for r in reports]), default=str))
            except Exception as exc:
                return self._send(200, json.dumps(dict(ok=False, error=str(exc)[:500])))
        if self.path == "/api/env":
            return self._send(200, json.dumps(dict(msg=switch_env(str(body.get("env", ""))),
                                                   environment=CFG.get("Environment"), org=CFG.get("OrgAlias"))))
        if self.path == "/api/start":
            mode = body.get("mode", "simulate")
            if mode not in ("simulate", "dry", "live"):
                return self._send(400, json.dumps(dict(msg="bad mode")))
            return self._send(200, json.dumps(dict(msg=start(mode, body.get("confirm", ""), body.get("stop_after"), body.get("skip_prechecks") is True))))
        if self.path == "/api/resume":
            return self._send(200, json.dumps(dict(msg=resume(str(body.get("folder", "")),
                                                               str(body.get("confirm", "")), body.get("stop_after"),
                                                               body.get("start_from"),
                                                               body.get("skip_intermediate") is True,
                                                               body.get("replay_completed") is True, body.get("skip_prechecks") is True))))
        if self.path == "/api/continue" and r:
            r.proceed()
            return self._send(200, json.dumps(dict(msg="Continuing.")))
        if self.path == "/api/stop" and r:
            r.stop()
            return self._send(200, json.dumps(dict(msg="Stopping after the current step.")))
        self._send(404, "{}")


def main(argv=None):
    argv = argv or sys.argv[1:]
    if "--readiness" in argv:
        report = inspect(CFG, ROOT)
        print(json.dumps(report, indent=2))
        return 0 if report["ready_for_full_run"] else 2
    if "--simulate" in argv:
        run = Run(CFG, "simulate", systems.build)
        run.execute()
        for s in run.steps:
            print("RO %-4s %-10s %-10s %s" % (s["ro"], s["id"], s["status"], s["detail"][:90]))
        print("STATE:", run.state, "| evidence:", run.folder)
        return 0 if run.state in ("DONE", "DONE_WITH_FINDINGS", "TARGET_REACHED") else 1
    port = int(CFG.get("Port", 8765))
    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    url = "http://localhost:%d" % port
    print("MCC Pilot running at %s  (Ctrl+C to quit)" % url)
    try:
        webbrowser.open(url)
    except Exception:  # noqa: BLE001
        pass
    srv.serve_forever()
    return 0
