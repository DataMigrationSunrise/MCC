"""Read-only: generator coverage and duplicate Delivery/Pickup WOs per order for batch UMB-0127."""
import sys
from collections import Counter
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems

c = systems.build(app.CFG, 'dry', lambda m: None)
c.sf.alias = 'Sunrise-QA'
B = 'aFOVD0000001Swj4AE'
wos = c.sf.query("SELECT Id, Order__c, Subject, Site_Address__c, CreatedDate FROM WorkOrder "
                 "WHERE Order__r.SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)
gen = c.sf.query("SELECT Id, OrderId FROM OrderItem WHERE Order.SBQQ__Quote__r.USS_Migration_Batch__c = '%s' "
                 "AND Product2.Name = 'GENERATOR RENTAL'" % B)
covered = {w['Order_Line_Item__c'] for w in c.sf.query(
    "SELECT Order_Line_Item__c FROM WorkOrderLineItem WHERE Order_Line_Item__r.Product2.Name = 'GENERATOR RENTAL' "
    "AND Order_Line_Item__r.Order.SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)}
kind = lambda s: 'Pickup' if 'pickup' in (s or '').lower() else ('Delivery' if 'deliver' in (s or '').lower() else (s or '?'))
cnt = Counter((w['Order__c'], kind(w['Subject']), w['Site_Address__c']) for w in wos)
dup = {k: n for k, n in cnt.items() if n > 1}
gen_orders = {g['OrderId'] for g in gen}
print('WOs in batch:', len(wos), '| WOs created since 2026-10-23:', sum(w['CreatedDate'] >= '2026-10-23' for w in wos))
print('generator lines:', len(gen), '| covered by a WOLI:', sum(g['Id'] in covered for g in gen))
print('orders with duplicate same-kind same-site WOs:', len({k[0] for k in dup}),
      '| of those generator orders:', len({k[0] for k in dup} & gen_orders))
orders = {o['Id'] for o in c.sf.query("SELECT Id FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)}
no_wo = sorted(orders - {w['Order__c'] for w in wos})
print('orders:', len(orders), '| without any WO:', len(no_wo), '| of those generator orders:', len(set(no_wo) & gen_orders))
print('  ', ', '.join(no_wo[:20]))
