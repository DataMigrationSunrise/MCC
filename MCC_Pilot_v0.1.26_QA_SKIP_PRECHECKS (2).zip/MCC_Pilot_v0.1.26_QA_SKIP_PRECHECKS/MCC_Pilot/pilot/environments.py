"""QA / Stage switch without re-editing config.json.

config.json holds the shared settings plus "Environment" (the default for NEW runs). Each file in
environments/ (QA.json, Stage.json) holds only what differs: org alias, allowed host, Informatica
login variable names and taskflow names, Sunrise app folder. A saved run remembers its environment,
so resuming it always goes back to the org it was loaded into, whatever the switch says now.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .engine import ROOT

ENV_DIR = ROOT / "environments"
CONFIG = ROOT / "config.json"


def names() -> list[str]:
    return sorted(p.stem for p in ENV_DIR.glob("*.json"))


def _merge(base: dict, over: dict) -> dict:
    for k, v in over.items():
        if k.startswith("_"):
            continue
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _merge(base[k], v)
        else:
            base[k] = v
    return base


def load(env: str | None = None) -> dict:
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    env = env or cfg.get("Environment") or ""
    if env:
        if env not in names():
            raise ValueError("Unknown environment %r; expected one of %s" % (env, names()))
        _merge(cfg, json.loads((ENV_DIR / ("%s.json" % env)).read_text(encoding="utf-8")))
    cfg["Environment"] = env
    return cfg


def set_default(env: str) -> None:
    if env not in names():
        raise ValueError("Unknown environment %r" % env)
    text = CONFIG.read_text(encoding="utf-8")
    if re.search(r'"Environment"\s*:', text):
        text = re.sub(r'("Environment"\s*:\s*)"[^"]*"', r'\g<1>"%s"' % env, text, count=1)
    else:
        text = text.replace("{", '{\n  "Environment": "%s",' % env, 1)
    CONFIG.write_text(text, encoding="utf-8")


def for_run(folder: Path) -> str:
    """Environment a saved run was loaded into. Older runs predate the field, so read the org
    from their log ("Salesforce: Sunrise-QA (...)")."""
    d = json.loads((Path(folder) / "run.json").read_text(encoding="utf-8"))
    if d.get("environment") in names():
        return d["environment"]
    log = "\n".join(d.get("log") or [])
    ev = Path(folder) / "events.log"
    if ev.exists():
        log += "\n" + ev.read_text(encoding="utf-8", errors="replace")
    for env in names():
        alias = json.loads((ENV_DIR / ("%s.json" % env)).read_text(encoding="utf-8")).get("OrgAlias")
        if alias and ("Salesforce: %s " % alias) in log:
            return env
    return ""
