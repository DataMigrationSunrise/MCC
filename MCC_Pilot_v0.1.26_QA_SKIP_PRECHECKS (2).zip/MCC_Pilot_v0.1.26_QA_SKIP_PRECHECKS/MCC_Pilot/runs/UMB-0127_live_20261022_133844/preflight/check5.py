import sys
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems

c = systems.build(app.CFG, 'dry', lambda m: None)
g = [r for s in c.goose.result_sets("SELECT ID, Name, BillingStreet, BillingPostalCode FROM dbo.SFDC_Account "
                                    "WHERE MigrationBatchID=468 AND ISNULL(SalesforceAccountID,'')=''") for r in s]
for a in g:
    print('GOOSE', a['ID'], a['Name'], '|', a['BillingStreet'], a['BillingPostalCode'])
names = ",".join("'" + a['Name'].replace("'", "\\'") + "'" for a in g)
for x in c.sf.query("SELECT Id, Name, BillingStreet, BillingPostalCode, USS_Migration_Batch__r.Name FROM Account "
                    "WHERE Name IN (" + names + ")"):
    print('QA', x['Id'], x['Name'], '|', x.get('BillingStreet'), x.get('BillingPostalCode'),
          (x.get('USS_Migration_Batch__r') or {}).get('Name'))
q = [r for s in c.goose.result_sets("SELECT COUNT(*) n FROM dbo.vw_SFDC_OpenBatch_Quote "
                                    "WHERE ISNULL(SalesforceQuoteID,'')=''") for r in s]
print('unsynced quotes', q)
