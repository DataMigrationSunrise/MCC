$ErrorActionPreference = 'Stop'
Write-Host 'MCC Pilot - Informatica SAND (usw3) credential setup' -ForegroundColor Cyan
Write-Host 'Saved as Windows user environment variables INFORMATICA_SAND_USERNAME / INFORMATICA_SAND_PASSWORD.'
$user = Read-Host 'Sand username (e.g. Vince.sand@unitedsiteservices.com)'
$secure = Read-Host 'Sand password' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
    $password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    [Environment]::SetEnvironmentVariable('INFORMATICA_SAND_USERNAME', $user, 'User')
    [Environment]::SetEnvironmentVariable('INFORMATICA_SAND_PASSWORD', $password, 'User')
} finally {
    if ($ptr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
    $password = $null
}
Write-Host 'Saved. You can close this window.' -ForegroundColor Green
