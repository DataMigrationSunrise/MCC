# v0.22.1 - "job already ran" was wrong on two SnapLogic steps

The tag added in v0.20.0 said **job already ran** on RO 3 (PL_05) and RO 8 (PL_10) in your
v0.22.0 run, while the page's own "Cannot confirm" list named RO 3 as unconfirmable. They
disagreed because the tag trusted any check that measured records (staging rows, ACRs that
have existed for years). It now needs a RAN.* output check with records, the same proof the
"Load jobs N of 15 confirmed run" counter uses, so the two can no longer contradict.

Effect on your run: RO 3 and RO 8 lose the tag. RO 17, 19 and 39 keep it.
