# v0.1.14 Preflight guard correction

- Fixed a live-write ordering bug: a configured record-exclusion rule can no longer write Goose rows if the selected batch identity check failed or was missing.
- Each Goose exclusion starts with a durable ATTEMPT_STARTED audit event; database exceptions are logged as WRITE_OUTCOME_UNKNOWN for later reconciliation.
- Empty exclusion reasons are rejected.
- Regression test added for missing batch plus simultaneous exclusion candidate.

This is a targeted safety fix, **not** completion of end-to-end taskflow execution. `StopAfter` and the downstream coverage requirements remain unchanged.
