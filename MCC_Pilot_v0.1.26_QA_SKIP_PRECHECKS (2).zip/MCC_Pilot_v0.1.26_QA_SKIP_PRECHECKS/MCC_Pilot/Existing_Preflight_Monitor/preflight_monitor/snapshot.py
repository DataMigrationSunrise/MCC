"""
Snapshots -- look at a run without querying Salesforce again.

Every run this tool has ever done is ALREADY stored: results, evidence, self-test stages,
metrics. Nothing needed re-querying to see a past run; there was simply no way to ask for
one, because the UI only ever read `latest_run_id(batch)`.

So there are two things here, and they are different:

  PICK A RUN      choose any run already in preflight_history.db and view it. No network,
                  no Salesforce, no Goose -- it is a database read. This is what you want
                  99% of the time: open the tool, look at this morning's run, close it.

  EXPORT/IMPORT   write one run to a single .json file, or read one back. This is for
                  moving a run OFF this machine -- attaching it to a ticket, sending it to
                  someone who cannot reach the org, or keeping it after the history
                  database is cleared. Importing writes it into the local history under its
                  original run id, so it then shows up in the picker like any other run.

An imported run is EVIDENCE, not a live result. It is stamped with where it came from and
the UI says so, because a stale snapshot presented as current is exactly the kind of
"LIVE CLEAN" mistake this tool exists to prevent.
"""
from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path

FORMAT = "preflight-monitor-snapshot/1"


def _rows(store, sql, args=()):
    with store._lock:
        return [dict(r) for r in store.db.execute(sql, args).fetchall()]


def list_runs(store, batch: str = "", limit: int = 60) -> list[dict]:
    """Every stored run, newest first, with enough detail to choose between them."""
    sql = ("SELECT run_id, batch, mode, started, finished, tool_version, sf_alias, "
           "goose_ok, selftest_ok FROM run WHERE finished IS NOT NULL")
    args = []
    if batch:
        sql += " AND batch = ?"
        args.append(batch)
    sql += " ORDER BY started DESC LIMIT %d" % int(limit)
    out = []
    for r in _rows(store, sql, tuple(args)):
        agg = _rows(store,
                    "SELECT verdict, COUNT(*) n, COALESCE(SUM(evidence_count),0) e "
                    "FROM result WHERE run_id = ? GROUP BY verdict", (r["run_id"],))
        by = {a["verdict"]: a for a in agg}
        r["failed"] = int((by.get("FAIL") or {}).get("n") or 0)
        r["unproven"] = int((by.get("UNPROVEN") or {}).get("n") or 0)
        r["passed"] = int((by.get("PASS") or {}).get("n") or 0)
        # records only: a job or staged-row count is a different unit (see terms.unit_of)
        import terms
        r["errors"] = sum(int(x["evidence_count"] or 0) for x in _rows(
            store, "SELECT check_id, evidence_count FROM result WHERE run_id = ? AND verdict = 'FAIL'",
            (r["run_id"],)) if terms.is_record(x["check_id"]))
        r["imported"] = bool(str(r.get("mode") or "").startswith("IMPORT"))
        out.append(r)
    return out


def describe(store, run_id: str) -> dict | None:
    r = _rows(store, "SELECT * FROM run WHERE run_id = ?", (run_id,))
    return r[0] if r else None


def export_run(store, run_id: str, path: Path) -> Path:
    """One run -> one portable .json file. Read-only; the history is not modified."""
    run = describe(store, run_id)
    if not run:
        raise RuntimeError("No run %r in this history database." % run_id)
    snap = {
        "format": FORMAT,
        "exported_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "run": run,
        "results": _rows(store, "SELECT * FROM result WHERE run_id = ?", (run_id,)),
        "evidence": _rows(store, "SELECT * FROM evidence WHERE run_id = ? ORDER BY check_id, seq",
                          (run_id,)),
        "selftest": _rows(store, "SELECT * FROM selftest WHERE run_id = ?", (run_id,)),
        "object_tally": _rows(store, "SELECT * FROM object_tally WHERE run_id = ? "
                                     "ORDER BY sequence", (run_id,)),
        "batch": _rows(store, "SELECT * FROM batch WHERE name = ?", (run["batch"],)),
        "verification": _rows(store, "SELECT * FROM verification WHERE run_id = ?", (run_id,)),
    }
    path = Path(path)
    if path.is_dir():
        path = path / ("Preflight_Snapshot_%s_%s.json" % (run["batch"], run_id))
    path.write_text(json.dumps(snap, indent=1, default=str), encoding="utf-8")
    return path


def import_run(store, path: Path) -> dict:
    """
    Read a snapshot back into the local history so the picker can show it.

    The run keeps its ORIGINAL run id and timestamps -- it is the same run, moved, not a
    new one. Importing the same file twice therefore replaces rather than duplicates. The
    mode is prefixed IMPORT so nothing downstream can mistake it for something this
    machine just measured.
    """
    path = Path(path)
    try:
        snap = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:                                   # noqa: BLE001
        raise RuntimeError("Not readable as a snapshot file: %s" % str(e)[:200])
    if not isinstance(snap, dict) or not str(snap.get("format", "")).startswith(
            "preflight-monitor-snapshot/"):
        raise RuntimeError(
            "%s is not a Preflight Monitor snapshot. Expected a .json file written by "
            "'Save snapshot'." % path.name)
    run = snap.get("run") or {}
    rid = str(run.get("run_id") or "").strip()
    if not rid:
        raise RuntimeError("Snapshot has no run id.")

    mode = str(run.get("mode") or "GATE")
    if not mode.startswith("IMPORT"):
        mode = "IMPORT/" + mode

    with store._lock:
        db = store.db
        for t in ("result", "evidence", "selftest", "object_tally", "verification"):
            db.execute("DELETE FROM %s WHERE run_id = ?" % t, (rid,))
        db.execute("DELETE FROM run WHERE run_id = ?", (rid,))
        _insert(db, "run", dict(run, mode=mode))
        for row in snap.get("results") or []:
            _insert(db, "result", row)
        for row in snap.get("evidence") or []:
            _insert(db, "evidence", row)
        for row in snap.get("selftest") or []:
            _insert(db, "selftest", row)
        for row in snap.get("object_tally") or []:
            _insert(db, "object_tally", row)
        for row in snap.get("verification") or []:
            _insert(db, "verification", row)
        for row in snap.get("batch") or []:
            _insert(db, "batch", row)
        db.commit()
    return dict(run_id=rid, batch=run.get("batch", ""),
                results=len(snap.get("results") or []),
                exported_at=snap.get("exported_at", ""), source=path.name)


def _insert(db, table, row: dict):
    """
    Insert only the columns this database actually has.

    A snapshot written by a newer build carries columns an older one lacks, and vice
    versa. Filtering here means a snapshot stays readable across versions instead of
    failing on a column name.
    """
    have = {r["name"] for r in db.execute("PRAGMA table_info(%s)" % table).fetchall()}
    cols = [c for c in row.keys() if c in have]
    if not cols:
        return
    db.execute("INSERT OR REPLACE INTO %s(%s) VALUES(%s)"
               % (table, ",".join(cols), ",".join("?" * len(cols))),
               tuple(row[c] for c in cols))
