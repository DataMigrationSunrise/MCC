"""Offline pre-run structural verification. No external connections or writes."""
from pathlib import Path
import json
from .pipeline import STEPS
from .extensions import load_extension, validate_extension

SCRIPT_KINDS = {"apex", "goose_sql", "goose_gen_check", "goose_gen_fix"}

def inspect(cfg, root):
    root = Path(root)
    ext = load_extension(root / "runbook_extension.json")
    steps = STEPS + ext.get("steps", [])
    errors = []
    warnings = []
    missing_scripts = []
    for s in steps:
        if s.get("kind") in SCRIPT_KINDS:
            script = s.get("script", "")
            if not (root / "scripts" / script).is_file():
                item = {"step": s["id"], "script": script, "optional": bool(s.get("optional"))}
                missing_scripts.append(item)
                (warnings if s.get("optional") else errors).append("Missing script for %s: %s" % (s["id"], script))
    errors.extend(validate_extension(ext, root / "scripts", cfg))
    inventory = root / "downstream_runbook_inventory.json"
    if inventory.exists():
        record = json.loads(inventory.read_text(encoding="utf-8"))
        configured_orders = {str(s.get("ro")) for s in steps}
        missing_rows = [x for x in record.get("rows", []) if str(x["order"]) not in configured_orders]
        if missing_rows:
            errors.append("Downstream run book incomplete: %s of %s rows still not implemented" % (len(missing_rows), len(record.get("rows", []))))
            for x in missing_rows:
                warnings.append("Not implemented RO %s: %s" % (x["order"], x["step"]))
    ids = [s.get("id") for s in steps]
    if len(ids) != len(set(ids)):
        errors.append("Duplicate run-book step IDs")
    # These are known remaining stages, NOT claims that their taskflow IDs or scripts are mapped.
    known_stages = ("TF_35", "TF_55", "TF_60")
    for stage in known_stages:
        if not any(str(i).startswith(stage) for i in ids):
            errors.append("No validated executable stage for %s" % stage)
    if str(cfg.get("SnapLogic", {}).get("Mode", "manual")).lower() == "manual":
        warnings.append("SnapLogic is in manual mode: unattended execution will pause")
    if str(cfg.get("Informatica", {}).get("Mode", "manual")).lower() != "sunrise":
        warnings.append("Informatica is not in automatic sunrise mode")
    if not cfg.get("RequireEndToEnd", False):
        warnings.append("RequireEndToEnd=false: partial runs are permitted")
    if cfg.get("StopAfter"):
        errors.append("StopAfter=%s prevents full run" % cfg["StopAfter"])
    return {"ready_for_full_run": not errors and not any("manual mode" in w for w in warnings),
            "errors": list(dict.fromkeys(errors)), "warnings": list(dict.fromkeys(warnings)),
            "missing_scripts": missing_scripts,
            "configured_steps": len(steps), "extension_steps": len(ext.get("steps", [])),
            "notes": "Structural checks only. Live API access, idempotence, Goose schema, and record lineage still require verification."}
