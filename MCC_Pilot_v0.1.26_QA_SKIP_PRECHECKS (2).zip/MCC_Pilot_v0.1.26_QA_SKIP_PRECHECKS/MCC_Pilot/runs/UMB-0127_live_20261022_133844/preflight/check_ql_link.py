"""Read-only: does each order's bundle line link to a jobsite through the SAME quote line (what DeliveryOrders matches on)?"""
import json, sys, collections
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

B = 'aFOVD0000001Swj4AE'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = {o['id'][:15] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']}
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
js_ql = {j['NF_Quote_Line__c'] for j in sf.query(
    "SELECT NF_Quote_Line__c FROM NF_Quoted_Jobsite__c WHERE NF_Quote__r.USS_Migration_Batch__c = '%s'" % B)}
rows = sf.query("SELECT Id, (SELECT Product_Type__c, SBQQ__QuoteLine__c, SBQQ__RequiredBy__c, "
                "SBQQ__RequiredBy__r.SBQQ__QuoteLine__c, CustomerOwned__c, Is_Power_Ancillary_Asset__c FROM OrderItems) "
                "FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)
out = collections.defaultdict(collections.Counter)
types = collections.defaultdict(collections.Counter)
for r in rows:
    g = 'stuck' if r['Id'][:15] in stuck else 'succeeded'
    items = [i for i in ((r.get('OrderItems') or {}).get('records') or [])
             if not i.get('CustomerOwned__c') or i.get('Is_Power_Ancillary_Asset__c')]
    for i in items:
        types[g][str(i.get('Product_Type__c'))] += 1
    bundles = [i for i in items if i.get('Product_Type__c') == 'Bundle']
    children = [i for i in items if i.get('Product_Type__c') in ('Asset', 'Ancillary Asset')]
    linked_bundle = [b for b in bundles if b.get('SBQQ__QuoteLine__c') in js_ql]
    linked_child = [c for c in children if ((c.get('SBQQ__RequiredBy__r') or {}).get('SBQQ__QuoteLine__c')) in js_ql]
    out[g]['orders'] += 1
    out[g]['no Bundle line'] += not bundles
    out[g]['bundle line has NO jobsite on its quote line'] += bool(bundles) and not linked_bundle
    out[g]['no Asset line under a jobsite bundle'] += not linked_child
for g in ('stuck', 'succeeded'):
    print(g, dict(out[g]))
    print('   usable line types:', dict(types[g].most_common(6)))
