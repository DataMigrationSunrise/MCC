"""Live Informatica IDMC reads, by BINDING to the Sunrise app's own adapter.

Same pattern connections.py already uses for Goose: find the Sunrise app folder, import
the module the user already wrote and tested, call its functions. Nothing here
reimplements IDMC authentication, session handling or endpoint shapes -- if Sunrise's
adapter is fixed, this follows automatically.

READ ONLY BY CONSTRUCTION
-------------------------
This module names only these Sunrise functions:

    login, credentials, validate_config, discover_workflows, get_run_status,
    latest_results, and the _json_request/_headers plumbing for the one read
    endpoint Sunrise does not already wrap (activityLog with no runId filter).

It deliberately does NOT name start_taskflow, run_and_wait or _invoke_advanced_taskflow.
Those START taskflows. tf_90a_CleanUpFailedOrderActivations deletes WorkOrders and
MaintenancePlans before it notifies -- on 2026-10-02 it destroyed 81 records across 11
runs because it failed after the deletes. A pre-flight MONITOR that can start taskflows
is not a monitor any more, and the one thing this tool guarantees is that it cannot
change anything. test_offline asserts this module never names those three.

CREDENTIALS
-----------
Never handled here, never stored, never logged. Sunrise's own credentials() reads them
from environment variables only -- INFORMATICA_USERNAME / INFORMATICA_PASSWORD by
default, or whatever names config.json points at. config.json holds env var NAMES, URLs
and the project/folder to look in. It never holds a secret.
"""
from __future__ import annotations

import sys
from pathlib import Path

import connections as cx

# Named here so a test can assert they are never referenced in this file's source.
FORBIDDEN = ("start_taskflow", "run_and_wait", "_invoke_advanced_taskflow")

# The read surface this module requires of Sunrise's adapter. A missing name is a LOUD
# failure -- the same philosophy as the Goose binding: UNPROVEN, never a wrong number.
REQUIRED = ("login", "credentials", "validate_config", "discover_workflows",
            "get_run_status", "latest_results", "_json_request", "_headers")

_IL = None
_ERR = ""
# One session per process. IDMC login is a network round trip and the checks run in
# parallel; logging in per check would be slow and would hammer the auth endpoint.
_SESSION = None


def bind(app_dir: str = "") -> tuple[bool, str]:
    """Import Sunrise's informatica_live. Returns (ok, message). Never raises."""
    global _IL, _ERR
    if _IL is not None:
        return True, "Already bound to Sunrise informatica_live."
    root = cx._find_sunrise(app_dir)
    if root is None:
        _ERR = ("Sunrise app folder not found, so live Informatica is unavailable. "
                "Set SunriseAppDir in config.json to the folder holding informatica_live.py "
                "(the same folder as goose_live). Job run times fall back to whatever "
                "Sunrise already captured to disk; checks still run.")
        return False, _ERR
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    try:
        import informatica_live as il                      # type: ignore
        missing = [f for f in REQUIRED if not hasattr(il, f)]
        if missing:
            raise AttributeError("informatica_live is missing %s -- Sunrise's interface changed"
                                 % ", ".join(missing))
        _IL = il
        return True, "Bound to Sunrise informatica_live at %s" % root
    except Exception as e:                                 # noqa: BLE001
        _ERR = ("Found Sunrise at %s but could not use informatica_live: %s. "
                "Live Informatica reads are unavailable; captured history is still used."
                % (root, e))
        return False, _ERR


def bound() -> bool:
    return _IL is not None


def error() -> str:
    return _ERR


def state_from_cfg(cfg: dict) -> dict:
    """
    The 'state' dict Sunrise's adapter expects. Only names and locations -- no secrets.
    Every key is optional; Sunrise falls back to its own documented defaults.
    """
    out = {}
    for ours, theirs in (
            ("InformaticaUsernameEnv", "InformaticaUsernameEnv"),
            ("InformaticaPasswordEnv", "InformaticaPasswordEnv"),
            ("InformaticaLoginUrl", "InformaticaLoginUrl"),
            ("InformaticaProject", "InformaticaProject"),
            ("InformaticaFolder", "InformaticaFolder")):
        v = str(cfg.get(ours) or "").strip()
        if v:
            out[theirs] = v
    return out


def has_credentials(cfg: dict) -> tuple[bool, str]:
    """
    Whether the credential environment variables resolve -- asked BEFORE any login, so a
    machine without them costs no network round trip and produces no scary error.
    The values themselves are never returned, logged or stored.
    """
    if _IL is None:
        return False, _ERR or "Sunrise informatica_live not bound."
    try:
        _IL.credentials(state_from_cfg(cfg))
        return True, "Credential environment variables are set."
    except Exception as e:                                 # noqa: BLE001
        return False, str(e)


def login(cfg: dict, reuse: bool = True):
    """A session dict, reused for the life of the process unless reuse=False."""
    global _SESSION
    if _IL is None:
        raise RuntimeError(_ERR or "Sunrise informatica_live not bound.")
    if reuse and _SESSION is not None:
        return _SESSION
    sess = _IL.login(state_from_cfg(cfg))
    if reuse:
        _SESSION = sess
    return sess


def reset_session() -> None:
    """Drop the cached session so the next call logs in again."""
    global _SESSION
    _SESSION = None


def validate(cfg: dict) -> dict:
    """
    Connectivity + taskflow discovery. Read-only: it logs in and lists objects.
    Sunrise writes its own validation JSON to its history folder as a side effect.
    """
    if _IL is None:
        return {"Status": "UNAVAILABLE", "Error": _ERR or "Sunrise informatica_live not bound."}
    try:
        return _IL.validate_config(state_from_cfg(cfg))
    except Exception as e:                                 # noqa: BLE001
        return {"Status": "FAILED", "Error": "%s: %s" % (type(e).__name__, e)}


def _rows_from(body) -> list:
    """activityLog comes back as a list, or wrapped under one of several keys."""
    if isinstance(body, list):
        return body
    if not isinstance(body, dict):
        return []
    for key in ("activityLogEntry", "activityMonitorEntry", "items", "entries"):
        v = body.get(key)
        if isinstance(v, list):
            return v
        if isinstance(v, dict):
            return [v]
    return [body] if body else []


def recent_runs(cfg: dict, session=None, limit: int = 200) -> list[dict]:
    """
    Every recent orchestrator run the user can see, live from the activity log.

    This is the one endpoint Sunrise does not already wrap: its get_run_status needs a
    runId, and the pre-flight needs "when did each step last run" across all of them.
    Built on Sunrise's _json_request and _headers so there is no second HTTP stack here.

    Returns raw-ish dicts; jobruns.py normalises them. An empty list is a normal answer.
    """
    if _IL is None:
        raise RuntimeError(_ERR or "Sunrise informatica_live not bound.")
    session = session or login(cfg)
    base = session["server_url"]
    headers = _IL._headers(session)
    # rowLimit is the documented v2 paging parameter. If a pod rejects it, fall back to
    # the bare resource rather than returning nothing.
    for url in ("%s/api/v2/activity/activityLog?rowLimit=%d" % (base, int(limit)),
                "%s/api/v2/activity/activityLog" % base):
        try:
            _, body = _IL._json_request(url, headers=headers)
            rows = _rows_from(body)
            if rows:
                return rows
        except Exception:                                  # noqa: BLE001
            continue
    return []


def in_flight(cfg: dict, session=None) -> list[dict]:
    """Runs executing right now. Empty is normal and means nothing is running."""
    if _IL is None:
        raise RuntimeError(_ERR or "Sunrise informatica_live not bound.")
    session = session or login(cfg)
    try:
        _, body = _IL._json_request(
            "%s/api/v2/activity/activityMonitor?details=true" % session["server_url"],
            headers=_IL._headers(session))
        return _rows_from(body)
    except Exception:                                      # noqa: BLE001
        return []


def captured_results(limit: int = 30) -> list[dict]:
    """What Sunrise already wrote to disk. The fallback when there is no live session."""
    if _IL is None:
        return []
    try:
        return _IL.latest_results(limit)
    except Exception:                                      # noqa: BLE001
        return []
