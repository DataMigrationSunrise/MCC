import sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, contract_orders

c = systems.build(app.CFG, 'dry', print)
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
print(contract_orders.run_recovery(c.sf, c.goose, app.CFG['OrgAlias'], 'aFOVD0000001Swj4AE', 468, folder,
                                   'TF_90A.C', say=lambda m: print(m, flush=True)))
