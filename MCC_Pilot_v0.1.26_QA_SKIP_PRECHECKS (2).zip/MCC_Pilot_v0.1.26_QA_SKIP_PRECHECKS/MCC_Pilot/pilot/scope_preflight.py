"""Bulk Preflight Monitor (pre-cut preflight): run every preflight rule over ALL staged rows of one Goose transformation,
before a batch is cut. STRICTLY READ-ONLY: Goose is opened with ApplicationIntent=ReadOnly and only
single SELECT statements are ever sent (anything else is refused before it reaches Goose). No fixes,
no exclusions, no Salesforce. Report-only: rows that need attention are "exceptions"; nothing blocks.

    python -m pilot.scope_preflight                      latest GoForLaunch transformation, project 10
    python -m pilot.scope_preflight --transformation 549

Each exception says which bucket it is in: in-scope (SFDC_Goose_ExclusionReason = ''), out-of-scope
phase N (out-of-phase orders and their customers/lines), or excluded: <reason>. Rules that only exist
for SFDC_* tables report "needs batch" and are skipped.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

from .step_preflight import BAD_SQL, READONLY

TOKEN = "{{TRANSFORMATION_ID}}"
FIELDS = ["rule", "bucket", "phase", "table", "record_id", "source_key", "parent_id", "detail"]
# (table, phase source). Line items take Phase and, if their own reason is blank, the reason of their order.
SCOPE_TABLES = [("STG_Customer", None), ("STG_CustomerContact", None), ("STG_Address", None),
                ("STG_Order", "self"), ("STG_OrderLineItem", "order"), ("STG_OrderLineItemAncillary", "order")]


class NotReadOnly(ValueError):
    pass


def _select(goose, sql: str, timeout: int) -> list[dict]:
    if not READONLY.match(sql) or BAD_SQL.search(sql):
        raise NotReadOnly("refused: not a single read-only SELECT")
    return [r for g in goose.result_sets(sql, timeout=timeout, read_only=True) for r in g]


def bucket(reason, phase) -> str:
    reason = str(reason or "").strip()
    if not reason:
        return "in-scope"
    if "phase" in reason.lower():
        # Customers, contacts and addresses carry no Phase of their own: they are out because their orders are.
        return "out-of-scope phase %s" % phase if phase not in (None, "") else "out-of-scope (orders out of phase)"
    return "excluded: %s" % reason


def default_transformation(goose, project: int, timeout: int = 120) -> int:
    rows = _select(goose, "SELECT TOP 1 ID FROM dbo.TRFM_Transformation WHERE ProjectID = %d AND GoForLaunch = 1 "
                          "ORDER BY ID DESC" % int(project), timeout)
    if not rows:
        raise ValueError("No GoForLaunch transformation for project %d" % project)
    return int(rows[0]["ID"])


def scope_counts(goose, tid: int, timeout: int) -> list[dict]:
    out = []
    for table, phase in SCOPE_TABLES:
        if phase == "order":
            sql = ("SELECT O.Phase AS Phase, COALESCE(NULLIF(X.SFDC_Goose_ExclusionReason, ''), "
                   "NULLIF(O.SFDC_Goose_ExclusionReason, ''), '') AS Reason, COUNT(*) AS N "
                   "FROM dbo.%s X LEFT JOIN dbo.STG_Order O ON O.ID = X.OrderID WHERE X.TransformationID = %d "
                   "GROUP BY O.Phase, COALESCE(NULLIF(X.SFDC_Goose_ExclusionReason, ''), "
                   "NULLIF(O.SFDC_Goose_ExclusionReason, ''), '')" % (table, tid))
        else:
            ph = "Phase" if phase == "self" else "CAST(NULL AS int)"
            sql = ("SELECT %s AS Phase, ISNULL(SFDC_Goose_ExclusionReason, '') AS Reason, COUNT(*) AS N "
                   "FROM dbo.%s WHERE TransformationID = %d GROUP BY %s, ISNULL(SFDC_Goose_ExclusionReason, '')"
                   % (ph, table, tid, "Phase" if phase == "self" else "SFDC_Goose_ExclusionReason"))
        try:
            for r in _select(goose, sql, timeout):
                out.append(dict(table=table, phase=r.get("Phase"), reason=r.get("Reason") or "",
                                bucket=bucket(r.get("Reason"), r.get("Phase")), rows=int(r.get("N") or 0)))
        except Exception as e:  # noqa: BLE001
            out.append(dict(table=table, phase=None, reason="", bucket="scope count failed: %s" % str(e)[:150], rows=0))
    return out


def run(goose, root: Path, tid: int | None = None, project: int = 10, out_root: Path | None = None,
        timeout: int = 600, say=print) -> dict:
    tid = int(tid) if tid else default_transformation(goose, project)
    header = _select(goose, "SELECT T.ID, T.Phase, T.GoForLaunch, T.MigrationBatchID, MB.BatchStatus "
                            "FROM dbo.TRFM_Transformation T LEFT JOIN dbo.MigrationBatch MB ON MB.ID = T.MigrationBatchID "
                            "WHERE T.ID = %d" % tid, 120)
    if not header:
        raise ValueError("Transformation %d not found" % tid)
    h = header[0]
    rows, notes = [], []
    batch = h.get("MigrationBatchID")
    notes.append(dict(rule="goose_batch_identity", status="INFO", detail=(
        "no batch attached yet (pre-cut)" if batch in (None, "") else
        "transformation already attached to batch %s (%s)" % (batch, h.get("BatchStatus")))))
    rules = json.loads((root / "preflight_rules.json").read_text(encoding="utf-8")).get("rules", [])
    for rule in rules:
        rid = rule["id"]
        if rid == "goose_batch_identity":
            continue
        fname = rule.get("transformation_file")
        if not fname:
            notes.append(dict(rule=rid, status="NEEDS_BATCH", detail="reads SFDC_* batch tables; skipped before a cut"))
            continue
        try:
            if Path(fname).name != fname or not fname.endswith(".sql"):
                raise ValueError("rule file must be a local .sql filename")
            sql = (root / "preflight_rules" / fname).read_text(encoding="utf-8")
            if TOKEN not in sql:
                raise ValueError("rule is not scoped to %s" % TOKEN)
            found = _select(goose, sql.replace(TOKEN, str(tid)), timeout)
            for r in found:
                rows.append(dict(rule=rid, bucket=bucket(r.get("ExclusionReason"), r.get("Phase")), phase=r.get("Phase"),
                                 table=rule.get("stage_table") or rule.get("fix_table") or "",
                                 record_id=r.get("SourceRecordId"), source_key=r.get("SourceKey"),
                                 parent_id=r.get("ParentId"), detail=str(r.get("Reason") or rule.get("description", rid))
                                 + ("" if not r.get("ProductCode") else " [%s / %s]" % (r.get("ProductCode"), r.get("SourceProductCode")))))
            notes.append(dict(rule=rid, status="CHECKED", detail="%d exception(s)" % len(found)))
        except Exception as e:  # noqa: BLE001  one rule failing never stops the others
            rows.append(dict(rule=rid, bucket="rule did not run", phase="", table="", record_id="", source_key="",
                             parent_id="", detail=str(e)[:300]))
            notes.append(dict(rule=rid, status="DID_NOT_RUN", detail=str(e)[:200]))
    scope = scope_counts(goose, tid, timeout)
    folder = (out_root or root / "runs" / "precut") / ("T%d_%s" % (tid, datetime.now().strftime("%Y%m%d_%H%M%S")))
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "exceptions.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    by_rule = Counter((r["rule"], r["bucket"]) for r in rows)
    lines = ["Bulk Preflight Monitor (read-only) - transformation %d, phase %s, GoForLaunch %s" % (tid, h.get("Phase"), h.get("GoForLaunch")), ""]
    lines += ["Scope (staged rows by bucket):"]
    totals = {}
    for s in scope:
        t = totals.setdefault(s["table"], Counter())
        t["staged"] += s["rows"]
        t[s["bucket"]] += s["rows"]
    for table, t in totals.items():
        rest = ", ".join("%s %d" % (k, v) for k, v in sorted(t.items()) if k not in ("staged", "in-scope"))
        lines.append("  %-28s staged %6d | in-scope %6d | %s" % (table, t["staged"], t.get("in-scope", 0), rest))
    lines += ["", "Rules:"] + ["  %-34s %-12s %s" % (n["rule"], n["status"], n["detail"]) for n in notes]
    lines += ["", "Exceptions by rule and bucket:"] + (
        ["  %-34s %-40s %d" % (k[0], k[1], v) for k, v in sorted(by_rule.items())] or ["  none"])
    summary = "\n".join(lines)
    (folder / "summary.txt").write_text(summary, encoding="utf-8")
    with (folder / "scope.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["table", "phase", "reason", "bucket", "rows"])
        w.writeheader()
        w.writerows(scope)
    say(summary)
    say("\nOutput: %s" % folder)
    return dict(transformation=tid, folder=str(folder), exceptions=len(rows), notes=notes, scope=scope)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--transformation", type=int, default=None)
    ap.add_argument("--project", type=int, default=10)
    ap.add_argument("--timeout", type=int, default=600)
    a = ap.parse_args(argv)
    from . import environments, systems
    from .engine import ROOT
    c = systems.build(environments.load(), "dry", lambda m: None)
    run(c.goose, ROOT, a.transformation, a.project, timeout=a.timeout)
    return 0


if __name__ == "__main__":
    sys.exit(main())
