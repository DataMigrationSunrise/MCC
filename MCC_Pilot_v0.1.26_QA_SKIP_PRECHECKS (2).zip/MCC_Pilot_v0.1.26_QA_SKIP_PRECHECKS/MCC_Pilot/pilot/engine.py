"""MCC Pilot migration runner with per-run stop targets and checkpoint resume.

Can resume from a selected step while preserving completed work. Explicit skips
are marked BYPASSED; intentional reruns are archived. Unknown outcomes require
review. Mapped downstream steps do not imply complete run-book coverage.
"""
from __future__ import annotations

import html
import json
import os
import re
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

from . import adapters as ad
from .pipeline import STEPS
from .extensions import load_extension, validate_extension
from .readiness import inspect
from .targets import validate_target, target_readiness
from .step_preflight import scan as scan_step_preflight
from .error_reconcile import reconcile as reconcile_goose_errors
from .coord_match import find as find_coordinates, summarize as summarize_coordinates, \
    write_report as write_coordinate_report, fill as fill_coordinates, log_entries as coordinate_log_entries
from .fixlog import write as write_fixlog, entry as fixlog_entry
from .jira_preflight import predict as predict_jira_preflight

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
RUNS = ROOT / "runs"

GENERIC_FAIL = [r"VERDICT:\s*BLOCKER", r"(?m)^\s*FAIL\b", r"\bABORT\b", r"(?m)^\s*BLOCKER\b"]
UNPROVEN = [r"UNPROVEN", r"NO QUOTE POPULATION", r"ABORT no batch named", r"No quotes\. Check the batch name"]


class Stop(Exception):
    pass


def _count(patterns, text):
    for p in patterns:
        m = re.search(p, text, re.I)
        if m:
            return int(m.group(1))
    return None


class Run:
    def __init__(self, cfg: dict, mode: str, factory, stop_after=None):
        self.skip_prechecks = False  # operator toggle: skip per-step Goose/Jira prechecks
        self.cfg, self.mode, self.factory = cfg, mode, factory
        self.extension = load_extension(ROOT / "runbook_extension.json")
        self.steps = [dict(s, status="PENDING", detail="", started="", finished="")
                      for s in STEPS + self.extension.get("steps", [])]
        self.stop_after = validate_target(self.steps, cfg.get("StopAfter", "") if stop_after is None else stop_after)
        self.log: list[str] = []
        self.state = "IDLE"
        self.batch: dict = {}
        self.waiting_for = ""
        self._continue = threading.Event()
        self._stop = threading.Event()
        self.folder: Path | None = None
        self.lock = threading.Lock()
        self.reconciliations = []
        self.coverage = {"complete": False, "missing": [], "errors": []}
        self.resuming = False
        self.preflight_history = []
        self.error_scans = []
        self.excluded_total = 0
        self.started_epoch = None
        self.step_started_epoch = None
        self.latest_informatica = {}
        self.phase = "IDLE"
        self.phase_step = ""
        self.last_activity_epoch = None
        self.resume_history = []
        self.resume_from = ""
        self.has_bypassed_steps = False
        self.jira_preflight_history = []

    # ------------------------------------------------------------- public
    def snapshot(self) -> dict:
        with self.lock:
            active = next((dict(s) for s in self.steps if s.get("status") == "RUNNING"), None)
            completed = sum(s.get("status") in ("PASS", "FIXED", "DONE", "INFO", "SKIPPED", "WOULD_FIX") for s in self.steps)
            return dict(active_step=active, completed_steps=completed, total_steps=len(self.steps),
                        stop_after=self.stop_after, resume_from=self.resume_from,
                        resume_history=self.resume_history,
                        has_bypassed_steps=self.has_bypassed_steps, target_name=next((s["name"] for s in self.steps if s["id"] == self.stop_after), "All configured steps"),
                        elapsed_seconds=round(time.time() - self.started_epoch) if self.started_epoch else None,
                        step_elapsed_seconds=round(time.time() - self.step_started_epoch) if active and self.step_started_epoch else None,
                        seconds_since_event=round(time.time() - self.last_activity_epoch) if self.last_activity_epoch else None,
                        informatica_last_result=self.latest_informatica,
                        last_event=self.log[-1] if self.log else "",
                        records={"processed": self.latest_informatica.get("metrics", {}).get("processed", self.latest_informatica.get("metrics", {}).get("totalRows")),
                                 "successful": self.latest_informatica.get("metrics", {}).get("successful", self.latest_informatica.get("metrics", {}).get("successRows")),
                                 "failed": self.latest_informatica.get("metrics", {}).get("failed", self.latest_informatica.get("metrics", {}).get("errorRows")),
                                 "excluded": self.excluded_total,
                                 "source": "INFORMATICA_LAST_RESULT" if self.latest_informatica.get("metrics") else "NO_LIVE_COUNTS"},
                        state=self.state, phase=self.phase, phase_step=self.phase_step,
                        mode=self.mode, batch=self.batch, environment=self.cfg.get("Environment", ""),
                        waiting_for=self.waiting_for, steps=self.steps,
                        log=self.log[-400:], folder=str(self.folder or ""),
                        reconciliations=self.reconciliations, coverage=self.coverage,
                        preflight_history=self.preflight_history[-100:],
                        jira_preflight_history=self.jira_preflight_history[-30:],
                        goose_error_scans=self.error_scans[-30:],
                        runbook_signature=[(s["id"], s["kind"]) for s in self.steps])

    def say(self, msg: str):
        line = "%s  %s" % (datetime.now().strftime("%H:%M:%S"), msg)
        with self.lock:
            self.log.append(line)
            self.last_activity_epoch = time.time()
        if self.folder:
            with (self.folder / "events.log").open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")

    def proceed(self):
        self._continue.set()

    def stop(self):
        self._stop.set()
        self._continue.set()

    # ------------------------------------------------------------- scan
    def discover(self, c) -> dict:
        """Read-only inventory; never hide batches that fail eligibility checks."""
        done = self._processed()
        # Only the most recent Goose batches, and only their linked Salesforce records: scanning 50
        # Goose batches and 2,000 Salesforce batches made every start slow.
        sets = c.goose.result_sets(
            "SELECT TOP (3) ID, BatchStatus, IsTestBatch, SalesforceUssMigrationBatchID "
            "FROM dbo.MigrationBatch ORDER BY ID DESC")
        rows = (sets[0] if sets else [])
        ids = sorted({str(g.get("SalesforceUssMigrationBatchID") or "").strip() for g in rows} - {""})
        sf_rows = c.sf.query("SELECT Id, Name, Batch_Status__c FROM USS_Migration_Batch__c WHERE Id IN (%s)"
                             % ",".join("'%s'" % i.replace("'", "") for i in ids)) if ids else []
        by_id = {str(r.get("Id", ""))[:15].lower(): r for r in sf_rows}
        by_name = {str(r.get("Name", "")).strip().lower(): r for r in sf_rows}
        candidates = []
        for g in rows:
            sfkey = str(g.get("SalesforceUssMigrationBatchID") or "").strip()
            sf = by_id.get(sfkey[:15].lower())
            status = str(g.get("BatchStatus") or "").strip()
            test = str(g.get("IsTestBatch") or "").strip().lower() in ("1", "true", "yes")
            name = sf.get("Name", "") if sf else ""
            reasons = []
            if status.lower() != "open":
                reasons.append("Goose status is %s (requires Open)" % (status or "BLANK"))
            # Every QA batch is IsTestBatch = 1. The pilot only reaches discovery after
            # verify_sandbox() confirmed an allowed QA sandbox, so test batches are allowed there.
            if test and not self.cfg.get("AllowTestBatchesInSandbox", False):
                reasons.append("test batch")
            if not sf:
                reasons.append("no Salesforce match by linked ID %s" % (sfkey or "BLANK"))
            if name in done and self.mode != "simulate":
                reasons.append("already completed by this pilot")
            candidates.append(dict(goose_id=g.get("ID"), goose_status=status,
                                   linked_sf_id=sfkey, sf_id=sf.get("Id") if sf else "",
                                   name=name, sf_status=sf.get("Batch_Status__c") if sf else "",
                                   is_test=g.get("IsTestBatch"), eligible=not reasons,
                                   reason="; ".join(reasons) or "Ready"))
        eligible = next((g for g in candidates if g["eligible"]), None)
        return dict(candidates=candidates, selected=eligible, goose_rows=len(rows),
                    sf_rows=len(sf_rows), sf_truncated=len(sf_rows) == 2000)

    def scan(self, c) -> dict:
        report = self.discover(c)
        for item in report["candidates"][:12]:
            self.say("Goose batch %s: status=%s linkedSF=%s name=%s -> %s" % (
                item["goose_id"], item["goose_status"], item["linked_sf_id"] or "BLANK",
                item["name"] or "UNMATCHED", item["reason"]))
        g = report["selected"]
        if not g:
            raise Stop("No eligible batch. Found %d recent Goose batch(es); see scan diagnostics for the exact reason."
                       % report["goose_rows"])
        return dict(name=g["name"], sf_id=g["sf_id"], goose_id=int(g["goose_id"]),
                    sf_status=g["sf_status"], goose_status=g["goose_status"], is_test=g["is_test"])

    @classmethod
    def from_checkpoint(cls, cfg, factory, folder, stop_after=None,
                        start_from=None, skip_intermediate=False, replay_completed=False):
        folder = Path(folder).resolve()
        if folder.parent != RUNS.resolve():
            raise Stop("Checkpoint must be inside this install's runs directory")
        data = json.loads((folder / "run.json").read_text(encoding="utf-8"))
        if data.get("state") in ("DONE", "DONE_WITH_FINDINGS"):
            raise Stop("Run is already complete. Start a new run for completed batches.")
        saved_target = data.get("stop_after", cfg.get("StopAfter", ""))
        r = cls(cfg, data["mode"], factory, saved_target if stop_after is None else stop_after)
        if not data.get("batch") or not data.get("steps"):
            raise Stop("Checkpoint has no recoverable batch or steps")
        expected = [(s["id"], s["kind"]) for s in r.steps]
        existing = [(s["id"], s["kind"]) for s in data["steps"]]
        if expected != existing:
            raise Stop("Run book changed since checkpoint; refusing unsafe resume")
        r.batch, r.steps, r.folder = data["batch"], data["steps"], folder
        journal = folder / "events.log"
        r.log = (journal.read_text(encoding="utf-8").splitlines() if journal.exists()
                 else list(data.get("log", [])))
        r.reconciliations = data.get("reconciliations", [])
        r.coverage = data.get("coverage", r.coverage)
        r.preflight_history = data.get("preflight_history", [])
        r.jira_preflight_history = data.get("jira_preflight_history", [])
        r.error_scans = data.get("goose_error_scans", [])
        r.excluded_total = data.get("records", {}).get("excluded") or 0
        r.resuming = True
        r.latest_informatica = data.get("informatica_last_result", {})
        r.phase = data.get("phase", "IDLE")
        r.phase_step = data.get("phase_step", "")
        r.resume_history = list(data.get("resume_history", []))
        r.has_bypassed_steps = bool(data.get("has_bypassed_steps"))

        safe = {"PASS", "FIXED", "DONE", "INFO", "SKIPPED", "WOULD_FIX", "WARNING"}
        bypassed = {"BYPASSED"}
        ordered = {s["id"]: i for i, s in enumerate(r.steps)}
        first_open = next((i for i, s in enumerate(r.steps) if s["status"] not in safe | bypassed), len(r.steps))
        if first_open == len(r.steps) and not start_from:
            raise Stop("No unexecuted steps remain; choose a completed step and explicitly enable rerun")
        explicit_start = bool(start_from)  # operator picked this step on purpose
        if start_from is None or start_from == "":
            start_index = first_open
            start_from = r.steps[start_index]["id"] if start_index < len(r.steps) else ""
        elif not isinstance(start_from, str) or start_from not in ordered:
            raise Stop("Unknown resume start step: %s" % str(start_from)[:80])
        else:
            start_index = ordered[start_from]
        if start_index >= len(r.steps):
            raise Stop("No step available to resume")

        final_index = len(r.steps) - 1 if not r.stop_after else ordered[r.stop_after]
        if final_index < start_index:
            raise Stop("Choose a later Run Through step: target %s is earlier than resume start %s" % (r.stop_after, start_from))

        # A completed step must never be replayed implicitly, even if it was
        # the previous Run Through target. An explicit rerun keeps old evidence.
        old_steps = [dict(s) for s in r.steps]
        prior_done = [s["id"] for s in r.steps[start_index:] if s["status"] in safe]
        if prior_done and not (replay_completed is True):
            raise Stop("Resume selection includes previously completed step(s) %s; enable intentional rerun to replay them" % ", ".join(prior_done[:6]))
        skipped = [s["id"] for s in r.steps[:start_index] if s["status"] not in safe | bypassed]
        if skipped and not (skip_intermediate is True):
            raise Stop("Resume from %s would bypass unexecuted step(s): %s. Enable skip intermediate steps to record this choice" %
                       (start_from, ", ".join(skipped[:8])))
        # Never implicitly mark a failed/in-flight step as successfully run.
        for idx in range(start_index, len(r.steps)):
            state = r.steps[idx]["status"]
            # A FAIL/UNKNOWN start step may be replayed only when the operator ticks
            # "Intentionally rerun" after reviewing it (e.g. confirmed it never started).
            if (replay_completed or (explicit_start and idx == start_index)) and state in ("FAIL", "UNPROVEN", "UNKNOWN", "RUNNING"):
                r.steps[idx]["status"] = "PENDING"
                r.steps[idx]["detail"] = "Operator reviewed %s outcome and chose to rerun" % state
                continue
            if state not in safe | bypassed | {"PENDING"}:
                raise Stop("Step %s is %s; its external outcome requires review before a replay" %
                           (r.steps[idx]["id"], state))
        for idx, step in enumerate(r.steps):
            if idx < start_index and step["status"] not in safe | bypassed:
                step.update(status="BYPASSED", detail="Operator skipped when resuming at %s" % start_from,
                            finished="", started="")
            elif idx >= start_index and step["status"] in safe | bypassed:
                step.update(status="PENDING", detail="", started="", finished="")
                step.pop("duration_seconds", None)
        r.has_bypassed_steps = any(s["status"] == "BYPASSED" for s in r.steps)
        r.resume_from = start_from
        from datetime import datetime
        r.resume_history.append(dict(timestamp=datetime.now().isoformat(timespec="seconds"),
                                     previous_state=data.get("state"), previous_stop_after=saved_target,
                                     new_stop_after=r.stop_after, start_from=start_from,
                                     bypassed=skipped, rerun=prior_done,
                                     previous_statuses={s["id"]: s["status"] for s in old_steps}))
        # Keep prior source evidence unchanged in individual step log files;
        # the checkpoint also records all previous statuses and choices.
        return r

    # ------------------------------------------------------------- main
    def execute(self, confirm_name: str = ""):
        self.state = "RUNNING"
        self.started_epoch = time.time()
        try:
            c = self.factory(self.cfg, self.mode, self.say)
            self.conn = c
            self.say("Mode: %s" % self.mode.upper())
            if self.mode != "simulate":
                self.say("Salesforce: " + c.sf.verify_sandbox())
            # Check extension definitions before initiating a live batch. Incomplete
            # run books are reported, not misrepresented as completed migrations.
            # Full-run readiness applies only to an unrestricted/end-of-book run.
            # The explicit operator-selected checkpoint is a legitimate partial run.
            full_request = not self.stop_after or self.stop_after == self.steps[-1]["id"]
            if self.mode == "live" and full_request and self.cfg.get("RequireEndToEnd", True):
                readiness = inspect(self.cfg, ROOT)
                if not readiness["ready_for_full_run"]:
                    self.coverage["errors"] = readiness["errors"]
                    raise Stop("End-to-end configuration incomplete: " + "; ".join(readiness["errors"][:5]))
            if self.mode == "live" and not full_request:
                readiness = target_readiness(self.cfg, ROOT, self.stop_after)
                if not readiness["ready"]:
                    raise Stop("Selected stop target is not runnable: " + "; ".join(readiness["errors"][:5]))
                for warning in readiness["warnings"]:
                    self.say("TARGET WARNING: " + warning)
            self.say("Run through: %s" % (self.stop_after or "ALL CONFIGURED STEPS"))
            if not self.resuming:
                self.batch = self.scan(c)
            self.say("New batch: %s (Goose %s, Salesforce %s)" % (
                self.batch["name"], self.batch["goose_id"], self.batch["sf_id"]))
            if self.mode == "live" and confirm_name.strip().upper() != self.batch["name"].upper():
                raise Stop("Live run needs the batch name typed back. Found %s, got %r." % (
                    self.batch["name"], confirm_name))
            if not self.resuming:
                # Unique per run: two runs started in the same second used to share a folder
                # and read each other's exclusion journals and checkpoints.
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                self.folder = RUNS / ("%s_%s_%s" % (self.batch["name"], self.mode, stamp))
                n = 1
                while self.folder.exists():
                    n += 1
                    self.folder = RUNS / ("%s_%s_%s_%d" % (self.batch["name"], self.mode, stamp, n))
            (self.folder / "logs").mkdir(parents=True, exist_ok=True)
            if self.resuming:
                # Preserve the *previous* checkpoint and step outputs before any
                # intentional rerun can replace a per-step log filename.
                choice = self.resume_history[-1]
                if choice["rerun"]:
                    import shutil
                    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                    archive = self.folder / "resume_history" / stamp
                    archive.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(self.folder / "run.json", archive / "prior_run.json")
                    if (self.folder / "logs").is_dir():
                        shutil.copytree(self.folder / "logs", archive / "prior_logs")
                self.say("Resuming saved checkpoint from %s through %s" %
                         (self.resume_from, self.stop_after or "ALL"))
                if choice["bypassed"]:
                    self.say("OPERATOR BYPASSED %d UNEXECUTED STEP(S): %s" %
                             (len(choice["bypassed"]), ", ".join(choice["bypassed"])))
                if choice["rerun"]:
                    self.say("OPERATOR REQUESTED RERUN of completed step(s): %s" % ", ".join(choice["rerun"]))
            else:
                self.say("Starting new run")
            self._save()

            reached_target = False
            for s in self.steps:
                if self.resuming and s["status"] in ("PASS", "FIXED", "DONE", "INFO", "SKIPPED", "WOULD_FIX", "WARNING", "BYPASSED"):
                    continue
                if self._stop.is_set():
                    raise Stop("Stopped by operator.")
                if self.skip_prechecks:
                    self.say("PRECHECKS SKIPPED %s (operator toggle)" % s["id"])
                else:
                    # Recheck exact Goose batch before *every* execution step. Findings
                    # are evidence, not instructions to delete source records.
                    self.phase, self.phase_step = "PREFLIGHT", s["id"]
                    guard = scan_step_preflight(c.goose, ROOT, self.folder / "preflight", s["id"],
                                                self.batch["goose_id"], self.mode)
                    self.preflight_history.append(dict(step=s["id"], status=guard["status"],
                                                       scans=guard["scans"], issues=len(guard["issues"]),
                                                       evidence=guard.get("file", "")))
                    if guard["issues"]:
                        acts = [i.get("action") for i in guard["issues"]]
                        self.say("PREFLIGHT %s: %d finding(s): %d fixed, %d would fix, %d pulled, %d to review; see %s" %
                                 (s["id"], len(acts), acts.count("FIXED"), acts.count("WOULD_FIX"),
                                  acts.count("EXCLUDED"), sum(a == "REVIEW_ONLY" for a in acts), guard.get("file", "")))
                    else:
                        self.say("PREFLIGHT %s: clear" % s["id"])
                    self._save()
                    # Jira-linked source predictions run before affected taskflows,
                    # not as false evidence of a Jira resolution. All checks are read-only.
                    if s['id'] in ('PREFLIGHT', 'TF_20', 'TF_35', 'TF_40'):
                        jira = predict_jira_preflight(
                            c.goose, ROOT, self.batch['goose_id'], s['id'],
                            self.folder / 'preflight' / 'jira', simulated=(self.mode == 'simulate'))
                        snapshot = {k: jira[k] for k in ('batch_id', 'step', 'observed_at', 'source', 'tests', 'evidence') if k in jira}
                        self.jira_preflight_history.append(snapshot)
                        alerts = [t for t in jira['tests'] if t['state'] in ('PREDICTED_FAILURE', 'SOURCE_RISK', 'INCOMPLETE_SAMPLE', 'NOT_TESTABLE')]
                        if alerts:
                            self.say('JIRA REGRESSION %s: %s (advisory; no source records excluded)' % (
                                s['id'], ', '.join(t['issue'] + '=' + t['state'] for t in alerts)))
                        self._save()
                    # A failed identity check is a concrete, technical block: running
                    # against a closed/reassigned batch cannot safely be inferred.
                    identity = [x for x in guard["scans"] if x.get("rule") == "goose_batch_identity"]
                    if self.mode == "live" and (len(identity) != 1 or identity[0].get("severity") != "ok"):
                        raise Stop("Cannot verify Goose batch identity before %s; see preflight evidence" % s["id"])
                    uncertain_writes = [i for i in guard["issues"] if (
                        i.get("reason", "").startswith("Exclusion failed:") or
                        i.get("reason") == "Exclusion not verified" or
                        i.get("action") in ("NOT_CHANGED_OR_UNVERIFIED", "WRITE_OUTCOME_UNKNOWN")
                    )]
                    if self.mode == "live" and uncertain_writes:
                        raise Stop("Goose exclusion write outcome requires reconciliation before %s" % s["id"])
                    advisory = [i for i in guard["issues"] if i.get("severity") == "unproven"]
                    if advisory:
                        self.say("PREFLIGHT WARNING %s: %d diagnostic finding(s), no new execution block" %
                                 (s["id"], len(advisory)))
                    if self.mode != "simulate":
                        self.phase = "ERROR_RECONCILIATION"
                        # Log entries are scoped by the *selected* Goose batch. A
                        # write is possible only after the exact identity canary.
                        try:
                            report = reconcile_goose_errors(c.goose, ROOT,
                                self.folder / "preflight" / ("goose_errors_%s.csv" % s["id"]),
                                batch_id=self.batch["goose_id"], step=s["id"],
                                mode=self.mode, identity_ok=True)
                            self.excluded_total += report["excluded"]
                            self.error_scans.append({k: report[k] for k in
                                ("scanned", "excluded", "uncertain", "reviewed", "evidence")})
                            if report["scanned"]:
                                self.say("GOOSE %s: %s error(s), %s excluded, %s review, %s uncertain" %
                                         (s["id"], report["scanned"], report["excluded"],
                                          report["reviewed"], report["uncertain"]))
                            self._save()
                            if report["uncertain"] and self.mode == "live":
                                raise Stop("Uncertain Goose exclusion write at %s; reconcile audit before any more writes" % s["id"])
                        except Stop:
                            raise
                        except Exception as exc:
                            self.say("GOOSE ERROR SCAN WARNING %s: %s (no exclusion write inferred)" %
                                     (s["id"], str(exc)[:300]))
                self.phase = "RUNNING"
                self._run_step(c, s)
                self._save()
                if s["status"] in ("FAIL", "UNPROVEN") and s["blocking"] and self.mode in ("live", "simulate"):
                    raise Stop("Blocked at RO %s %s: %s" % (s["ro"], s["id"], s["detail"]))
                if self.stop_after and s["id"] == self.stop_after:
                    reached_target = True
                    self.say("Selected stop point reached: %s. Remaining steps not executed." % s["id"])
                    break
            self.coverage = self._coverage()
            bad = [s for s in self.steps if s["status"] in ("FAIL", "UNPROVEN") and s["blocking"]]
            self.phase, self.phase_step = "FINISHED", ""
            self.state = ("TARGET_REACHED" if reached_target and any(s["status"] == "PENDING" for s in self.steps)
                          else "INCOMPLETE" if not self.coverage["complete"] else
                          "DONE_WITH_FINDINGS" if bad else "DONE")
            if self.mode == "live" and not bad and self.coverage["complete"] and not self.has_bypassed_steps:
                self._mark_processed()
            self.say("Finished: %s" % self.state)
            self._write_reconciliation_summary()
        except Stop as e:
            self.phase = "BLOCKED"
            self.state = "BLOCKED"
            self.say("STOPPED: %s" % e)
        except Exception as e:  # noqa: BLE001
            self.phase = "ERROR"
            self.state = "ERROR"
            self.say("ERROR: %s" % e)
            self.say(traceback.format_exc()[-1500:])
        finally:
            self._write_reconciliation_summary()
            self._save()
            self._post_jira()

    # ------------------------------------------------------------- one step
    def _run_step(self, c, s):
        s["started"] = datetime.now().strftime("%H:%M:%S")
        s["status"] = "RUNNING"
        self.step_started_epoch = time.time()
        self.say("RO %s  %s  %s" % (s["ro"], s["id"], s["name"]))
        self._save()  # Persist RUNNING before any external side effect.
        try:
            fn = getattr(self, "_k_" + s["kind"])
            status, detail = fn(c, s)
            # Quotes with no lines would convert into empty orders. When Goose has no lines for them
            # either (nothing left to load), pull them from the batch, log, and re-check once.
            if s["id"] == "TF_25.04" and status == "FAIL" and self.mode == "live" \
                    and self.cfg.get("PullEmptyQuotes", True):
                from .link_existing import pull_empty_quotes
                n = pull_empty_quotes(c.goose, c.sf, self.batch["goose_id"], self.batch["sf_id"], self.folder,
                                      s["id"], self.say)
                if n:
                    status, detail = fn(c, s)
        except Stop:
            raise
        except Exception as e:  # noqa: BLE001
            status, detail = "FAIL", "Error: %s" % str(e)[:500]
        # Dry run: a Salesforce-side check after a skipped load has no data to judge, so a FAIL or
        # UNPROVEN there is about the dry run, not the batch (e.g. TF_15.01 "no Salesforce Id").
        skipped_load = next((x["id"] for x in self.steps[:self.steps.index(s)]
                             if x["kind"] == "informatica" and x.get("status") == "SKIPPED"), None)
        if (self.mode == "dry" and skipped_load and status in ("FAIL", "UNPROVEN")
                and s["kind"] in ("apex", "goose_gen_check", "goose_gen_fix")):
            status, detail = "NOT_TESTABLE", "Needs data from %s, which a dry run does not load. (%s)" % (
                skipped_load, detail[:200])
        s["status"], s["detail"] = status, detail
        s["finished"] = datetime.now().strftime("%H:%M:%S")
        s["duration_seconds"] = round(time.time() - self.step_started_epoch, 1)
        self.step_started_epoch = None
        self.say("      %s  %s" % (status, detail))

    def _script(self, s) -> str | None:
        p = SCRIPTS / s["script"]
        if not p.exists():
            return None
        return ad.substitute(p.read_text(encoding="utf-8", errors="replace"),
                             self.batch["name"], self.batch.get("goose_id"), self.batch.get("sf_id"))

    def _keep(self, s, name, text):
        if self.folder:
            (self.folder / "logs" / ("%s_%s_%s.txt" % (s["ro"], s["id"], name))).write_text(
                text, encoding="utf-8")

    def _judge_apex(self, s, res) -> tuple[str, str]:
        text = "\n".join(res["debug"])
        if not res["ok"]:
            return "FAIL", "Apex did not run: %s" % res["error"][:300]
        if not s["blocking"]:
            if s.get("diagnostic") and re.search(r"(?im)^\s*(?:FAIL|REVIEW REQUIRED|VERDICT:\s*THE TWO RULES DISAGREE)", text):
                return "WARNING", _match_line([r"FAIL|REVIEW REQUIRED|THE TWO RULES DISAGREE"], res["debug"])
            return "INFO", _last_lines(res["debug"], 2)
        if any(re.search(p, text, re.I) for p in UNPROVEN):
            return "UNPROVEN", _match_line(UNPROVEN, res["debug"])
        for label, pat in (s.get("count_fail") or {}).items():
            n = _count([pat], text)
            if n:
                return "FAIL", "%s = %d" % (label, n)
        pats = (s.get("fail") or []) + GENERIC_FAIL
        if any(re.search(p, text) for p in pats):
            return "FAIL", _match_line(pats, res["debug"])
        return "PASS", _last_lines(res["debug"], 1) or "No findings."

    # ------------------------------------------------------------- kinds
    def _k_preflight(self, c, s):
        b = self.batch
        problems = []
        if str(b.get("goose_status")) != "Open":
            problems.append("Goose status %s" % b.get("goose_status"))
        test = str(b.get("is_test")) in ("1", "True", "true")
        if test and not self.cfg.get("AllowTestBatchesInSandbox", False):
            problems.append("Goose IsTestBatch = 1")
        if str(b.get("sf_status") or "").lower() in ("canceled", "cancelled"):
            problems.append("Salesforce status %s" % b.get("sf_status"))
        if problems:
            return "FAIL", "; ".join(problems)
        return "PASS", "Goose %s Open%s; Salesforce %s %s" % (
            b["goose_id"], " (test batch, allowed: verified QA sandbox)" if test else ", not a test batch",
            b["name"], b.get("sf_status") or "")

    def _k_coord_match(self, c, s):
        """Fill blank Goose address coordinates from confident Salesforce matches (live only),
        and log every blank address in GOOSE_ErrorLog: MCC_FIXED or MCC_PUSHED_THROUGH.
        Dry runs report what would happen. Unmatched addresses still load (push-through)."""
        if self.mode == "simulate":
            return "INFO", "Simulated: coordinate match not run against Goose."
        bid = int(self.batch["goose_id"])
        try:
            items = find_coordinates(c.goose, c.sf, bid)
        except Exception as e:  # noqa: BLE001
            return "WARNING", "Coordinate lookup failed; addresses load as staged (nothing written): %s" % str(e)[:250]
        summary = summarize_coordinates(items)
        report = write_coordinate_report(items, (self.folder or RUNS) / "preflight")
        base = "%s blank; %s matched, %s ambiguous, %s no match, %s not matchable. Report: %s." % (
            summary.get("blank", 0), summary.get("MATCH", 0), summary.get("AMBIGUOUS", 0),
            summary.get("NO_MATCH", 0), summary.get("NOT_MATCHABLE", 0), report.name)
        if not items:
            return "PASS", "No blank coordinates."
        if self.mode != "live" or not self.cfg.get("CoordinateFill", {}).get("Enabled"):
            return "WOULD_FIX", base + " Dry run: nothing written."
        journal = (self.folder or RUNS) / "preflight" / "coordinate_fill.jsonl"
        try:
            filled = set(fill_coordinates(c.goose, items, bid, journal))
            logged = write_fixlog(c.goose, bid, coordinate_log_entries(items, filled, s["id"]),
                                  (self.folder or RUNS) / "preflight" / "goose_fixlog.jsonl")
        except Exception as e:  # noqa: BLE001
            # A write may have committed before the error: stop and reconcile from the journals.
            return "FAIL", "Coordinate fill/log outcome unknown: %s. Journal: %s" % (str(e)[:200], journal)
        self.say("      MCC fix log: %d GOOSE_ErrorLog row(s) for batch %d" % (logged, bid))
        return "FIXED", base + " Filled %d; %d pushed through without coordinates; all logged in GOOSE_ErrorLog." % (
            len(filled), len(items) - len(filled))

    def _k_field_fill(self, c, s):
        """Fill gap-analysis fields Goose has but the load never maps; blanks only (pilot/field_fill.py)."""
        if self.mode == "simulate":
            return "INFO", "Simulated: field fill not run."
        from .field_fill import run as fill
        return fill(c.goose, c.sf, int(self.batch["goose_id"]), s["id"], s["fills"], self.mode,
                    (self.folder or RUNS) / "preflight", self.say)

    def _k_note(self, c, s):
        return "SKIPPED", "Confirm-only step; covered by the step before it."

    def _k_apex(self, c, s):
        code = self._script(s)
        if code is None:
            return ("SKIPPED" if s.get("optional") else "FAIL"), "Script %s not in scripts/." % s["script"]
        res = c.sf.run_apex(code)
        self._keep(s, "apex_log", "\n".join(res["debug"]) or res["raw"])
        return self._judge_apex(s, res)

    def _k_goose_sql(self, c, s):
        sql = self._script(s)
        if sql is None:
            return ("SKIPPED" if s.get("optional") else "FAIL"), "Script %s not in scripts/." % s["script"]
        sets = c.goose.result_sets(sql)
        self._keep(s, "result_sets", json.dumps(sets, indent=1, default=str)[:400000])
        last = sets[-1] if sets else []
        if s.get("fail_if_rows") and last:
            return "FAIL", "%d row(s) returned; expected none." % len(last)
        return "INFO", "%d result set(s), %d row(s) in the last." % (len(sets), len(last))

    def _apex_rows(self, sets):
        rows = []
        for st in sets:
            for r in st:
                if isinstance(r, dict) and any(k.lower() == "apex" for k in r):
                    key = next(k for k in r if k.lower() == "apex")
                    label = next((str(v) for k, v in r.items() if k != key), "")
                    rows.append((label.upper(), r[key]))
        return rows

    def _k_goose_gen_check(self, c, s):
        sql = self._script(s)
        if sql is None:
            return ("SKIPPED" if s.get("optional") else "FAIL"), "Script %s not in scripts/." % s["script"]
        sets = c.goose.result_sets(sql)
        self._keep(s, "generator", json.dumps(sets, indent=1, default=str)[:400000])
        rows = self._apex_rows(sets)
        if not rows:
            return "UNPROVEN", "Generator produced no Apex."
        worst, notes = "PASS", []
        for i, (label, code) in enumerate(rows, 1):
            res = c.sf.run_apex(code)
            self._keep(s, "apex_%d" % i, "\n".join(res["debug"]) or res["raw"])
            st, d = self._judge_apex(s, res)
            notes.append("%s%s" % (("%s: " % label) if label else "", d))
            if st == "FAIL" or (st == "UNPROVEN" and worst == "PASS"):
                worst = st
        return worst, "%d check(s). %s" % (len(rows), " | ".join(notes)[:600])

    def _k_goose_gen_fix(self, c, s):
        sql = self._script(s)
        if sql is None:
            return ("SKIPPED" if s.get("optional") else "FAIL"), "Script %s not in scripts/." % s["script"]
        sets = c.goose.result_sets(sql)
        self._keep(s, "generator", json.dumps(sets, indent=1, default=str)[:400000])
        flat = {k: v for st in sets for r in st if isinstance(r, dict) for k, v in r.items()}
        if int(flat.get("addresses_without_sf_id") or 0) > 0:
            return "FAIL", "%s addresses have no Salesforce Id; fix refused." % flat["addresses_without_sf_id"]
        rows = dict(self._apex_rows(sets))
        check, live = rows.get(s["check_label"]), rows.get(s["live_label"])
        if not check or not live:
            return "UNPROVEN", "Generator did not return both %s and %s Apex." % (s["check_label"], s["live_label"])
        res = c.sf.run_apex(check)
        self._keep(s, "check", "\n".join(res["debug"]) or res["raw"])
        if not res["ok"]:
            return "FAIL", "%s Apex failed: %s" % (s["check_label"], res["error"][:300])
        text = "\n".join(res["debug"])
        need = _count(s["needs"], text)
        if need is None:
            need = int(flat.get("rows_to_update") or 0)
        if need == 0:
            return "PASS", "Nothing to fix."
        if need > int(self.cfg.get("MaxFixRecords", 500)):
            return "FAIL", "%d records need fixing; above MaxFixRecords. Refused." % need
        if self.mode == "dry":
            return "WOULD_FIX", "%d record(s) would be fixed in a live run." % need
        self.say("      Applying fix to %d record(s)" % need)
        res = c.sf.run_apex(live)
        self._keep(s, "live", "\n".join(res["debug"]) or res["raw"])
        ltext = "\n".join(res["debug"])
        if not res["ok"] or re.search(r"ROLLED BACK|ABORT|FAIL\|", ltext) or "COMMITTED" not in ltext.upper():
            return "FAIL", "Fix did not commit: %s" % (_match_line([r"ROLLED BACK|ABORT|FAIL"], res["debug"]) or res["error"])[:300]
        res = c.sf.run_apex(check)
        self._keep(s, "recheck", "\n".join(res["debug"]) or res["raw"])
        after = _count(s["needs"], "\n".join(res["debug"])) or 0
        if after:
            return "FAIL", "Fix committed but %d still need fixing." % after
        self._log_fix(s, "MCC FIX %s (%s): %d record(s) fixed in Salesforce and re-verified; evidence %s"
                      % (s["id"], s["name"], need, self.folder))
        return "FIXED", "%d record(s) fixed and re-verified." % need

    def _log_fix(self, s, message, log_type="MCC_FIXED", source_object="RUN", source_id=None):
        """Record an applied MCC fix in GOOSE_ErrorLog. The fix itself is already verified, so a
        logging failure is reported loudly but does not undo or block it."""
        try:
            if self.mode != "live":
                return
            write_fixlog(self.conn.goose, int(self.batch["goose_id"]),
                         [fixlog_entry(log_type, s["id"], source_object, source_id or self.batch.get("name", ""), message)],
                         (self.folder or RUNS) / "preflight" / "goose_fixlog.jsonl")
        except Exception as e:  # noqa: BLE001
            self.say("      WARNING: fix applied but GOOSE_ErrorLog entry failed: %s" % str(e)[:200])

    def _wait_operator(self, what: str) -> tuple[str, str]:
        self.waiting_for = what
        self.state = "WAITING"
        self.say("      WAITING: %s. Press Continue when it has finished." % what)
        self._continue.clear()
        self._continue.wait()
        self.waiting_for = ""
        self.state = "RUNNING"
        if self._stop.is_set():
            raise Stop("Stopped by operator.")
        return "DONE", "Run by operator: %s" % what

    def _k_snaplogic(self, c, s):
        if self.mode == "dry":
            return "SKIPPED", "Dry run: pipeline not started."
        cfg = self.cfg.get("SnapLogic", {})
        if self.mode == "simulate":
            return c.snap_sim(s["id"])
        if cfg.get("Mode") in ("rest", "sunrise"):
            r = c.snap.run(s["id"], int(cfg.get("TimeoutMinutes", 120)) * 60, self.say)
            return ("DONE" if r["ok"] else "FAIL"), "HTTP %s %s" % (r["status"], r.get("detail", ""))
        return self._wait_operator("run %s in SnapLogic" % s["name"])

    # Goose staging tables each taskflow syncs back (Salesforce Id column). A taskflow whose
    # "not synced" loop never empties re-sends the same rows forever.
    LOOP_TABLES = {
        "TF_15": [("SFDC_Opportunity", "SalesforceOpportunityID"), ("SFDC_USF_Address", "Salesforce_USF_AddressID"),
                  ("SFDC_Purchase_Order", "SalesforcePurchaseOrderID"), ("SFDC_Quote", "SalesforceQuoteID")],
        "TF_20": [("SFDC_Quote_Line", "SalesforceQuoteLineID"), ("SFDC_QuotedJobSite", "SalesforceQuotedJobsiteID")],
        "TF_30": [("SFDC_Order", "SalesforceOrderID"), ("SFDC_Contract", "SalesforceContractID")],
        "TF_40": [("SFDC_MaintenancePlan", "SalesforceMaintenancePlanID")],
        "TF_55": [("SFDC_WorkOrder", "SalesforceWorkOrderID")],
        "TF_60": [("SFDC_ServiceAppointment", "SalesforceServiceAppointmentID"),
                  ("SFDC_BillingImpactQueue", "SalesforceBiqID")],
    }

    def _loop_watchdog(self, c, s):
        """Detect an Informatica "not synced" loop and pull the stuck rows so the taskflow can finish.

        Loop evidence, per watched table: the SAME unsynced rows on every one of StallChecks checks,
        CheckMinutes apart, while nothing else in that table synced. Only up to MaxPull rows are pulled
        (MigrationBatchID -> NULL, logged MCC_EXCLUDED with the restore value); more than that is a real
        failure and is reported, not pulled."""
        cfg = self.cfg.get("LoopWatchdog", {})
        tables = (cfg.get("Tables") or {}).get(s["id"]) or self.LOOP_TABLES.get(s["id"])
        if cfg.get("Enabled", True) is False or self.mode != "live" or not tables:
            return None
        # One "not synced" loop pass (count -> load -> sync IDs) takes about a minute, so three
        # unchanged checks a minute apart is a loop, caught in ~3 minutes instead of ~15.
        every = max(30, int(cfg.get("CheckSeconds", 60)))
        need = max(2, int(cfg.get("StallChecks", 3)))
        cap = int(cfg.get("MaxPull", 25))
        done = threading.Event()

        def watch():
            from .link_existing import unsynced, pull_rows
            seen = {}
            while not done.wait(every):
                for table, col in tables:
                    try:
                        ids, synced = unsynced(c.goose, self.batch["goose_id"], table, col)
                        key = frozenset(ids)
                        prev = seen.get(table)
                        # synced > 0: the taskflow has reached this table. Rows of a table it has not
                        # started yet are "unsynced and not moving" too, and must never be pulled.
                        streak = (prev[2] + 1 if prev and ids and synced > 0 and prev[0] == key
                                  and prev[1] == synced else 0)
                        seen[table] = (key, synced, streak)
                        if streak + 1 < need:
                            continue
                        if len(ids) > cap:
                            self.say("      LOOP SUSPECTED %s: %d %s rows unsynced and not moving; above MaxPull "
                                     "%d, not pulled -- check Informatica" % (s["id"], len(ids), table, cap))
                            seen[table] = (key, synced, -10 ** 6)  # report once
                            continue
                        n = pull_rows(c.goose, self.batch["goose_id"], self.folder, s["id"] + ".W", table, col,
                                      sorted(ids), "still unsynced and not moving after %d checks %ds apart "
                                      "(%s looping)" % (need, every, s["id"]))
                        self.say("      Loop detected in %s: pulled %d stuck %s row(s) from the batch "
                                 "(MCC_EXCLUDED in GOOSE_ErrorLog)" % (s["id"], n, table))
                        seen.pop(table, None)
                    except Exception as exc:  # noqa: BLE001
                        self.say("      Loop watchdog warning %s/%s: %s" % (s["id"], table, str(exc)[:200]))

        threading.Thread(target=watch, daemon=True).start()
        return done

    def _k_contract_orders(self, c, s):
        """Run book row 21 (Script 5a): contract every Activated order Salesforce left un-contracted."""
        if self.mode == "dry":
            from .contract_orders import remaining
            n = remaining(c.sf, self.batch["sf_id"])
            return ("WOULD_FIX" if n else "PASS"), "%d activated order(s) not contracted" % n
        if self.mode == "simulate":
            return "PASS", "SIMULATED: 0 activated orders not contracted"
        from .contract_orders import run_recovery
        return run_recovery(c.sf, c.goose, self.cfg["OrgAlias"], self.batch["sf_id"], self.batch["goose_id"],
                            self.folder, s["id"], self.say)

    def _k_informatica(self, c, s):
        # PWSTM-308 reminder gate: Craig's WorkType = Delivery condition must be in the MCC copy of
        # m_75 before tf_55 runs, or Service WOs get "B&R - Nav to CPQ Transfer" again.
        if s["id"] == "TF_55" and not self.cfg.get("Confirmations", {}).get("PWSTM308_m75_updated"):
            return "FAIL", ("STOPPED BEFORE TF_55: apply Craig's PWSTM-308 change to the MCC copy of "
                            "m_75_SFDC_WOs_CompleteDeliveryOrFirstService (B&R only when WorkType = Delivery), "
                            "then set Confirmations.PWSTM308_m75_updated = true in config.json and resume.")
        if self.mode == "dry":
            return "SKIPPED", "Dry run: taskflow not started."
        cfg = self.cfg.get("Informatica", {})
        tf = (cfg.get("Taskflows") or {}).get(s["id"], s["id"])
        if self.mode == "simulate":
            return c.inf_sim(s["id"])
        if cfg.get("Mode") != "sunrise":
            return self._wait_operator("run %s in Informatica" % tf)
        # Accounts/Contacts PL_07 skipped because an earlier batch created them have no Salesforce Id
        # in Goose; their quotes never load and tf_30_Quotes loops. Link exact matches first (logged).
        if s["id"] == "TF_15" and self.cfg.get("LinkExistingRecords", True):
            from .link_existing import link
            try:
                link(c.goose, c.sf, self.batch["goose_id"], self.folder, s["id"] + ".L", say=self.say)
            except Exception as exc:
                return "FAIL", "Existing-record link before TF_15 failed: %s" % str(exc)[:300]

        # Only an explicitly allowlisted, known-idempotent taskflow may be
        # re-started automatically. Timeout/UNKNOWN means it may STILL be running.
        # Never launch a second copy when completion is ambiguous.
        retry = cfg.get("Retry", {})
        allow = retry.get("IdempotentTaskflows", [])
        max_retry = max(0, min(int(retry.get("MaxRetries", 0)), 3)) if tf in allow else 0
        attempts = []
        for attempt in range(max_retry + 1):
            if self._stop.is_set():
                raise Stop("Stopped by operator before Informatica attempt.")
            watchdog = self._loop_watchdog(c, s)
            timeout = int(cfg.get("TimeoutMinutes", 120)) * 60

            def remember(run_id):
                # Checkpoint the live run id at once: if MCC is closed mid-job, a resume
                # reattaches to this run instead of launching a second copy.
                s["inflight_run_id"] = run_id
                self._save()
            try:
                r = None
                prior = s.get("inflight_run_id")
                if prior and hasattr(c.inf, "watch"):
                    r = c.inf.watch(prior, timeout, self.say)
                if r is None:
                    r = c.inf.run(tf, timeout, self.say, on_run_id=remember)
            except Exception as exc:
                # A network exception after launch is ambiguous. Do not retry.
                r = dict(ok=False, done=False, status="UNKNOWN", detail=str(exc)[:1000])
            finally:
                if watchdog:
                    watchdog.set()
            if r.get("done"):
                s.pop("inflight_run_id", None)  # outcome known; a later resume must not reattach
            attempts.append(r)
            # Preserve only metrics explicitly returned by Informatica; do not infer loaded rows.
            self.latest_informatica = {"step": s["id"], "taskflow": tf,
                "status": r.get("status", "UNKNOWN"), "attempt": attempt + 1,
                "metrics": {k: r[k] for k in ("processed", "successful", "failed", "totalRows", "successRows", "errorRows", "run_id", "job_id") if k in r}}
            self._save()
            self._keep(s, "taskflow_attempt_%d" % (attempt + 1),
                       json.dumps(r, default=str, indent=1))
            self._reconcile_informatica(c, s, tf, r)
            status = str(r.get("status", "UNKNOWN")).upper()
            if r.get("ok"):
                self._keep(s, "attempt_summary", json.dumps(attempts, default=str, indent=1))
                done = "%s %s after %d attempt(s); error evidence captured" % (tf, status, len(attempts))
                if s["id"] == "TF_35":
                    # tf_35 can report SUCCESS with orders activated but never contracted (UMB-0127:
                    # 1,014 activated, 334 contracted). Always follow through with run book row 21
                    # (Script 5a + orders without work orders); TF_35 is done only when all are zero.
                    from .contract_orders import run_recovery
                    st, d = run_recovery(c.sf, c.goose, self.cfg["OrgAlias"], self.batch["sf_id"],
                                         self.batch["goose_id"], self.folder, s["id"], self.say)
                    return ("DONE" if st != "FAIL" else "FAIL"), "%s; order recovery: %s" % (done, d)
                return "DONE", done
            if not r.get("done") or status not in ("FAILED", "FAULTED", "ERROR", "ABORTED"):
                break
            if attempt < max_retry:
                self.say("Informatica %s definitively failed (%s); verified idempotent allowlist permits retry %d" %
                         (tf, status, attempt + 1))
                # Do not sleep for long on an operator stop.
                if self._stop.wait(min(30, max(0, int(retry.get("DelaySeconds", 5))))):
                    raise Stop("Stopped by operator before Informatica retry.")
        self._keep(s, "attempt_summary", json.dumps(attempts, default=str, indent=1))
        return "FAIL", "%s %s after %d attempt(s); inspect reconciliation evidence; no source rows deleted" % (
            tf, attempts[-1].get("status", "UNKNOWN"), len(attempts))

    def _reconcile_informatica(self, c, s, tf, result):
        """Read-only evidence collection. Never infer deletion keys from free-text errors."""
        import hashlib
        raw = json.dumps(result, default=str, sort_keys=True)
        entry = dict(step=s["id"], taskflow=tf, status=result.get("status"),
                     result_sha256=hashlib.sha256(raw.encode()).hexdigest(),
                     disposition="READ_ONLY_REVIEW", goose_log_rows=[],
                     note="No record removal or log updates without validated batch, record keys and schema")
        # Store a schema snapshot AND current log rows. Existing legacy SQL uses SELECT *;
        # row contents may be sensitive, so retain only in local run evidence.
        try:
            bid = int(self.batch["goose_id"])
            sets = c.goose.result_sets("""
                SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = 'GOOSE_ErrorLog' ORDER BY ORDINAL_POSITION;
                SELECT TOP (100) ID, CreatedDate, MigrationBatchID, LogType,
                    ProcessName, ProcessStep, SourceObject, SourceRecordID, ErrorMessage
                FROM dbo.GOOSE_ErrorLog
                WHERE MigrationBatchID = %d ORDER BY ID DESC;
            """ % bid)
            entry["columns"] = sets[0] if sets else []
            entry["goose_log_rows"] = sets[1] if len(sets) > 1 else []
            entry["note"] = "Captured Goose error rows scoped by selected Goose MigrationBatchID; pre-step exclusion engine tracks applied changes"
        except Exception as exc:
            entry["note"] = "Goose error-log read unavailable: %s" % str(exc)[:350]
        if (self.mode == "live" and self.folder and result.get("done") and
                str(result.get("status", "")).upper() in ("FAILED", "FAULTED", "ERROR", "ABORTED")):
            # A DEFINITIVELY FAILED job may have recorded exact row errors.
            # UNKNOWN/TIMEOUT may still be processing; never alter its batch. Re-attest the
            # batch and resolve safe per-row failures before an approved retry.
            bid = int(self.batch["goose_id"])
            guard = scan_step_preflight(c.goose, ROOT, self.folder / "preflight",
                                        s["id"] + "_post_error", bid, "live")
            checked = [x for x in guard["scans"] if x.get("rule") == "goose_batch_identity"]
            if len(checked) == 1 and checked[0].get("severity") == "ok":
                report = reconcile_goose_errors(c.goose, ROOT,
                    self.folder / "preflight" / ("goose_errors_%s_post_error.csv" % s["id"]),
                    batch_id=bid, step=s["id"], mode="live", identity_ok=True)
                self.excluded_total += report["excluded"]
                self.error_scans.append({k: report[k] for k in
                    ("scanned", "excluded", "uncertain", "reviewed", "evidence")})
                entry["disposition"] = ("AUTO_EXCLUDED" if report["excluded"] else "REVIEW_ONLY")
                entry["note"] += "; auto-excluded %d verified source record(s)" % report["excluded"]
                self.say("AFTER ERROR %s: %d Goose error(s), %d records excluded" %
                         (s["id"], report["scanned"], report["excluded"]))
                if report["uncertain"]:
                    raise Stop("Goose error write outcome unknown after %s; reconcile journal" % s["id"])
            else:
                entry["note"] += "; record reconciliation withheld: batch identity unverified"
        self.reconciliations.append(entry)
        self._keep(s, "error_reconciliation", json.dumps(entry, indent=2, default=str))
        self.say("Informatica reconciliation %s: %s" % (tf, entry["note"]))

    def _write_reconciliation_summary(self):
        """Operator-readable, durable exception ledger for the current run."""
        if not self.folder:
            return
        import csv
        path = self.folder / "informatica_exception_ledger.csv"
        with path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=[
                "step", "taskflow", "status", "result_sha256", "disposition",
                "goose_log_count", "note"])
            writer.writeheader()
            for e in self.reconciliations:
                writer.writerow({"step": e.get("step"), "taskflow": e.get("taskflow"),
                                 "status": e.get("status"), "result_sha256": e.get("result_sha256"),
                                 "disposition": e.get("disposition"),
                                 "goose_log_count": len(e.get("goose_log_rows", [])),
                                 "note": e.get("note")})

    def _coverage(self):
        required = self.extension.get("required_milestones", [])
        passed = {s["id"] for s in self.steps if s["status"] in ("PASS", "DONE", "FIXED")}
        missing = [m for m in required if m not in passed]
        if not required:
            missing = ["No complete downstream run-book milestone list configured"]
        pending = [s["id"] for s in self.steps if s["status"] == "PENDING"]
        bypassed = [s["id"] for s in self.steps if s["status"] == "BYPASSED"]
        # Intentional skips never produce "full migration complete" evidence.
        return {"complete": not missing and not pending and not bypassed and not self.coverage.get("errors"),
                "missing": missing, "pending": pending, "bypassed": bypassed,
                "errors": self.coverage.get("errors", [])}

    # ------------------------------------------------------------- evidence
    def _save(self):
        if not self.folder:
            return
        snap = self.snapshot()
        target = self.folder / "run.json"
        tmp = self.folder / "run.json.tmp"
        with tmp.open("w", encoding="utf-8") as handle:
            json.dump(snap, handle, indent=1, default=str)
            handle.flush()
            os.fsync(handle.fileno())
        # Windows: antivirus/indexers briefly lock run.json; a failed save used to crash the run.
        for attempt in range(10):
            try:
                os.replace(tmp, target)
                break
            except PermissionError:
                if attempt == 9:
                    raise
                time.sleep(0.2)
        (self.folder / "summary.html").write_text(summary_html(snap), encoding="utf-8")

    def _processed(self) -> set:
        p = RUNS / "processed.json"
        return set(json.loads(p.read_text())) if p.exists() else set()

    def _mark_processed(self):
        p = RUNS / "processed.json"
        done = self._processed() | {self.batch["name"]}
        p.write_text(json.dumps(sorted(done)), encoding="utf-8")

    def _post_jira(self):
        try:
            if self.mode == "simulate" or not self.batch:
                return
            lines = ["MCC Pilot %s run on %s: %s" % (self.mode, self.batch.get("name"), self.state)]
            lines += ["RO %s %s: %s %s" % (s["ro"], s["id"], s["status"], s["detail"][:120])
                      for s in self.steps if s["status"] != "PENDING"]
            self.say(ad.jira_comment(self.cfg.get("Jira", {}), "\n".join(lines)))
        except Exception as e:  # noqa: BLE001
            self.say("Jira post failed: %s" % e)


def _last_lines(lines, n):
    keep = [l.strip() for l in lines if l.strip() and not l.strip().startswith("=")]
    return " / ".join(keep[-n:])[:300]


def _match_line(pats, lines):
    for l in lines:
        if any(re.search(p, l, re.I) for p in pats):
            return l.strip()[:300]
    return ""


def summary_html(snap) -> str:
    rows = "".join(
        "<tr><td>%s</td><td>%s</td><td>%s</td><td class='%s'>%s</td><td>%s</td></tr>" % (
            s["ro"], s["id"], html.escape(s["name"]), s["status"].lower(), s["status"],
            html.escape(s["detail"])) for s in snap["steps"])
    b = snap.get("batch") or {}
    return ("<!doctype html><meta charset='utf-8'><title>MCC Pilot run</title>"
            "<style>body{font-family:Segoe UI,Arial;margin:24px}td,th{border:1px solid #ccc;padding:6px 8px;"
            "font-size:13px;vertical-align:top}table{border-collapse:collapse}.pass,.fixed,.done{color:#137333}"
            ".fail,.unproven{color:#b3261e;font-weight:600}.would_fix,.info{color:#7a5a00}</style>"
            "<h2>MCC Pilot: %s, %s mode, %s</h2><table><tr><th>RO</th><th>Step</th><th>Name</th>"
            "<th>Status</th><th>Detail</th></tr>%s</table>" % (
                html.escape(str(b.get("name", ""))), snap["mode"], snap["state"], rows))
