"""Add generator WOLIs to existing Delivery/Pickup WOs, one order per Apex run. Usage: add_gen_wolis.py [first|all]"""
import re, sys, json
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, fixlog

mode = sys.argv[1] if len(sys.argv) > 1 else 'first'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
tpl = (folder / 'preflight' / 'add_gen_wolis.apex').read_text(encoding='utf-8')
c = systems.build(app.CFG, 'dry', lambda m: None)
c.sf.alias = 'Sunrise-QA'  # UMB-0127 lives in QA; config.json now points at Stage for UMB-0069
c.sf.allowed_hosts = ['ussprod--qa.sandbox.my.salesforce.com']
assert 'ussprod--qa.' in c.sf.verify_sandbox(), 'not QA'
B ='aFOVD0000001Swj4AE'
gen = c.sf.query("SELECT Id, OrderId FROM OrderItem WHERE Order.SBQQ__Quote__r.USS_Migration_Batch__c = '%s' "
                 "AND Product2.Name = 'GENERATOR RENTAL'" % B)
covered = {w['Order_Line_Item__c'] for w in c.sf.query(
    "SELECT Order_Line_Item__c FROM WorkOrderLineItem WHERE Order_Line_Item__r.Product2.Name = 'GENERATOR RENTAL' "
    "AND Order_Line_Item__r.Order.SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)}
with_wos = {w['Order__c'] for w in c.sf.query(
    "SELECT Order__c FROM WorkOrder WHERE Order__r.SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)}
todo = sorted({g['OrderId'] for g in gen if g['Id'] not in covered and g['OrderId'] in with_wos})
print('orders with generator but no generator WO lines (and other WOs):', len(todo))
if mode == 'first':
    todo = todo[:1]
done, journal = [], folder / 'preflight' / 'add_gen_wolis.jsonl'
for o in todo:
    res = c.sf.run_apex(tpl.replace('{ORDER}', o))
    lines = [l[l.find('MCCGEN'):] for l in (res.get('debug') or []) if 'MCCGEN' in l]
    print(o, '|', ' | '.join(lines)[:300] or (res.get('error') or '')[:200])
    with journal.open('a', encoding='utf-8') as f:
        f.write(json.dumps(dict(order=o, out=lines, error=res.get('error'))) + '\n')
    if any('COMMITTED' in l for l in lines):
        done.append(o)
if done:
    fixlog.write(c.goose, 468, [fixlog.entry('MCC_FIXED', 'TF_90A.C', 'Order', o,
        'MCC FIX generator rental: generator Delivery/Pickup WOLIs added to existing WOs (CPQOrders output, no duplicates)',
        'WorkOrderLineItem') for o in done], folder / 'preflight' / 'goose_fixlog.jsonl')
print('fixed orders:', len(done))
