"""Batch-scoped, reversible exclusion of staging rows (never DELETE).

The caller must supply a preflight-verified integer staging ID and an explicit
allowlisted stage table. The SQL uses a transaction and OUTPUT readback; a
second verification query confirms the exclusion persisted.
"""
import json
from datetime import datetime
from pathlib import Path

TABLES = {'STG_Customer', 'STG_CustomerContact', 'STG_Order', 'STG_OrderLineItem', 'STG_OrderLineItemService', 'STG_OrderLineItemServiceSchedule'}

def _lit(value):
    return "N'" + str(value).replace("'", "''") + "'"

def exclude(goose, audit_file: Path, *, batch_id: int, stage_table: str, record_id: int, reason: str, step: str):
    if stage_table not in TABLES:
        raise ValueError('Stage table not allowlisted')
    batch_id, record_id = int(batch_id), int(record_id)
    if batch_id <= 0 or record_id <= 0:
        raise ValueError('Batch and staging IDs must be positive integers')
    if not str(reason).strip():
        raise ValueError('Exclusion reason must be nonempty')
    reason = ('MCC ' + str(step) + ': ' + str(reason))[:100]
    table = 'dbo.' + stage_table
    # READ/UPDATE uses the *same* batch membership join. Conditional write is
    # idempotent: an already-excluded row is not overwritten.
    where = (f"S.ID = {record_id} AND EXISTS (SELECT 1 FROM dbo.TRFM_Transformation T "
             f"WHERE T.ID = S.TransformationID AND T.MigrationBatchID = {batch_id})")
    sql = ("SET XACT_ABORT ON; BEGIN TRANSACTION; "
           "DECLARE @Updated TABLE (ID int, OldReason nvarchar(100), NewReason nvarchar(100)); "
           f"UPDATE S SET SFDC_Goose_ExclusionReason = {_lit(reason)} "
           "OUTPUT inserted.ID, deleted.SFDC_Goose_ExclusionReason, inserted.SFDC_Goose_ExclusionReason "
           "INTO @Updated (ID, OldReason, NewReason) "
           f"FROM {table} S WHERE {where} "
           "AND (S.SFDC_Goose_ExclusionReason IS NULL OR S.SFDC_Goose_ExclusionReason = ''); "
           "SELECT ID, OldReason, NewReason FROM @Updated; COMMIT TRANSACTION;")
    # Error evidence is appended before a database write, so interrupted
    # attempts remain discoverable even if a connection dies during commit.
    audit_file.parent.mkdir(parents=True, exist_ok=True)
    with audit_file.open('a', encoding='utf-8') as f:
        f.write(json.dumps(dict(time=datetime.now().isoformat(), batch_id=batch_id,
                                table=stage_table, record_id=record_id, step=step,
                                reason=reason, status='ATTEMPT_STARTED')) + '\n')
    try:
        result = goose.result_sets(sql)
    except Exception as exc:
        with audit_file.open('a', encoding='utf-8') as f:
            f.write(json.dumps(dict(time=datetime.now().isoformat(), batch_id=batch_id,
                                    table=stage_table, record_id=record_id, step=step,
                                    status='WRITE_OUTCOME_UNKNOWN', error=str(exc))) + '\n')
        raise
    updates = [r for group in result for r in group if 'NewReason' in r]
    check = goose.result_sets(f"SELECT S.ID, S.SFDC_Goose_ExclusionReason AS CurrentReason "
                              f"FROM {table} S WHERE {where}")
    matches = [r for group in check for r in group if 'CurrentReason' in r]
    outcome = ('EXCLUDED' if len(updates) == 1 and len(matches) == 1 and
               matches[0]['CurrentReason'] == reason else 'NOT_CHANGED_OR_UNVERIFIED')
    entry = dict(time=datetime.now().isoformat(), batch_id=batch_id, table=stage_table,
                 record_id=record_id, step=step, reason=reason, status=outcome,
                 before=updates[0].get('OldReason') if updates else None,
                 after=matches[0].get('CurrentReason') if len(matches) == 1 else None)
    audit_file.parent.mkdir(parents=True, exist_ok=True)
    with audit_file.open('a', encoding='utf-8') as f:
        f.write(json.dumps(entry) + '\n')
    return entry
