"""
THE ONLY FILE THAT KNOWS SUNRISE EXISTS.

Sunrise's connection code has no opinion about what is CORRECT -- it runs a query and
returns rows -- so it cannot carry a specification defect, and when it breaks it breaks
loudly. Check logic is never shared, because that is where a defect hides silently.

If Sunrise moves, this file changes and the error message says exactly that.

Salesforce  -> `sf` CLI  (same invocation control_center.py uses)
Goose       -> sunrise goose_live.invoke_query, else the bundled PowerShell runner
"""
from __future__ import annotations
import base64, json, os, re, shutil, subprocess, sys, tempfile, threading, time
from pathlib import Path

# ---------------------------------------------------------------- Sunrise discovery
_SUNRISE = None
_SUNRISE_ERR = ""


SUNRISE_MARKER = ("goose_live", "goose_live.py")


def _is_sunrise(c: Path) -> bool:
    try:
        return (c / SUNRISE_MARKER[0] / SUNRISE_MARKER[1]).is_file()
    except OSError:
        return False


def _search_down(root: Path, max_depth: int = 4, budget: int = 4000) -> Path | None:
    """
    Find the Sunrise app folder somewhere BENEATH a folder the person pointed at.

    Requiring the exact `app` folder meant a reasonable answer like "my Documents folder"
    silently did nothing. The marker is distinctive, so looking a few levels down is safe
    and saves a hunt through Explorer.

    Bounded on purpose: a Documents folder can be enormous, and a config value must never
    turn startup into a disk crawl. Depth 4, a few thousand directories, and it gives up.
    """
    try:
        if _is_sunrise(root):
            return root
    except OSError:
        return None
    seen = 0
    frontier = [(root, 0)]
    while frontier:
        cur, depth = frontier.pop(0)
        if depth >= max_depth or seen > budget:
            continue
        try:
            kids = [k for k in cur.iterdir() if k.is_dir()]
        except (OSError, PermissionError):
            continue
        for k in kids:
            seen += 1
            if seen > budget:
                break
            name = k.name
            # skip the obvious time sinks and anything hidden
            if name.startswith(".") or name in (
                    "node_modules", "__pycache__", "venv", ".git", "test_run_history",
                    "AppData", "Windows", "Program Files"):
                continue
            if _is_sunrise(k):
                return k
            frontier.append((k, depth + 1))
    return None


def _find_sunrise(explicit: str = "") -> Path | None:
    """
    Locate the Sunrise `app` folder -- the one holding goose_live/goose_live.py.

    Explicit config wins, then the SUNRISE_APP env var, then a walk upward from this file.
    A path that is not itself the app folder is searched a few levels down, so pointing at
    the folder Sunrise lives IN works as well as pointing at it exactly.
    """
    for raw in (explicit, os.environ.get("SUNRISE_APP", "")):
        if not str(raw or "").strip():
            continue
        c = Path(str(raw).strip().strip('"'))
        if _is_sunrise(c):
            return c
        found = _search_down(c)
        if found is not None:
            return found
    here = Path(__file__).resolve()
    for p in [here.parent, *here.parents]:
        for c in (p / "app", p):
            if _is_sunrise(c):
                return c
    return None


def bind_sunrise(app_dir: str = "") -> tuple[bool, str]:
    """Import Sunrise's goose_live. Returns (ok, message). Never raises."""
    global _SUNRISE, _SUNRISE_ERR
    root = _find_sunrise(app_dir)
    if root is None:
        _SUNRISE_ERR = (
            "Sunrise app folder not found. Looked for a folder containing "
            "goose_live\\goose_live.py, at %r and up to 4 levels beneath it. "
            "Set SunriseAppDir in config.json to the Sunrise folder (the one holding "
            "goose_live), or the SUNRISE_APP env var. If the path is on OneDrive, make "
            "sure the files are downloaded locally rather than online-only. "
            "Goose checks will report UNPROVEN; Salesforce checks still run."
            % (app_dir or "(not set)"))
        return False, _SUNRISE_ERR
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    try:
        from goose_live import goose_live as gl          # type: ignore
        for fn in ("invoke_query", "read_json_rows", "validate_readonly_sql"):
            if not hasattr(gl, fn):
                raise AttributeError("goose_live.%s is missing -- Sunrise's interface changed" % fn)
        _SUNRISE = gl
        return True, "Bound to Sunrise goose_live at %s" % root
    except Exception as e:                                # noqa: BLE001
        _SUNRISE_ERR = ("Found Sunrise at %s but could not use goose_live: %s. "
                        "This is a LOUD failure by design -- Goose checks report UNPROVEN "
                        "rather than returning a wrong number." % (root, e))
        return False, _SUNRISE_ERR


# ------------------------------------------------------------ Informatica (live)
def informatica_live_rows(cfg: dict) -> tuple[list, str]:
    """
    Recent orchestrator runs, live from the IDMC activity log. NEVER raises and never
    blocks a run: every failure returns ([], reason) and the tool falls back to whatever
    Sunrise captured to disk. An empty list is a normal answer.

    `informatica` is imported HERE rather than at module level because it imports this
    module -- a top-level import would be circular.
    """
    if str(cfg.get("InformaticaLive", "true")).strip().lower() in ("0", "false", "no", "off"):
        return [], "Live Informatica is switched off (InformaticaLive in config.json)."
    try:
        import informatica as ia
    except Exception as e:                                # noqa: BLE001
        return [], "Could not load the Informatica adapter: %s" % e
    ok, msg = ia.bind(cfg.get("SunriseAppDir", ""))
    if not ok:
        return [], msg
    has, why = ia.has_credentials(cfg)
    if not has:
        return [], ("No Informatica credentials in this environment, so no live read was "
                    "attempted (%s). Captured history is used instead." % why)
    try:
        rows = ia.recent_runs(cfg)
    except Exception as e:                                # noqa: BLE001
        return [], "Informatica live read failed: %s: %s" % (type(e).__name__, e)
    return rows, ("Live: %d run(s) read from the IDMC activity log." % len(rows)
                  if rows else "Logged in to IDMC, but the activity log returned no runs.")


# ---------------------------------------------------------------- Salesforce
def _sf_exe() -> str:
    return shutil.which("sf") or shutil.which("sf.cmd") or ("sf.cmd" if os.name == "nt" else "sf")


_BANNED_SOQL = re.compile(r"\b(INSERT|UPDATE|DELETE|UPSERT|MERGE)\b", re.I)


def validate_readonly_soql(soql: str) -> str:
    q = str(soql or "").strip().rstrip(";")
    if not q:
        raise ValueError("Empty SOQL.")
    if not re.match(r"^(SELECT|FIND)\b", q, re.I):
        raise ValueError("Read-only tool: SOQL must start with SELECT.")
    m = _BANNED_SOQL.search(q)
    if m:
        raise ValueError("Blocked token in SOQL: %s" % m.group(1).upper())
    return q


def cli_error_text(stdout: str, stderr: str = "", limit: int = 700) -> str:
    """
    The error a person needs, not the tail of a stack trace.

    The sf CLI's JSON error carries the useful text at the HEAD ("message", "name") and a long
    JS stack at the END. Slicing the last N characters kept the stack and cut the message
    mid-word -- a real run showed `tus__c' on entity 'Billing_Impacts_Queue__c'` where the
    column name should have been, which is how a wrong field name stayed hidden.

    A SOQL error also echoes the whole query before the real error. Dropping everything before
    "ERROR at Row" keeps the part that says WHAT is wrong. The error name (INVALID_FIELD,
    INVALID_TYPE, ...) is kept because friendly_sf_error() matches on it.
    """
    raw = (stdout or "").strip()
    msg = name = ""
    try:
        d = json.loads(raw)
        if isinstance(d, dict):
            msg = str(d.get("message") or "").strip()
            name = str(d.get("name") or d.get("errorCode") or "").strip()
    except Exception:                                         # noqa: BLE001
        pass
    if msg:
        i = msg.find("ERROR at Row")
        if i > 0:
            msg = msg[i:]
        text = ("%s: %s" % (name, msg)) if name and name not in msg else msg
        return text[:limit]
    both = (raw + (("\n" + stderr.strip()) if stderr and stderr.strip() else "")).strip()
    if len(both) <= limit:
        return both
    return both[: limit // 2] + " ... " + both[-(limit // 2):]       # head AND tail


class SalesforceError(RuntimeError):
    pass


def sf_query_raw(alias: str, soql: str, timeout: int = 180) -> dict:
    """The full CLI result payload, including totalSize. COUNT() needs totalSize because
    an aggregate COUNT() returns an EMPTY records array -- reading records[0] gives 0."""
    q = validate_readonly_soql(soql)
    cp = subprocess.run([_sf_exe(), "data", "query", "--query", q,
                         "--target-org", str(alias), "--json"],
                        capture_output=True, text=True, timeout=timeout)
    out = (cp.stdout or "") + (("\n" + cp.stderr) if cp.stderr else "")
    if cp.returncode != 0:
        raise SalesforceError(cli_error_text(cp.stdout, cp.stderr))
    try:
        payload = json.loads(cp.stdout)
    except Exception as e:                                # noqa: BLE001
        raise SalesforceError("Salesforce CLI returned non-JSON: %s" % out[-1500:]) from e
    return payload.get("result", {}) or {}


def sf_query_tooling(alias: str, soql: str, timeout: int = 180) -> list[dict]:
    """
    Tooling API query -- reads METADATA, which field-level security does not filter.

    This is the only way to tell a field that DOES NOT EXIST from a field that exists and
    is hidden from the running user. An ordinary describe cannot: both come back absent.
    That distinction is the whole answer when somebody asks 'is there a permission I am
    missing?' -- a missing permission and a missing deployment need opposite fixes.
    """
    q = validate_readonly_soql(soql)
    cp = subprocess.run([_sf_exe(), "data", "query", "--query", q, "--use-tooling-api",
                         "--target-org", str(alias), "--json"],
                        capture_output=True, text=True, timeout=timeout)
    if cp.returncode != 0:
        raise SalesforceError(cli_error_text(cp.stdout, cp.stderr))
    try:
        payload = json.loads(cp.stdout)
    except Exception as e:                                # noqa: BLE001
        raise SalesforceError("Tooling API returned non-JSON: %s" % (cp.stdout or "")[-1500:]) from e
    return [_flatten(r) for r in ((payload.get("result", {}) or {}).get("records") or [])]


def sf_query(alias: str, soql: str, timeout: int = 180) -> list[dict]:
    """Run SELECT-only SOQL. Flattens relationship fields to dotted keys."""
    res = sf_query_raw(alias, soql, timeout)
    return [_flatten(r) for r in (res.get("records") or [])]


def _flatten(rec: dict, prefix: str = "") -> dict:
    flat = {}
    for k, v in (rec or {}).items():
        if k == "attributes":
            continue
        key = prefix + k
        if isinstance(v, dict):
            flat.update(_flatten(v, key + "."))
        else:
            flat[key] = v
    return flat


def sf_count(alias: str, soql: str, timeout: int = 180) -> int:
    """
    Count rows.

    `SELECT COUNT() FROM X` is an AGGREGATE query: Salesforce returns totalSize with an
    EMPTY records array. Reading records[0] therefore yields 0 for every count in the
    tool -- which silently turns every canary into "found nothing", and every zero result
    into UNPROVEN. totalSize is the authoritative value.

    `SELECT COUNT(Id) c FROM X` DOES return a row, so that form is handled too.
    """
    res = sf_query_raw(alias, soql, timeout)
    recs = res.get("records") or []
    if recs:
        for k, v in (recs[0] or {}).items():
            if k == "attributes":
                continue
            try:
                return int(v or 0)
            except (TypeError, ValueError):
                continue
    ts = res.get("totalSize")
    try:
        return int(ts or 0)
    except (TypeError, ValueError):
        return 0


def sf_describe_fields(alias: str, sobject: str, timeout: int = 180) -> set[str]:
    """Lowercased field API names present AND visible to this user (FLS applies)."""
    cp = subprocess.run([_sf_exe(), "sobject", "describe", "--sobject", sobject,
                         "--target-org", str(alias), "--json"],
                        capture_output=True, text=True, timeout=timeout)
    if cp.returncode != 0:
        raise SalesforceError(cli_error_text(cp.stdout, cp.stderr))
    data = json.loads(cp.stdout).get("result", {})
    return {str(f.get("name", "")).lower() for f in data.get("fields", [])}


def friendly_sf_error(raw: str, alias: str = "") -> str:
    """Translate sf CLI noise into something a person can act on."""
    t = str(raw or "")
    if "NamedOrgNotFoundError" in t or "No authorization information" in t or \
       "No authorized org" in t:
        return ("The org alias %r is not authorized on this machine. Run `sf org list`, "
                "copy the ALIAS of your QA sandbox, and set \"OrgAlias\" in config.json."
                % alias)
    if "ENOENT" in t or "No such file or directory: 'sf'" in t or "not recognized" in t:
        return ("The Salesforce CLI (`sf`) is not on PATH. Open a Command Prompt and check "
                "with `sf --version`.")
    if "expired" in t.lower() or "refresh token" in t.lower() or "INVALID_SESSION" in t:
        return ("The session for %r has expired. Re-authorize with "
                "`sf org login web --alias %s`." % (alias, alias or "YOUR_ALIAS"))
    if "INVALID_TYPE" in t or "sObject type" in t:
        return "An object in a query does not exist in this org: %s" % t[:200]
    if "INVALID_FIELD" in t:
        return "A field in a query does not exist in this org: %s" % t[:200]
    return t[:300]


def sf_test(alias: str) -> tuple[bool, str]:
    if not str(alias or "").strip():
        return False, ('No "OrgAlias" set in config.json. Run `sf org list` and copy the ALIAS '
                       'of your QA sandbox.')
    try:
        n = sf_count(alias, "SELECT COUNT() FROM USS_Migration_Batch__c")
        return True, "Salesforce OK (alias %s, %d migration batches visible)" % (alias, n)
    except Exception as e:                                # noqa: BLE001
        return False, friendly_sf_error(str(e), alias)


# ---------------------------------------------------------------- Goose
class GooseUnavailable(RuntimeError):
    pass


def goose_query(server: str, database: str, sql: str, timeout: int = 180) -> list[dict]:
    """SELECT-only against Goose, through Sunrise's validated read-only runner."""
    if _SUNRISE is None:
        raise GooseUnavailable(_SUNRISE_ERR or "Sunrise goose_live not bound.")
    safe = _SUNRISE.validate_readonly_sql(sql)       # Sunrise's own guard, not a reimplementation
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "q.json"
        _SUNRISE.invoke_query(server, database or "Goose", safe, out, "JSON", timeout)
        return _SUNRISE.read_json_rows(out)


def goose_scalar(server: str, database: str, sql: str, timeout: int = 180) -> int:
    rows = goose_query(server, database, sql, timeout)
    if not rows:
        return 0
    for v in rows[0].values():
        try:
            return int(v or 0)
        except (TypeError, ValueError):
            continue
    return 0


def goose_test(server: str, database: str = "Goose") -> tuple[bool, str]:
    if _SUNRISE is None:
        return False, _SUNRISE_ERR or "Sunrise goose_live not bound."
    try:
        n = goose_scalar(server, database, "SELECT COUNT_BIG(*) AS C FROM dbo.MigrationBatch")
        return True, "Goose OK (%s/%s, %d migration batches)" % (server, database, n)
    except Exception as e:                                # noqa: BLE001
        return False, "Goose unreachable: %s" % str(e)[:400]


# ---------------------------------------------------------------- Sunrise run outputs
def latest_preflight_run(app_dir: str = "") -> Path | None:
    """Most recent Sunrise preflight output folder, for the cross-check checks."""
    root = _find_sunrise(app_dir)
    if root is None:
        return None
    base = root / "test_run_history" / "full_migration_preflight"
    if not base.is_dir():
        return None
    runs = sorted(p for p in base.glob("*") if p.is_dir() and (p / "summary.json").is_file())
    return runs[-1] if runs else None


import jobruns as _jobruns

# Every Salesforce call here is a separate `sf` CLI process: Node starts, authenticates and
# round-trips, roughly 5-8 seconds each. Run serially, the self-test alone fired 53 of them
# and took six minutes before the first check ran. They are almost entirely WAITING, so a
# small pool of threads collapses that without touching the org any harder -- the same
# queries, just not one at a time.
DEFAULT_WORKERS = 6


def parallel(fn, items, workers: int = 0, ordered: bool = True):
    """
    Map `fn` over `items` concurrently, returning results in the ORIGINAL order.

    An exception in one item is returned as that item's result rather than killing the
    batch -- callers here need the other 46 answers even when one query fails.
    """
    items = list(items)
    if not items:
        return []
    n = max(1, min(int(workers or DEFAULT_WORKERS), len(items)))
    if n == 1:
        out = []
        for it in items:
            try:
                out.append(fn(it))
            except Exception as e:                           # noqa: BLE001
                out.append(e)
        return out
    from concurrent.futures import ThreadPoolExecutor
    results = [None] * len(items)

    def run(i_it):
        i, it = i_it
        try:
            return i, fn(it)
        except Exception as e:                               # noqa: BLE001
            return i, e

    with ThreadPoolExecutor(max_workers=n) as ex:
        for i, r in ex.map(run, list(enumerate(items))):
            results[i] = r
    return results


class Conn:
    """Everything a check is handed. One object, so checks stay declarative."""

    def __init__(self, cfg: dict, batch: str = ""):
        self.cfg = cfg
        self.batch = batch
        self.alias = cfg.get("OrgAlias", "")
        self.goose_server = cfg.get("GooseServer", "")
        self.goose_db = cfg.get("GooseDatabase", "Goose")
        self.goose_ok = False
        self.sunrise_run = None
        self._fields: dict[str, set] = {}
        # Job run times, read from whatever the Sunrise MCC app already captured from the
        # Informatica and SnapLogic APIs. Read-only, no credentials, and an empty history
        # is normal -- it leaves the Time column blank, it never fails a check.
        live_rows, live_note = [], ""
        try:
            live_rows, live_note = informatica_live_rows(cfg)
        except Exception as e:                            # noqa: BLE001
            live_note = "Live Informatica read raised unexpectedly: %s" % e
        self.informatica_note = live_note
        self.informatica_live = bool(live_rows)
        self.jobs = _jobruns.JobHistory(cfg.get("SunriseAppDir", ""), live_rows, live_note)
        self.workers = int(cfg.get("Workers") or DEFAULT_WORKERS)
        # The self-test runs every canary, and then each check runs its own again when it
        # finds zero rows -- the same query twice per run. Cached here for the life of one
        # run so it is paid for once.
        self.canary_cache: dict = {}
        # Every query a check sends, kept per check so verify.py can ask afterwards: was
        # this tied to the batch, did it hit its LIMIT, how many rows came back. The ledger
        # is thread-local because checks run on a pool.
        self._tl = threading.local()
        self.audit_log: dict = {}
        self._audit_lock = threading.Lock()

    def job_run(self, label: str):
        """The orchestrator's own record of when this step ran, if Sunrise captured it."""
        try:
            return self.jobs.find(label)
        except Exception:                                 # noqa: BLE001
            return None

    # -- query ledger
    def audit_begin(self, check_id: str):
        self._tl.check, self._tl.entries = check_id, []

    def audit_end(self) -> list:
        entries = getattr(self._tl, "entries", None) or []
        cid = getattr(self._tl, "check", "")
        self._tl.check, self._tl.entries = "", []
        if cid:
            with self._audit_lock:
                self.audit_log[cid] = entries
        return entries

    def _audited(self, kind: str, raw: str, fn):
        """Run fn(), noting the query against the check that sent it (if one is running)."""
        entries = getattr(self._tl, "entries", None)
        if entries is None or not getattr(self._tl, "check", "") or getattr(self._tl, "mute", False):
            return fn(raw.replace("{BATCH}", self.batch))
        sent = raw.replace("{BATCH}", self.batch)
        sfid = getattr(self, "_sf_batch_id_val", "") if getattr(self, "_sf_batch_id_for", None) == self.batch else ""
        scoped = ("{BATCH}" in raw) or bool(self.batch and self.batch in sent) \
            or bool(sfid and sfid[:15] in sent)
        t0 = time.time()
        ent = dict(kind=kind, sql=sent[:700], scoped=scoped, rows=None, ms=0, error="")
        try:
            out = fn(sent)
            ent["rows"] = len(out) if isinstance(out, list) else int(out or 0)
            return out
        except Exception as e:                               # noqa: BLE001
            ent["error"] = str(e)[:200]
            raise
        finally:
            ent["ms"] = int((time.time() - t0) * 1000)
            if len(entries) < 40:
                entries.append(ent)

    # -- Salesforce
    def q(self, soql: str) -> list[dict]:
        return self._audited("soql", soql, lambda s: sf_query(self.alias, s))

    def n(self, soql: str) -> int:
        return self._audited("count", soql, lambda s: sf_count(self.alias, s))

    def fields(self, sobject: str) -> set:
        if sobject not in self._fields:
            self._fields[sobject] = sf_describe_fields(self.alias, sobject)
        return self._fields[sobject]

    def has_field(self, dotted: str) -> bool:
        """dotted = 'Contract.LastBillingDate__c'"""
        obj, _, fld = dotted.partition(".")
        try:
            return fld.lower() in self.fields(obj)
        except Exception:                                 # noqa: BLE001
            return False

    def tq(self, soql: str) -> list[dict]:
        """Tooling API -- metadata, unfiltered by field-level security."""
        return self._audited("tooling", soql, lambda s: sf_query_tooling(self.alias, s))

    def field_reality(self, sobject: str, fields: list[str]) -> dict:
        """
        For each field: does it EXIST in the org, and can the running user SEE it?

        describe -> visible to me          (FLS applies)
        Tooling  -> exists at all          (FLS does not apply)

        exists + visible   -> fine
        exists + invisible -> a PERMISSION problem; the field is deployed
        absent everywhere  -> a DEPLOYMENT problem; no permission will ever reveal it
        """
        visible = set()
        try:
            visible = {f.lower() for f in self.fields(sobject)}
        except Exception:                                 # noqa: BLE001
            pass
        deployed, tooling_err = set(), ""
        try:
            for r in self.tq("SELECT DeveloperName FROM CustomField "
                             "WHERE TableEnumOrId = '%s'" % sobject):
                dn = str(r.get("DeveloperName") or "")
                if dn:
                    deployed.add((dn + "__c").lower())
        except Exception as e:                            # noqa: BLE001
            tooling_err = str(e)[:300]
        out = {}
        for f in fields:
            k = f.lower()
            out[f] = dict(
                visible=k in visible,
                deployed=(None if tooling_err else (k in deployed)),
                verdict=("visible" if k in visible
                         else ("unknown -- Tooling API unavailable" if tooling_err
                               else ("DEPLOYED BUT HIDDEN FROM THIS USER" if k in deployed
                                     else "NOT DEPLOYED -- the field does not exist"))))
        return dict(fields=out, tooling_error=tooling_err)

    # -- Goose
    def sf_batch_id(self) -> str:
        """
        The Salesforce Id of this batch, cached. Goose does NOT carry the batch name:
        MigrationBatch has ID, BatchStatus, AcquisitionCode and SalesforceUssMigrationBatchID
        (the join key Sunrise's own reference SQL calls verified). So every Goose lookup by
        batch goes through this Id, never through a name that the table does not have.
        """
        if getattr(self, "_sf_batch_id_for", None) != self.batch:
            self._sf_batch_id_for = self.batch
            tl = getattr(self, "_tl", None)
            if tl is not None:
                tl.mute = True      # looking up the batch must not make a check look batch-scoped
            try:
                rows = self.q("SELECT Id FROM USS_Migration_Batch__c WHERE Name = '{BATCH}' LIMIT 1")
            except Exception:                                     # noqa: BLE001
                rows = []
            finally:
                if tl is not None:
                    tl.mute = False
            self._sf_batch_id_val = str((rows or [{}])[0].get("Id") or "").strip()
        return self._sf_batch_id_val

    def gq(self, sql: str) -> list[dict]:
        return self._audited("goose", sql, lambda s: goose_query(self.goose_server, self.goose_db, s))

    def gn(self, sql: str) -> int:
        return self._audited("goose-count", sql, lambda s: goose_scalar(self.goose_server, self.goose_db, s))
