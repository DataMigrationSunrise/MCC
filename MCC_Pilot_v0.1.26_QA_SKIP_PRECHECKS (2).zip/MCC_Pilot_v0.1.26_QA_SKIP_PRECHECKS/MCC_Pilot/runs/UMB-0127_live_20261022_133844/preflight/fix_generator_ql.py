"""Set SBQQ__QuoteLine__c.CustomerOwned__c = false on the generator-rental Power Bundle quote lines of the stuck orders.
All-or-nothing: exact count, and rolled back if CPQ triggers change any quantity or price on those lines."""
import json, re, sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, fixlog

folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = [o['id'] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']]
c = systems.build(app.CFG, 'dry', print)
names = ['Power Bundle', 'GENERATOR RENTAL', 'Delivery Power - Standard', 'Pickup Power - Standard', 'No Service']
apex = """
Set<Id> orderIds = new Set<Id>{%s};
Set<String> names = new Set<String>{%s};
Set<Id> qlIds = new Set<Id>();
for (OrderItem oi : [SELECT SBQQ__QuoteLine__c FROM OrderItem WHERE OrderId IN :orderIds AND CustomerOwned__c = true
                     AND Product2.Name IN :names AND SBQQ__QuoteLine__c != null]) qlIds.add(oi.SBQQ__QuoteLine__c);
List<SBQQ__QuoteLine__c> qls = [SELECT Id, SBQQ__Quote__c, SBQQ__Quantity__c, SBQQ__BundledQuantity__c, SBQQ__NetPrice__c,
                                SBQQ__ListPrice__c, CustomerOwned__c FROM SBQQ__QuoteLine__c WHERE Id IN :qlIds AND CustomerOwned__c = true];
Integer EXPECTED = 295;
System.debug(LoggingLevel.ERROR, 'MCCFIX found=' + qls.size() + ' expected=' + EXPECTED);
if (qls.size() != EXPECTED) { System.debug(LoggingLevel.ERROR, 'MCCFIX ABORT count mismatch, nothing changed'); return; }
Map<Id, String> before = new Map<Id, String>();
for (SBQQ__QuoteLine__c q : qls) before.put(q.Id, q.SBQQ__Quantity__c + '|' + q.SBQQ__BundledQuantity__c + '|' + q.SBQQ__NetPrice__c + '|' + q.SBQQ__ListPrice__c);
Savepoint sp = Database.setSavepoint();
SBQQ.TriggerControl.disable();  // flag-only change: skip CPQ recalculation (and its SOQL)
for (SBQQ__QuoteLine__c q : qls) q.CustomerOwned__c = false;
Integer bad = 0;
for (Database.SaveResult r : Database.update(qls, false)) if (!r.isSuccess()) { bad++; if (bad <= 5) System.debug(LoggingLevel.ERROR, 'MCCFIX FAIL ' + r.getErrors()[0].getMessage()); }
if (bad > 0) { Database.rollback(sp); System.debug(LoggingLevel.ERROR, 'MCCFIX ROLLED BACK failed=' + bad); return; }
Integer changed = 0;
for (SBQQ__QuoteLine__c q : [SELECT Id, SBQQ__Quantity__c, SBQQ__BundledQuantity__c, SBQQ__NetPrice__c, SBQQ__ListPrice__c, CustomerOwned__c
                             FROM SBQQ__QuoteLine__c WHERE Id IN :qlIds]) {
    String now = q.SBQQ__Quantity__c + '|' + q.SBQQ__BundledQuantity__c + '|' + q.SBQQ__NetPrice__c + '|' + q.SBQQ__ListPrice__c;
    if (now != before.get(q.Id) || q.CustomerOwned__c) { changed++; if (changed <= 3) System.debug(LoggingLevel.ERROR, 'MCCFIX DRIFT ' + q.Id + ' ' + before.get(q.Id) + ' -> ' + now); }
}
if (changed > 0) { Database.rollback(sp); System.debug(LoggingLevel.ERROR, 'MCCFIX ROLLED BACK qty/price drift on ' + changed + ' lines'); return; }
Integer oiStill = [SELECT COUNT() FROM OrderItem WHERE OrderId IN :orderIds AND CustomerOwned__c = true AND Product2.Name IN :names];
System.debug(LoggingLevel.ERROR, 'MCCFIX COMMITTED quote_lines=' + qls.size() + ' order_lines_still_customer_owned=' + oiStill);
""" % (",".join("'%s'" % i for i in stuck), ",".join("'%s'" % n for n in names))
res = c.sf.run_apex(apex)
dbg = "\n".join(res.get('debug') or [])
for line in dbg.splitlines():
    if 'MCCFIX' in line:
        print(line[line.find('MCCFIX'):][:220])
if 'MCCFIX COMMITTED' not in dbg:
    sys.exit('Not committed: ' + (res.get('error') or '')[:300])
n = fixlog.write(c.goose, 468, [fixlog.entry(
    'MCC_FIXED', 'TF_90A.C', 'RUN', 'TF_90A.C',
    'MCC FIX generator rental: SBQQ__QuoteLine__c.CustomerOwned__c true -> false on 295 Power Bundle lines (59 orders; '
    'Customer Owned Power unchanged); qty/price verified unchanged', 'SBQQ__QuoteLine__c')],
    folder / 'preflight' / 'goose_fixlog.jsonl')
print('logged', n)
