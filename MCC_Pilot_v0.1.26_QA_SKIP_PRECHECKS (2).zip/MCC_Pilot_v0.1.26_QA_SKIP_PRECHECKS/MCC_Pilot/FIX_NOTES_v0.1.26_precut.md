# FIX NOTES: Bulk Preflight Monitor (pre-cut preflight, 2026-10-25)

Start it from the top of the MCC folder: `START Bulk Preflight Monitor.bat` (optional TransformationID).

Runs every preflight rule over ALL staged rows of one Goose transformation, before a batch is cut.

    CHECK PRECUT.bat            latest GoForLaunch transformation (project 10)
    CHECK PRECUT.bat 549        a specific TransformationID
    py -3 -X utf8 -m pilot.scope_preflight --transformation 549

Output: `runs\precut\T<id>_<timestamp>\` holds `exceptions.csv` (one row per exception: rule, bucket, phase, table,
record_id, source_key, parent_id, detail), `scope.csv` (staged rows by table, phase and reason) and `summary.txt`.

- **Strictly read-only.** Goose is opened with `ApplicationIntent=ReadOnly` (`goose_runner.ps1 -ReadOnly`), and any SQL
  that is not a single SELECT is refused before it is sent. There are no fixes, no exclusions and no Salesforce calls.
  Batch-run live fixes are unchanged.
- **Report only.** Rows that need attention are exceptions. A rule that fails or times out is recorded as
  "rule did not run", and the other rules still run.
- **Buckets:** `in-scope` (SFDC_Goose_ExclusionReason = ''), `out-of-scope phase N`, and `excluded: <reason>`.
  Line items use their order's Phase and, when their own reason is blank, their order's reason.
- **Rules:** a rule runs before a cut only if `preflight_rules.json` gives it a `transformation_file` that uses
  `{{TRANSFORMATION_ID}}`. Rules without one report NEEDS_BATCH. `goose_batch_identity` is informational
  ("no batch attached yet").
- New files: `pilot/scope_preflight.py`, `pilot/test_scope_preflight.py`, `preflight_rules/*_trfm.sql`, `CHECK PRECUT.bat`.

Validated on transformation 549 (batch 469) in one read-only run. Staged / in-scope:

| Table | Staged | In scope |
|---|---|---|
| Customer | 1968 | 618 |
| Contact | 16374 | 3741 |
| Address | 7170 | 1717 |
| Order | 4798 | 1006 |
| OrderLineItem | 6718 | 1031 |
| Ancillary | 2033 | 438 (one ancillary has a blank reason, but its order is excluded) |

The generator rule found 0 rows in STG for 549: the customer-owned flag on generator rentals is set later
(SFDC staging). Keep the batch-level TF_20 rule.
