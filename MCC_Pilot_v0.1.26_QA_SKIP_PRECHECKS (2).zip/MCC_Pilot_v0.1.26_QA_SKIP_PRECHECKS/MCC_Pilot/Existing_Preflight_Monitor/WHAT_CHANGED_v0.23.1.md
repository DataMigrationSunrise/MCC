# v0.23.1 - the All issues list now shows the Salesforce verification

New **Verified** column. Each issue gets a tag: a green "verified" (sample records were re-read
from Salesforce and exist), an orange "caution" with the first reason (hover for all), or a plain
"checked". Click a tag to open that check's records page with the full explanation. Unproven
issues that depend on a missing or hidden field show their field warning here too. The column
only appears on runs that have verification (v0.23.0 and later).
