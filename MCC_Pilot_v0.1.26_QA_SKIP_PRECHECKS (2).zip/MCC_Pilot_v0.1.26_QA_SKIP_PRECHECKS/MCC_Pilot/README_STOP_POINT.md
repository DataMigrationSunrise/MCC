# Run Through Step selector

In MCC Pilot, choose a target from **Run through step** and click **Run through TF_35** (or your selected step).

- All configured steps before and including the chosen target execute in existing order, with normal preflight, logging, and checkpoints.
- The selection belongs to this run, not a global setting in `config.json`. Existing default `TF_30.01` remains the default in the dropdown.
- Stop is **after** the selected step is executed and its result saved. A failed step can still stop execution earlier.
- The state becomes `TARGET_REACHED` when the selected point has been reached, not `DONE`, because the overall migration is not complete.
- The batch is not marked fully processed when stopped early.
- To extend a saved run, choose a **later** target from the dropdown, select the saved checkpoint, and click **Resume saved run**. Completed steps are not replayed.
- `All configured steps` is still subject to existing full-run readiness validation. Downstream run-book actions missing executable mappings remain missing; selecting TF_35 does not magically run undocumented procedures.
- With `SnapLogic.Mode=manual`, the existing operator Continue interaction still applies. Live runs require the batch-name confirmation and verified QA sandbox.
- Remaining stages after a selected point remain `PENDING`; evidence is in `runs/<batch>.../`.

The dropdown is populated by `GET /api/targets`, validated at the server endpoint, and persisted in `run.json` as `stop_after`.

## Resume from a chosen step

1. Pick the saved batch under **Resume saved run**. **Start back up at** defaults to the first pending step.
2. Select **Run through step** for the end of this continuation (must be at/after the start step).
3. Choose any step under **Start back up at**, including TF_35 after stopping at TF_35.
4. If that choice bypasses pending steps, check **Skip incomplete steps**. They are marked `BYPASSED` in the checkpoint and explicitly recorded as omissions. A bypassed batch cannot receive a full-completion result.
5. If that choice re-executes a previously successful step, check **Intentionally rerun completed steps**. Previously completed step states are preserved in `resume_history` in `run.json`, and steps from the chosen restart onward become pending. In LIVE mode, keep the existing batch name confirmation. Do not do this while an earlier external taskflow might still be running.
6. `RUNNING`, `FAIL`, `UNPROVEN` and ambiguous/unknown taskflow results are never replayed automatically. Investigate the existing external execution before retrying.
7. Clicking Resume launches the selected prefix of the *saved* run, not a new batch discovery. It retains the original batch identity, folder, and logs.

The endpoint is `POST /api/resume` with `folder`, `confirm`, `start_from`, `stop_after`, `skip_intermediate` and `replay_completed`.

**Known limitation:** Downstream run-book rows lacking an executable mapping still do not run. The selector cannot substitute for those missing procedures.
