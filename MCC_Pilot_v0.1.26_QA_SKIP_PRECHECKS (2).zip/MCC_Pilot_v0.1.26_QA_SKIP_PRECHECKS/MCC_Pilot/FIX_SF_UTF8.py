"""FIX_SF_UTF8 - one-line fix in pilot/adapters.py so large Salesforce CLI output is read as UTF-8.
Run from the MCC_Pilot folder (Pilot closed):  py -3 FIX_SF_UTF8.py

Bug: _sf_json() reads `sf ... --json` output with Windows' default cp1252 codec. sf writes UTF-8, so any
accented/special character in a Salesforce record (e.g. an address) crashes the reader thread
(UnicodeDecodeError ... byte 0x8d) and the step fails or hangs.

Change (only this):
    capture_output=True, text=True,
 -> capture_output=True, text=True, encoding="utf-8", errors="replace",
A backup is saved as pilot/adapters.py.bak_utf8. Touches nothing else.
"""
import shutil
import sys
from pathlib import Path

p = Path("pilot") / "adapters.py"
if not p.is_file():
    sys.exit("STOPPED: run this from the MCC_Pilot folder (pilot\\adapters.py not found). END")
src = p.read_text(encoding="utf-8")
old = 'cp = subprocess.run([_sf()] + args + ["--json"], capture_output=True, text=True,'
new = 'cp = subprocess.run([_sf()] + args + ["--json"], capture_output=True, text=True, encoding="utf-8", errors="replace",'
if new in src:
    sys.exit("Already fixed. Nothing changed. END")
if src.count(old) != 1:
    sys.exit("STOPPED: expected line not found exactly once; nothing changed. END")
shutil.copy2(p, p.with_name("adapters.py.bak_utf8"))
p.write_text(src.replace(old, new), encoding="utf-8")
print("FIXED pilot\\adapters.py (backup: pilot\\adapters.py.bak_utf8). Restart the Pilot. END")
# END
