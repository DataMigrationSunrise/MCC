"""Offline Jira regression predictor tests. Run: python -m pilot.test_jira_preflight"""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from .jira_preflight import predict, registry

ROOT=Path(__file__).resolve().parent.parent

class Goose:
    def __init__(self, rows=None, fault=None):
        self.rows=rows if rows is not None else []
        self.fault=fault
        self.queries=[]
    def result_sets(self, sql):
        self.queries.append(sql)
        assert 'T.MigrationBatchID = 567' in sql
        assert 'TOP (1001)' in sql
        assert '{{GOOSE_BATCH_ID}}' not in sql
        if self.fault: raise RuntimeError(self.fault)
        return [self.rows]

def test_registry_complete_with_no_false_verified_flags():
    issues=registry(ROOT)['issues']
    assert len(issues)==39
    assert {'PWSTM-328','PWSTM-356','PWSTM-401','PWSTM-407'} <= {i['key'] for i in issues}
    assert all(not i['jira_checked_live'] for i in issues)

def test_missing_generator_service_predicts_failure_without_writes():
    row={'SourceRecordId':25,'SourceKey':'0-2339712-10000','TransformationId':543,
         'TestResult':'PREDICTED_FAILURE','Reason':'No service'}
    g=Goose([row])
    with TemporaryDirectory() as tmp:
        report=predict(g,ROOT,567,'TF_20',Path(tmp))
        assert report['tests'][0]['state']=='PREDICTED_FAILURE'
        assert next(i for i in report['issues'] if i['key']=='PWSTM-328')['prediction']=='PREDICTED_FAILURE'
        assert Path(report['evidence']['json']).exists()
        assert Path(report['evidence']['csv']).exists()
        assert len(g.queries)==1 and g.queries[0].lstrip().startswith('--')

def test_good_input_not_marked_fixed():
    g=Goose([{'SourceRecordId':25,'TestResult':'SOURCE_INPUT_PASS'}])
    report=predict(g,ROOT,567,'TF_20')
    i=next(i for i in report['issues'] if i['key']=='PWSTM-328')
    assert i['prediction']=='SOURCE_INPUT_PASS'
    assert i['jira_status']=='Ready for QA'
    assert not i['jira_checked_live']

def test_empty_cohort_not_pass():
    r=predict(Goose(),ROOT,567,'TF_20')
    assert r['tests'][0]['state']=='NOT_TESTABLE'

def test_query_fault_does_not_fake_pass():
    r=predict(Goose(fault='view timeout'),ROOT,567,'TF_20')
    assert r['tests'][0]['state']=='NOT_TESTABLE' and 'view timeout' in r['tests'][0]['reason']

def test_result_cap_is_not_pass():
    rows=[{'SourceRecordId':i,'TestResult':'SOURCE_INPUT_PASS'} for i in range(1001)]
    r=predict(Goose(rows),ROOT,567,'TF_20')
    assert r['tests'][0]['state']=='INCOMPLETE_SAMPLE'

def test_simulated_has_no_live_proof():
    r=predict(None,ROOT,567,'TF_20',simulated=True)
    assert r['tests'][0]['state']=='SIMULATED_NOT_VERIFIED'

if __name__=='__main__':
    fs=[(n,f) for n,f in list(globals().items()) if n.startswith('test_') and callable(f)]
    for n,f in fs:
        f();print('ok ',n)
    print('Passed',len(fs),'Jira preflight offline tests')
