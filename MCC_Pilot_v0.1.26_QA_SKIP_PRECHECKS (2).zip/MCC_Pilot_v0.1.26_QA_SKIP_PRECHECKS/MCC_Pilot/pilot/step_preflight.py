"""Read-only, batch-scoped pre-step guards. Do not guess source table deletion keys.

Each rule is a SELECT returning issue rows. Custom rules are installed as .sql
files in preflight_rules/ and only executed if listed in preflight_rules.json.
The {{GOOSE_BATCH_ID}} token is an integer supplied by the runner.
"""
import csv
import json
import re
from datetime import datetime
from pathlib import Path

VALID_STEP = re.compile(r'^[A-Za-z0-9_.-]+$')
READONLY = re.compile(r'^\s*(?:--[^\n]*\n\s*)*SELECT\b', re.I)
BAD_SQL = re.compile(r'\b(INSERT|UPDATE|DELETE|MERGE|EXEC|EXECUTE|DROP|ALTER|TRUNCATE|CREATE|GRANT|REVOKE|INTO|OPENROWSET|OPENDATASOURCE)\b|;', re.I)


def scan(goose, root: Path, folder: Path, step_id: str, batch_id: int, mode: str):
    config_path = root / 'preflight_rules.json'
    rules = json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else {'rules': []}
    issues = []
    scans = []
    exclusions = []
    fixes = {}  # rule id -> (rule, [rows]) for action=fix
    applicable = [r for r in rules.get('rules', []) if '*' in r.get('steps', []) or step_id in r.get('steps', [])]
    if mode == 'simulate':
        return {'issues': [], 'scans': [{'rule': 'SIMULATE', 'rows': 0}], 'status': 'SIMULATED'}
    for rule in applicable:
        rid = rule['id']
        try:
            filename = rule['file']
            if Path(filename).name != filename or not filename.endswith('.sql'):
                raise ValueError('rule file must be a local .sql filename')
            sql = (root / 'preflight_rules' / filename).read_text(encoding='utf-8')
            if not READONLY.match(sql) or BAD_SQL.search(sql):
                raise ValueError('rule SQL is not a single read-only SELECT')
            if '{{GOOSE_BATCH_ID}}' not in sql:
                raise ValueError('rule is not explicitly scoped to Goose batch ID')
            sql = sql.replace('{{GOOSE_BATCH_ID}}', str(int(batch_id)))
            sets = goose.result_sets(sql)
            rows = [row for result in sets for row in result]
            if rid == 'goose_batch_identity':
                # This is an identity attestation, not an issues-only query:
                # zero rows means the batch disappeared, never "clear".
                if len(rows) != 1 or str(rows[0].get('SourceRecordId')) != str(int(batch_id)):
                    raise ValueError('Selected Goose batch missing or ambiguous')
                if str(rows[0].get('IsEligible', '')).lower() not in ('1', 'true'):
                    raise ValueError('Selected Goose batch is no longer open/eligible')
                scans.append({'rule': rid, 'rows': 1, 'severity': 'ok'})
                continue
            scans.append({'rule': rid, 'rows': len(rows), 'severity': rule.get('severity', 'warning')})
            for row in rows:
                issues.append({'step': step_id, 'rule': rid, 'severity': rule.get('severity', 'warning'),
                               'source_record_id': str(row.get('SourceRecordId') or row.get('ID') or ''),
                               'reason': str(row.get('Reason') or rule.get('description', rid)),
                               'action': 'REVIEW_ONLY', 'data': json.dumps(row, default=str)[:2000]})
                if (rule.get('action') == 'exclude' and rule.get('verified_nonblocking') is True
                        and mode == 'live' and rules.get('exclusion_mode') == 'enabled'):
                    exclusions.append((rule, row))
                if rule.get('action') == 'fix':
                    if mode == 'live' and rules.get('fix_mode') == 'enabled':
                        fixes.setdefault(rid, (rule, []))[1].append(row)
                    else:
                        issues[-1]['action'] = 'WOULD_FIX'
        except Exception as exc:
            scans.append({'rule': rid, 'error': str(exc)})
            issues.append({'step': step_id, 'rule': rid, 'severity': 'unproven',
                           'source_record_id': '', 'reason': 'Preflight failed: ' + str(exc),
                           'action': 'REVIEW_ONLY', 'data': ''})
    # Identity attestation must pass before *any* live exclusion write.
    # A failed identity scan must not be overridden by a later rule match.
    identity = [s for s in scans if s.get('rule') == 'goose_batch_identity']
    identity_ok = len(identity) == 1 and identity[0].get('severity') == 'ok'
    if fixes and not identity_ok:
        fixes = {}
        issues.append({'step': step_id, 'rule': 'goose_batch_identity', 'severity': 'unproven',
                       'source_record_id': '', 'reason': 'Automatic fixes withheld: batch identity not verified',
                       'action': 'REVIEW_ONLY', 'data': ''})
    for rid, (rule, rows) in fixes.items():
        from .goose_fixes import fix
        mine = [i for i in issues if i['rule'] == rid]
        try:
            result = fix(goose, folder / 'goose_fixes.jsonl', batch_id=batch_id, table=rule['fix_table'],
                         column=rule['fix_column'], value=rule['fix_value'],
                         ids=[r['SourceRecordId'] for r in rows], step=step_id,
                         max_records=int(rule.get('max_records', 500)))
        except Exception as exc:
            for i in mine:
                i['action'] = 'WRITE_OUTCOME_UNKNOWN'
            issues.append({'step': step_id, 'rule': rid, 'severity': 'unproven', 'source_record_id': '',
                           'reason': 'Fix failed: ' + str(exc)[:300], 'action': 'WRITE_OUTCOME_UNKNOWN', 'data': ''})
            continue
        fixed = {str(x) for x in result['fixed']}
        for i in mine:
            i['action'] = 'FIXED' if i['source_record_id'] in fixed else (
                'NOT_CHANGED_OR_UNVERIFIED' if result['status'] == 'NOT_CHANGED_OR_UNVERIFIED' else 'REVIEW_ONLY')
        if result['status'] in ('TOO_MANY', 'TYPE_MISMATCH'):
            # Nothing written: report it, the batch loads as staged and later steps catch it.
            issues.append({'step': step_id, 'rule': rid, 'severity': 'warning', 'source_record_id': '',
                           'reason': 'Fix not applied: ' + result['detail'], 'action': 'REVIEW_ONLY', 'data': ''})
        elif fixed:
            from .fixlog import write as write_fixlog, entry as fixlog_entry
            try:
                write_fixlog(goose, batch_id, [fixlog_entry(
                    'MCC_FIXED', step_id, rule['fix_table'], 'BATCH',
                    'MCC FIX before %s: %s; %s. IDs in goose_fixes.jsonl' % (
                        step_id, rule.get('description', rid), result['detail']))],
                    folder / 'goose_fixlog.jsonl')
            except Exception as log_exc:
                issues.append({'step': step_id, 'rule': rid, 'severity': 'warning', 'source_record_id': '',
                               'reason': 'Fixed and verified, but GOOSE_ErrorLog entry failed: ' + str(log_exc)[:200],
                               'action': 'LOG_FAILED', 'data': ''})
    if exclusions and not identity_ok:
        for issue in issues:
            if issue['action'] == 'REVIEW_ONLY':
                issue['action'] = 'WITHHELD_IDENTITY_UNVERIFIED'
        issues.append({'step': step_id, 'rule': 'goose_batch_identity',
                       'severity': 'unproven', 'source_record_id': '',
                       'reason': 'Automatic exclusions withheld: batch identity not verified',
                       'action': 'REVIEW_ONLY', 'data': ''})
        exclusions = []
    if exclusions:
        from .goose_exclusions import exclude
        for rule, row in exclusions:
            try:
                result = exclude(goose, folder / 'goose_exclusions.jsonl',
                                 batch_id=batch_id, stage_table=rule['stage_table'],
                                 record_id=int(row['SourceRecordId']),
                                 reason=str(row.get('Reason') or rule['id']), step=step_id)
                for issue in issues:
                    if issue['rule'] == rule['id'] and issue['source_record_id'] == str(row['SourceRecordId']):
                        issue['action'] = result['status']
                if result['status'] == 'EXCLUDED':
                    # Fix-and-log: the exclusion is identifiable in GOOSE_ErrorLog like every MCC fix.
                    # A logging failure must not be reported as an unknown exclusion write.
                    from .fixlog import write as write_fixlog, entry as fixlog_entry
                    try:
                        write_fixlog(goose, batch_id, [fixlog_entry(
                            'MCC_EXCLUDED', step_id, rule['stage_table'], row['SourceRecordId'],
                            'MCC EXCLUDED before %s: %s' % (step_id, str(row.get('Reason') or rule['id'])))],
                            folder / 'goose_fixlog.jsonl')
                    except Exception as log_exc:
                        issues.append({'step':step_id,'rule':rule['id'],'severity':'warning',
                            'source_record_id':str(row['SourceRecordId']),
                            'reason':'Excluded and verified, but GOOSE_ErrorLog entry failed: '+str(log_exc)[:200],
                            'action':'LOG_FAILED','data':''})
                if result['status'] != 'EXCLUDED':
                    issues.append({'step':step_id,'rule':rule['id'],'severity':'unproven',
                        'source_record_id':str(row['SourceRecordId']), 'reason':'Exclusion not verified',
                        'action':'NOT_CHANGED_OR_UNVERIFIED','data':''})
            except Exception as exc:
                issues.append({'step':step_id,'rule':rule['id'],'severity':'unproven',
                    'source_record_id':str(row.get('SourceRecordId','')),
                    'reason':'Exclusion failed: '+str(exc), 'action':'WRITE_OUTCOME_UNKNOWN','data':''})
    folder.mkdir(parents=True, exist_ok=True)
    outfile = folder / ('preflight_%s_%s.csv' % (step_id, datetime.now().strftime('%Y%m%d_%H%M%S_%f')))
    with outfile.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['step', 'rule', 'severity', 'source_record_id', 'reason', 'action', 'data'])
        writer.writeheader()
        writer.writerows(issues)
    return {'issues': issues, 'scans': scans, 'status': 'FINDINGS' if issues else 'CLEAR', 'file': str(outfile)}
