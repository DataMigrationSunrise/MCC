# v0.28.0 - the full self-test runs only when you choose

Run checks no longer repeats the whole self-test every time.

- **Run checks** now does the quick part only: registry, Salesforce / Goose / Informatica / Sunrise connections,
  the batch resolves to exactly one, and the rule-conflict registration. If Salesforce or the batch is wrong it still
  refuses to report.
- **Skipped on a run:** the field describes (stage 4) and the canary probes (stage 6), the slow part. A canary still
  runs on its own when a check finds nothing, so a zero is still not mistaken for "clean".
- **Self-test button** (More menu) runs everything, as before, and remembers the result. A run's self-test panel shows
  the last full self-test's schema and canary lines, labelled with when they were taken.
- Want the old behaviour on every run? Set "FullSelfTestOnRun": true in config.json.
