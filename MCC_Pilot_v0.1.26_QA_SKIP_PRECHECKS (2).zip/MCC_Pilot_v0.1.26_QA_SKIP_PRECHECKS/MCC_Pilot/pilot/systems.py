"""
Builds the connections for a run.

Real mode binds the live adapters. Simulate mode builds stand-ins that return the shapes the
real systems return (Apex debug lines, Goose result sets, taskflow status), so the whole
one-click flow can be shown and tested without touching QA. Simulated numbers are labelled
SIMULATED in every result.
"""
from __future__ import annotations

import random
import time
from types import SimpleNamespace

from . import adapters as ad


def build(cfg: dict, mode: str, say):
    if mode == "simulate":
        return _sim(say)
    sf = ad.Salesforce(cfg["OrgAlias"], cfg.get("AllowedOrgHosts") or [])
    goose = ad.Goose(cfg.get("SunriseAppDir", ""), cfg.get("GooseServer", ""), cfg.get("GooseDatabase", "Goose"))
    say("Goose: bound to Sunrise goose_live (%s/%s)" % (cfg.get("GooseServer"), cfg.get("GooseDatabase")))
    inf = None
    if mode == "live" and cfg.get("Informatica", {}).get("Mode") == "sunrise":
        state = {k: v for k, v in cfg.get("Informatica", {}).items() if k.startswith("Informatica")}
        inf = ad.Informatica(cfg.get("SunriseAppDir", ""), state)
        say("Informatica: " + inf.describe())
    sl = cfg.get("SnapLogic", {})
    snap = ad.SunriseSnapLogic(sl["SunriseAppDir"]) if mode == "live" and sl.get("Mode") == "sunrise" \
        else ad.SnapLogic(sl)
    return SimpleNamespace(sf=sf, goose=goose, inf=inf, snap=snap)


# ------------------------------------------------------------------ simulation
SIM_BATCH = dict(ID=999, BatchStatus="Open", IsTestBatch=0, SalesforceUssMigrationBatchID="aFOSIMULATED0001")

SIM_APEX = [
    ("TF_00.02", ["SIMULATED. In-window broken batch links: 0. Dead polygons: 0."]),
    ("TF_00.03", ["SIMULATED. ASYNC APEX FAILED/ABORTED in the last day: 0", "===== VERDICT =====",
                  "Step finished: no running or failed jobs."]),
    ("TF_02.01", ["SIMULATED. Quotes read: 917", "VERDICT: serviceable ZIP references present and consistent."]),
    ("MISSQ", ["SIMULATED. MISSQ untagged quotes: 0"]),
    ("TF_25.03", ["SIMULATED. Quote lines: 4,972", "VERDICT: every Quote Line resolves to an active PricebookEntry."]),
    ("TF_25.04", ["SIMULATED. Quotes read: 917", "Quotes with ZERO lines      : 0"]),
    ("TF_25.02", ["SIMULATED. Jobsites on batch quotes: 949", "Orders in batch: 0",
                  "  Not applicable yet -- TF_30 has not converted this batch. PART 1 is the gate at this point.",
                  "=== VERDICT ===",
                  "PASS -- all 949 jobsites have an address, coordinates, a Site Name and are Order Ready."]),
    ("TF_30.01", ["SIMULATED. Quotes read: 917", "NOT ORDERED (0)", "===== SUMMARY =====", "917 of 917 quotes ordered."]),
]


class _SimSF:
    def __init__(self):
        self.fixed = set()

    def verify_sandbox(self):
        return "SIMULATED sandbox"

    def query(self, soql):
        return [dict(Id="aFOSIMULATED0001AAA", Name="UMB-SIM", Batch_Status__c="Processing")]

    def run_apex(self, code):
        time.sleep(0.25)
        for key in ("SIMFIX:TF_15.01", "SIMFIX:TF_20.05"):
            if key in code:
                tag = key.split(":")[1]
                live = "LIVE" in code
                if live:
                    self.fixed.add(tag)
                    return _ok(["SIMULATED %s COMMITTED updated=5 lands_on_total=5 remaining=0" % tag])
                n = 0 if tag in self.fixed else 5
                return _ok(["SIMULATED %s ROLLED BACK (dry=true) needs_fix=%d" % (tag, n),
                            "%s already_ok=%d needs_fix=%d this_run=%d" % (tag, 912 if n else 917, n, n)])
        if "SIMCHECK" in code:
            return _ok(["SIMULATED check: 0 differences."])
        for key, lines in SIM_APEX:
            if key in code:
                return _ok(lines)
        return _ok(["SIMULATED: no findings."])


def _ok(lines):
    return dict(ok=True, error="", debug=lines, raw="\n".join(lines))


class _SimGoose:
    def result_sets(self, sql, timeout=600):
        time.sleep(0.2)
        if "FROM dbo.MigrationBatch" in sql:
            return [[SIM_BATCH]]
        if "Parent_Address_Update" in sql or "NF_Parent_USF_Address__c" in sql:
            return [[dict(rows_to_update=5, addresses_without_sf_id=0)],
                    [dict(run="CHECK", apex="// SIMFIX:TF_15.01 CHECK"),
                     dict(run="LIVE", apex="// SIMFIX:TF_15.01 LIVE")]]
        if "FIXBQ" in sql:
            return [[dict(chk="FIXBQ_SCOPE", components_under_multi_qty_parent=5)],
                    [dict(run_this_first="DRY", apex="// SIMFIX:TF_20.05 DRY"),
                     dict(run_this_first="LIVE", apex="// SIMFIX:TF_20.05 LIVE")]]
        if "AS apex" in sql:
            return [[dict(chk="SIMULATED", rows=0)], [dict(label="CHECK", apex="// SIMCHECK")]]
        return [[dict(simulated="row", value=0)]]


def _sim(say):
    say("SIMULATION: no system is contacted. Every result below is simulated.")

    def snap(step_id):
        time.sleep(0.6)
        return "DONE", "SIMULATED %s finished in %ds" % (step_id, random.randint(30, 300))

    def inf(step_id):
        time.sleep(0.8)
        return "DONE", "SIMULATED %s SUCCESS in %d min" % (step_id, random.randint(5, 30))

    return SimpleNamespace(sf=_SimSF(), goose=_SimGoose(), inf=None, snap=None,
                           snap_sim=snap, inf_sim=inf)
