import sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, fixlog
from pilot.link_existing import _journal

c = systems.build(app.CFG, 'dry', lambda m: None)
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
journal = folder / 'preflight' / 'link_existing.jsonl'
rows = [r for s in c.goose.result_sets(
    "SELECT Q.ID, A.Name FROM dbo.SFDC_Quote Q JOIN dbo.SFDC_Account A ON A.ID = Q.SFDC_AccountID_SBQQ__Account__c "
    "WHERE Q.MigrationBatchID = 468 AND ISNULL(Q.SalesforceQuoteID,'') = ''") for r in s if 'ID' in r]
print('unsynced quotes:', rows)
ids = [int(r['ID']) for r in rows]
if ids:
    _journal(journal, status='PULL_ATTEMPT', batch_id=468, quotes=ids, reason='rejected by Salesforce on every mct_09 pass')
    c.goose.result_sets("SET XACT_ABORT ON; BEGIN TRANSACTION; UPDATE dbo.SFDC_Quote SET MigrationBatchID = NULL "
                        "WHERE MigrationBatchID = 468 AND ID IN (%s) AND ISNULL(SalesforceQuoteID,'') = ''; "
                        "SELECT 1 AS Done; COMMIT TRANSACTION;" % ",".join(map(str, ids)))
    _journal(journal, status='PULLED', quotes=ids)
    fixlog.write(c.goose, 468, [fixlog.entry(
        'MCC_EXCLUDED', 'TF_15.L', 'SFDC_Quote', r['ID'],
        'MCC EXCLUDED quote from batch 468: %s rejected by Salesforce on every mct_09 pass (Warning); '
        'restore by setting MigrationBatchID = 468' % r['Name'], 'Quote') for r in rows],
        folder / 'preflight' / 'goose_fixlog.jsonl')
left = [r for s in c.goose.result_sets("SELECT COUNT(*) n FROM dbo.SFDC_Quote WHERE MigrationBatchID = 468 "
                                       "AND ISNULL(SalesforceQuoteID,'') = ''") for r in s]
print('still unsynced after pull:', left)
