import sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, link_existing as le

c = systems.build(app.CFG, 'dry', lambda m: None)
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
r = le.link(c.goose, c.sf, 468, folder, 'TF_15.L', apply=True)
print(r)
print([x for s in c.goose.result_sets("SELECT COUNT(*) n FROM dbo.vw_SFDC_OpenBatch_Quote "
                                      "WHERE ISNULL(SalesforceQuoteID,'')=''") for x in s])
