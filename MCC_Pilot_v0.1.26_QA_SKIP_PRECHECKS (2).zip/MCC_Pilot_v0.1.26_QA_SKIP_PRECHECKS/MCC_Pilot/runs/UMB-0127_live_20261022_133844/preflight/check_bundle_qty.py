"""Read-only: bundle quantity of the 62 stuck orders vs the batch's successful orders."""
import json, sys, statistics as st
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

B = 'aFOVD0000001Swj4AE'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = {o['id'][:15] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']}
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
rows = sf.query("SELECT Id, AccountId, SBQQ__Quote__r.Total_bundle_quantity_count__c FROM Order "
                "WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)
acct_orders = {}
for r in rows:
    acct_orders[r['AccountId']] = acct_orders.get(r['AccountId'], 0) + 1


def stats(label, vals):
    vals = sorted(v for v in vals if v is not None)
    if not vals:
        print(label, 'no values'); return
    print('%-28s n=%-4d min=%-6s median=%-6s p90=%-6s max=%s' % (
        label, len(vals), vals[0], st.median(vals), vals[int(len(vals) * 0.9) - 1], vals[-1]))


bq = lambda r: (r.get('SBQQ__Quote__r') or {}).get('Total_bundle_quantity_count__c')
s_rows = [r for r in rows if r['Id'][:15] in stuck]
ok_rows = [r for r in rows if r['Id'][:15] not in stuck]
stats('bundle qty - stuck', [bq(r) for r in s_rows])
stats('bundle qty - succeeded', [bq(r) for r in ok_rows])
stats('orders on account - stuck', [acct_orders[r['AccountId']] for r in s_rows])
stats('orders on account - succeeded', [acct_orders[r['AccountId']] for r in ok_rows])
try:
    print('safeguard threshold Appointment_Settings__c.Total_Bundle_Quantity_Count__c:',
          sf.query("SELECT Total_Bundle_Quantity_Count__c FROM Appointment_Settings__c LIMIT 1"))
except Exception as e:
    print('threshold not readable:', str(e)[:150])
