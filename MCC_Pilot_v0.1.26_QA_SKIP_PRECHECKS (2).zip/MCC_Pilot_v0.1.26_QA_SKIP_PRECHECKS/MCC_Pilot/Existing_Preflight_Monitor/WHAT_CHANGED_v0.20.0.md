# v0.20.0 - one meaning per word

Four different things shared the words "error" and "blocked". A run could read "10,039 errors"
when 7,910 of them were one check on staging data, and a step called BLOCKED might have nothing
wrong with it at all. Each word now means one thing (the in-app glossary, "What these words
mean", under the run book table, is the same text as `terms.py`).

| Question | Words |
|---|---|
| What did a check find? | **Clear** / **Issue** / **Unproven** (not a pass) |
| How much does an issue matter? | **Blocker** (going on would be wrong or harmful) / **Review** (a person decides; was "warning" / "exception") / **Note** |
| Can I pass this run book step? | **Ready** / **Review** / **Blocked** (its own blocker) / **Held** (nothing wrong here, a blocker elsewhere) / **Unproven** |
| Did the tool or a job fail? | **Error** - and only that |

## Behaviour changes (not just labels)
- A failing **review-level** check no longer marks its step BLOCKED. It marks it REVIEW.
  Expect some steps that were BLOCKED to read REVIEW now. That is the point.
- A step that is only downstream of a blocker is **HELD**, with "fix elsewhere" under it, and the
  blocker it is held by is named in the last column. Fix that step, not this one.
- BLOCKED / HELD steps that have already run say **job already ran**: it is a finding about work
  that happened, not a gate in front of work that has not.
- "Records held by blockers" no longer includes review-level records.
- "Stopped at RO n" replaces "earliest blocker RO n" (the step may be held, not the blocker).
- A count of wrong records is **failing**, never "errors". Run list, object band, issues pills,
  Excel sheets and banners all follow. Last column header: "Next Action / What's in the way".
- Excel: sheet "Blocked Records" is now "Records Needing a Fix"; HELD and REVIEW get their own colours.

## Not changed on purpose
Stored values (`FAIL`, `WARNING`, `BLOCKER`) are unchanged, so history from earlier versions
opens and means what it did. Only the words shown differ. `object state ERROR` (a query that
failed) is kept: that is a genuine tool error.

## Not verified
I have only seen these screens through the offline tests (477 checks), not in your browser or
in Excel. Open a run, check the table's Status column and the "What these words mean" panel.
