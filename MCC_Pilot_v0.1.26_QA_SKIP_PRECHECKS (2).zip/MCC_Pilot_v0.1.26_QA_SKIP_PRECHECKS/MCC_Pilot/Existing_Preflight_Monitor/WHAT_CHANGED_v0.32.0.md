# v0.32.0 - audit of every check: stop reporting things that are not true

Four independent read-throughs of all the checks, each finding checked against the code before changing anything.

**Fixed (these gave a wrong answer):**
- Maintenance Plans with no Work Orders: a plan counts as covered when ANY Work Order names it. The "marked generated"
  condition hid services that exist (UMB-0117 spot checks). If every plan fails (20 or more) the check is UNPROVEN,
  since that points at the rule, not the data. Active__c is now a declared field.
- Orders missing Work Orders: judged by the Order link, not through the Contract (WOs with no Contract link made their
  Orders look empty), and only Activated Orders (a draft Order has none by design).
- RO 33 Work Order Line Items: falls back to the parent line only when the Subscription field is missing, says so in
  the note, and any other error is UNPROVEN; a group where one line lacks a subscription is still judged per
  subscription; the pass ratio no longer counts unjudgeable groups as passes.
- Orders with more deliveries than bundles: counted in Orders (it mixed Orders and Work Orders), Canceled deliveries
  not counted, wording fixed.
- Errors logged during Work Order generation: informational rows of the same family are not counted as errors.
- Monthly LastBillingDate rule: nothing to compare is UNPROVEN, not PASS.
- Serviceable ZIP: 12345-6789 and 12345 are the same ZIP.
- Biq parity text follows the sign of the difference; Goose error log says when resolved errors are included.
- Load-failure prediction: one reason on every staged row is treated as a mapping question (UNPROVEN) like many reasons already was.
- Customer-owned flag: needs at least one staging table read, otherwise UNPROVEN.
- Duplicate Contracts metric is labelled for what it counts.
- RO 2 "WorkOrders with no Contract link" and "Activated Contracts belonging to no batch" are notes: ordinary daytime
  records, no longer BLOCKED/HELD/failing records. Jobsite "Order Ready" is REVIEW, not a blocker (open business question).

**Not changed - reported, needs a business or data decision:** see the reply.
