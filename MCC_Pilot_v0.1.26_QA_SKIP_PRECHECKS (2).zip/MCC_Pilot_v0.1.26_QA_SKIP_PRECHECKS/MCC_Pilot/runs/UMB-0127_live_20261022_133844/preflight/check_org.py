"""Read-only: which org the pilot alias hits and whether batch UMB-0127 is visible."""
import sys
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems

c = systems.build(app.CFG, 'dry', lambda m: None)
print('alias:', c.sf.alias)
print(c.sf.verify_sandbox())
for q in ["SELECT COUNT() FROM USS_Migration_Batch__c WHERE Id = 'aFOVD0000001Swj4AE'",
          "SELECT COUNT() FROM SBQQ__Quote__c WHERE USS_Migration_Batch__c = 'aFOVD0000001Swj4AE'",
          "SELECT COUNT() FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = 'aFOVD0000001Swj4AE'",
          "SELECT COUNT() FROM WorkOrder WHERE Order__r.SBQQ__Quote__r.USS_Migration_Batch__c = 'aFOVD0000001Swj4AE'"]:
    try:
        from pilot.adapters import _sf_json
        import tempfile, pathlib
        with tempfile.TemporaryDirectory() as td:
            f = pathlib.Path(td) / 'q.soql'; f.write_text(q, encoding='utf-8')
            print(q[21:70], '->', _sf_json(['data', 'query', '--file', str(f), '--target-org', c.sf.alias], 180).get('totalSize'))
    except Exception as e:
        print(q[21:70], '-> ERROR', str(e)[:200])
