"""Midflight fill of fields Goose has but the load never maps (Field_Gap_Analysis.md).

Runs right after the step that creates the records. For each field: read the Goose value by the
Salesforce Id Goose stores, and fill only Salesforce records where the field is blank. Never
overwrites. On unique fields, a value shared by more than one record (in Goose, or already held by
another Salesforce record) is skipped and logged instead of filled. A rerun finds nothing to do.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import fixlog

CHUNK = 100  # records per Apex run: record triggers fire on update


def _s(v) -> str:
    return "'" + str(v).replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "") + "'"


def _blank(v) -> bool:
    return v is None or str(v).strip() == ""


def plan(goose, sf, batch_id: int, spec: dict) -> dict:
    """What would be filled for one field. Read-only."""
    gt, sid, gcol, obj, fld = spec["goose_table"], spec["goose_sf_id"], spec["goose_field"], spec["sobject"], spec["field"]
    rows = [r for g in goose.result_sets(
        "SELECT %s AS SFID, %s AS VAL FROM dbo.%s WHERE MigrationBatchID = %d AND NULLIF(%s, '') IS NOT NULL "
        "AND NULLIF(LTRIM(RTRIM(CAST(%s AS nvarchar(4000)))), '') IS NOT NULL"
        % (sid, gcol, gt, int(batch_id), sid, gcol)) for r in g]
    goose_vals = {str(r["SFID"]): str(r["VAL"]).strip() for r in rows}
    skipped = {}
    if spec.get("unique"):
        owners = {}
        for i, v in goose_vals.items():
            owners.setdefault(v, set()).add(i)
        for v, ids in owners.items():
            if len(ids) > 1:
                for i in ids:
                    skipped[i] = "value %s is on %d records in Goose; %s is unique" % (v, len(ids), fld)
    current = {}
    ids = sorted(goose_vals)
    for k in range(0, len(ids), 200):
        part = ids[k:k + 200]
        for r in sf.query("SELECT Id, %s FROM %s WHERE Id IN (%s)" % (fld, obj, ",".join("'%s'" % i for i in part))):
            current[r["Id"][:15]] = r.get(fld)
    todo = {i: v for i, v in goose_vals.items() if i not in skipped and i[:15] in current and _blank(current[i[:15]])}
    missing = [i for i in goose_vals if i[:15] not in current]
    if spec.get("unique") and todo:
        vals = sorted(set(todo.values()))
        taken = {}
        for k in range(0, len(vals), 100):
            in_list = ",".join("'%s'" % v.replace("\\", "\\\\").replace("'", "\\'") for v in vals[k:k + 100])
            for r in sf.query("SELECT Id, %s FROM %s WHERE %s IN (%s)" % (fld, obj, fld, in_list)):
                taken[str(r.get(fld))] = r["Id"]
        for i, v in list(todo.items()):
            if v in taken and taken[v][:15] != i[:15]:
                skipped[i] = "value %s already on Salesforce record %s; %s is unique" % (v, taken[v], fld)
                del todo[i]
    return dict(field="%s.%s" % (obj, fld), goose=len(goose_vals), todo=todo, skipped=skipped, not_in_salesforce=missing)


def apply(sf, spec: dict, todo: dict) -> tuple[list, dict]:
    """Fill blanks only. Returns (filled ids, {id: error})."""
    obj, fld = spec["sobject"], spec["field"]
    filled, errors, items = [], {}, sorted(todo.items())
    for k in range(0, len(items), CHUNK):
        part = items[k:k + CHUNK]
        code = ("List<%s> recs = new List<%s>();\n" % (obj, obj) +
                "".join("recs.add(new %s(Id = '%s', %s = %s));\n" % (obj, i, fld, _s(v)) for i, v in part) +
                # Re-check blank inside the transaction so a value set since planning is never overwritten.
                "Map<Id, %s> now = new Map<Id, %s>([SELECT Id, %s FROM %s WHERE Id IN :recs]);\n" % (obj, obj, fld, obj) +
                "List<%s> go = new List<%s>();\n" % (obj, obj) +
                "for (%s r : recs) if (now.containsKey(r.Id) && String.isBlank(String.valueOf(now.get(r.Id).%s))) go.add(r);\n" % (obj, fld) +
                "Database.SaveResult[] res = Database.update(go, false);\n"
                "for (Integer i = 0; i < res.size(); i++) System.debug(LoggingLevel.ERROR, 'MCCFILL ' + go[i].Id + ' ' + "
                "(res[i].isSuccess() ? 'OK' : 'ERR ' + res[i].getErrors()[0].getMessage()));\n")
        res = sf.run_apex(code)
        if not res.get("ok"):
            for i, _ in part:
                errors[i] = "Apex did not run: %s" % (res.get("error") or "")[:200]
            continue
        for line in res.get("debug") or []:
            if "MCCFILL " not in line:
                continue
            parts = line[line.find("MCCFILL ") + 8:].split(" ", 2)
            rid = next((i for i, _ in part if i[:15] == parts[0][:15]), parts[0])
            if parts[1] == "OK":
                filled.append(rid)
            else:
                errors[rid] = parts[2] if len(parts) > 2 else "update failed"
    return filled, errors


def run(goose, sf, batch_id: int, step: str, specs: list, mode: str, folder: Path, say=print) -> tuple[str, str]:
    notes, total_fill, total_skip, entries = [], 0, 0, []
    for spec in specs:
        if spec.get("enabled") is False:
            notes.append("%s.%s not filled: %s" % (spec["sobject"], spec["field"], spec.get("reason", "disabled")))
            continue
        p = plan(goose, sf, batch_id, spec)
        skip = dict(p["skipped"])
        if mode != "live" or not p["todo"]:
            notes.append("%s: %d %s, %d skipped" % (p["field"], len(p["todo"]),
                                                   "to fill" if mode != "live" else "filled", len(skip)))
            total_fill += len(p["todo"]) if mode != "live" else 0
        else:
            filled, errors = apply(sf, spec, p["todo"])
            skip.update(errors)
            total_fill += len(filled)
            notes.append("%s: %d filled, %d skipped" % (p["field"], len(filled), len(skip)))
            if filled:
                entries.append(fixlog.entry("MCC_FIXED", step, spec["sobject"], "BATCH",
                    "MCC FIX %s: filled blank %s from Goose %s.%s on %d record(s)"
                    % (step, p["field"], spec["goose_table"], spec["goose_field"], len(filled)), spec["sobject"]))
        total_skip += len(skip)
        if mode == "live":
            entries += [fixlog.entry("MCC_PUSHED_THROUGH", step, spec["sobject"], i,
                                     "MCC %s: %s left blank: %s" % (step, p["field"], why), spec["sobject"])
                        for i, why in skip.items()]
        folder.mkdir(parents=True, exist_ok=True)
        with (folder / ("%s_field_fill.jsonl" % step)).open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(field=p["field"], mode=mode, goose=p["goose"], todo=len(p["todo"]),
                                    skipped=skip, not_in_salesforce=p["not_in_salesforce"][:50])) + "\n")
    if entries:
        try:
            fixlog.write(goose, batch_id, entries, folder / "goose_fixlog.jsonl")
        except Exception as e:  # noqa: BLE001
            say("      WARNING: fields filled but GOOSE_ErrorLog entry failed: %s" % str(e)[:200])
    detail = "; ".join(notes)
    if mode != "live":
        return ("WOULD_FIX" if total_fill else "PASS"), detail
    if total_skip:
        return "WARNING", detail
    return ("FIXED" if total_fill else "PASS"), detail or "Nothing to fill."
