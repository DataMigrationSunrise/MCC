"""
VERIFY AGAINST SALESFORCE.

A check can be confidently wrong in ways no verdict shows: it counted the whole org instead of
the batch, it hit its own LIMIT and under-counted, it named a field that is not in the org,
or it listed Ids that Salesforce does not have. None of those look different from a good result.

This module runs AFTER the checks and looks at what each one actually did. It never changes a
verdict and never writes to Salesforce -- it adds a second opinion beside each result:

  VERIFIED   a failing check's sample records were re-read from Salesforce and exist, and
             nothing below applies
  SUSPECT    something below applies; the number may not mean what it says
  --         nothing to verify (passed, unproven, or no record Ids to look up)

Flags (code -> meaning):
  ORG_WIDE        none of the check's queries was tied to this batch
  TRUNCATED       a query returned exactly its LIMIT, so the real count may be higher
  DUPLICATE_IDS   the same record is counted more than once
  OVER_EXAMINED   more records failing than were examined -- impossible
  SAMPLE_MISSING  sample Ids are not in Salesforce (deleted, or from another org)
  FIELD_MISSING   a field the check's code names is not in this org at all
  FIELD_HIDDEN    the field is deployed but this user cannot see it (reads as empty)
  QUERY_FAILED    a query the check sent errored (the check may still have returned a verdict)
"""
from __future__ import annotations
import inspect, re

from model import FAIL, PASS, UNPROVEN

SUSPECT_CODES = {"ORG_WIDE", "TRUNCATED", "DUPLICATE_IDS", "OVER_EXAMINED", "SAMPLE_MISSING",
                 "FIELD_MISSING", "FIELD_HIDDEN"}
LABEL = {
    "ORG_WIDE": "Not tied to this batch",
    "TRUNCATED": "Hit its query limit -- real count may be higher",
    "DUPLICATE_IDS": "Same record counted more than once",
    "OVER_EXAMINED": "More failing than examined (impossible)",
    "SAMPLE_MISSING": "Sample records not found in Salesforce",
    "FIELD_MISSING": "Names a field that is not in this org",
    "FIELD_HIDDEN": "Field exists but this user cannot see it",
    "QUERY_FAILED": "A query errored",
}
_ID15 = re.compile(r"^[a-zA-Z0-9]{15}([a-zA-Z0-9]{3})?$")
_FIELD = re.compile(r"\b([A-Za-z][A-Za-z0-9_]*__c)\b")
_FROM = re.compile(r"\bFROM\s+([A-Za-z][A-Za-z0-9_]*)", re.I)
_LIMIT = re.compile(r"\bLIMIT\s+(\d+)", re.I)
SAMPLE_N = 5


def _flag(code, text=""):
    return dict(code=code, text=text or LABEL[code])


def record_ids(rows):
    """The Salesforce Ids in a check's evidence rows, in order, if it has any."""
    out = []
    for r in rows or []:
        for k, v in r.items():
            if str(k).lower() in ("id", "recordid", "sfid") and _ID15.match(str(v or "")):
                out.append(str(v)); break
    return out


def _scope_and_limits(entries):
    flags = []
    if not entries:
        return "", flags
    if all(e.get("error") for e in entries):
        flags.append(_flag("QUERY_FAILED", "Every query this check sent failed: %s"
                           % entries[0]["error"][:160]))
    soql = [e for e in entries if e["kind"] in ("soql", "count", "goose", "goose-count")]
    scope = "BATCH" if any(e["scoped"] for e in soql) else ("ORG-WIDE" if soql else "")
    for e in entries:
        m = _LIMIT.search(e["sql"])
        if m and e["kind"] in ("soql", "goose") and e["rows"] is not None and e["rows"] >= int(m.group(1)):
            flags.append(_flag("TRUNCATED", "A query returned exactly its LIMIT of %s rows, so "
                               "records past that were never seen: %s" % (m.group(1), e["sql"][:140])))
            break
    return scope, flags


def _objects_for(conn, ids, default):
    """{id: sobject} by key prefix, so an Order Id is looked up on Order, not on the check's object."""
    prefixes = sorted({i[:3] for i in ids})
    names = {}
    try:
        for r in conn.tq("SELECT KeyPrefix, QualifiedApiName FROM EntityDefinition WHERE KeyPrefix IN (%s)"
                         % ",".join("'%s'" % p for p in prefixes)):
            names[str(r.get("KeyPrefix") or "")] = str(r.get("QualifiedApiName") or "")
    except Exception:                                        # noqa: BLE001
        pass
    return {i: (names.get(i[:3]) or default) for i in ids}


def confirm_sample(conn, sobject, ids, n=SAMPLE_N):
    """Re-read up to n of the Ids from Salesforce. -> (found, missing, error)."""
    sample = list(dict.fromkeys(ids))[:n]
    if not sample:
        return [], [], ""
    objs = _objects_for(conn, sample, sobject)
    if not all(objs.values()):
        return [], [], "could not tell which object these Ids belong to"
    have, err = set(), ""
    for obj in sorted(set(objs.values())):
        mine = [i for i in sample if objs[i] == obj]
        try:
            rows = conn.q("SELECT Id FROM %s WHERE Id IN (%s)"
                          % (obj, ",".join("'%s'" % i for i in mine)))
            have |= {str(r.get("Id") or "")[:15] for r in rows}
        except Exception as e:                               # noqa: BLE001
            err = "%s: %s" % (obj, str(e)[:160])
    if err:
        return [], [], err
    return ([i for i in sample if i[:15] in have], [i for i in sample if i[:15] not in have], "")


# ---------------------------------------------------------------- schema audit
def _source(fn):
    try:
        return inspect.getsource(fn)
    except Exception:                                        # noqa: BLE001
        return ""


_NOT_SF = {"Goose", "INFORMATION_SCHEMA", "dbo", "GOOSE_ErrorLog"}


def _is_sf_object(name):
    """'FROM the ...' in a docstring, or a Goose table, is not a Salesforce object."""
    return bool(name) and name[0].isupper() and name not in _NOT_SF and len(name) > 3


def check_tokens(chk):
    """Custom-field names the check's own code mentions (best effort -- from its source)."""
    src = _source(chk.run) + "\n" + (_source(chk.canary) if chk.canary else "")
    toks = {t for t in _FIELD.findall(src)}
    objs = {o for o in _FROM.findall(src) if _is_sf_object(o)} | ({chk.sobject} if chk.sobject else set())
    return toks, objs


def schema_audit(conn, checks):
    """
    -> {check_id: [flag, ...]}. A field named in a check's code must exist in the org.

    A field the org lacks makes a query fail or, worse, makes a safe-looking check read an
    empty column as clean. Objects searched are every object any check queries, because a
    relationship field (Order__r.Foo__c) lives on a different object than the check's own.
    """
    per = {c.id: check_tokens(c) for c in checks}
    objects = sorted({o for _, os_ in per.values() for o in os_})
    def _desc(o):
        try:
            return {f.lower() for f in conn.fields(o)}
        except Exception:                                    # noqa: BLE001
            return None                                      # could not describe: no verdict
    try:
        import connections as _cx
        got = _cx.parallel(_desc, objects, max(1, int(getattr(conn, "workers", 1) or 1)))
        visible = {o: (None if isinstance(g, Exception) else g) for o, g in zip(objects, got)}
    except Exception:                                        # noqa: BLE001
        visible = {o: _desc(o) for o in objects}
    describable = [o for o in objects if visible[o] is not None]
    everywhere = set().union(*[visible[o] for o in describable]) if describable else set()
    objset = {o.lower() for o in objects}

    unseen = sorted({t for toks, _ in per.values() for t in toks
                     if t.lower() not in everywhere and t.lower() not in objset})
    deployed = {}                                            # token.lower() -> where
    tooling_ok = True
    for i in range(0, len(unseen), 40):
        chunk = unseen[i:i + 40]
        names = []
        for t in chunk:
            parts = t[:-3].split("__")
            names.append(parts[-1])
        lit = ",".join("'%s'" % n.replace("'", "") for n in sorted(set(names)))
        try:
            for r in conn.tq("SELECT DeveloperName, NamespacePrefix, TableEnumOrId FROM CustomField "
                             "WHERE DeveloperName IN (%s)" % lit):
                ns = str(r.get("NamespacePrefix") or "")
                tok = ("%s__%s__c" % (ns, r.get("DeveloperName")) if ns
                       else "%s__c" % r.get("DeveloperName")).lower()
                deployed[tok] = str(r.get("TableEnumOrId") or "")
        except Exception:                                    # noqa: BLE001
            tooling_ok = False
    out = {}
    for cid, (toks, _) in per.items():
        flags = []
        for t in sorted(toks):
            k = t.lower()
            if k in everywhere or k in objset:
                continue
            if k in deployed:
                flags.append(_flag("FIELD_HIDDEN", "%s is deployed (on %s) but not visible to this "
                                   "user, so queries on it read as empty. Grant read access."
                                   % (t, deployed[k])))
            elif tooling_ok and describable:
                flags.append(_flag("FIELD_MISSING", "%s is named in this check's code but was not "
                                   "found on any object the tool queries, or in the org's custom "
                                   "fields. The check may be reading a field that does not exist." % t))
        if flags:
            out[cid] = flags
    return out


# ---------------------------------------------------------------- per-run verification
def verify_run(conn, checks, results, evidence_of=None, sample_n=SAMPLE_N):
    """
    -> {check_id: dict(status, scope, flags, samples, queries)}.
    evidence_of(check_id) -> the retained evidence rows (so the whole list is checked for
    duplicates, not only what fits in memory on the Result).
    """
    by_id = {c.id: c for c in checks}
    try:
        schema = schema_audit(conn, checks)
    except Exception as e:                                   # noqa: BLE001
        schema = {}
        schema_err = str(e)[:200]
    else:
        schema_err = ""
    out = {}
    for r in results:
        chk = by_id.get(r.check_id)
        entries = (getattr(conn, "audit_log", {}) or {}).get(r.check_id, [])
        scope, flags = _scope_and_limits(entries)
        flags += schema.get(r.check_id, [])
        rows = list(r.evidence_sample or [])
        if evidence_of is not None and not rows:
            try:
                rows = evidence_of(r.check_id) or []
            except Exception:                                # noqa: BLE001
                rows = []
        ids = record_ids(rows)
        samples = []
        if r.verdict == FAIL:
            if scope == "ORG-WIDE":
                flags.append(_flag("ORG_WIDE", "None of this check's %d queries mentioned the batch, "
                                   "so its count covers more than UMB records. It can inflate the "
                                   "headline or block a step for work that is not this batch's."
                                   % len(entries)))
            if ids:
                if len(set(ids)) < len(ids):
                    flags.append(_flag("DUPLICATE_IDS", "%d rows but only %d distinct records"
                                       % (len(ids), len(set(ids)))))
                found, missing, err = confirm_sample(conn, chk.sobject if chk else "", ids, sample_n)
                samples = [dict(id=i, found=True) for i in found] + [dict(id=i, found=False) for i in missing]
                if missing:
                    flags.append(_flag("SAMPLE_MISSING", "%d of %d sampled Ids were not found in "
                                       "Salesforce (%s)" % (len(missing), len(found) + len(missing),
                                                            ", ".join(missing[:3]))))
                if err:
                    flags.append(_flag("QUERY_FAILED", "Could not re-read the sample: " + err))
            if r.processed and r.evidence_count > r.processed:
                flags.append(_flag("OVER_EXAMINED", "%s failing but only %s examined"
                                   % ("{:,}".format(r.evidence_count), "{:,}".format(r.processed))))
        if r.verdict == PASS and schema.get(r.check_id):
            pass                                             # already flagged: a pass on a missing field
        suspect = [f for f in flags if f["code"] in SUSPECT_CODES]
        if suspect:
            status = "SUSPECT"
        elif r.verdict == FAIL and samples and all(s["found"] for s in samples):
            status = "VERIFIED"
        else:
            status = ""
        out[r.check_id] = dict(status=status, scope=scope, flags=flags, samples=samples,
                               queries=entries, schema_error=schema_err)
    return out
