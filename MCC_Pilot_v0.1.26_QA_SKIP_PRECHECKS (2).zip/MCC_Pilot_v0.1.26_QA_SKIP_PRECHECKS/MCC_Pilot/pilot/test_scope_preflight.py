"""Offline tests for the pre-cut (transformation-scoped) preflight. Run: python -m pilot.test_scope_preflight"""
import json
import tempfile
from pathlib import Path

from . import scope_preflight as sp


class FakeGoose:
    def __init__(self, batch=None):
        self.sql, self.flags, self.batch = [], [], batch

    def result_sets(self, sql, timeout=600, read_only=False):
        self.sql.append(sql)
        self.flags.append(read_only)
        if "FROM dbo.TRFM_Transformation T" in sql:
            return [[{"ID": 549, "Phase": 2, "GoForLaunch": 1, "MigrationBatchID": self.batch, "BatchStatus": None}]]
        if "STG_CustomerContact CC" in sql:
            return [[{"SourceRecordId": 1, "Reason": "no last name", "ExclusionReason": "", "Phase": None},
                     {"SourceRecordId": 2, "Reason": "no last name", "ExclusionReason": "Omit - Out of Phase", "Phase": 3}]]
        if "boom" in sql:
            raise RuntimeError("timeout")
        if "COUNT(*) AS N" in sql:
            return [[{"Phase": 2, "Reason": "", "N": 10}, {"Phase": 3, "Reason": "Order out of phase", "N": 5}]]
        return [[]]


def _root(rules, files):
    root = Path(tempfile.mkdtemp())
    (root / "preflight_rules").mkdir()
    (root / "preflight_rules.json").write_text(json.dumps({"rules": rules}), encoding="utf-8")
    for name, text in files.items():
        (root / "preflight_rules" / name).write_text(text, encoding="utf-8")
    return root


def test_token_scoped_and_read_only():
    root = _root([{"id": "goose_batch_identity", "file": "x.sql"},
                  {"id": "lastname", "file": "a.sql", "transformation_file": "a_trfm.sql", "stage_table": "STG_CustomerContact"}],
                 {"a_trfm.sql": "SELECT CC.ID FROM dbo.STG_CustomerContact CC WHERE CC.TransformationID = {{TRANSFORMATION_ID}}"})
    g = FakeGoose()
    r = sp.run(g, root, 549, out_root=root / "out", say=lambda m: None)
    assert any("TransformationID = 549" in s for s in g.sql) and not any("{{" in s for s in g.sql)
    assert all(g.flags), "every query must open Goose read-only"
    assert r["exceptions"] == 2
    assert {n["detail"] for n in r["notes"] if n["rule"] == "goose_batch_identity"} == {"no batch attached yet (pre-cut)"}
    text = (Path(r["folder"]) / "exceptions.csv").read_text(encoding="utf-8")
    assert "in-scope" in text and "out-of-scope phase 3" in text


def test_writes_refused_needs_batch_skipped_and_failures_isolated():
    root = _root([{"id": "writer", "file": "w.sql", "transformation_file": "w.sql"},
                  {"id": "batch_only", "file": "b.sql"},
                  {"id": "slow", "file": "s.sql", "transformation_file": "s.sql"},
                  {"id": "lastname", "file": "a.sql", "transformation_file": "a.sql"}],
                 {"w.sql": "UPDATE dbo.STG_Order SET Phase = 1 WHERE TransformationID = {{TRANSFORMATION_ID}}",
                  "s.sql": "SELECT boom FROM dbo.STG_Order WHERE TransformationID = {{TRANSFORMATION_ID}}",
                  "a.sql": "SELECT CC.ID FROM dbo.STG_CustomerContact CC WHERE CC.TransformationID = {{TRANSFORMATION_ID}}"})
    g = FakeGoose(batch=469)
    r = sp.run(g, root, 549, out_root=root / "out", say=lambda m: None)
    status = {n["rule"]: n["status"] for n in r["notes"]}
    assert status == {"goose_batch_identity": "INFO", "writer": "DID_NOT_RUN", "batch_only": "NEEDS_BATCH",
                      "slow": "DID_NOT_RUN", "lastname": "CHECKED"}
    assert not any(s.lstrip().upper().startswith("UPDATE") for s in g.sql), "a write must never reach Goose"


def test_bucket():
    assert sp.bucket("", 2) == "in-scope"
    assert sp.bucket("Order out of phase", 4) == "out-of-scope phase 4"
    assert sp.bucket("Data appears in fallout", 2) == "excluded: Data appears in fallout"


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f()
            print("ok ", n)
