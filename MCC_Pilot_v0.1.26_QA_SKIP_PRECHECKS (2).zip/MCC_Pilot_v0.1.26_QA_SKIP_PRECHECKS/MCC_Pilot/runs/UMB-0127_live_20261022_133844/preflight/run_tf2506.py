"""Run MCC check TF_25.06 (read-only CHKALL compare) on its own, with MCC's step code."""
import sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems
from pilot.engine import Run
from pilot.pipeline import STEPS

c = systems.build(app.CFG, 'dry', lambda m: None)
r = Run(app.CFG, 'live', systems.build)
r.folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844\standalone_TF_25.06')
r.folder.mkdir(exist_ok=True)
r.batch = dict(name='UMB-0127', goose_id=468, sf_id='aFOVD0000001Swj4AE')
r.say = print
print(r._k_goose_gen_check(c, next(s for s in STEPS if s['id'] == 'TF_25.06')))
