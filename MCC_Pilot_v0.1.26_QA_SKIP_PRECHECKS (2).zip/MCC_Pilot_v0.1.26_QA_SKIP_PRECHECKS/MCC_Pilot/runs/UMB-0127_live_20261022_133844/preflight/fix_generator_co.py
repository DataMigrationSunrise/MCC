"""Set CustomerOwned__c = false on the generator-rental Power Bundle lines of the stuck UMB-0127 orders.
All-or-nothing: expects exactly 295 lines; any count mismatch or failed update changes nothing. Logged to GOOSE_ErrorLog."""
import json, re, sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, fixlog

folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = [o['id'] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']]
c = systems.build(app.CFG, 'dry', print)
names = ['Power Bundle', 'GENERATOR RENTAL', 'Delivery Power - Standard', 'Pickup Power - Standard', 'No Service']
apex = """
Set<Id> orderIds = new Set<Id>{%s};
Set<String> names = new Set<String>{%s};
List<OrderItem> lines = [SELECT Id, OrderId FROM OrderItem WHERE OrderId IN :orderIds AND CustomerOwned__c = true
                         AND Product2.Name IN :names];
Integer EXPECTED = 295;
System.debug(LoggingLevel.ERROR, 'MCCFIX found=' + lines.size() + ' expected=' + EXPECTED);
if (lines.size() != EXPECTED) { System.debug(LoggingLevel.ERROR, 'MCCFIX ABORT count mismatch, nothing changed'); return; }
Savepoint sp = Database.setSavepoint();
for (OrderItem l : lines) l.CustomerOwned__c = false;
Integer bad = 0;
for (Database.SaveResult r : Database.update(lines, false)) if (!r.isSuccess()) { bad++; if (bad <= 5) System.debug(LoggingLevel.ERROR, 'MCCFIX FAIL ' + r.getErrors()[0].getMessage()); }
if (bad > 0) { Database.rollback(sp); System.debug(LoggingLevel.ERROR, 'MCCFIX ROLLED BACK failed=' + bad + ' - nothing changed'); return; }
Set<Id> touched = new Set<Id>(); for (OrderItem l : lines) touched.add(l.OrderId);
System.debug(LoggingLevel.ERROR, 'MCCFIX COMMITTED lines=' + lines.size() + ' orders=' + touched.size());
System.debug(LoggingLevel.ERROR, 'MCCFIX ORDERS ' + String.join(new List<Id>(touched), ','));
""" % (",".join("'%s'" % i for i in stuck), ",".join("'%s'" % n for n in names))
res = c.sf.run_apex(apex)
dbg = "\n".join(res.get('debug') or [])
for line in dbg.splitlines():
    if 'MCCFIX' in line and 'ORDERS' not in line:
        print(line[line.find('MCCFIX'):][:200])
if 'MCCFIX COMMITTED' not in dbg:
    sys.exit('Not committed: ' + (res.get('error') or '')[:300])
orders = re.search(r'MCCFIX ORDERS ([^\n]+)', dbg).group(1).split(',')
n = fixlog.write(c.goose, 468, [fixlog.entry(
    'MCC_FIXED', 'TF_90A.C', 'Order', o.strip(),
    'MCC FIX generator rental: CustomerOwned__c true -> false on Power Bundle, GENERATOR RENTAL, Delivery/Pickup Power, '
    'No Service (Customer Owned Power line unchanged) so delivery/pickup WOs can generate', 'OrderItem') for o in orders],
    folder / 'preflight' / 'goose_fixlog.jsonl')
print('logged', n, 'orders to GOOSE_ErrorLog')
