"""One-order regeneration with a 1-hour FINEST trace flag; aborts if the order already has work orders."""
import json, re, subprocess, sys, tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

ORG, ORDER = app.CFG['OrgAlias'], '801VD00000v8wkQYAQ'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
sf = ad.Salesforce(ORG, [])


def sfj(args, timeout=300):
    cp = subprocess.run([ad._sf()] + args + ['--target-org', ORG, '--json'], capture_output=True, text=True, timeout=timeout)
    return json.loads(cp.stdout or '{}')


uname = sfj(['org', 'display'])['result']['username']
uid = sf.query("SELECT Id FROM User WHERE Username = '%s'" % uname)[0]['Id']
existing = sfj(['data', 'query', '--use-tooling-api', '-q', "SELECT Id FROM DebugLevel WHERE DeveloperName = 'MCC_Diag'"])
recs = existing.get('result', {}).get('records') or []
if recs:
    dl = recs[0]['Id']
else:
    dl = sfj(['data', 'create', 'record', '--use-tooling-api', '-s', 'DebugLevel', '-v',
              "DeveloperName=MCC_Diag MasterLabel=MCC_Diag ApexCode=FINEST Database=FINEST System=DEBUG "
              "Workflow=INFO Validation=INFO Callout=INFO ApexProfiling=INFO Visualforce=NONE Wave=NONE Nba=NONE"])['result']['id']
now = datetime.now(timezone.utc)
tf = sfj(['data', 'create', 'record', '--use-tooling-api', '-s', 'TraceFlag', '-v',
          "TracedEntityId=%s DebugLevelId=%s LogType=USER_DEBUG StartDate=%s ExpirationDate=%s"
          % (uid, dl, now.strftime('%Y-%m-%dT%H:%M:%SZ'), (now + timedelta(hours=1)).strftime('%Y-%m-%dT%H:%M:%SZ'))])
print('trace flag:', tf.get('result', {}).get('id') or tf.get('message'))

apex = ("Id target = '%s'; Integer before = [SELECT COUNT() FROM WorkOrder WHERE Order__c = :target]; "
        "if (before > 0) { System.debug(LoggingLevel.ERROR, 'MCCDIAG ABORT already has ' + before + ' work orders'); return; } "
        "List<SObject> orders = [SELECT Id FROM Order WHERE Id = :target]; "
        "try { new CPQOrders().generateOrders(orders); } catch (Exception e) { System.debug(LoggingLevel.ERROR, 'MCCDIAG EXCEPTION ' + e.getMessage()); } "
        "System.debug(LoggingLevel.ERROR, 'MCCDIAG WOS ' + [SELECT COUNT() FROM WorkOrder WHERE Order__c = :target]);" % ORDER)
with tempfile.TemporaryDirectory() as td:
    f = Path(td) / 'd.apex'
    f.write_text(apex, encoding='utf-8')
    run = sfj(['apex', 'run', '--file', str(f)], 600)
inline = (run.get('result') or {}).get('logs') or ''
print('\n'.join(re.findall(r'MCCDIAG[^\n]*', inline)) or 'no MCCDIAG lines')
lid = sfj(['data', 'query', '--use-tooling-api', '-q',
           "SELECT Id, LogLength, Operation FROM ApexLog WHERE LogUserId = '%s' ORDER BY StartTime DESC LIMIT 1" % uid])
lrec = (lid.get('result', {}).get('records') or [{}])[0]
full = sfj(['apex', 'get', 'log', '--log-id', lrec.get('Id', '')], 300) if lrec.get('Id') else {}
body = ''
res = full.get('result')
if isinstance(res, list) and res:
    body = res[0].get('log', '') if isinstance(res[0], dict) else str(res[0])
log_file = folder / 'logs' / 'diag_traced_debug.log'
log_file.write_text(body or inline, encoding='utf-8')
text = body or inline
print('log bytes:', len(text), '| SOQL:', text.count('SOQL_EXECUTE_BEGIN'), '| DML:', text.count('DML_BEGIN'))
for pat in (r'"success"\s*:\s*false[^\n]{0,400}', r'FIELD_[A-Z_]+[^\n]{0,250}', r'VALIDATION_FAIL[^\n]{0,250}',
            r'REQUIRED_FIELD_MISSING[^\n]{0,250}', r'INVALID_[A-Z_]+[^\n]{0,250}', r'EXCEPTION_THROWN[^\n]{0,250}'):
    hits = re.findall(pat, text)
    if hits:
        print('==', pat[:30], len(hits))
        for h in hits[:3]:
            print('   ', h[:400])
