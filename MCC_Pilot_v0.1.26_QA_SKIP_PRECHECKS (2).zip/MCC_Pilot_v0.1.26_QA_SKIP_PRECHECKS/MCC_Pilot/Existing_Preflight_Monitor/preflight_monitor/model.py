"""Core types. No I/O, no Salesforce, no Goose -- importable and testable anywhere."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Optional, List, Any

BLOCKER, WARNING, INFO = "BLOCKER", "WARNING", "INFO"
PASS, FAIL, UNPROVEN = "PASS", "FAIL", "UNPROVEN"

# Baseline classes
NORMAL, OUTLIER, FIRST_OF_KIND, REGRESSION, IMPROVED = (
    "NORMAL", "OUTLIER", "FIRST_OF_KIND", "REGRESSION", "IMPROVED")


@dataclass
class Metric:
    """A number that can be compared across batches. Without one, a check cannot be baselined."""
    name: str
    value: float
    unit: str = "ratio"          # ratio | count | days
    numerator: int = 0
    denominator: int = 0

    def pretty(self) -> str:
        if self.unit == "ratio":
            return "%.1f%%  (%d/%d)" % (self.value * 100, self.numerator, self.denominator)
        if self.unit == "count":
            return "%d" % self.value
        return "%g %s" % (self.value, self.unit)


@dataclass
class Evidence:
    """
    What a check found. The runner -- not the check -- turns this into a verdict.

    THREE DIFFERENT NUMBERS, deliberately kept apart, because collapsing them is how a
    dashboard lies:

      processed  how many records the check LOOKED AT -- the population it examined
      count      how many of them are WRONG -- len(rows). This is the error count.
      rows       the actual offending records, capped for storage but counted exactly

    A check that examines 906 Orders and finds 447 bad ones reports processed=906,
    count=447. Reporting only one of those two numbers is what made the old single
    "Records" column unreadable.
    """
    rows: List[dict] = field(default_factory=list)
    metric: Optional[Metric] = None
    note: str = ""
    # Set when the check could not run at all (missing field, query error, system down).
    unprovable: str = ""
    # How many records this check examined. 0 means "not stated", NOT "examined nothing".
    processed: int = 0
    # When the work this check validates actually ran, where that is observable.
    ran_from: str = ""
    ran_to: str = ""
    run_status: str = ""
    run_source: str = ""          # where the timing came from: an API, or record stamps

    @property
    def count(self) -> int:
        """The ERROR count -- offending records, not records examined."""
        return len(self.rows)

    @property
    def examined(self) -> int:
        """
        Records LOOKED AT. Explicit `processed` first, then a ratio metric's denominator.

        It deliberately does NOT fall back to a COUNT metric's numerator. On a count metric
        the numerator is the FINDING, not the population -- so that fallback reported the
        async-jobs check as "46 errors of 39 examined", more errors than records looked at,
        which is nonsense on its face. A check with no meaningful population reports 0 here
        and the UI then shows the error count alone.
        """
        if self.processed:
            return int(self.processed)
        if self.metric and self.metric.unit == "ratio" and self.metric.denominator:
            return int(self.metric.denominator)
        return 0


@dataclass
class BaselineComparison:
    cls: str                       # NORMAL | OUTLIER | FIRST_OF_KIND | REGRESSION | IMPROVED
    detail: str
    prior_mean: Optional[float] = None
    prior_n: int = 0
    sigma: Optional[float] = None


@dataclass
class Result:
    check_id: str
    batch: str
    verdict: str
    reason: str = ""
    evidence_count: int = 0            # ERRORS found
    processed: int = 0                  # records EXAMINED
    evidence_sample: List[dict] = field(default_factory=list)
    metric: Optional[Metric] = None
    baseline: Optional[BaselineComparison] = None
    duration_ms: int = 0
    ran_at: str = ""
    # When the validated work ran (Informatica/SnapLogic/record stamps), not when we checked.
    ran_from: str = ""
    ran_to: str = ""
    run_status: str = ""
    run_source: str = ""


@dataclass
class Remediation:
    """
    What an operator actually DOES about a failure.

    A finding without a fix is a complaint. Every failing check must name the Run Book step
    that owns the fix, the script that performs it, and whether that script writes.
    """
    summary: str                      # one line: what to do
    runbook_order: Optional[int] = None   # Run Order in the run book that fixes this
    script: str = ""                  # repo path of the script that performs the fix
    writes: bool = False              # does the fix write data?
    approval: str = ""                # who signs off before it runs, if anyone
    steps: List[str] = field(default_factory=list)   # ordered operator steps
    note: str = ""


@dataclass(frozen=True)
class Check:
    """
    A check is DATA. Adding one is a registry entry, not a code path.

    `run` returns Evidence. It never decides PASS/FAIL -- runner.py does, so the
    evidence invariant is enforced in one place instead of per author.

    `finds_problems=True`  (default): rows mean something is WRONG.
    `finds_problems=False`           : rows are the healthy population; emptiness is the problem.

    RUN BOOK BINDING
      `runbook_order`  the Run Order this check VALIDATES
      `blocks`         Run Orders that must not proceed while this check fails
      `remediation`    what to do about it
    """
    id: str
    name: str
    stage: str
    sequence: int
    sobject: str
    severity: str
    rule: str
    rule_source: str
    proves: str
    cannot_prove: str
    run: Callable[[Any], Evidence]
    canary: Optional[Callable[[Any], int]] = None
    requires: tuple = ()
    needs_goose: bool = False
    needs_sunrise: bool = False
    finds_problems: bool = True
    runbook_order: Optional[int] = None
    blocks: tuple = ()
    remediation: Optional[Remediation] = None

    def validate(self) -> List[str]:
        errs = []
        for f in ("id", "name", "stage", "sobject", "rule", "rule_source", "proves", "cannot_prove"):
            if not str(getattr(self, f) or "").strip():
                errs.append("%s: '%s' is required and empty" % (self.id or "<no id>", f))
        if self.severity not in (BLOCKER, WARNING, INFO):
            errs.append("%s: severity must be BLOCKER/WARNING/INFO" % self.id)
        if not callable(self.run):
            errs.append("%s: run must be callable" % self.id)
        if self.canary is None and self.finds_problems:
            errs.append("%s: a problem-finding check needs a canary, or a zero result is "
                        "indistinguishable from broken scoping" % self.id)
        if self.finds_problems and self.remediation is None:
            errs.append("%s: a check that can FAIL must say what to do about it. A finding "
                        "without a fix is a complaint." % self.id)
        if self.remediation and not str(self.remediation.summary or "").strip():
            errs.append("%s: remediation.summary is required" % self.id)
        return errs


@dataclass
class Fixture:
    """A defect we have already proven. If it stops being found, the tool asks why."""
    check_id: str
    batch: str
    expected_count: int
    note: str = ""


@dataclass
class Rule:
    """A documented assertion plus its provenance. Two rules on one field = a contradiction."""
    rule_id: str
    sobject: str
    rule_field: str
    assertion: str
    source: str
    registered_by: str
