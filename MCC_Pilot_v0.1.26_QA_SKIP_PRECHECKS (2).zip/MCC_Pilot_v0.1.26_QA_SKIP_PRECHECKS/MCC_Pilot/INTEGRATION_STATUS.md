# Integration status — v0.1.17

**Available and locally tested:** Goose error-log scan, proactive pre-PL_07 missing-LastName exclusion, and exact batch-scoped contact exclusion, appended Goose resolution log, pre-step scan, recovery evidence, live status panel, checkpoint and resume, seven mapped downstream Informatica taskflows, six additional read-only validations.

**Not finished for unattended end-to-end use:** 30 downstream run-book rows and associated recovery writes, automatic exclusions for all staging objects, triggered SnapLogic credentials/URLs, and live QA end-to-end verification. `StopAfter` remains TF_30.01; end-to-end readiness continues to report failure rather than false completion.

See WHAT_CHANGED_v0.1.17.md and READINESS_REPORT.json.
