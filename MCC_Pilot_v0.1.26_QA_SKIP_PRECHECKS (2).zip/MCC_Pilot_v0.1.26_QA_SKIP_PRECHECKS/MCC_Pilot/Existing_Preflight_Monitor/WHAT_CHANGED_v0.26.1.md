# v0.26.1 - the record count no longer freezes the run

Found from a live run: the log stopped after "Orders" and sat there. The next object, Order Products, is counted
through Order -> Quote -> Batch on a very large table; each attempt could run 3 minutes, twice, and the objects
after it (Work Order Lines, Service Appointments) were the same.

- Objects are now counted side by side (6 at a time), so one slow count does not hold the rest.
- Each object has a 90 second limit. If Salesforce does not answer, the tile says ERROR "did not answer ... not zero"
  instead of the run hanging, and the run continues and saves.
- Order Products, Subscriptions, Work Order Lines and Service Appointments are counted with an `IN (SELECT Id ...)`
  filter. Same rows, easier for Salesforce to plan. (Not testable offline - if one is still slow it will show ERROR.)
- No check, no run book row and no number changed.
