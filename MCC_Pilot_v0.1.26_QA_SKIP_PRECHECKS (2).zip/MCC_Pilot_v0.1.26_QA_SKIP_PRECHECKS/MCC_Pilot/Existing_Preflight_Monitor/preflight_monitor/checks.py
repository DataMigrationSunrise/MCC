"""
Every check, as data. Adding one is a registry entry -- no runner, dashboard or report change.

Each check states the RULE it asserts and WHERE THAT RULE CAME FROM, plus what a PASS
proves and what it explicitly does not. `registry.validate()` refuses to register a check
missing any of those.

Ported from the Apex/SOQL proven against UMB-0116 on 2026-10-01/02.
"""
from __future__ import annotations
from model import (Check, Evidence, Metric, Rule, BLOCKER, WARNING, INFO)
import jobruns

B = "{BATCH}"


# ===================================================================== SCOPE
def _soql_dt(v) -> str:
    """
    '2026-09-18T14:22:01.000+0000' -> '2026-09-18T14:22:01Z'.
    SOQL datetime literals are unquoted and must be ISO8601; a stray '.000+0000' is
    rejected outright, and a quoted literal is read as a string and matches nothing.
    """
    t = str(v or "").strip()
    if not t:
        return ""
    t = t.replace(" ", "T", 1) if ("T" not in t and " " in t) else t
    head = t[:19]
    return head + "Z" if len(head) == 19 else ""


def _batch_window(conn) -> dict:
    """
    WHEN was this batch written? Derived from records that ARE attributable to it.

    This exists because of a false positive that reported 22,027 WorkOrders, 10,095 BIQs,
    2,322 Maintenance Plans and 414 Contracts as a blocking "blind spot" on UMB-0117. They
    were nothing of the kind: an org-wide "WHERE Contract__c = null" in a sandbox full of
    ordinary USS business records returns the ordinary business records. They were never
    migration rows, so they cannot be MISSING from a migration population.

    The blind-spot question is still real -- a null link does hide a row from every
    batch-scoped query -- but it is only answerable INSIDE the window this batch wrote in.
    Outside it, the number measures the sandbox, not the batch.

    Quotes carry USS_Migration_Batch__c directly and appear at the first load step, so
    they define the window. Padded one day each side, because steps straddle midnight.
    The batch record's own CreatedDate is the fallback before any Quote exists.
    """
    try:
        rows = conn.q("SELECT COUNT(Id) c, MIN(CreatedDate) mn, MAX(CreatedDate) mx "
                      "FROM SBQQ__Quote__c WHERE USS_Migration_Batch__r.Name = '%s'" % B)
    except Exception as e:                                   # noqa: BLE001
        return dict(ok=False, why="Could not derive the batch window: %s" % str(e)[:160])
    r = (rows or [{}])[0] or {}
    lo, hi = _soql_dt(r.get("mn")), _soql_dt(r.get("mx"))
    src = "this batch's Quotes"
    if not (lo and hi):
        try:
            b = conn.q("SELECT CreatedDate FROM USS_Migration_Batch__c WHERE Name = '%s'" % B)
        except Exception as e:                               # noqa: BLE001
            return dict(ok=False, why="Could not derive the batch window: %s" % str(e)[:160])
        lo = _soql_dt((b or [{}])[0].get("CreatedDate") if b else "")
        if not lo:
            return dict(ok=False, why="No Quotes and no batch record -- the window this batch "
                                      "wrote in cannot be established, so a blind spot cannot "
                                      "be distinguished from ordinary business data.")
        hi, src = "", "the batch record's CreatedDate (no Quotes yet)"

    from datetime import datetime, timedelta
    def pad(x, days):
        try:
            return (datetime.strptime(x[:19], "%Y-%m-%dT%H:%M:%S")
                    + timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
        except Exception:                                    # noqa: BLE001
            return x
    lo_p = pad(lo, -1)
    hi_p = pad(hi, 1) if hi else ""
    return dict(ok=True, lo=lo_p, hi=hi_p, source=src,
                label=("%s to %s" % (lo_p[:10], hi_p[:10])) if hi_p else ("from %s" % lo_p[:10]))


def _blind(conn, sobject, where, label):
    """
    A broken batch link is only a BLIND SPOT if the record was written by this batch.

    Reports two numbers and fails on only one of them:
      in-window   records with a null link written while this batch ran -> the blind spot
      org-wide    the same condition with no window -> CONTEXT, almost entirely ordinary
                  non-migration business data, and never a blocker
    """
    org = conn.n("SELECT COUNT() FROM %s WHERE %s" % (sobject, where))
    win = _batch_window(conn)
    if not win.get("ok"):
        return Evidence(processed=org,
                        unprovable="%s %s record(s) org-wide carry a null batch link, but %s "
                                   "Reporting UNPROVEN rather than calling ordinary business "
                                   "records a migration blind spot."
                                   % (org, sobject, win.get("why", "")))
    clause = "%s AND CreatedDate >= %s" % (where, win["lo"])
    if win.get("hi"):
        clause += " AND CreatedDate <= %s" % win["hi"]
    try:
        inwin = conn.n("SELECT COUNT() FROM %s WHERE %s" % (sobject, clause))
    except Exception as e:                                   # noqa: BLE001
        return Evidence(processed=org,
                        unprovable="Org-wide count is %d, but the windowed count failed (%s), "
                                   "so the blind spot cannot be separated from ordinary "
                                   "business data." % (org, str(e)[:160]))

    ctx = ("%d org-wide match the same condition, derived from %s. The org-wide number is "
           "NOT a finding: in a sandbox holding ordinary USS business records, most records "
           "with a null migration link were never migration records at all."
           % (org, win["source"]))

    # Pull the ACTUAL offending records, not a one-row summary.
    # A single summary row made evidence_count 1 while the note said 11, so the Record
    # Count cell read "1 error" for an 11-record finding -- and gave nobody the Ids to go
    # and look at. Capped, with the exact count always taken from the aggregate.
    rows = []
    if inwin:
        try:
            rows = conn.q("SELECT Id, CreatedDate FROM %s WHERE %s ORDER BY CreatedDate"
                          % (sobject, clause))
        except Exception:                                    # noqa: BLE001
            rows = []
        for r in rows:
            r["sobject"] = sobject
            r["issue"] = "written in this batch's window with a null batch link"
            r["window"] = win["label"]
        if not rows:                       # query refused: keep the finding, lose the detail
            rows = [{"sobject": sobject, "condition": where, "in_batch_window": inwin,
                     "org_wide": org, "window": win["label"],
                     "issue": "record list unavailable -- the count is from the aggregate"}]
        elif len(rows) < inwin:
            rows[-1]["note"] = "%d more not listed" % (inwin - len(rows))
    return Evidence(
        rows=rows, processed=org,
        metric=Metric(label, float(inwin), "count", inwin, 0),
        ran_from=win["lo"], ran_to=win.get("hi", ""),
        run_source="batch window from %s" % win["source"],
        note=("%d %s record(s) written during this batch's window (%s) carry a null batch "
              "link, so they are absent from EVERY batch-scoped population rather than "
              "flagged within one. %s" % (inwin, sobject, win["label"], ctx)) if inwin
             else ("No %s record(s) written during this batch's window (%s) have a broken "
                   "batch link. %s" % (sobject, win["label"], ctx)))


def _c_wo_no_contract(conn):
    fld = "Contract__c" if conn.has_field("WorkOrder.Contract__c") else "ContractId"
    return _blind(conn, "WorkOrder", "%s = null" % fld, "WorkOrders with no Contract")


CHECKS: list[Check] = [

    Check(id="SCOPE.WO_NO_CONTRACT", name="WorkOrders with no Contract link",
          stage="pre", sequence=160, sobject="WorkOrder", severity=INFO,
          rule="Every WorkOrder reaches its batch through Contract; a null link makes it invisible",
          rule_source="AF60 boundary note, live_touchpoint_automation.py v0.17.181",
          requires=(), canary=lambda c: c.n("SELECT COUNT() FROM WorkOrder"),
          run=_c_wo_no_contract,
          proves="No WorkOrder is excluded from batch-scoped populations by a null Contract link",
          cannot_prove="That the Contract it points at belongs to the right batch"),

    Check(id="SCOPE.BIQ_NO_PARENT", name="BIQs with no parent USS Order",
          stage="pre", sequence=200, sobject="Billing_Impacts_Queue__c", severity=BLOCKER,
          rule="A BIQ reaches its batch via Parent_USS_Order__r.USS_Migration_Batch__c",
          rule_source="preflight_pipeline.py manual_touchpoints() BIQ query",
          canary=lambda c: c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c"),
          run=lambda c: _blind(c, "Billing_Impacts_Queue__c", "Parent_USS_Order__c = null",
                               "BIQs with no parent"),
          proves="No BIQ is missing from every batch BIQ count",
          cannot_prove="That parented BIQs carry correct values"),

    Check(id="SCOPE.MP_NO_CONTRACT", name="Maintenance Plans with no Contract",
          stage="pre", sequence=150, sobject="MaintenancePlan", severity=WARNING,
          rule="An MP reaches its batch via Contract__r.USS_Migration_Batch__c",
          rule_source="preflight_pipeline.py TP-118 query",
          canary=lambda c: c.n("SELECT COUNT() FROM MaintenancePlan"),
          run=lambda c: _blind(c, "MaintenancePlan", "Contract__c = null", "MPs with no Contract"),
          proves="No MP is invisible to TP-129 queries",
          cannot_prove="That linked MPs generate Work Orders"),

    Check(id="SCOPE.CONTRACT_NO_BATCH", name="Activated Contracts belonging to no batch",
          stage="pre", sequence=130, sobject="Contract", severity=INFO,
          rule="Every migrated Contract carries USS_Migration_Batch__c",
          rule_source="Object Fingerprinting tab, run book v39+",
          canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE Status='Activated'"),
          run=lambda c: _blind(c, "Contract",
                               "USS_Migration_Batch__c = null AND Status = 'Activated'",
                               "Activated Contracts with no batch"),
          proves="Every Activated Contract is attributable to a batch",
          cannot_prove="That it is attributed to the CORRECT batch"),

    # ============================================================== CONTRACT
    Check(id="CONTRACT.ACTIVATED_POPULATION", name="Activated Contracts exist in this batch",
          stage="tf_35", sequence=130, sobject="Contract", severity=BLOCKER,
          finds_problems=False,
          rule="A migrated batch has Activated Contracts",
          rule_source="Run Book tf_35",
          run=lambda c: (lambda rows: Evidence(
              rows=rows,
              metric=Metric("Activated Contracts", float(len(rows)), "count", len(rows), 0),
              note="%d Activated Contract(s)." % len(rows)))(
              c.q("SELECT Id, ContractNumber, Billing_Period__c, StartDate, LastBillingDate__c, "
                  "Fuel_Surcharge_Percent__c FROM Contract "
                  "WHERE USS_Migration_Batch__r.Name = '%s' AND Status = 'Activated'" % B)),
          proves="The batch produced Activated Contracts and the scope resolves",
          cannot_prove="That the count is right, or that downstream records exist"),

    Check(id="CONTRACT.NONMONTHLY_NULL_LASTBILLINGDATE",
          name="Non-Monthly FSC Contracts with no LastBillingDate",
          stage="tf_60", sequence=130, sobject="Contract", severity=BLOCKER,
          rule="LastBillingDate__c must be populated for billingEffectiveDateCombined__c to resolve",
          rule_source="UMB-0065 'Adding FSC BIQs' step 2 -- WHICH SCOPES ONLY TO MONTHLY. "
                      "That scope is the originating defect; this check covers what it excludes.",
          requires=("Contract.LastBillingDate__c", "Contract.Billing_Period__c"),
          canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE "
                               "USS_Migration_Batch__r.Name='%s' AND Status='Activated'" % B),
          run=lambda c: (lambda rows: Evidence(
              rows=rows,
              metric=Metric("Non-Monthly FSC Contracts missing LastBillingDate",
                            float(len(rows)), "count", len(rows), 0),
              note=("%d non-Monthly FSC-eligible Contract(s) have a null LastBillingDate__c. "
                    "AF160 cannot reach these -- its query filters Billing_Period__c = "
                    "'Monthly Bill Period'. This is the originating cause of null FSC "
                    "Effective Dates." % len(rows)) if rows else ""))(
              c.q("SELECT Id, ContractNumber, Billing_Period__c, StartDate, "
                  "Fuel_Surcharge_Percent__c FROM Contract "
                  "WHERE USS_Migration_Batch__r.Name = '%s' AND Status = 'Activated' "
                  "AND Fuel_Surcharge_Percent__c > 0 "
                  "AND Billing_Period__c != 'Monthly Bill Period' "
                  "AND LastBillingDate__c = null" % B)),
          proves="Every FSC-eligible non-Monthly Contract can resolve its billing date formula",
          cannot_prove="That the date VALUE is right -- see CONTRACT.LASTBILLINGDATE_RULE"),

    Check(id="CONTRACT.LASTBILLINGDATE_RULE",
          name="Monthly Contracts where LastBillingDate != StartDate - 1",
          stage="tf_60", sequence=130, sobject="Contract", severity=WARNING,
          rule="LastBillingDate__c = StartDate - 1 day",
          rule_source="Run Book steps 154-158, via preflight_pipeline.py checkpoint '154-158'",
          requires=("Contract.LastBillingDate__c", "Contract.StartDate"),
          canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE "
                               "USS_Migration_Batch__r.Name='%s' AND Status='Activated'" % B),
          run=lambda c: _lastbilling_rule(c),
          proves="Monthly Contracts carry the billing date the Run Book specifies",
          cannot_prove="Which of the two documented rules governs -- UMB-0065 says 'today', "
                       "steps 154-158 say StartDate-1. AF160 writes 'today'. See contradictions."),

    # ============================================================== BIQ
    Check(id="BIQ.COVERAGE", name="Activated Contracts with ZERO BIQs",
          stage="tf_60", sequence=200, sobject="Billing_Impacts_Queue__c", severity=BLOCKER,
          rule="Every Activated Contract in a migrated batch produces at least one BIQ",
          rule_source="Cross-batch baseline: UMB-0113 97.4%, UMB-0114 100%",
          canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE "
                               "USS_Migration_Batch__r.Name='%s' AND Status='Activated'" % B),
          run=lambda c: _biq_coverage(c),
          proves="Every Activated Contract produced BIQs",
          cannot_prove="That the BIQs are correct, complete, or will be accepted by Zuora"),

    Check(id="BIQ.FSC_NULL_EFFECTIVE_DATE", name="FSC BIQs with a null Effective Date",
          stage="tf_60", sequence=200, sobject="Billing_Impacts_Queue__c", severity=BLOCKER,
          rule="Effective_Date__c must be non-null on every FSC BIQ",
          rule_source="TP-160 requirement; 21 of 21 such rows org-wide are in Error",
          requires=("Billing_Impacts_Queue__c.Effective_Date__c",),
          canary=lambda c: c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
                               "Parent_USS_Order__r.USS_Migration_Batch__r.Name='%s' "
                               "AND Charge_Type__c LIKE '%%Fuel%%'" % B),
          run=lambda c: (lambda rows: Evidence(
              rows=rows,
              metric=Metric("FSC BIQs with null Effective Date", float(len(rows)), "count",
                            len(rows), 0),
              note=("%d FSC BIQ(s) have a NULL Effective_Date__c. AF160 reads this field and "
                    "tags it EXISTING_BIQ_PROOF_NOT_DEFECT_COUNT, so it reports LIVE CLEAN over "
                    "exactly these rows." % len(rows)) if rows else ""))(
              c.q("SELECT Id, Name, BIQ_Key__c, Charge_Code__c, Processing_Status__c, Impact_Date__c, "
                  "Parent_USS_Order__r.ContractNumber FROM Billing_Impacts_Queue__c "
                  "WHERE Parent_USS_Order__r.USS_Migration_Batch__r.Name = '%s' "
                  "AND Charge_Type__c LIKE '%%Fuel%%' AND Effective_Date__c = null" % B)),
          proves="No FSC BIQ will be rejected downstream for a missing Effective Date",
          cannot_prove="That non-null dates are CORRECT -- two rules compete, see the "
                       "contradiction panel"),

    Check(id="BIQ.ERROR_STATUS", name="BIQs sitting in Error",
          stage="tf_75", sequence=200, sobject="Billing_Impacts_Queue__c", severity=BLOCKER,
          rule="No BIQ should remain in Error at the end of a batch",
          rule_source="Run Book tf_75 / BIQ Resets",
          canary=lambda c: c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
                               "Parent_USS_Order__r.USS_Migration_Batch__r.Name='%s'" % B),
          run=lambda c: _biq_errors(c),
          proves="No BIQ is in Error",
          cannot_prove="That Complete BIQs reached Zuora"),

    # ============================================================== WORK ORDERS
    Check(id="WO.ORDERS_MISSING_WOS", name="Orders with no Work Orders at all",
          stage="tf_35", sequence=110, sobject="Order", severity=BLOCKER,
          rule="A converted, activated Order generates Work Orders",
          rule_source="TP-129; CPQOrders.generateOrders",
          canary=lambda c: c.n("SELECT COUNT() FROM Order WHERE "
                               "SBQQ__Quote__r.USS_Migration_Batch__r.Name='%s'" % B),
          run=lambda c: _orders_missing_wos(c),
          proves="Every Order produced Work Orders",
          cannot_prove="That the right NUMBER or TYPE of Work Orders were produced"),

    Check(id="WO.MP_NO_GENERATION", name="Active Maintenance Plans generating no Work Orders",
          stage="tf_40", sequence=150, sobject="MaintenancePlan", severity=BLOCKER,
          requires=("MaintenancePlan.Active__c",),
          rule="An Active MP has at least one Work Order naming it (MaintenancePlanId). The "
               "IsGeneratedFromMaintenancePlan flag is not required: migration-created Work Orders lack it",
          rule_source="preflight_pipeline.py TP-129 query. NOTE: the touch point's documented "
                      "cause (NULL SFDC_AccountID) was FALSIFIED on UMB-0116 -- 5 of 1,027 "
                      "active MPs, zero with a null Account. Real cause unknown.",
          canary=lambda c: c.n("SELECT COUNT() FROM MaintenancePlan WHERE "
                               "Contract__r.USS_Migration_Batch__r.Name='%s'" % B),
          run=lambda c: _mp_no_generation(c),
          proves="Every Active MP generated at least one Work Order",
          cannot_prove="Why an MP failed to generate -- the documented cause does not hold"),

    # ============================================================== QUOTES
    Check(id="QUOTE.NOT_ORDERED", name="Quotes that never converted to an Order",
          stage="tf_30", sequence=80, sobject="SBQQ__Quote__c", severity=BLOCKER,
          rule="Every Quote in a migrated batch is Ordered after tf_30",
          rule_source="preflight_pipeline.py checkpoint '95-96 Ordered Quotes'",
          canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__Quote__c WHERE "
                               "USS_Migration_Batch__r.Name='%s'" % B),
          run=lambda c: _quotes_not_ordered(c),
          proves="Every Quote converted",
          cannot_prove="That the resulting Orders are correct. An unordered Quote presents "
                       "downstream as missing Work Orders or missing BIQs."),

    Check(id="QUOTE.SERVICEABLE_ZIP", name="Quotes with a missing or mismatched serviceable ZIP",
          stage="tf_02", sequence=80, sobject="SBQQ__Quote__c", severity=BLOCKER,
          rule="A Quote's Serviceable_Zip_Code__c matches its shipping ZIP",
          rule_source="preflight_pipeline.py checkpoint '30 Serviceable ZIP'",
          requires=("SBQQ__Quote__c.Serviceable_Zip_Code__c",),
          canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__Quote__c WHERE "
                               "USS_Migration_Batch__r.Name='%s'" % B),
          run=lambda c: _serviceable_zip(c),
          proves="Serviceable ZIP references are present and consistent",
          cannot_prove="That a referenced ZIP is actually serviced by an existing territory"),

    # ============================================================== GOOSE PARITY
    Check(id="GOOSE.BIQ_PARITY", name="Salesforce vs Goose BIQ counts disagree",
          stage="tf_75", sequence=200, sobject="Billing_Impacts_Queue__c", severity=WARNING,
          needs_goose=True,
          rule="Salesforce and Goose hold the same BIQ population for a batch",
          rule_source="Proven 2026-10-02: Salesforce 163 vs Goose 124 on UMB-0116 -- "
                      "39 rows created after the sync, invisible to every Goose-side remedy",
          canary=lambda c: c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
                               "Parent_USS_Order__r.USS_Migration_Batch__r.Name='%s'" % B),
          run=lambda c: _goose_biq_parity(c),
          proves="Both systems agree on the BIQ population",
          cannot_prove="Which system is right when they disagree"),
]


# ===================================================================== implementations
def _lastbilling_rule(c):
    rows = c.q("SELECT Id, ContractNumber, StartDate, LastBillingDate__c "
               "FROM Contract WHERE USS_Migration_Batch__r.Name = '%s' "
               "AND Status = 'Activated' AND Billing_Period__c = 'Monthly Bill Period'" % B)
    from datetime import date, timedelta
    bad = []
    for r in rows:
        sd, lb = r.get("StartDate"), r.get("LastBillingDate__c")
        if not sd or not lb:
            continue
        try:
            want = date.fromisoformat(str(sd)[:10]) - timedelta(days=1)
            if str(lb)[:10] != want.isoformat():
                r["expected"] = want.isoformat()
                bad.append(r)
        except ValueError:
            continue
    den = len([r for r in rows if r.get("StartDate") and r.get("LastBillingDate__c")])
    if not den:
        return Evidence(processed=len(rows), unprovable=(
            "None of the %d Monthly Contract(s) has both a StartDate and a LastBillingDate, so the "
            "rule has nothing to compare. That is not a pass." % len(rows)))
    ratio = (den - len(bad)) / den
    return Evidence(rows=bad,
                    metric=Metric("Monthly LastBillingDate conforming", ratio, "ratio",
                                  den - len(bad), den),
                    note=("%d Monthly Contract(s) differ from StartDate-1. If the values sit near "
                          "today, AF160 applied the UMB-0065 rule ('today') instead." % len(bad))
                    if bad else "")


def _biq_coverage(c):
    cons = c.q("SELECT Id, ContractNumber FROM Contract WHERE "
               "USS_Migration_Batch__r.Name = '%s' AND Status = 'Activated'" % B)
    if not cons:
        return Evidence(unprovable="No Activated Contracts in this batch -- cannot measure coverage.")
    withbiq = c.q("SELECT Parent_USS_Order__c FROM Billing_Impacts_Queue__c "
                  "WHERE Parent_USS_Order__r.USS_Migration_Batch__r.Name = '%s' "
                  "AND Parent_USS_Order__c != null" % B)
    have = {r.get("Parent_USS_Order__c") for r in withbiq}
    missing = [r for r in cons if r.get("Id") not in have]
    n_ok = len(cons) - len(missing)
    return Evidence(rows=missing,
                    metric=Metric("BIQ coverage", n_ok / len(cons), "ratio", n_ok, len(cons)),
                    note=("%d of %d Activated Contract(s) have ZERO BIQs." % (len(missing), len(cons)))
                    if missing else "")


def _biq_errors(c):
    rows = c.q("SELECT Id, Name, Processing_Status__c, Charge_Type__c, Effective_Date__c, "
               "Parent_USS_Order__r.ContractNumber FROM Billing_Impacts_Queue__c "
               "WHERE Parent_USS_Order__r.USS_Migration_Batch__r.Name = '%s' "
               "AND Processing_Status__c = 'Error'" % B)
    total = c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
                "Parent_USS_Order__r.USS_Migration_Batch__r.Name = '%s'" % B)
    ok = total - len(rows)
    return Evidence(rows=rows,
                    metric=Metric("BIQs not in Error", (ok / total) if total else 0.0, "ratio",
                                  ok, total),
                    note="%d of %d BIQ(s) are in Error." % (len(rows), total) if rows else "")


def _orders_missing_wos(c):
    orders = c.q("SELECT Id, OrderNumber, Status FROM Order WHERE "
                 "SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s' AND Status = 'Activated'" % B)
    if not orders:
        return Evidence(unprovable="No Activated Orders in this batch.")
    # By the Order link only. Going through the Contract as well hid Work Orders whose Contract
    # link is null (SCOPE.WO_NO_CONTRACT finds some), so their Orders read as having none.
    wos = c.q("SELECT Order__c FROM WorkOrder WHERE Order__c IN (SELECT Id FROM Order WHERE "
              "SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s')" % B)
    have = {r.get("Order__c") for r in wos}
    missing = [o for o in orders if o.get("Id") not in have]
    ok = len(orders) - len(missing)
    return Evidence(rows=missing, processed=len(orders),
                    metric=Metric("Orders with Work Orders", ok / len(orders), "ratio", ok, len(orders)),
                    note="%d of %d Activated Order(s) have no Work Orders." % (len(missing), len(orders))
                    if missing else "")


def _mp_no_generation(c):
    mps = c.q("SELECT Id, MaintenancePlanNumber, Active__c, Contract__c FROM MaintenancePlan "
              "WHERE Contract__r.USS_Migration_Batch__r.Name = '%s' AND Active__c = true" % B)
    if not mps:
        return Evidence(unprovable="No Active Maintenance Plans in this batch.")
    # A plan has Work Orders if ANY Work Order names it. Requiring IsGeneratedFromMaintenancePlan as
    # well hid services that exist (spot-checked on UMB-0117): Work Orders created by the migration
    # scripts do not carry that flag.
    on_plan = {}
    for r in c.q("SELECT MaintenancePlanId, IsGeneratedFromMaintenancePlan FROM WorkOrder "
                 "WHERE MaintenancePlanId != null AND MaintenancePlanId IN "
                 "(SELECT Id FROM MaintenancePlan WHERE "
                 "Contract__r.USS_Migration_Batch__r.Name = '%s')" % B):
        on_plan[r.get("MaintenancePlanId")] = on_plan.get(r.get("MaintenancePlanId"), 0) + 1
    missing = [dict(m) for m in mps if m.get("Id") not in on_plan]
    ok = len(mps) - len(missing)
    if len(mps) >= 20 and not ok:
        return Evidence(processed=len(mps), unprovable=(
            "Every one of %d Active Maintenance Plan(s) has no Work Order naming it. Nothing passes, "
            "which points at the rule (how this org links plans to Work Orders) rather than at the "
            "data -- spot checks on UMB-0117 found plans with services. Not counted as a finding." % len(mps)))
    note = ""
    if missing:
        fld = "Contract__c" if c.has_field("WorkOrder.Contract__c") else "ContractId"
        on_con = {}
        for r in c.q("SELECT %s k, COUNT(Id) n FROM WorkOrder WHERE %s IN (SELECT Id FROM Contract "
                     "WHERE USS_Migration_Batch__r.Name = '%s') GROUP BY %s" % (fld, fld, B, fld)):
            on_con[r.get("k")] = int(r.get("n") or 0)
        causes = {}
        for m in missing:
            nc = on_con.get(m.get("Contract__c"), 0)
            m["work_orders_naming_the_plan"] = 0
            m["work_orders_on_its_contract"] = nc
            if nc:
                m["likely_cause"] = ("no Work Order names this plan, but its Contract has %d Work "
                                     "Order(s) -- the services may be linked to the Contract" % nc)
                k = "no Work Order names the plan, but its Contract has some"
            else:
                m["likely_cause"] = "no Work Order on the plan or on its Contract"
                k = "no Work Order on the plan or its Contract"
            causes[k] = causes.get(k, 0) + 1
        note = ("%d of %d Active MP(s) have no Work Order naming them. Breakdown: %s."
                % (len(missing), len(mps), "; ".join("%d %s" % (n, k) for k, n in
                                                      sorted(causes.items(), key=lambda x: -x[1]))))
    return Evidence(rows=missing, processed=len(mps),
                    metric=Metric("Active MPs generating Work Orders", ok / len(mps), "ratio",
                                  ok, len(mps)),
                    note=note)


def _quotes_not_ordered(c):
    qs = c.q("SELECT Id, Name, SBQQ__Ordered__c, SBQQ__Status__c FROM SBQQ__Quote__c "
             "WHERE USS_Migration_Batch__r.Name = '%s'" % B)
    if not qs:
        return Evidence(unprovable="No Quotes in this batch.")
    bad = [q for q in qs if str(q.get("SBQQ__Ordered__c")).lower() not in ("true", "1")]
    ok = len(qs) - len(bad)
    return Evidence(rows=bad,
                    metric=Metric("Quotes Ordered", ok / len(qs), "ratio", ok, len(qs)),
                    note="%d of %d Quote(s) never converted." % (len(bad), len(qs)) if bad else "")


def _serviceable_zip(c):
    qs = c.q("SELECT Id, Name, Shipping_Address__r.USF_Zip_Code__c, Serviceable_Zip_Code__c, "
             "Serviceable_Zip_Code__r.Zip_Code__c FROM SBQQ__Quote__c "
             "WHERE USS_Migration_Batch__r.Name = '%s'" % B)
    if not qs:
        return Evidence(unprovable="No Quotes in this batch.")
    bad = []
    evaluated = 0
    for q in qs:
        ship = str(q.get("Shipping_Address__r.USF_Zip_Code__c") or "").strip()
        ref = str(q.get("Serviceable_Zip_Code__r.Zip_Code__c") or "").strip()
        if not ship:
            continue
        evaluated += 1
        if not q.get("Serviceable_Zip_Code__c"):
            q["issue"] = "MISSING serviceable ZIP reference"; bad.append(q)
        elif ref and ref[:5] != ship[:5]:
            q["issue"] = "MISMATCH: references %s, ships to %s" % (ref, ship); bad.append(q)
    ok = evaluated - len(bad)
    return Evidence(rows=bad,
                    metric=Metric("Serviceable ZIP correct",
                                  (ok / evaluated) if evaluated else 0.0, "ratio", ok, evaluated),
                    note="%d Quote(s) with a missing or mismatched serviceable ZIP." % len(bad)
                    if bad else "")


def _goose_biq_parity(c):
    sf = c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
             "Parent_USS_Order__r.USS_Migration_Batch__r.Name = '%s'" % B)
    sfid = c.sf_batch_id()
    if not sfid:
        return Evidence(unprovable="Could not resolve the Salesforce Id of batch %s, which is the "
                                   "only key Goose's MigrationBatch carries." % c.batch)
    try:
        g = c.gn("SELECT COUNT_BIG(*) AS C FROM dbo.SFDC_BillingImpactQueue biq "
                 "JOIN dbo.MigrationBatch mb ON mb.ID = biq.MigrationBatchID "
                 "WHERE mb.SalesforceUssMigrationBatchID = '%s'" % sfid)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Goose BIQ query failed: %s" % str(e)[:300])
    if sf == g:
        return Evidence(rows=[], metric=Metric("SF/Goose BIQ parity", 1.0, "ratio", sf, g),
                        note="Both systems report %d BIQ(s)." % sf)
    row = {"salesforce": sf, "goose": g, "delta": sf - g,
           "meaning": ("Salesforce has %d more BIQs than Goose: created after the sync, and invisible to "
                       "every Goose-side remedy, including TF_75." % (sf - g)) if sf > g else
                      ("Goose has %d more BIQs than Salesforce: staged rows that never reached "
                       "Salesforce." % (g - sf))}
    return Evidence(rows=[row],
                    metric=Metric("SF/Goose BIQ parity",
                                  (min(sf, g) / max(sf, g)) if max(sf, g) else 0.0, "ratio",
                                  min(sf, g), max(sf, g)),
                    note="Salesforce %d vs Goose %d (delta %+d)." % (sf, g, sf - g))


# ===================================================================== rules registry
RULES = [
    Rule("LASTBILLING_TODAY", "Contract", "LastBillingDate__c",
         "today", "UMB-0065 'Adding FSC BIQs' step 2 (implemented by AF160)",
         "CONTRACT.NONMONTHLY_NULL_LASTBILLINGDATE"),
    Rule("LASTBILLING_STARTDATE_MINUS_1", "Contract", "LastBillingDate__c",
         "StartDate - 1 day", "Run Book steps 154-158 (preflight_pipeline.py checkpoint)",
         "CONTRACT.LASTBILLINGDATE_RULE"),
    Rule("FSC_EFFDATE_PARENT_BIQ", "Billing_Impacts_Queue__c", "Effective_Date__c",
         "parent BIQ Effective_Date__c (strip ' FSC|' from BIQ_Key__c)",
         "UMB-0065 'Fix the Effective Dates' steps 3-5; TP-160 requirement text",
         "BIQ.FSC_NULL_EFFECTIVE_DATE"),
    Rule("FSC_EFFDATE_GOOSE_PROC", "Billing_Impacts_Queue__c", "Effective_Date__c",
         "BilledThroughDate + 1 day, else ServiceStartDate",
         "Goose sp_SFDC_20_BiqEffectiveDateUpdates (what TF_75 runs)",
         "BIQ.FSC_NULL_EFFECTIVE_DATE"),
]

# The 20-object spine, for the coverage self-audit.
SPINE = [(10, "USS_Migration_Batch__c"), (20, "Account"), (30, "Contact"),
         (40, "AccountContactRelation"), (50, "USF_Address__c"), (60, "Opportunity"),
         (70, "Purchase_Order__c"), (80, "SBQQ__Quote__c"), (90, "SBQQ__QuoteLine__c"),
         (100, "NF_Quoted_Jobsite__c"), (110, "Order"), (120, "OrderItem"),
         (130, "Contract"), (140, "SBQQ__Subscription__c"), (150, "MaintenancePlan"),
         (160, "WorkOrder"), (170, "WorkOrderLineItem"), (180, "ServiceAppointment"),
         (190, "AssignedResource"), (200, "Billing_Impacts_Queue__c")]

# Defects proven this week. If a check stops finding its fixture, the tool asks why.
FIXTURES = [
    ("BIQ.FSC_NULL_EFFECTIVE_DATE", "UMB-0116", 18, "18 rows across 17 Contracts, all Status=Error"),
    ("BIQ.COVERAGE", "UMB-0116", 750, "750 of 786 Activated Contracts with zero BIQs"),
    ("WO.MP_NO_GENERATION", "UMB-0116", 5, "5 of 1,027 active MPs; documented NULL-Account cause falsified"),
]


# =====================================================================================
# RUN BOOK BINDING
# Where each check sits in the run book, what it blocks, and what an operator DOES
# about a failure. Applied at registry load, so check definitions above stay readable.
#
# `runbook_order` = the Run Order this check VALIDATES
# `blocks`        = Run Orders that must not proceed while it fails
# Run Orders are from UMB_Master_Run_Book_v40 (58 steps).
# =====================================================================================
from model import Remediation as _R

BINDINGS = {
 "SCOPE.WO_NO_CONTRACT": dict(runbook_order=2, blocks=(),
   remediation=_R(
     summary="Size the blind spot before trusting ANY population count in this run book.",
     runbook_order=2, script="31_preflight_derived_checks/TF_00.02_Check_Batch_Scope_Blind_Spot.apex",
     writes=False,
     steps=["Run TF_00.02 and read PART 1 -- it reports whether WorkOrder carries ContractId, "
            "Contract__c, or both.",
            "If BOTH exist and their null counts differ, scripts using one field see a different "
            "population than scripts using the other. Settle which is authoritative before "
            "acting on any WorkOrder count.",
            "Records counted here are in NO batch-scoped population -- they were never in the "
            "denominator of any other check."],
     note="Cannot be batch-scoped by design: the field needed to attribute them to a batch is "
          "the field that is missing.")),

 "SCOPE.BIQ_NO_PARENT": dict(runbook_order=2, blocks=(51, 52, 55),
   remediation=_R(summary="BIQs with no parent are absent from every batch BIQ count.",
     runbook_order=2, script="31_preflight_derived_checks/TF_00.02_Check_Batch_Scope_Blind_Spot.apex",
     writes=False,
     steps=["Confirm the count, then treat every BIQ coverage number in this run as a floor, "
            "not a total."])),

 "SCOPE.MP_NO_CONTRACT": dict(runbook_order=2, blocks=(38,),
   remediation=_R(summary="MPs with no Contract are invisible to every TP-129 query.",
     runbook_order=2, script="31_preflight_derived_checks/TF_00.02_Check_Batch_Scope_Blind_Spot.apex",
     writes=False, steps=["Size it, then re-read RO 38's result as a floor."])),

 "SCOPE.CONTRACT_NO_BATCH": dict(runbook_order=2, blocks=(),
   remediation=_R(summary="Activated Contracts belonging to no batch at all.",
     runbook_order=2, script="31_preflight_derived_checks/TF_00.02_Check_Batch_Scope_Blind_Spot.apex",
     writes=False, steps=["Identify which batch each should belong to before closing the run."])),

 "CONTRACT.ACTIVATED_POPULATION": dict(runbook_order=18, blocks=(),
   remediation=None),

 "CONTRACT.NONMONTHLY_NULL_LASTBILLINGDATE": dict(runbook_order=47, blocks=(50, 51, 52),
   remediation=_R(
     summary="Populate LastBillingDate__c on non-Monthly FSC Contracts BEFORE the FSC batch runs.",
     runbook_order=48,
     script="25_umb0116_fsc_biq_effective_dates/TF_60.01a_Set_LastBillingDate_Non_Monthly_Contracts.apex",
     writes=True, approval="Billing confirms the date rule before APPLY = true",
     steps=["Run RO 47 (TF_60.0b) first -- it reports which of the two documented rules the "
            "existing data follows.",
            "Open TF_60.01a. DATE_RULE defaults to RULE_START_DATE_MINUS_1 (per Run Book steps "
            "154-158). RULE_TODAY_OFFSET reproduces what AF160 does.",
            "Run with APPLY = false and TEST_ONE = true first. Confirm the formula "
            "billingEffectiveDateCombined__c actually resolves.",
            "Only then APPLY = true."],
     note="THIS IS THE ORIGINATING CAUSE of null FSC Effective Dates. AF160 cannot reach these "
          "Contracts -- its query filters Billing_Period__c = 'Monthly Bill Period', because "
          "UMB-0065 step 2 does. Fix here and RO 52 never fails.")),

 "CONTRACT.LASTBILLINGDATE_RULE": dict(runbook_order=47, blocks=(48,),
   remediation=_R(
     summary="Two documented rules compete for this field. Billing decides which governs.",
     runbook_order=47,
     script="31_preflight_derived_checks/TF_60.0b_Check_Monthly_LastBillingDate_Rule.apex",
     writes=False, approval="Billing",
     steps=["Run TF_60.0b and read the buckets.",
            "If values sit near today, AF160 applied the UMB-0065 rule ('today').",
            "If they are StartDate-1, Run Book steps 154-158 were applied.",
            "The value propagates through billingEffectiveDateCombined__c into the BIQ Effective "
            "Date and on to Zuora, so this is a billing decision, not a technical one."])),

 "BIQ.COVERAGE": dict(runbook_order=51, blocks=(55, 57),
   remediation=_R(
     summary="Contracts with zero BIQs will never bill. Establish cause before remediating.",
     runbook_order=51, script="25_umb0116_fsc_biq_effective_dates/TF_60.06_Verify_FSC_BIQs_Created.apex",
     writes=False,
     steps=["Compare against the baseline view -- prior batches ran 97-100%.",
            "Check Asset Location counts per Contract (TF_60.06 section A): ALs are the "
            "documented gate on createRelatedFSC silently no-opping.",
            "If the batch is Closed or Canceled in Goose, there is NO Informatica remedy -- "
            "vw_GOOSE_OpenMigrationBatches filters BatchStatus='Open' and takes MAX(ID).",
            "Escalate: once the next batch opens, this one can never be repaired through "
            "Informatica."],
     note="On UMB-0116 this was 750 of 786. AF160's only population alarm requires the BIQ count "
          "to be ZERO, so with 163 BIQs present it could never fire.")),

 "BIQ.FSC_NULL_EFFECTIVE_DATE": dict(runbook_order=52, blocks=(54, 55, 57),
   remediation=_R(
     summary="Set the Effective Date -- but confirm WHICH rule first. RO 53 gates RO 54.",
     runbook_order=54,
     script="25_umb0116_fsc_biq_effective_dates/TF_60.05_Fix_FSC_BIQs_Missing_Effective_Date.apex",
     writes=True, approval="Billing confirms the value; RO 53 must report MATCH on every row",
     steps=["RO 53 (TF_60.04b) FIRST -- it computes both competing rules per row and prints "
            "MATCH / DISAGREE.",
            "If any row DISAGREES, stop. Billing decides which rule governs, not us.",
            "If all MATCH, TF_60.05 is corroborated by two independent sources.",
            "Run TF_60.05 with APPLY = false, confirm EXPECTED_ROWS matches, then APPLY = true.",
            "Re-run RO 52 to confirm zero remain."],
     note="There is NO Goose-side remedy: these rows were created after the SFDC->Goose sync and "
          "their batch is Canceled, so both views feeding TF_75 exclude them.")),

 "BIQ.ERROR_STATUS": dict(runbook_order=55, blocks=(57,),
   remediation=_R(summary="Reset errored BIQs after the underlying cause is fixed.",
     runbook_order=55, script="11_claude_review_tooling/Reset Errored BIQs.apex", writes=True,
     approval="Confirm the cause is fixed first",
     steps=["Identify why they errored -- a null Effective Date (RO 52) is the commonest cause.",
            "Fix the cause. Resetting without fixing produces the same error again.",
            "Then reset and re-run the BIQ integration."])),

 "WO.ORDERS_MISSING_WOS": dict(runbook_order=25, blocks=(27, 30, 37),
   remediation=_R(summary="Classify the cause before regenerating -- causes need different fixes.",
     runbook_order=25, script="24_umb0116_missing_workorders/TF_90A.04_Classify_Orders_Missing_Work_Orders.apex",
     writes=False,
     steps=["Run RO 25 (TF_90A.04) to split dead polygon / no geocode / missing config.",
            "Dead polygon -> RO 26 (TF_90A.05) repoints it. Regenerating first achieves nothing.",
            "No geocode -> RO 12 (TF_25.02) should have caught it pre-conversion.",
            "No territory coverage at all -> RO 28 (TF_90A.07); Field Service must create the "
            "territory. No script can fix it.",
            "Only then RO 27 (TF_90A.06) to regenerate.",
            "Finally RO 30 (TF_90A.09) to confirm regeneration did not double-generate."])),

 "WO.MP_NO_GENERATION": dict(runbook_order=38, blocks=(39,),
   remediation=_R(summary="Touch Point 129. The documented cause was falsified -- investigate, "
                          "do not assume.",
     runbook_order=38, script="24_umb0116_missing_workorders/TF_90A.08_Check_Active_MPs_Missing_WorkOrders.apex",
     writes=False,
     steps=["Run TF_90A.08. It now requires IsGeneratedFromMaintenancePlan = true, so an MP whose "
            "only WorkOrders came from another path is correctly counted as failed.",
            "TP-129's documented cause (NULL SFDC_AccountID) does NOT hold -- retested on "
            "UMB-0116: 5 of 1,027 active MPs, zero with a null Account.",
            "The TP-129 procedure is deactivate/reactivate the MP. Informatica ships the delete "
            "half (m_25, m_30) but it is not wired to a detect-and-retrigger workflow.",
            "After any reactivation, run RO 30 to confirm it did not double-generate."])),

 "QUOTE.NOT_ORDERED": dict(runbook_order=14, blocks=(16, 25, 51),
   remediation=_R(summary="An unordered Quote produces no Order, no Work Orders and no BIQs.",
     runbook_order=14, script="31_preflight_derived_checks/TF_30.01_Check_Quotes_Not_Ordered.apex",
     writes=False,
     steps=["Resolve before RO 16 (tf_35). A Quote that never converted presents downstream as "
            "missing Work Orders (TP-129) or missing BIQs (TP-135/160), which sends the operator "
            "hunting in the wrong place entirely.",
            "Re-run tf_30 for the affected Quotes."])),

 "QUOTE.SERVICEABLE_ZIP": dict(runbook_order=13, blocks=(14,),
   remediation=_R(summary="Two different defects: a missing reference and a WRONG one.",
     runbook_order=13, script="31_preflight_derived_checks/TF_02.01_Check_Serviceable_Zip_Coverage.apex",
     writes=False, approval="Field Service creates Serviceable Zip records",
     steps=["CLASS A (missing) is a reference-data gap -- send the distinct ZIP list to Field "
            "Service to create the records.",
            "CLASS B (mismatch) is worse: it LOOKS configured and silently mis-routes. Correct "
            "the pointer; do not create a new record.",
            "Resolve before RO 14 converts the quote."])),

 "GOOSE.BIQ_PARITY": dict(runbook_order=55, blocks=(57,),
   remediation=_R(summary="Rows in Salesforce but not Goose are invisible to every Goose-side remedy.",
     runbook_order=55, script="", writes=False,
     steps=["Establish WHEN the extra rows were created relative to the SFDC->Goose sync.",
            "Rows created after the sync cannot be repaired by TF_75 -- both feeding views filter "
            "BatchStatus='Open' and the batch may be Canceled.",
            "Salesforce-side remediation is the only option for those rows."],
     note="UMB-0116: Salesforce 163 vs Goose 124. The 39-row gap WAS the finding.")),
}


# =====================================================================================
# MONITORING RATIOS  -- the highest-value checks per line of code.
# Almost every real finding this week was a RATIO compared against prior batches, or a
# NULL nobody tested. These are the ratios.
# =====================================================================================
def _ratio(c, name, total_soql, bad_soql, bad_fields, note_fmt):
    total = c.n(total_soql)
    if not total:
        return Evidence(unprovable="No population for '%s' in this batch -- nothing to measure." % name)
    bad = c.q(bad_soql)
    ok = total - len(bad)
    return Evidence(rows=bad,
                    metric=Metric(name, ok / total, "ratio", ok, total),
                    note=(note_fmt % (len(bad), total)) if bad else "")


RATIO_CHECKS = [
 Check(id="ORDER.ACTIVATION_RATE", name="Orders not Activated / not Contracted",
       stage="tf_35", sequence=110, sobject="Order", severity=BLOCKER,
       rule="Every migrated Order reaches Activated and Contracted after tf_35",
       rule_source="Run Book tf_35 / TP-97; preflight_pipeline.py TP-97 query",
       canary=lambda c: c.n("SELECT COUNT() FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name='%s'" % B),
       run=lambda c: _ratio(c, "Orders activated",
            "SELECT COUNT() FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s'" % B,
            "SELECT Id, OrderNumber, Status, SBQQ__Contracted__c FROM Order "
            "WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s' "
            "AND (Status != 'Activated' OR SBQQ__Contracted__c = false)" % B,
            (), "%d of %d Order(s) are not Activated/Contracted."),
       proves="Every Order reached Activated and Contracted",
       cannot_prove="That activation produced the right downstream records"),

 Check(id="SUB.FSC_FLAG_COVERAGE", name="Subscriptions needing the Fuel Surcharge flag",
       stage="tf_60", sequence=140, sobject="SBQQ__Subscription__c", severity=BLOCKER,
       rule="A Subscription whose Product has Apply_Fuel_Surcharge__c = true must itself have it true",
       rule_source="UMB-0065 'Adding FSC BIQs' steps 3-4; AF160 writes this",
       canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__Subscription__c WHERE "
                            "SBQQ__Contract__r.USS_Migration_Batch__r.Name='%s'" % B),
       run=lambda c: _ratio(c, "FSC flag set where required",
            "SELECT COUNT() FROM SBQQ__Subscription__c WHERE "
            "SBQQ__Contract__r.USS_Migration_Batch__r.Name='%s' "
            "AND SBQQ__Product__r.Apply_Fuel_Surcharge__c = true "
            "AND SBQQ__Contract__r.Fuel_Surcharge_Percent__c > 0" % B,
            "SELECT Id, SBQQ__Contract__r.ContractNumber, SBQQ__Product__r.Name "
            "FROM SBQQ__Subscription__c WHERE "
            "SBQQ__Contract__r.USS_Migration_Batch__r.Name='%s' "
            "AND SBQQ__Product__r.Apply_Fuel_Surcharge__c = true "
            "AND SBQQ__Contract__r.Fuel_Surcharge_Percent__c > 0 "
            "AND Apply_Fuel_Surcharge__c = false" % B,
            (), "%d of %d eligible Subscription(s) still have Apply_Fuel_Surcharge__c = false."),
       proves="Every FSC-eligible Subscription is flagged, so FuelSurchargeBatch will see it",
       cannot_prove="That the resulting BIQ is correct"),

 Check(id="WO.SERVICE_COVERAGE", name="Orders flagged for service with no Service Work Order",
       stage="tf_55", sequence=160, sobject="WorkOrder", severity=BLOCKER,
       rule="An Order with Has_Service__c = true has at least one Service WorkOrder",
       rule_source="TP-129; tf_55_Mechanics_Analysis.md confirms tf_55 has NO data-condition "
                   "check for this -- it is one of three pure-manual SOQL checks",
       canary=lambda c: c.n("SELECT COUNT() FROM Order WHERE "
                            "SBQQ__Quote__r.USS_Migration_Batch__r.Name='%s'" % B),
       run=lambda c: _service_wo_coverage(c),
       proves="Every service-flagged Order has a Service Work Order",
       cannot_prove="That the Work Order is scheduled, or on the right day"),
]
CHECKS.extend(RATIO_CHECKS)


def _service_wo_coverage(c):
    orders = c.q("SELECT Id, OrderNumber FROM Order WHERE "
                 "SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s' "
                 "AND Has_Service__c = true" % B)
    if not orders:
        return Evidence(unprovable="No Orders flagged Has_Service__c = true in this batch.")
    svc = c.q("SELECT Order__c FROM WorkOrder WHERE Order__c != null "
              "AND Work_Type_Name__c LIKE '%%Service%%' "
              "AND Contract__r.USS_Migration_Batch__r.Name = '%s'" % B) \
        if c.has_field("WorkOrder.Work_Type_Name__c") else \
        c.q("SELECT Order__c FROM WorkOrder WHERE Order__c != null "
            "AND Contract__r.USS_Migration_Batch__r.Name = '%s'" % B)
    have = {r.get("Order__c") for r in svc}
    missing = [o for o in orders if o.get("Id") not in have]
    ok = len(orders) - len(missing)
    return Evidence(rows=missing,
                    metric=Metric("Service WO coverage", ok / len(orders), "ratio", ok, len(orders)),
                    note="%d of %d service-flagged Order(s) have no Service Work Order."
                         % (len(missing), len(orders)) if missing else "")


# =====================================================================================
# LOGIC GAPS -- records that are STRUCTURALLY valid but LOGICALLY wrong.
# These load fine and pass every schema check. They are the ones that surface three
# weeks later as a billing problem.
# =====================================================================================
LOGIC_CHECKS = [
 Check(id="LOGIC.FSC_CONTRACT_NO_FLAGGED_SUB",
       name="FSC Contract with no flagged Subscription",
       stage="tf_60", sequence=130, sobject="Contract", severity=BLOCKER,
       rule="A Contract with Fuel_Surcharge_Percent__c > 0 must have >=1 Subscription with "
            "Apply_Fuel_Surcharge__c = true, or FuelSurchargeBatch produces nothing for it",
       rule_source="FuelSurchargeBatch source, read 2026-10-01",
       canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE "
                            "USS_Migration_Batch__r.Name='%s' AND Fuel_Surcharge_Percent__c > 0" % B),
       run=lambda c: _fsc_contract_no_sub(c),
       proves="Every FSC Contract can actually produce an FSC BIQ",
       cannot_prove="That the BIQ it produces carries the right dates"),

 Check(id="LOGIC.ACTIVATED_NO_STARTDATE", name="Activated Contract with no StartDate",
       stage="tf_35", sequence=130, sobject="Contract", severity=BLOCKER,
       rule="An Activated Contract has a StartDate -- every billing date derives from it",
       rule_source="Run Book steps 154-158 derive LastBillingDate from StartDate",
       canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE "
                            "USS_Migration_Batch__r.Name='%s' AND Status='Activated'" % B),
       run=lambda c: _ratio(c, "Activated Contracts with StartDate",
            "SELECT COUNT() FROM Contract WHERE USS_Migration_Batch__r.Name='%s' "
            "AND Status='Activated'" % B,
            "SELECT Id, ContractNumber, Status FROM Contract WHERE "
            "USS_Migration_Batch__r.Name='%s' AND Status='Activated' AND StartDate = null" % B,
            (), "%d of %d Activated Contract(s) have NO StartDate -- every derived billing "
                "date is unresolvable for these."),
       proves="Every Activated Contract can derive its billing dates",
       cannot_prove="That the StartDate is the right one"),

 Check(id="LOGIC.MP_ACTIVE_NO_FREQUENCY", name="Active Maintenance Plan with no Service Frequency",
       stage="tf_40", sequence=150, sobject="MaintenancePlan", severity=WARNING,
       rule="An Active MP has a Service_Frequency__c, or it cannot generate a schedule",
       rule_source="MaintenancePlan generation requires a frequency",
       canary=lambda c: c.n("SELECT COUNT() FROM MaintenancePlan WHERE "
                            "Contract__r.USS_Migration_Batch__r.Name='%s'" % B),
       run=lambda c: _ratio(c, "Active MPs with a frequency",
            "SELECT COUNT() FROM MaintenancePlan WHERE "
            "Contract__r.USS_Migration_Batch__r.Name='%s' AND Active__c = true" % B,
            "SELECT Id, MaintenancePlanNumber FROM MaintenancePlan WHERE "
            "Contract__r.USS_Migration_Batch__r.Name='%s' AND Active__c = true "
            "AND Service_Frequency__c = null" % B,
            (), "%d of %d Active MP(s) have no Service_Frequency__c."),
       proves="Every Active MP can generate a schedule",
       cannot_prove="That the frequency is correct for the contract"),

 Check(id="LOGIC.FSC_BIQ_BEFORE_GOLIVE", name="FSC BIQ dated before the FSC go-live clamp",
       stage="tf_60", sequence=200, sobject="Billing_Impacts_Queue__c", severity=WARNING,
       rule="An FSC BIQ Effective Date is clamped to >= 2022-08-01",
       rule_source="Goose sp_SFDC_20_BiqEffectiveDateUpdates -- the FSC clamp",
       canary=lambda c: c.n("SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
                            "Parent_USS_Order__r.USS_Migration_Batch__r.Name='%s' "
                            "AND Charge_Type__c LIKE '%%Fuel%%'" % B),
       run=lambda c: _ratio(c, "FSC BIQs at/after the clamp date",
            "SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
            "Parent_USS_Order__r.USS_Migration_Batch__r.Name='%s' "
            "AND Charge_Type__c LIKE '%%Fuel%%' AND Effective_Date__c != null" % B,
            "SELECT Id, BIQ_Key__c, Effective_Date__c, Processing_Status__c FROM Billing_Impacts_Queue__c "
            "WHERE Parent_USS_Order__r.USS_Migration_Batch__r.Name='%s' "
            "AND Charge_Type__c LIKE '%%Fuel%%' AND Effective_Date__c < 2022-08-01" % B,
            (), "%d of %d FSC BIQ(s) are dated before the 2022-08-01 clamp."),
       proves="No FSC BIQ predates the documented clamp",
       cannot_prove="That dates at or after the clamp are otherwise right"),
]
CHECKS.extend(LOGIC_CHECKS)


def _fsc_contract_no_sub(c):
    cons = c.q("SELECT Id, ContractNumber, Fuel_Surcharge_Percent__c FROM Contract "
               "WHERE USS_Migration_Batch__r.Name='%s' AND Status='Activated' "
               "AND Fuel_Surcharge_Percent__c > 0" % B)
    if not cons:
        return Evidence(unprovable="No FSC-eligible Contracts in this batch.")
    subs = c.q("SELECT SBQQ__Contract__c FROM SBQQ__Subscription__c WHERE "
               "SBQQ__Contract__r.USS_Migration_Batch__r.Name='%s' "
               "AND Apply_Fuel_Surcharge__c = true" % B)
    have = {r.get("SBQQ__Contract__c") for r in subs}
    missing = [x for x in cons if x.get("Id") not in have]
    ok = len(cons) - len(missing)
    return Evidence(rows=missing,
                    metric=Metric("FSC Contracts with a flagged Subscription",
                                  ok / len(cons), "ratio", ok, len(cons)),
                    note=("%d of %d FSC Contract(s) have NO Subscription with "
                          "Apply_Fuel_Surcharge__c = true. FuelSurchargeBatch will produce "
                          "nothing for these -- they are structurally fine and logically dead."
                          % (len(missing), len(cons))) if missing else "")


# =====================================================================================
# PREDICTIVE -- which records will FAIL to load, before anyone loads them.
# Schema-driven: validates candidate rows against the LIVE target metadata.
# =====================================================================================
def _predict(c, sobject, source_rows, operation="CREATE"):
    """
    One row per STAGED RECORD that Salesforce would reject -- not one per issue.

    The old version returned an issue per row, so "failing" counted problems: 500 staged rows
    with 14 issues each read as 7,000 "failing records" out of 500 examined.
    """
    import predict as pr
    try:
        meta = pr.describe_full(c.alias, sobject)
    except Exception as e:                                       # noqa: BLE001
        return Evidence(unprovable="Could not describe %s: %s" % (sobject, str(e)[:200]))
    if not source_rows:
        return Evidence(unprovable="No candidate rows available for %s. Configure a Goose "
                                   "staging view in config.json PredictTargets, or this check "
                                   "has nothing to predict on." % sobject)
    res = pr.predict_batch(meta, source_rows, operation)
    rows = []
    for r in res["per_record"]:
        if not r["blocking"]:
            continue                                  # warnings alone do not stop a load
        iss = [i for i in r["issues"] if i["severity"] == "ERROR"] or r["issues"]
        src = r.get("record") or {}
        sk = next((k for k in src if any(h in str(k).lower() for h in
                   ("legacy", "external", "source", "stg"))), None) or \
            next((k for k in src if str(k).lower() in ("id", "recordid")), None)
        rows.append({"record_index": r["index"],
                     "source_id": (str(src.get(sk))[:80] if sk and src.get(sk) is not None else ""),
                     "source_id_field": sk or "",
                     "issue_count": len(iss),
                     "first_issue": iss[0]["type"], "first_field": iss[0]["field"],
                     "issues": "; ".join("%s (%s)" % (i["field"], i["type"]) for i in iss)[:600],
                     "failed_values": "; ".join("%s = %r" % (i["field"], i.get("value")) for i in iss)[:900],
                     "why": " | ".join(str(i.get("message") or i["type"]) for i in iss)[:1200]})
    ratio = ((res["records_checked"] - res["records_blocked"]) / res["records_checked"]) \
        if res["records_checked"] else 0.0
    ev = Evidence(rows=rows, processed=res["records_checked"],
                  metric=Metric("%s records that will load" % sobject, ratio, "ratio",
                                res["records_checked"] - res["records_blocked"],
                                res["records_checked"]),
                  note=res["headline"])
    ev.patterns = res["patterns"]
    return ev


def _predict_targets(c):
    """config.json: {"PredictTargets": {"SBQQ__QuoteLine__c": "vw_SFDC_OpenBatch_Quote_Line"}}"""
    return (c.cfg.get("PredictTargets") or {})


def _goose_status_for_batch(c):
    """-> (status, why_not). The staging views describe the OPEN batch; is this one it?"""
    sfid = c.sf_batch_id()
    if not sfid:
        return "", "could not resolve the Salesforce Id of %s" % c.batch
    try:
        mb = c.gq("SELECT TOP 1 mb.BatchStatus AS BatchStatus FROM dbo.MigrationBatch mb "
                  "WHERE mb.SalesforceUssMigrationBatchID = '%s'" % sfid)
    except Exception as e:                                       # noqa: BLE001
        return "", "could not read the batch from Goose (%s)" % str(e)[:120]
    if not mb:
        return "", "Goose has no MigrationBatch for %s" % c.batch
    return str(mb[0].get("BatchStatus") or "").strip(), ""


def _predict_check(c):
    targets = _predict_targets(c)
    if not targets:
        return Evidence(unprovable="No PredictTargets configured. Add e.g. "
                                   '{"PredictTargets": {"SBQQ__QuoteLine__c": '
                                   '"vw_SFDC_OpenBatch_Quote_Line"}} to config.json.')
    if not c.goose_ok:
        return Evidence(unprovable="GOOSE UNAVAILABLE -- staged rows are the input to prediction.")

    # The views are named OpenBatch: they hold whichever batch is Open in Goose. If that is
    # not this batch, every number below would describe a different batch.
    status, why = _goose_status_for_batch(c)
    if why:
        return Evidence(unprovable="Cannot tell whether the staging views hold this batch: %s." % why)
    if status.lower() != "open":
        return Evidence(unprovable=(
            "%s is '%s' in Goose, not Open. The staging views (%s) show the Open batch, so "
            "they are not this batch's rows and are not counted against it."
            % (c.batch, status or "no status", ", ".join(targets.values()))))

    allrows, notes, mixed = [], [], []
    num = den = 0
    for sobject, view in targets.items():
        try:
            src = c.gq("SELECT * FROM dbo.%s" % view)            # every staged row, no TOP
        except Exception as e:                                   # noqa: BLE001
            notes.append("%s: could not read %s (%s)" % (sobject, view, str(e)[:120]))
            continue
        ev = _predict(c, sobject, src, "CREATE")
        if ev.unprovable:
            notes.append("%s: %s" % (sobject, ev.unprovable)); continue
        pats = getattr(ev, "patterns", []) or []
        n_rec = ev.metric.denominator if ev.metric else 0
        # Every row failing, for many different reasons, is far more likely to mean the view
        # does not line up with the Salesforce fields than that every row is bad.
        top = max((p.get("count", 0) for p in pats), default=0)
        if n_rec >= 20 and len(ev.rows) == n_rec and (len(pats) >= 5 or top >= 0.9 * n_rec):
            mixed.append("%s: all %d staged row(s) fail, across %d different patterns (%s)"
                         % (sobject, n_rec, len(pats),
                            ", ".join("%s on %s" % (p["type"], p["field"]) for p in pats[:3])))
            continue
        for r in ev.rows:
            r["sobject"] = sobject
        allrows.extend(ev.rows)
        notes.append("%s (all %d staged rows in %s): %s" % (sobject, n_rec, view, ev.note))
        if ev.metric:
            num += ev.metric.numerator; den += ev.metric.denominator
    if mixed and not allrows:
        return Evidence(unprovable=(
            "Not counted as a finding. " + " | ".join(mixed) + ". When every row fails for "
            "many different reasons, the staging view probably does not match the Salesforce "
            "field names or types, rather than every record being bad. Compare one staged "
            "row to its target fields before believing this." + (" | " + " | ".join(notes) if notes else "")))
    if not den:
        return Evidence(unprovable="No staged rows could be read. " + " | ".join(notes))
    if mixed:
        notes.append("NOT COUNTED: " + " | ".join(mixed))
    return Evidence(rows=allrows, processed=den,
                    metric=Metric("Staged records that will load", num / den, "ratio", num, den),
                    note=" | ".join(notes))


CHECKS.append(
 Check(id="PREDICT.LOAD_FAILURES", name="Staged records that will FAIL to load",
       stage="pre", sequence=90, sobject="SBQQ__QuoteLine__c", severity=BLOCKER,
       needs_goose=True,
       rule="Every staged record validates against the LIVE target schema: active picklist "
            "values, field lengths, types, createable flags, required fields",
       rule_source="Salesforce describe of the target org -- ground truth, and it shares no "
                   "specification with the mapping being checked",
       canary=lambda c: 1,
       run=_predict_check,
       proves="These records will not be rejected by Salesforce for a schema or picklist reason",
       cannot_prove="That the VALUES are business-correct, or that triggers/validation rules "
                    "will not reject them -- this predicts platform rejections only"))


BINDINGS.update({
 "ORDER.ACTIVATION_RATE": dict(runbook_order=16, blocks=(25, 27, 51),
   remediation=_R(summary="Re-run activation for the Orders that did not reach Activated/Contracted.",
     runbook_order=23, script="10_real_numbered_scripts/Script_05a (Activate Non-Contracted Orders)",
     writes=True, approval="Batch scope guard must name the batch before running",
     steps=["RO 17 (Restart failed step in TF_35) handles the Informatica side.",
            "RO 23 (TF_90A.01) activates non-contracted Orders Salesforce-side.",
            "Monitor the Apex job queue -- activation fires FSL automation.",
            "Re-run this check; it must reach 100% before RO 25 is meaningful.",
            "AF35_ORDER_RECOVERY may already have done this -- check before double-submitting."],
     note="TP-97, ~2 hrs/batch manually. AF35 automates it but refuses to run against a "
          "floating batch scope.")),

 "SUB.FSC_FLAG_COVERAGE": dict(runbook_order=49, blocks=(50, 51),
   remediation=_R(summary="Set Apply_Fuel_Surcharge__c = true on the eligible Subscriptions.",
     runbook_order=49, script="11_claude_review_tooling/AF160_FSC_Subscription_Fix_UMB0114_2026-09-25.apex",
     writes=True, approval="None -- the rule is unambiguous (product flag drives subscription flag)",
     steps=["UMB-0065 step 3 gives the query; step 4 says update via Inspector.",
            "AF160_FSC_BIQ_VALIDATION automates this (candidate type SUBSCRIPTION_FSC_FLAG_REQUIRED).",
            "Must be done BEFORE RO 50 creates the BIQs -- FuelSurchargeBatch only sees flagged subs.",
            "Re-run this check; 100% before proceeding."])),

 "WO.SERVICE_COVERAGE": dict(runbook_order=37, blocks=(39, 42),
   remediation=_R(summary="Split the cause: no WOs at all vs Delivery/Pickup present but no Service.",
     runbook_order=37, script="24_umb0116_missing_workorders/TF_55.0y_Check_For_Missing_Service_Work_Orders.apex",
     writes=False,
     steps=["Orders with NO WorkOrders at all -> RO 25 (TF_90A.04) for cause classification.",
            "Orders with Delivery/Pickup but no Service -> the MP side, RO 38.",
            "tf_55 has NO data-condition check for this -- it is a pure-manual SOQL check, "
            "which is why it needs its own step."])),

 "LOGIC.FSC_CONTRACT_NO_FLAGGED_SUB": dict(runbook_order=49, blocks=(50, 51, 52),
   remediation=_R(summary="These Contracts are structurally fine and logically dead -- "
                          "FuelSurchargeBatch will produce nothing for them.",
     runbook_order=49, script="11_claude_review_tooling/Verify_FuelSurchargeEligibility_REPEATABLE_2026-09-28.apex",
     writes=False,
     steps=["Confirm the Contract SHOULD carry fuel surcharge (Fuel_Surcharge_Percent__c > 0 "
            "is the claim).",
            "Find the Subscription whose Product has Apply_Fuel_Surcharge__c = true.",
            "If no such Subscription exists, the problem is upstream in product configuration, "
            "not in the FSC step -- escalate rather than forcing a flag.",
            "If it exists but is unflagged, RO 49 fixes it."],
     note="This is a LOGIC gap, not an error. Nothing rejects these records; they simply "
          "never produce the BIQ anyone expects.")),

 "LOGIC.ACTIVATED_NO_STARTDATE": dict(runbook_order=18, blocks=(47, 48, 50),
   remediation=_R(summary="Every derived billing date is unresolvable without a StartDate.",
     runbook_order=18, script="", writes=False,
     steps=["Trace the Contract back to its Quote and Goose staging row.",
            "A null StartDate on an Activated Contract means the activation path skipped it -- "
            "this is a data problem, not a date problem.",
            "TF_60.01a EXCLUDES these rather than guessing a date."])),

 "LOGIC.MP_ACTIVE_NO_FREQUENCY": dict(runbook_order=41, blocks=(38,),
   remediation=_R(summary="An Active MP with no frequency cannot generate a schedule.",
     runbook_order=41, script="", writes=False,
     steps=["Check the source Quote Line service configuration.",
            "NF_MaintenancePlanLineMappingClass defaults Active__c to false -- an MP that is "
            "Active with no frequency has been activated by something that did not set it."])),

 "LOGIC.FSC_BIQ_BEFORE_GOLIVE": dict(runbook_order=52, blocks=(55,),
   remediation=_R(summary="Clamp FSC effective dates to the 2022-08-01 go-live.",
     runbook_order=54, script="25_umb0116_fsc_biq_effective_dates/TF_60.05_Fix_FSC_BIQs_Missing_Effective_Date.apex",
     writes=True, approval="Billing",
     steps=["The Goose proc sp_SFDC_20_BiqEffectiveDateUpdates clamps FSC dates to >= 2022-08-01.",
            "A date before that will bill for a period before fuel surcharge existed.",
            "Confirm with Billing, then correct."])),

 "PREDICT.LOAD_FAILURES": dict(runbook_order=3, blocks=(5, 7, 9, 14),
   remediation=_R(summary="Fix the PATTERN, not the records. One decision usually clears most of them.",
     runbook_order=3, script="32_preflight_optimization/PREFLIGHT_OPTIMIZATION_SPEC.md",
     writes=False, approval="Salesforce admin for picklist values; mapping owner for fields",
     steps=["Read the pattern rollup, not the record list. On the 2026-09-18 baseline, 84% of "
            "1,459 errors were ONE inactive picklist value.",
            "RESTRICTED_PICKLIST with a single distinct value -> activate the value, or map it "
            "to the active equivalent. One decision.",
            "FIELD_NOT_CREATEABLE -> remove it from the create payload; write it post-create "
            "if the value is genuinely needed.",
            "FIELD_NOT_FOUND on a managed-package field (ZSB__, SBQQ__, FSL__) -> refresh the "
            "field-constraints bundle BEFORE believing it is absent.",
            "REQUIRED_FIELD_MISSING -> the mapping does not populate a required field; that is "
            "a registry gap, not a data gap.",
            "Re-run until the pattern count is zero, then load."],
     note="Predicts PLATFORM rejections only -- schema, picklists, lengths, types, required "
          "fields. It cannot predict trigger or validation-rule rejections.")),
})


# =====================================================================================
# DID THE JOB RUN?  -- step output counts
#
# The most reliable evidence that an Informatica or SnapLogic job ran for a batch is
# WHAT IT PRODUCED. A job status API tells you a process exited 0; a record count tells
# you the batch actually has the records that step exists to create. The second is the
# question that matters, and it needs only Salesforce.
#
# These also populate the run book table -- every step below stops showing NOT CHECKED.
# =====================================================================================
STEP_OUTPUTS = [
 # (run_order, id, label, sobject, count SOQL, what the step is)
 # ------------------------------------------------------------------------------------
 # ACCOUNT SCOPING -- these three were WRONG and reported a false blocker.
 #
 # They scoped through Account.USS_Migration_Batch__c. In an ACQUISITION ONBOARDING the
 # Accounts ALREADY EXIST in Salesforce and are never tagged with the batch, so that
 # field is null on every one of them and the count was always 0 -- which the tool then
 # reported as "PL_07 produced NOTHING", a blocker, on a batch where PL_07 was fine.
 # Repo folder 08 documents the correct path: reach Accounts through the batch's QUOTES,
 # which DO carry USS_Migration_Batch__c.
 #
 # Note what this means for timing: PL_07 UPDATES pre-existing Accounts rather than
 # creating them, so CreatedDate is old and irrelevant. LastModifiedDate is the evidence
 # that the pipeline touched them, which is why _made reports it separately.
 # ------------------------------------------------------------------------------------
 (5,  "RAN.PL_07_ACCOUNTS",  "PL_07 Accounts reachable from this batch", "Account",
      "SELECT COUNT() FROM Account WHERE Id IN "
      "(SELECT SBQQ__Account__c FROM SBQQ__Quote__c "
      "WHERE USS_Migration_Batch__r.Name = '{B}' AND SBQQ__Account__c != null)",
      "SnapLogic PL_07 Accounts and Contacts"),
 (5,  "RAN.PL_07_CONTACTS",  "PL_07 Contacts on this batch's Accounts", "Contact",
      "SELECT COUNT() FROM Contact WHERE AccountId IN "
      "(SELECT SBQQ__Account__c FROM SBQQ__Quote__c "
      "WHERE USS_Migration_Batch__r.Name = '{B}' AND SBQQ__Account__c != null)",
      "SnapLogic PL_07 Accounts and Contacts"),
 (7,  "RAN.PL_10_ACR",       "PL_10 Account Contact Relations on this batch's Accounts",
      "AccountContactRelation",
      "SELECT COUNT() FROM AccountContactRelation WHERE AccountId IN "
      "(SELECT SBQQ__Account__c FROM SBQQ__Quote__c "
      "WHERE USS_Migration_Batch__r.Name = '{B}' AND SBQQ__Account__c != null)",
      "SnapLogic PL_10 AccountContactRelations"),
 (8,  "RAN.TF_15_QUOTES",    "TF_15 produced Quotes", "SBQQ__Quote__c",
      "SELECT COUNT() FROM SBQQ__Quote__c WHERE USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_15 Opportunities to Quotes"),
 (9,  "RAN.TF_20_QUOTELINES", "TF_20 produced Quote Lines", "SBQQ__QuoteLine__c",
      "SELECT COUNT() FROM SBQQ__QuoteLine__c WHERE "
      "SBQQ__Quote__r.USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_20 Quote Lines to Job Sites"),
 (14, "RAN.TF_30_ORDERS",    "TF_30 produced Orders", "Order",
      "SELECT COUNT() FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_30 Convert Quote to Order"),
 (16, "RAN.TF_35_CONTRACTS", "TF_35 produced Activated Contracts", "Contract",
      "SELECT COUNT() FROM Contract WHERE USS_Migration_Batch__r.Name = '{B}' "
      "AND Status = 'Activated'",
      "Informatica TF_35 Activate FSL Order"),
 (32, "RAN.TF_40_MPS",       "TF_40 produced Maintenance Plans", "MaintenancePlan",
      "SELECT COUNT() FROM MaintenancePlan WHERE Contract__r.USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_40 Update MP Days"),
 (36, "RAN.TF_55_WORKORDERS", "TF_55 produced Work Orders", "WorkOrder",
      "SELECT COUNT() FROM WorkOrder WHERE Contract__r.USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_55 Complete Delivery/First Service WOs"),
 (36, "RAN.TF_55_WOLIS",     "TF_55 produced Work Order Line Items", "WorkOrderLineItem",
      "SELECT COUNT() FROM WorkOrderLineItem WHERE "
      "WorkOrder.Contract__r.USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_55 Complete Delivery/First Service WOs"),
 (45, "RAN.TF_60_APPOINTMENTS", "TF_60 produced Service Appointments", "ServiceAppointment",
      "SELECT COUNT() FROM ServiceAppointment WHERE "
      "Work_Order__r.Contract__r.USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_60 FSL Scheduling Updates and BIQs"),
 (45, "RAN.TF_60_BIQS",      "TF_60 produced BIQs", "Billing_Impacts_Queue__c",
      "SELECT COUNT() FROM Billing_Impacts_Queue__c WHERE "
      "Parent_USS_Order__r.USS_Migration_Batch__r.Name = '{B}'",
      "Informatica TF_60 FSL Scheduling Updates and BIQs"),
]


def _made(label, soql, job):
    """
    Did the step run, when, and what did it produce?

    THREE independent signals, kept separate because each can be true while the others
    are false:

      produced   how many records exist for this batch -- the only signal that needs
                 nothing but Salesforce, and the one that actually matters
      written    MIN/MAX CreatedDate and MAX LastModifiedDate of those records: when
                 rows landed. A PROXY for the run window, not the run window.
      reported   the orchestrator's OWN start/end/status, as captured by the Sunrise MCC
                 app from the Informatica and SnapLogic APIs. Authoritative when present.

    The combinations are the point. "API says SUCCESS, produced 0" is a different and
    far more serious finding than "no API record, produced 0" -- the first means the job
    ran clean against the wrong batch, the second means nobody knows if it ran at all.
    """
    def run(c):
        q = soql.replace("{B}", c.batch)
        st = jobruns.window_from_stamps(c, q)
        n = st["count"]
        if n is None:                      # aggregate refused; fall back to the plain count
            n = c.n(q)
            st = dict(first="", last="", modified="", source="")

        api = c.job_run(job)
        ran_from = ran_to = run_status = run_source = ""
        if api:
            ran_from, ran_to = api.get("started", ""), api.get("ended", "")
            run_status = api.get("status", "")
            run_source = "%s API (captured %s)" % (api.get("system", ""), api.get("source", ""))
        elif st.get("first") or st.get("last"):
            ran_from, ran_to = st.get("first", ""), st.get("last", "")
            run_status = ""
            run_source = "record stamps (first/last row written, NOT the job clock)"

        api_failed = bool(api) and not api.get("succeeded") and \
            str(run_status).upper() not in ("", "RUNNING", "TRIGGERED", "QUEUED", "STARTING")

        bits = []
        if api:
            bits.append("%s reports %s" % (api.get("system", "orchestrator"),
                                           run_status or "an unknown status"))
        if st.get("modified") and st.get("last") and st["modified"] > st["last"]:
            bits.append("last modified %s (later than creation -- this step UPDATED rows)"
                        % st["modified"][:19])
        tail = (" " + "; ".join(bits) + ".") if bits else ""

        # A failed job with records is still a failure: partial output is the worst case,
        # because every count downstream looks plausible.
        if api_failed:
            rows = [{"job": job, "produced": n, "orchestrator_status": run_status,
                     "run_id": api.get("run_id", ""), "started": ran_from, "ended": ran_to}]
            note = ("%s reports status %s for this run. It produced %d record(s) -- a failed "
                    "job that produced SOME records is the worst case, because every "
                    "downstream count looks plausible." % (job, run_status, n))
        elif n:
            rows = []
            note = "%s produced %d record(s).%s" % (job, n, tail)
        else:
            rows = [{"job": job, "produced": 0, "orchestrator_status": run_status or "no record",
                     "started": ran_from, "ended": ran_to}]
            if api and api.get("succeeded"):
                note = ("%s produced NOTHING for this batch, yet %s reports it SUCCEEDED. It "
                        "ran clean against a different batch, or its scope is wrong.%s"
                        % (job, api.get("system", "the orchestrator"), tail))
            else:
                note = ("%s produced NOTHING for this batch. Either it never ran, it failed, or "
                        "it ran against a different batch.%s" % (job, tail))

        return Evidence(rows=rows, processed=n,
                        metric=Metric(label, float(n), "count", n, 0),
                        note=note, ran_from=ran_from, ran_to=ran_to,
                        run_status=run_status, run_source=run_source)
    return run


for _ro, _id, _label, _obj, _soql, _job in STEP_OUTPUTS:
    CHECKS.append(Check(
        id=_id, name=_label, stage="ran", sequence=0, sobject=_obj, severity=BLOCKER,
        rule="%s must produce records for a batch it ran against" % _job,
        rule_source="Run Book step sequence; the job's output is the evidence it ran",
        canary=(lambda c: 1),
        run=_made(_label, _soql, _job),
        proves="This step produced records for this batch, so the job ran and wrote something",
        cannot_prove="That the COUNT is right, or that the records are correct. A job can "
                     "run, succeed, and produce too few rows."))
    BINDINGS[_id] = dict(runbook_order=_ro, blocks=(),
      remediation=_R(summary="%s produced nothing. Check whether the job ran for this batch." % _job,
        runbook_order=_ro, script="", writes=False,
        steps=["Confirm the job was actually run FOR THIS BATCH -- a job that ran against a "
               "different open batch looks identical from here.",
               "Check GOOSE_ErrorLog for failures in that step's window (RO 4).",
               "In Informatica/IDMC, open the taskflow's activity log for the run window.",
               "Re-run the step if it did not run; investigate the log if it ran and failed."]))


# ------------------------------------------------------------------ Goose error log
def _goose_errorlog(c):
    """
    Column names in GOOSE_ErrorLog are NOT assumed -- the existing repeatable SQL
    deliberately discovers them first, and so does this. Guessing a batch column here
    would produce a confident wrong answer.
    """
    try:
        cols = c.gq("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS "
                    "WHERE TABLE_NAME = 'GOOSE_ErrorLog' ORDER BY ORDINAL_POSITION")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read GOOSE_ErrorLog columns: %s" % str(e)[:200])
    if not cols:
        return Evidence(unprovable="GOOSE_ErrorLog not found in this database.")
    names = [str(x.get("COLUMN_NAME") or "") for x in cols]
    lower = {n.lower(): n for n in names}

    status_col = next((lower[k] for k in ("status", "errorstatus", "state") if k in lower), "")
    batch_col = next((lower[k] for k in ("migrationbatchid", "batchid", "migrationid",
                                         "batch_id") if k in lower), "")

    where = []
    if status_col:
        where.append("%s IN ('Open','OPEN','New','Error')" % status_col)

    # SCOPE IT TO THIS BATCH, or do not call it a finding. This used to find a batch column,
    # say "scoped", and then count the whole table: 54,358 open errors across EVERY batch
    # blocked RO 5, 7 and 8 on UMB-0117. A count that cannot be tied to the batch is not
    # evidence against the batch.
    if not batch_col:
        return Evidence(unprovable="GOOSE_ErrorLog has no batch column (columns: %s), so open "
                                   "errors cannot be tied to this batch. Not counted against it."
                                   % ", ".join(names[:12]))
    sfid = c.sf_batch_id()
    if not sfid:
        return Evidence(unprovable="Could not resolve the Salesforce Id of batch %s, so the "
                                   "error log cannot be scoped to it." % c.batch)
    try:
        mb = c.gq("SELECT TOP 1 mb.ID AS ID, mb.MigrationID AS MigrationID "
                  "FROM dbo.MigrationBatch mb WHERE mb.SalesforceUssMigrationBatchID = '%s'" % sfid)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read this batch from Goose: %s" % str(e)[:200])
    if not mb:
        return Evidence(unprovable="Goose has no MigrationBatch for %s, so the error log cannot "
                                   "be scoped to it." % c.batch)
    key = mb[0].get("MigrationID") if batch_col.lower() == "migrationid" else mb[0].get("ID")
    if key is None or str(key).strip() == "":
        return Evidence(unprovable="Goose has no %s value for this batch." % batch_col)
    lit = str(key).strip()
    lit = lit if lit.lstrip("-").isdigit() else "'%s'" % lit.replace("'", "''")
    where.append("%s = %s" % (batch_col, lit))
    sql = "SELECT COUNT_BIG(*) AS C FROM dbo.GOOSE_ErrorLog WHERE " + " AND ".join(where)
    try:
        n = c.gn(sql)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="GOOSE_ErrorLog count failed: %s" % str(e)[:200])

    kind = "open error" if status_col else "error"
    caveat = "" if status_col else " The log has no status column, so resolved errors are included."
    note = (("%d %s row(s) in GOOSE_ErrorLog for this batch (%s = %s).%s" % (n, kind, batch_col, key, caveat))
            if n else "No %ss in GOOSE_ErrorLog for this batch." % kind)
    return Evidence(rows=[{"open_errors": n, "scoped_to_batch": True, "scoped_by": batch_col,
                           "columns": ", ".join(names[:15])}] if n else [],
                    metric=Metric("GOOSE_ErrorLog open errors", float(n), "count", n, 0),
                    note=note)


CHECKS.append(Check(
    id="RAN.GOOSE_ERRORLOG", name="Goose pipeline error log",
    stage="ran", sequence=0, sobject="USS_Migration_Batch__c", severity=BLOCKER,
    needs_goose=True,
    rule="The Goose pipeline error log has no open errors for this run",
    rule_source="Run Book 'Check GOOSE_ErrorLog for errors'; "
                "Verify_GooseErrorLog_REPEATABLE_2026-09-28.sql",
    canary=lambda c: 1, run=_goose_errorlog,
    proves="The staging pipeline logged no open errors",
    cannot_prove="That a job ran at all -- a job that never started logs nothing"))
BINDINGS["RAN.GOOSE_ERRORLOG"] = dict(runbook_order=4, blocks=(5, 7, 8),
  remediation=_R(summary="Open errors in the Goose pipeline log.",
    runbook_order=4, script="11_claude_review_tooling/Verify_GooseErrorLog_REPEATABLE_2026-09-28.sql",
    writes=False,
    steps=["Run the repeatable SQL to see the real rows and columns.",
           "Open errors mean the SnapLogic/Informatica step logged failures -- read them "
           "before running anything downstream.",
           "Re-run this at the END of the batch as well; the Run Book has it twice."],
    note="Column names are discovered, not assumed. If no batch column exists, the count is "
         "whole-table and is labelled as such rather than silently presented as batch-scoped."))


# =====================================================================================
# WHAT ACTUALLY WENT WRONG ON THE UMB-0116 QA LOAD
# Every check below exists because a specific thing happened and cost specific orders.
# Sources: the UMB-0116 QA run book notes, and the load report.
# =====================================================================================
def _missing_pbe(c):
    lines = c.q("SELECT Id, Name, SBQQ__Product__c, SBQQ__Product__r.ProductCode, "
                "SBQQ__Product__r.Name, SBQQ__Quote__c, SBQQ__Quote__r.Name, "
                "SBQQ__Quote__r.SBQQ__PriceBook__c "
                "FROM SBQQ__QuoteLine__c "
                "WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s'" % B)
    if not lines:
        return Evidence(unprovable="No Quote Lines in this batch -- see QUOTE.NO_LINES.")
    prods, pbs, pending = set(), set(), []
    bad = []
    for l in lines:
        p = l.get("SBQQ__Product__c")
        pb = l.get("SBQQ__Quote__r.SBQQ__PriceBook__c")
        if not p:
            d = dict(l); d["issue"] = "Quote Line has NO Product"; bad.append(d); continue
        if not pb:
            d = dict(l); d["issue"] = "Quote has NO Pricebook"; bad.append(d); continue
        prods.add(p); pbs.add(pb); pending.append((l, p, pb))
    live = set()
    ids = sorted(prods)
    for i in range(0, len(ids), 200):
        chunk = ids[i:i + 200]
        clause = ",".join("'%s'" % x for x in chunk)
        pbl = ",".join("'%s'" % x for x in sorted(pbs))
        if not clause or not pbl:
            continue
        for pe in c.q("SELECT Product2Id, Pricebook2Id FROM PricebookEntry "
                      "WHERE IsActive = true AND Product2Id IN (%s) AND Pricebook2Id IN (%s)"
                      % (clause, pbl)):
            live.add("%s|%s" % (pe.get("Product2Id"), pe.get("Pricebook2Id")))
    quotes = set()
    for l, p, pb in pending:
        if "%s|%s" % (p, pb) not in live:
            d = dict(l)
            d["issue"] = "Product has NO ACTIVE PricebookEntry in this Pricebook"
            bad.append(d); quotes.add(l.get("SBQQ__Quote__c"))
    ok = len(lines) - len(bad)
    return Evidence(rows=bad,
                    metric=Metric("Quote Lines that can convert", ok / len(lines), "ratio",
                                  ok, len(lines)),
                    note=("%d of %d Quote Line(s) cannot convert, across %d quote(s). Each "
                          "affected QUOTE becomes a pulled ORDER at tf_30 -- this is what cost "
                          "70 orders on UMB-0116." % (len(bad), len(lines), len(quotes)))
                    if bad else "")


def _quotes_no_lines(c):
    quotes = c.q("SELECT Id, Name, SBQQ__Status__c, SBQQ__Account__r.Name "
                 "FROM SBQQ__Quote__c WHERE USS_Migration_Batch__r.Name = '%s'" % B)
    if not quotes:
        return Evidence(unprovable="No Quotes in this batch.")
    withlines = c.q("SELECT SBQQ__Quote__c FROM SBQQ__QuoteLine__c "
                    "WHERE SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s'" % B)
    have = {r.get("SBQQ__Quote__c") for r in withlines}
    empty = [q for q in quotes if q.get("Id") not in have]
    ok = len(quotes) - len(empty)
    return Evidence(rows=empty,
                    metric=Metric("Quotes with lines", ok / len(quotes), "ratio", ok, len(quotes)),
                    note=("%d of %d Quote(s) have NO lines and will convert to nothing at tf_30. "
                          "Cost 18 orders on UMB-0116. NOTE: this cannot see a quote that got "
                          "2 lines when it should have had 5 -- that needs the Goose comparison."
                          % (len(empty), len(quotes))) if empty else "")


def _step_finished(c):
    live = c.q("SELECT Id, ApexClass.Name, Status, JobType, JobItemsProcessed, TotalJobItems, "
               "NumberOfErrors, CreatedDate FROM AsyncApexJob "
               "WHERE Status IN ('Queued','Processing','Preparing','Holding')")
    failed = c.q("SELECT Id, ApexClass.Name, Status, NumberOfErrors, ExtendedStatus "
                 "FROM AsyncApexJob WHERE Status IN ('Failed','Aborted') "
                 "AND CompletedDate = LAST_N_DAYS:1")
    rows = []
    for j in live:
        d = dict(j); d["issue"] = "STILL RUNNING -- the step is not finished"; rows.append(d)
    for j in failed:
        d = dict(j); d["issue"] = "FAILED/ABORTED in the last day"; rows.append(d)
    return Evidence(rows=rows,
                    metric=Metric("Async jobs in flight", float(len(live)), "count", len(live), 0),
                    note=("%d async job(s) still running, %d failed in the last day. A step can "
                          "announce completion while Salesforce is still writing -- the UMB-0116 "
                          "run book records this twice, on tf_40 and tf_60."
                          % (len(live), len(failed))) if rows else "")


QA_CHECKS = [
 Check(id="QUOTE.MISSING_PRICEBOOK_ENTRY",
       name="Quote Lines whose Product has no active PricebookEntry",
       stage="tf_25", sequence=90, sobject="SBQQ__QuoteLine__c", severity=BLOCKER,
       rule="Every Quote Line's Product has an ACTIVE PricebookEntry in the Quote's Pricebook",
       rule_source="UMB-0116 run book, tf_30: 'Pulled an additional 70 orders because "
                   "PricebookEntryID is missing.' The Sept 18 preflight saw this as a "
                   "transformation gap (1,233 rows) and never as an error.",
       canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__QuoteLine__c WHERE "
                            "SBQQ__Quote__r.USS_Migration_Batch__r.Name='%s'" % B),
       run=_missing_pbe,
       proves="Every Quote Line can convert -- tf_30 will not pull orders for this reason",
       cannot_prove="That the PRICE on the entry is right"),

 Check(id="QUOTE.NO_LINES", name="Quotes with no Quote Lines",
       stage="tf_20", sequence=80, sobject="SBQQ__Quote__c", severity=BLOCKER,
       rule="Every Quote in a migrated batch has at least one Quote Line",
       rule_source="UMB-0116: '23 order line items were never turned into quote lines'; "
                   "18 orders pulled. Cause is upstream in Goose.",
       canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__Quote__c WHERE "
                            "USS_Migration_Batch__r.Name='%s'" % B),
       run=_quotes_no_lines,
       proves="No Quote will convert to an empty Order",
       cannot_prove="That every EXPECTED line arrived. A quote that should have 5 lines and "
                    "has 2 passes this. Use GOOSE_Expected_Vs_Actual_QuoteLines.sql."),

 # REVIEW, not BLOCKER: AsyncApexJob has no batch, so this counts every job running in the whole
# org. In a shared sandbox that is never zero (41 running, unrelated to UMB-0117), and as a
# blocker it marked RO 5 BLOCKED for work that has nothing to do with the batch.
 Check(id="RAN.STEP_NOT_FINISHED", name="Async Apex still running in the org (not tied to this batch)",
       stage="ran", sequence=0, sobject="USS_Migration_Batch__c", severity=WARNING,
       rule="No async Apex is running when a step is declared complete",
       rule_source="UMB-0116 run book: tf_40 'sends premature Slack Msg. Check Informatica'; "
                   "tf_60 'Sends premature Slack. Check job status in Informatica'. "
                   "Sunrise's wait_for_stable covers only 5 of 17 steps and tf_40 is not one.",
       canary=lambda c: 1, run=_step_finished,
       proves="Salesforce is not still writing, so a validation run now is meaningful",
       cannot_prove="That the Informatica/SnapLogic side finished -- this sees Salesforce only"),
]
CHECKS.extend(QA_CHECKS)

BINDINGS.update({
 "QUOTE.MISSING_PRICEBOOK_ENTRY": dict(runbook_order=11, blocks=(13, 14, 16),
   remediation=_R(summary="Create the missing PricebookEntries BEFORE tf_30. One per product, "
                          "not one per order.",
     runbook_order=11, script="34_umb0116_qa_load_failures/TF_25.03_Check_Missing_PricebookEntry.apex",
     writes=False, approval="Salesforce admin creates the PricebookEntry records",
     steps=["Run TF_25.03. It separates three causes: no Product, no Pricebook on the Quote, "
            "and no ACTIVE PricebookEntry.",
            "The third bucket is the 70-order case. It lists DISTINCT PRODUCTS -- fix is one "
            "PricebookEntry per product, not one per order.",
            "Have the Salesforce admin create them in the Quote's pricebook, active.",
            "Re-run until zero, then run tf_30.",
            "ROOT CAUSE: the mapping does not populate SBQQ__PricebookEntryId__c at all. Five "
            "QuoteLine fields failed at exactly 1,233 rows each in the Sept 18 preflight -- "
            "identical counts mean a MISSING MAPPING, not missing data. Fix the registry entry "
            "or this returns every batch."])),

 "QUOTE.NO_LINES": dict(runbook_order=9, blocks=(11, 13, 14),
   remediation=_R(summary="A Quote with no lines converts to nothing. Pull it or fix the source.",
     runbook_order=9, script="34_umb0116_qa_load_failures/TF_25.04_Check_Quotes_With_No_Lines.apex",
     writes=False,
     steps=["Run TF_25.04 for the Salesforce symptom -- quotes with zero lines.",
            "Run GOOSE_Expected_Vs_Actual_QuoteLines.sql for the cause. It discovers the real "
            "column names first rather than assuming them.",
            "A quote with FEWER lines than expected is more dangerous than one with none -- it "
            "looks healthy and bills wrong. Only the Goose comparison finds those.",
            "Pull the affected orders from the batch, or fix the staging data, before tf_30."],
     note="On UMB-0116 this was 18 orders / 23 line items, described as 'an issue on the Goose "
          "side'.")),

 "RAN.STEP_NOT_FINISHED": dict(runbook_order=4, blocks=(),
   remediation=_R(summary="Do not validate a step while Salesforce is still writing.",
     runbook_order=4, script="34_umb0116_qa_load_failures/TF_00.03_Check_Step_Actually_Finished.apex",
     writes=False,
     steps=["Run TF_00.03 after any Informatica/SnapLogic step, BEFORE validating it.",
            "Async Apex in Queued/Processing/Preparing means the step is NOT done, whatever "
            "Slack said.",
            "Also check the failed/aborted list -- a step can 'finish' with failed jobs behind it.",
            "Re-run after two minutes; if every count is identical, it is genuinely settled.",
            "Then validate."],
     note="Validating too early is worse than not validating: records that would have failed may "
          "not exist yet, so the check reports CLEAN.")),
})


# =====================================================================================
# RUN ORDER 15 -- JOBSITE ORDER READINESS (the gap folder 26 left as "PART 3: stub")
#
# Every field name below is taken from salesforce_field_constraints.csv, the org's own
# field snapshot -- not guessed. Guessing cost real time before (Site_Address__c,
# Has_Misc_Order__c, Contract__c on Order, LastBillingDate__c on Subscription all failed
# to compile), which is why every check here also DECLARES the fields it needs: if a name
# is wrong or hidden by FLS the check reports UNPROVEN instead of a silent zero.
#
# THE PATH. Folder 26 said a true pre-conversion gate was blocked because the quote-side
# route to the address was unknown. It is not: NF_Quoted_Jobsite__c carries BOTH
# NF_Quote__c -> SBQQ__Quote__c (which holds USS_Migration_Batch__c) and
# NF_USF_Address__c -> USF_Address__c. So these run BEFORE TF_30 converts, which is the
# whole point -- TF_30 converts, TF_35 activates, TF_90A cleans up afterwards, and until
# now nothing stood in front of any of it.
#
# WHY IT MATTERS. On 2026-10-01 Santhosh cloned the quote behind Order 800VD00000grfWLYAY
# and took it end to end by hand. Business Type blank, jobsite not Order Ready, Site Name
# validation unmet, address never validated through the Google API, site contacts missing,
# Billing Configuration pending. Then: "After clearing all required fields, I got BIQs."
# That last line is the finding. P2O is not broken. These gaps are upstream of the missing
# BIQs, the null ServiceTerritoryId and the missing Work Orders -- all of which this tool
# previously detected forty run orders too late, at the wreckage rather than the cause.
# =====================================================================================
JOBSITE_SEL = (
    "SELECT Id, Name, NF_Quote__c, NF_Quote__r.Name, "
    "NF_Site_Name__c, NF_Site_Complete__c, NF_Site_Contact__c, "
    "NF_USF_Address__c, NF_USF_Address__r.Name, NF_USF_Address__r.Site_Name__c, "
    "NF_USF_Address__r.Address_Validated__c, NF_USF_Address__r.NF_Order_Ready__c, "
    "NF_USF_Address__r.NF_Site_Contact__c, "
    "NF_USF_Address__r.Address_Latitude_Longitude__Latitude__s, "
    "NF_USF_Address__r.Address_Latitude_Longitude__Longitude__s, "
    "NF_Quote__r.Business_Type__c, NF_Quote__r.Billing_Period__c, "
    "NF_Quote__r.Bill_Timing__c, NF_Quote__r.SBQQ__PaymentTerms__c "
    "FROM NF_Quoted_Jobsite__c "
    "WHERE NF_Quote__r.USS_Migration_Batch__r.Name = '{BATCH}'")

JOBSITE_CANARY = ("SELECT COUNT() FROM NF_Quoted_Jobsite__c "
                  "WHERE NF_Quote__r.USS_Migration_Batch__r.Name = '%s'" % B)


def _jobsites(c):
    """
    One query, reused by every jobsite check on the same run.

    Six checks that each fired their own SOQL would be six round trips over the same rows
    and could disagree with each other if anything changed between them. Cached on the
    connection, which lives exactly one run.
    """
    cached = getattr(c, "_jobsite_rows", None)
    if cached is None:
        cached = c.q(JOBSITE_SEL)
        try:
            c._jobsite_rows = cached
        except Exception:                                    # noqa: BLE001
            pass
    return cached


def _g(row, *keys):
    for k in keys:
        v = row.get(k)
        if v not in (None, "", "null"):
            return v
    return None


def _jobsite_check(c, label, bad_fn, note_fn, extra=()):
    rows = _jobsites(c)
    if not rows:
        return Evidence(unprovable=(
            "No NF_Quoted_Jobsite__c records reach this batch through "
            "NF_Quote__r.USS_Migration_Batch__c. Either the quotes carry no jobsites yet, or "
            "the quote-side path is not populated for this batch -- reporting UNPROVEN rather "
            "than a clean zero."))
    bad = []
    for r in rows:
        why = bad_fn(r)
        if why:
            d = {"jobsite": r.get("Name"), "jobsite_id": r.get("Id"),
                 "quote": _g(r, "NF_Quote__r.Name"), "quote_id": r.get("NF_Quote__c"),
                 "address_id": r.get("NF_USF_Address__c"), "issue": why}
            for k in extra:
                d[k.split(".")[-1]] = r.get(k)
            bad.append(d)
    ok = len(rows) - len(bad)
    return Evidence(rows=bad, processed=len(rows),
                    metric=Metric(label, ok / len(rows), "ratio", ok, len(rows)),
                    note=note_fn(len(bad), len(rows)) if bad else "")


def _no_geocode(r):
    if not r.get("NF_USF_Address__c"):
        return "Jobsite has NO address at all"
    lat = _g(r, "NF_USF_Address__r.Address_Latitude_Longitude__Latitude__s")
    lng = _g(r, "NF_USF_Address__r.Address_Latitude_Longitude__Longitude__s")
    if lat is None or lng is None:
        return "Address has no coordinates -- never geocoded"
    return ""


JOBSITE_CHECKS = [
 Check(id="JOBSITE.NO_GEOCODE", name="Jobsite address never geocoded",
       stage="tf_25", sequence=100, sobject="USF_Address__c", severity=BLOCKER,
       requires=("USF_Address__c.Address_Latitude_Longitude__Latitude__s",
                 "NF_Quoted_Jobsite__c.NF_USF_Address__c"),
       rule="Every jobsite address on a batch quote has Address_Latitude_Longitude "
            "coordinates before TF_30 converts the quote",
       rule_source="26_umb0116_jobsite_order_readiness/README.md -- Orders 00753673, 00753870, "
                   "00753685 all returned NO GEOCODE on 2026-10-01",
       canary=lambda c: c.n(JOBSITE_CANARY),
       run=lambda c: _jobsite_check(
           c, "Jobsite addresses with coordinates", _no_geocode,
           lambda b, t: ("%d of %d jobsite address(es) have no coordinates. "
                         "FSL.PolygonUtils.getTerritoryIdByPolygons has nothing to look up for "
                         "these, so WorkOrder.ServiceTerritoryId lands null -- which is "
                         "INDISTINGUISHABLE from the dead-polygon defect unless the two "
                         "populations are split before either is remediated." % (b, t))),
       proves="Every jobsite address can resolve to a service territory",
       cannot_prove="That the coordinates are ACCURATE, or that a live polygon covers them"),

 Check(id="JOBSITE.ADDRESS_NOT_VALIDATED", name="Jobsite address never validated (Google API)",
       stage="tf_25", sequence=105, sobject="USF_Address__c", severity=BLOCKER,
       requires=("USF_Address__c.Address_Validated__c",),
       rule="Every jobsite address on a batch quote has Address_Validated__c = true",
       rule_source="26_umb0116_jobsite_order_readiness -- 'The primary Jobsite address had not "
                   "been validated through the Google API' (Santhosh, 2026-10-01)",
       canary=lambda c: c.n(JOBSITE_CANARY),
       run=lambda c: _jobsite_check(
           c, "Jobsite addresses validated",
           lambda r: ("" if _g(r, "NF_USF_Address__r.Address_Validated__c") in (True, "true")
                      else ("Jobsite has NO address at all" if not r.get("NF_USF_Address__c")
                            else "Address_Validated__c is not true -- never validated")),
           lambda b, t: ("%d of %d jobsite address(es) were never validated through the address "
                         "service. This is upstream of the geocode: an unvalidated address is "
                         "what fails to produce coordinates." % (b, t))),
       proves="Every jobsite address passed address validation",
       cannot_prove="That the validated address is the CORRECT one for the site"),

 Check(id="JOBSITE.NOT_ORDER_READY", name="Jobsite not Order Ready",
       stage="tf_25", sequence=110, sobject="USF_Address__c", severity=WARNING,
       requires=("USF_Address__c.NF_Order_Ready__c",),
       rule="Every jobsite on a batch quote has NF_Order_Ready__c = true before conversion",
       rule_source="26_umb0116_jobsite_order_readiness -- 'The migrated Order showed the Jobsite "
                   "as not Order Ready because required information was missing'",
       canary=lambda c: c.n(JOBSITE_CANARY),
       run=lambda c: _jobsite_check(
           c, "Jobsites Order Ready",
           lambda r: ("" if _g(r, "NF_USF_Address__r.NF_Order_Ready__c") in (True, "true")
                      else ("Jobsite has NO address at all" if not r.get("NF_USF_Address__c")
                            else "NF_Order_Ready__c is not true")),
           lambda b, t: ("%d of %d jobsite(s) are not Order Ready. Migration is not producing an "
                         "Order-Ready record. Whether it is SUPPOSED to is an open scope "
                         "question for the business -- until that is answered this is a "
                         "measurement, and the number is the point." % (b, t))),
       proves="Every jobsite satisfies the Order Ready requirements",
       cannot_prove="Whether a migrated order is EXPECTED to be Order Ready -- that is a "
                    "business scope decision, not a data fact"),

 Check(id="JOBSITE.SITE_NAME_MISSING", name="Jobsite Site Name blank",
       stage="tf_25", sequence=115, sobject="USF_Address__c", severity=BLOCKER,
       requires=("USF_Address__c.Site_Name__c",),
       rule="Every jobsite carries a Site Name -- the org validates that it is non-blank and "
            "contains the Account Name",
       rule_source="26_umb0116_jobsite_order_readiness -- 'the system generated an error "
                   "indicating that the Site Name cannot be blank or must contain the Account "
                   "Name'",
       canary=lambda c: c.n(JOBSITE_CANARY),
       run=lambda c: _jobsite_check(
           c, "Jobsites with a Site Name",
           lambda r: ("" if (_g(r, "NF_USF_Address__r.Site_Name__c") or _g(r, "NF_Site_Name__c"))
                      else "Site Name is blank on both the jobsite and its address"),
           lambda b, t: ("%d of %d jobsite(s) have a blank Site Name and will fail the org's "
                         "Site Name validation when anyone tries to make them Order Ready."
                         % (b, t))),
       proves="Every jobsite has a Site Name to validate",
       cannot_prove="That the Site Name CONTAINS the Account Name -- the org rule also requires "
                    "that, and it needs the Account name per row to assert"),

 Check(id="JOBSITE.NO_SITE_CONTACT", name="Jobsite has no site contact",
       stage="tf_25", sequence=120, sobject="USF_Address__c", severity=WARNING,
       requires=("USF_Address__c.NF_Site_Contact__c",),
       rule="Every jobsite has a primary site contact before conversion",
       rule_source="26_umb0116_jobsite_order_readiness -- 'Contact information and other Jobsite "
                   "details were not fully populated'",
       canary=lambda c: c.n(JOBSITE_CANARY),
       run=lambda c: _jobsite_check(
           c, "Jobsites with a site contact",
           lambda r: ("" if (_g(r, "NF_USF_Address__r.NF_Site_Contact__c")
                             or _g(r, "NF_Site_Contact__c"))
                      else "No primary site contact on the jobsite or its address"),
           lambda b, t: ("%d of %d jobsite(s) have no site contact. This is one of the Order "
                         "Ready requirements and had to be entered by hand on the cloned quote."
                         % (b, t))),
       proves="Every jobsite has a contact for the Order Ready requirements",
       cannot_prove="That the contact is the RIGHT person, or reachable"),

 Check(id="QUOTE.BUSINESS_TYPE_MISSING", name="Migrated Quote has no Business Type",
       stage="tf_25", sequence=125, sobject="SBQQ__Quote__c", severity=BLOCKER,
       requires=("SBQQ__Quote__c.Business_Type__c",),
       rule="Every migrated Quote carries Business_Type__c",
       rule_source="26_umb0116_jobsite_order_readiness -- 'Business Type was blank on the "
                   "migrated Quote. The Account itself had the expected information, so this "
                   "appears to be a data mapping rather than missing Account data.'",
       canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__Quote__c "
                            "WHERE USS_Migration_Batch__r.Name = '%s'" % B),
       run=lambda c: _quote_field_missing(
           c, "Business_Type__c", "Quotes with a Business Type",
           "%d of %d migrated Quote(s) have a blank Business Type. The Account carries the "
           "value, so this is a MAPPING gap, not missing source data -- fixing the records "
           "without fixing the mapping leaves the next batch identical."),
       proves="Every migrated Quote carries a Business Type",
       cannot_prove="That the Business Type MATCHES the Account's -- this only asserts presence"),

 Check(id="QUOTE.BILLING_CONFIG_INCOMPLETE", name="Migrated Quote billing configuration blank",
       stage="tf_25", sequence=130, sobject="SBQQ__Quote__c", severity=BLOCKER,
       requires=("SBQQ__Quote__c.Billing_Period__c", "SBQQ__Quote__c.Bill_Timing__c"),
       rule="Every migrated Quote carries Billing_Period__c and Bill_Timing__c before conversion",
       rule_source="26_umb0116_jobsite_order_readiness -- 'Billing Configuration was still "
                   "pending and several billing-related fields were blank'",
       canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__Quote__c "
                            "WHERE USS_Migration_Batch__r.Name = '%s'" % B),
       run=lambda c: _quote_billing_config(c),
       proves="Every migrated Quote has the billing fields the Order Ready flow requires",
       cannot_prove="That the values are the ones Billing intends. 'Billing Configuration' is a "
                    "step in the P2O UI, not a single field -- these are the underlying fields "
                    "it writes, so a complete set here is necessary but may not be sufficient"),
]


def _quote_field_missing(c, field, label, note):
    rows = c.q("SELECT Id, Name, %s, SBQQ__Account__r.Name FROM SBQQ__Quote__c "
               "WHERE USS_Migration_Batch__r.Name = '%s'" % (field, B))
    if not rows:
        return Evidence(unprovable="No Quotes in this batch -- nothing to measure.")
    bad = [dict(quote=r.get("Name"), quote_id=r.get("Id"),
                account=_g(r, "SBQQ__Account__r.Name"), issue="%s is blank" % field)
           for r in rows if not _g(r, field)]
    ok = len(rows) - len(bad)
    return Evidence(rows=bad, processed=len(rows),
                    metric=Metric(label, ok / len(rows), "ratio", ok, len(rows)),
                    note=(note % (len(bad), len(rows))) if bad else "")


def _quote_billing_config(c):
    rows = c.q("SELECT Id, Name, Billing_Period__c, Bill_Timing__c, SBQQ__PaymentTerms__c, "
               "SBQQ__Account__r.Name FROM SBQQ__Quote__c "
               "WHERE USS_Migration_Batch__r.Name = '%s'" % B)
    if not rows:
        return Evidence(unprovable="No Quotes in this batch -- nothing to measure.")
    bad = []
    for r in rows:
        gaps = [f for f in ("Billing_Period__c", "Bill_Timing__c", "SBQQ__PaymentTerms__c")
                if not _g(r, f)]
        if gaps:
            bad.append(dict(quote=r.get("Name"), quote_id=r.get("Id"),
                            account=_g(r, "SBQQ__Account__r.Name"),
                            issue="blank: " + ", ".join(gaps)))
    ok = len(rows) - len(bad)
    return Evidence(rows=bad, processed=len(rows),
                    metric=Metric("Quotes with billing configured", ok / len(rows), "ratio",
                                  ok, len(rows)),
                    note=("%d of %d migrated Quote(s) have at least one billing field blank. "
                          "Billing Configuration stays 'pending' in the P2O UI until these are "
                          "set, and the jobsite cannot become Order Ready."
                          % (len(bad), len(rows))) if bad else "")


CHECKS.extend(JOBSITE_CHECKS)


# =====================================================================================
# SCHEMA -- fields an Apex service writes that may not exist in this org
#
# 2026-10-02, CJ, creating a contract:
#   "Operation failed due to fields being inaccessible on Sobject WorkOrder, check errors
#    on Exception or Result! fieldNames: Is_NHLW__c,Is_Power__c,Is_Storage__c,Is_Hydroflow__c"
#   "I tried checking for the fields mentioned in the error message on WorkOrder but I dont
#    see them. I cannot see them when viewing permission settings either. ... Is there a
#    permission I am missing?"
#
# That question has a one-query answer and nobody ran it. NONE of the four appear in the
# org's own field snapshot (salesforce_field_constraints.csv, 2026-09-21), which lists 217
# WorkOrder fields -- so the snapshot is comprehensive and their absence is meaningful, but
# it predates the error by eleven days and a field could have been deployed since.
#
# A describe cannot by itself separate "not in the org" from "hidden from this profile",
# because a restricted profile's describe simply omits an FLS-hidden field. So this check
# says exactly what it knows and hands over the Apex that settles it -- rather than
# guessing, which is what "is there a permission I am missing?" already is.
# =====================================================================================
BUNDLE_FLAGS = ("Is_NHLW__c", "Is_Power__c", "Is_Storage__c", "Is_Hydroflow__c")


def _workorder_bundle_flags(c):
    try:
        present = c.fields("WorkOrder")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not describe WorkOrder: %s" % str(e)[:200])
    if not present:
        return Evidence(unprovable="WorkOrder describe returned no fields.")
    missing = [f for f in BUNDLE_FLAGS if f.lower() not in present]
    rows = [{"sobject": "WorkOrder", "field": f,
             "visible_to_this_user": False,
             "in_org_snapshot_2026_09_21": False,
             "cause": "absent from the org, OR present but hidden from this profile by FLS"}
            for f in missing]
    return Evidence(
        rows=rows, processed=len(BUNDLE_FLAGS),
        metric=Metric("WorkOrder bundle flags visible",
                      (len(BUNDLE_FLAGS) - len(missing)) / len(BUNDLE_FLAGS), "ratio",
                      len(BUNDLE_FLAGS) - len(missing), len(BUNDLE_FLAGS)),
        note=("%d of %d WorkOrder bundle flag field(s) are not visible to this user: %s. "
              "NF_WorkOrderBundleFlagService writes them, so contract creation fails with "
              "'fields being inaccessible'. TWO possible causes: the field is ABSENT from this "
              "org (a deployment gap -- no permission will fix it), or it exists and is HIDDEN "
              "from this profile by field-level security (a permission gap -- no deployment is "
              "needed). A describe cannot separate them, because a restricted profile's "
              "describe simply omits an FLS-hidden field. Run the Apex in the remediation; it "
              "settles it in one execution."
              % (len(missing), len(BUNDLE_FLAGS), ", ".join(missing))) if missing else "")


CHECKS.append(Check(
    id="SCHEMA.WORKORDER_BUNDLE_FLAGS", name="WorkOrder bundle flag fields not accessible",
    stage="pre", sequence=170, sobject="WorkOrder", severity=BLOCKER,
    rule="Every field NF_WorkOrderBundleFlagService writes exists on WorkOrder and is "
         "accessible to the running user",
    rule_source="CJ, 2026-10-02: 'Operation failed due to fields being inaccessible on Sobject "
                "WorkOrder ... Is_NHLW__c,Is_Power__c,Is_Storage__c,Is_Hydroflow__c' "
                "(error Id a1vVD00000J5mNeYAJ)",
    canary=lambda c: 1,
    run=_workorder_bundle_flags,
    proves="Every bundle flag field is present and visible, so the service can write it",
    cannot_prove="That the service's LOGIC is right, or that the values it writes are correct"))


BINDINGS.update({
 "JOBSITE.NO_GEOCODE": dict(runbook_order=15, blocks=(17, 19, 28, 29, 30),
   remediation=_R(summary="Validate the addresses so they geocode, BEFORE TF_30 converts.",
     runbook_order=15, script="26_umb0116_jobsite_order_readiness/TF_25.02_Verify_Jobsite_Order_Readiness.apex",
     writes=False,
     steps=["An ungeocoded address and a dead polygon both end as a null "
            "WorkOrder.ServiceTerritoryId. SPLIT the two populations before remediating "
            "either -- RO 28 (TF_90A.04) performs that split.",
            "Applying the polygon fix (RO 29) to an ungeocoded address appears to fail for "
            "no reason. That is the trap this step exists to prevent.",
            "Re-run address validation on the affected jobsites, then re-check.",
            "Only then regenerate Work Orders (RO 30)."],
     note="Confirmed on Orders 00753673, 00753870, 00753685 in UMB-0116. Scale across the "
          "batch has never been measured -- this check measures it.")),

 "JOBSITE.ADDRESS_NOT_VALIDATED": dict(runbook_order=15, blocks=(17, 19),
   remediation=_R(summary="Run address validation on the jobsite addresses.",
     runbook_order=15, script="26_umb0116_jobsite_order_readiness/TF_25.02_Verify_Jobsite_Order_Readiness.apex",
     writes=False,
     steps=["Address_Validated__c = false is UPSTREAM of the missing geocode -- an "
            "unvalidated address is what fails to produce coordinates.",
            "Fix this first and JOBSITE.NO_GEOCODE usually clears with it.",
            "Validate through the org's address service, not by typing coordinates in."])),

 "JOBSITE.NOT_ORDER_READY": dict(runbook_order=15, blocks=(17, 19),
   remediation=_R(summary="Complete the jobsite so it reaches Order Ready, or get the scope "
                          "question answered.",
     runbook_order=15, script="26_umb0116_jobsite_order_readiness/TF_25.02_Verify_Jobsite_Order_Readiness.apex",
     writes=False, approval="Business -- see the note",
     steps=["Order Ready is a roll-up: Site Name, validated address, site contacts and "
            "billing configuration all feed it. The four sibling checks at this step say "
            "WHICH one is missing -- fix those, not this.",
            "OPEN SCOPE QUESTION, raised by Santhosh and still unanswered: is a migrated "
            "Order expected to be immediately Order Ready, or are these validations meant to "
            "be completed post-migration? The answer decides whether this step is a hard gate "
            "or an informational measurement.",
            "Until it is answered, treat the number as a measurement and do not block on it "
            "alone."],
     note="'After clearing all required fields, I got BIQs.' P2O is not broken. The migrated "
          "data is incomplete, and completing it makes the process work.")),

 "JOBSITE.SITE_NAME_MISSING": dict(runbook_order=15, blocks=(17,),
   remediation=_R(summary="Populate Site Name so the org's validation can pass.",
     runbook_order=15, script="", writes=False,
     steps=["The org rule is that Site Name cannot be blank AND must contain the Account Name.",
            "This check asserts only the first half; the second needs the Account name per row.",
            "Trace back to the source NAV/legacy site name rather than inventing one."])),

 "JOBSITE.NO_SITE_CONTACT": dict(runbook_order=15, blocks=(),
   remediation=_R(summary="Populate the jobsite site contact.",
     runbook_order=15, script="", writes=False,
     steps=["One of the Order Ready requirements; entered by hand on the cloned quote.",
            "Source the contact from the Account's contacts rather than creating new ones.",
            "PL_07/PL_10 are what should have supplied these -- if many are missing, check "
            "RO 5 and RO 7 before fixing records one by one."])),

 "QUOTE.BUSINESS_TYPE_MISSING": dict(runbook_order=15, blocks=(17,),
   remediation=_R(summary="Fix the MAPPING, not the records -- the Account already has the value.",
     runbook_order=15, script="", writes=False,
     approval="Mapping owner; validate against source NAV/legacy data",
     steps=["Santhosh confirmed the Account carries Business Type and the Quote does not.",
            "That makes this a migration MAPPING gap, not missing source data.",
            "Validate against the source NAV/legacy data to confirm the expected value.",
            "Patching the records without fixing the mapping leaves the next batch identical.",
            "This is not a Salesforce-side fix."])),

 "QUOTE.BILLING_CONFIG_INCOMPLETE": dict(runbook_order=15, blocks=(17, 19),
   remediation=_R(summary="Populate the Quote billing fields the Order Ready flow requires.",
     runbook_order=15, script="", writes=False, approval="Billing",
     steps=["Billing Configuration shows 'pending' in the P2O UI until Billing_Period__c, "
            "Bill_Timing__c and SBQQ__PaymentTerms__c are set.",
            "Contracts 00533739 and 00534219 ended with ZERO BIQs of any kind, and incomplete "
            "billing configuration is the documented reason.",
            "RO 21 (TF_35.01) verifies the CONTRACT-side equivalents after activation. This is "
            "the quote-side gate in front of it -- the same data, forty run orders earlier."])),

 "SCHEMA.WORKORDER_BUNDLE_FLAGS": dict(runbook_order=2, blocks=(19, 25, 27, 30),
   remediation=_R(summary="Settle whether the fields are ABSENT or merely FLS-hidden -- the "
                          "fix is completely different either way.",
     runbook_order=2, script="", writes=False,
     approval="Salesforce admin",
     steps=["Run this in anonymous Apex as the failing user. It is the only thing that "
            "separates the two causes, because a restricted profile's describe simply omits "
            "an FLS-hidden field:",
            "  for (String f : new List<String>{'Is_NHLW__c','Is_Power__c','Is_Storage__c',"
            "'Is_Hydroflow__c'}) {",
            "    Schema.SObjectField t = Schema.SObjectType.WorkOrder.fields.getMap().get(f);",
            "    System.debug(f + ' -> ' + (t == null ? 'NOT IN THIS ORG' :",
            "      'exists, accessible=' + t.getDescribe().isAccessible()));",
            "  }",
            "NOT IN THIS ORG -> this is a DEPLOYMENT gap. NF_WorkOrderBundleFlagService "
            "references fields the sandbox does not have; no permission will fix that.",
            "exists, accessible=false -> FLS. Grant read/edit on the four fields to the "
            "profile or permission set, and no deployment is needed.",
            "Either way it blocks contract creation, so it belongs at the pre-flight."],
     note="None of the four appear in the org field snapshot of 2026-09-21, which lists 217 "
          "WorkOrder fields -- comprehensive enough that their absence is meaningful. But it "
          "predates CJ's error by eleven days, so a deployment since then would not show. "
          "Run the Apex; do not assume either way.")),
})


# =====================================================================================
# DEAD MAP POLYGONS -- org-wide infrastructure, not a batch defect
#
# A polygon pointing at a DELETED ServiceTerritory silently blocks WorkOrder creation for
# every site inside it, on EVERY batch. Salesforce rejects the insert with
# INVALID_CROSS_REFERENCE_KEY and BatchContractOrders.finish() swallows the error into
# Log__c, which purges hourly -- so TF_35, Script 5 and the Has_Service toggle all report
# success and create nothing.
#
# Reconciliation of 2026-10-01 found 502 such polygons across 80 branch prefixes, every
# one pointing at a territory that no longer exists. 501 are still unfixed. That is a very
# large area of geography in which no address can resolve a territory, which is why this
# sits at the PRE-FLIGHT rather than inside the run book: it is not UMB-0117's problem, it
# is the org's, and every batch inherits it.
#
# THE RESOLUTION RULE, proven across ~4,500 working polygons: a healthy polygon points at
# a territory with an IDENTICAL NAME, one to one. So a broken polygon's correct target is
# a lookup, not a judgement -- which is what lets 486 of 502 be fixed mechanically.
#
# DO NOT resolve by eyeballing the name. The first manual fix pointed SJO-P at
# "San Jose, CA" because the prefix was SJO; it passed validation, created working records
# and was still WRONG. Territories come in branch level ("San Jose, CA") and route level
# ("SJO-P"); polygons use the route level. Only the exact match is reliable.
# =====================================================================================
# Fetch caps. A polygon is judged dead by ABSENCE from the live-territory set, so a
# truncated territory list does not under-report -- it INVENTS dead polygons. Every
# territory past the cap would make every polygon pointing at it look broken. The counts
# are therefore checked against the caps first, and a truncated read reports UNPROVEN
# rather than a confident list of false positives.
TERR_CAP, POLY_CAP = 1000000, 1000000   # no practical limit; kept only as a guard against a runaway read


def _fsl_dead_polygons(c):
    try:
        n_terr = c.n("SELECT COUNT() FROM ServiceTerritory")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not count ServiceTerritory: %s" % str(e)[:200])
    if n_terr > TERR_CAP:
        return Evidence(unprovable=(
            "This org has %d ServiceTerritory records but this check reads at most %d. A "
            "polygon is judged dead by ABSENCE from that set, so a truncated read would "
            "report every polygon pointing at territory %d or beyond as broken -- false "
            "positives, not findings. Raise TERR_CAP and re-run."
            % (n_terr, TERR_CAP, TERR_CAP + 1)))
    try:
        terrs = c.q("SELECT Id, Name, IsActive FROM ServiceTerritory")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read ServiceTerritory: %s" % str(e)[:200])
    if not terrs:
        return Evidence(unprovable="No ServiceTerritory records readable -- cannot tell a "
                                   "dead polygon from a healthy one.")
    live_ids = {t.get("Id") for t in terrs}
    by_name = {}
    for t in terrs:
        if t.get("Name"):
            by_name[str(t["Name"]).upper()] = t

    try:
        n_poly = c.n("SELECT COUNT() FROM FSL__Polygon__c "
                     "WHERE FSL__Service_Territory__c != null")
        polys = c.q("SELECT Id, Name, FSL__Service_Territory__c FROM FSL__Polygon__c "
                    "WHERE FSL__Service_Territory__c != null")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read FSL__Polygon__c: %s" % str(e)[:200])
    if not polys:
        return Evidence(unprovable="No FSL__Polygon__c records readable.")
    if n_poly > len(polys):
        return Evidence(unprovable=(
            "%d polygons carry a territory but only %d were read. A partial read cannot be "
            "trusted here. Raise POLY_CAP and re-run." % (n_poly, len(polys))))

    bad = []
    mech = inactive = nomatch = 0
    for p in polys:
        if p.get("FSL__Service_Territory__c") in live_ids:
            continue                                          # healthy
        nm = str(p.get("Name") or "").upper()
        t = by_name.get(nm)
        if t is None:
            nomatch += 1
            res = "NO MATCH -- needs a human decision (retire, or choose a territory)"
        elif not t.get("IsActive"):
            inactive += 1
            res = ("target '%s' exists but IsActive = false -- reactivate it or pick a live "
                   "one. Repointing at an inactive territory looks like a fix and solves "
                   "nothing." % t.get("Name"))
        else:
            mech += 1
            res = "exact name match -> %s (%s). Mechanical." % (t.get("Id"), t.get("Name"))
        bad.append({"polygon": p.get("Name"), "polygon_id": p.get("Id"),
                    "dead_territory_id": p.get("FSL__Service_Territory__c"),
                    "resolution": res})

    ok = len(polys) - len(bad)
    note = ""
    if bad:
        note = ("%d of %d map polygon(s) point at a DELETED ServiceTerritory. No address "
                "inside them can resolve a territory, so WorkOrder inserts fail with "
                "INVALID_CROSS_REFERENCE_KEY and the error is swallowed -- the step reports "
                "success and creates nothing. %d resolve MECHANICALLY by exact name match "
                "(RO 29 applies these), %d point at an INACTIVE territory, %d have NO match "
                "and need a human. This is ORG-WIDE and affects every batch, not just this one."
                % (len(bad), len(polys), mech, inactive, nomatch))
    return Evidence(rows=bad, processed=len(polys),
                    metric=Metric("Polygons pointing at a live territory",
                                  ok / len(polys), "ratio", ok, len(polys)),
                    note=note)


CHECKS.append(Check(
    id="FSL.DEAD_POLYGONS", name="Map polygons pointing at a deleted Service Territory",
    stage="pre", sequence=180, sobject="ServiceTerritory", severity=BLOCKER,
    requires=("FSL__Polygon__c.FSL__Service_Territory__c",),
    rule="Every FSL map polygon points at a ServiceTerritory that still exists and is active",
    rule_source="Polygon_Territory_Reconciliation_HANDOFF_2026-10-01 -- 502 polygons across "
                "80 branch prefixes, all pointing at deleted territories; SJO-P fixed and "
                "proven on Orders 00753996 and 00754184",
    canary=lambda c: c.n("SELECT COUNT() FROM FSL__Polygon__c"),
    run=_fsl_dead_polygons,
    proves="Every polygon can resolve an address to a live service territory",
    cannot_prove="That the polygon's GEOGRAPHY is right, or that a given address falls "
                 "inside any polygon at all -- RO 31 covers coverage gaps"))

BINDINGS["FSL.DEAD_POLYGONS"] = dict(runbook_order=2, blocks=(19, 25, 27, 30),
  remediation=_R(summary="Repoint the polygons at the live territory with the identical name.",
    runbook_order=29,
    script="29_umb0117_dead_polygons/TF_90A.05_Repoint_Dead_Service_Territory_Polygons.apex",
    writes=True, approval="None for exact name matches; a person decides the rest",
    steps=["Run RO 29 with APPLY = false first. It lists every broken polygon and the "
           "territory it would set.",
           "MAX_UPDATES caps each run. 486 mechanical fixes is several runs, not one -- the "
           "script prints how many remain so it does not look stalled.",
           "Apply a handful, verify the territory on the resulting WorkOrders, then do the rest.",
           "NO MATCH rows are NEVER written automatically. Rt1-Rt14 are legacy route "
           "polygons with no target and should be retired, not repointed.",
           "An INACTIVE target is not a fix: reactivate that territory or choose a live one.",
           "DO NOT resolve by eyeballing the name. SJO-P was first pointed at the 'San Jose, "
           "CA' BRANCH territory; it passed validation, created records, and was wrong. "
           "Polygons use ROUTE-level territories. Only the exact match is reliable."],
    note="Org-wide, not batch-specific. It silently blocks WorkOrder creation on every "
         "batch, which is why it is a pre-flight rather than a run book step."))


# =====================================================================================
# RUN ORDERS 21, 22, 24 -- verification steps that were never automated
#
# All three are labelled "RUN AUTOMATION" in the run book, but none of them writes: they
# are verification queries that happened to be written as Apex because that was the tool to
# hand. Classify by what a script DOES, not by what it is labelled, and they are read-only
# checks like any other. Field names confirmed against salesforce_field_constraints.csv and
# declared below, so a wrong or FLS-hidden name reports UNPROVEN rather than a silent zero.
# =====================================================================================
def _contract_fields_blank(c, fields, label, note):
    cols = ", ".join(fields)
    rows = c.q("SELECT Id, ContractNumber, Status, %s FROM Contract "
               "WHERE USS_Migration_Batch__r.Name = '%s' AND Status = 'Activated'"
               % (cols, B))
    if not rows:
        return Evidence(unprovable="No Activated Contracts in this batch -- nothing to measure.")
    bad = []
    for r in rows:
        gaps = [f for f in fields if not _g(r, f)]
        if gaps:
            bad.append(dict(contract=r.get("ContractNumber"), contract_id=r.get("Id"),
                            status=r.get("Status"), issue="blank: " + ", ".join(gaps)))
    ok = len(rows) - len(bad)
    return Evidence(rows=bad, processed=len(rows),
                    metric=Metric(label, ok / len(rows), "ratio", ok, len(rows)),
                    note=(note % (len(bad), len(rows))) if bad else "")


def _branch_codes(c):
    rows = c.q("SELECT Id, ContractNumber, Location_Code__c, Account.USF_Department_Code__c "
               "FROM Contract WHERE USS_Migration_Batch__r.Name = '%s' "
               "AND Status = 'Activated'" % B)
    if not rows:
        return Evidence(unprovable="No Activated Contracts in this batch -- nothing to measure.")
    bad = []
    for r in rows:
        gaps = []
        if not _g(r, "Location_Code__c"):
            gaps.append("Contract.Location_Code__c")
        if not _g(r, "Account.USF_Department_Code__c"):
            gaps.append("Account.USF_Department_Code__c")
        if gaps:
            bad.append(dict(contract=r.get("ContractNumber"), contract_id=r.get("Id"),
                            issue="blank: " + ", ".join(gaps)))
    ok = len(rows) - len(bad)
    return Evidence(rows=bad, processed=len(rows),
                    metric=Metric("Contracts with a branch code", ok / len(rows), "ratio",
                                  ok, len(rows)),
                    note=("%d of %d Activated Contract(s) are missing a branch code. Branch "
                          "drives routing and billing attribution downstream."
                          % (len(bad), len(rows))) if bad else "")


def _one_batch_processing(c):
    rows = c.q("SELECT Id, Name, Batch_Status__c FROM USS_Migration_Batch__c "
               "WHERE Batch_Status__c = 'Processing'")
    mine = [r for r in rows if str(r.get("Name") or "") == c.batch]
    others = [r for r in rows if str(r.get("Name") or "") != c.batch]
    if not mine:
        return Evidence(rows=[{"batch": c.batch, "issue": "this batch is NOT Processing"}],
                        processed=len(rows),
                        metric=Metric("Batches Processing", float(len(rows)), "count",
                                      len(rows), 0),
                        note=("%s is not in Processing. Every batch-scoped script keys off "
                              "the Processing batch, so running one now would target "
                              "something else." % c.batch))
    bad = [dict(batch=r.get("Name"), batch_id=r.get("Id"),
                issue="also Processing -- a batch-scoped script could target THIS instead")
           for r in others]
    return Evidence(rows=bad, processed=len(rows),
                    metric=Metric("Batches Processing", float(len(rows)), "count",
                                  len(rows), 0),
                    note=("%d batch(es) are Processing, not just %s: %s. Scripts 5a/5b/15/28/30 "
                          "key off the Processing batch -- with more than one, they may write "
                          "to the wrong batch." % (len(rows), c.batch,
                                                  ", ".join(str(r.get("Name")) for r in others[:5])))
                         if bad else "")


VERIFY_CHECKS = [
 Check(id="CONTRACT.BILL_TIMING_BLANK", name="Activated Contract missing bill timing fields",
       stage="tf_35", sequence=140, sobject="Contract", severity=BLOCKER,
       requires=("Contract.Billing_Period__c", "Contract.NF_Bill_Timing__c",
                 "Contract.InvoiceDeliveryMethod__c"),
       rule="Every Activated Contract carries Billing_Period__c, NF_Bill_Timing__c and "
            "InvoiceDeliveryMethod__c",
       rule_source="Run Book RO 21, TF_35.01_Verify_Bill_Timing_Period_Delivery_Method_"
                   "Repeatable_v2.apex -- fields confirmed via salesforce_field_constraints.csv",
       canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE "
                            "USS_Migration_Batch__r.Name='%s' AND Status='Activated'" % B),
       run=lambda c: _contract_fields_blank(
           c, ["Billing_Period__c", "NF_Bill_Timing__c", "InvoiceDeliveryMethod__c"],
           "Contracts with billing fields set",
           "%d of %d Activated Contract(s) are missing at least one billing field. These "
           "drive when and how the customer is invoiced."),
       proves="Every Activated Contract has the fields billing needs to invoice it",
       cannot_prove="That the VALUES are the ones billing intends -- only that they are set"),

 Check(id="CONTRACT.BRANCH_CODE_BLANK", name="Activated Contract missing a branch code",
       stage="tf_35", sequence=145, sobject="Contract", severity=WARNING,
       requires=("Contract.Location_Code__c", "Account.USF_Department_Code__c"),
       rule="Every Activated Contract and its Account carry a branch code",
       rule_source="Run Book RO 22, TF_35.02_Verify_Branch_Codes_Repeatable_v2.apex",
       canary=lambda c: c.n("SELECT COUNT() FROM Contract WHERE "
                            "USS_Migration_Batch__r.Name='%s' AND Status='Activated'" % B),
       run=_branch_codes,
       proves="Every Activated Contract can be attributed to a branch",
       cannot_prove="That the branch is the CORRECT one for the service address"),

 Check(id="BATCH.ONLY_ONE_PROCESSING", name="More than one batch is Processing",
       stage="pre", sequence=120, sobject="USS_Migration_Batch__c", severity=BLOCKER,
       requires=("USS_Migration_Batch__c.Batch_Status__c",),
       rule="Exactly ONE batch is in Processing, and it is the batch being worked on",
       rule_source="Run Book RO 24, TF_35.04_Verify_Batch_Status.apex -- 'Confirms exactly "
                   "ONE batch shows Processing ... before running any of Scripts 5a/5b/15/28/30'",
       canary=lambda c: c.n("SELECT COUNT() FROM USS_Migration_Batch__c"),
       run=_one_batch_processing,
       proves="A batch-scoped script will target the batch you intend",
       cannot_prove="That the scripts themselves scope correctly -- only that the batch "
                    "status they key off is unambiguous"),
]
CHECKS.extend(VERIFY_CHECKS)

BINDINGS.update({
 "CONTRACT.BILL_TIMING_BLANK": dict(runbook_order=21, blocks=(48, 58, 61),
   remediation=_R(summary="Populate the billing fields on the Activated Contracts.",
     runbook_order=21, script="", writes=False, approval="Billing",
     steps=["Billing_Period__c, NF_Bill_Timing__c and InvoiceDeliveryMethod__c decide WHEN "
            "and HOW the customer is invoiced.",
            "RO 15 checks the QUOTE-side equivalents before conversion; if those were blank "
            "the Contract inherits blanks. Fix upstream first or the next batch repeats it.",
            "Blank values reach Zuora, so this blocks Ready for Billing (RO 61)."])),

 "CONTRACT.BRANCH_CODE_BLANK": dict(runbook_order=22, blocks=(),
   remediation=_R(summary="Populate the branch code on the Contract and its Account.",
     runbook_order=22, script="", writes=False,
     steps=["Account.USF_Department_Code__c (Label 'Branch') and Contract.Location_Code__c "
            "(Label 'Branch Code') drive routing and billing attribution.",
            "A blank branch does not stop a load; it surfaces later as work routed nowhere.",
            "Trace back to the source NAV/legacy branch rather than inventing one."])),

 "BATCH.ONLY_ONE_PROCESSING": dict(runbook_order=24, blocks=(26, 27, 29, 30, 53, 57),
   remediation=_R(summary="Leave exactly ONE batch in Processing before running any "
                          "batch-scoped script.",
     runbook_order=24, script="", writes=False, approval="Whoever owns the other batch",
     steps=["Scripts 5a/5b/15/28/30 key off the Processing batch. With two Processing, they "
            "can write to the wrong one -- and the write succeeds, so nothing looks wrong.",
            "Confirm which batch the other team is working, then set the ones you are not "
            "working to a non-Processing status.",
            "This is the cheapest check in the run book and the most expensive to skip."])),
})


# =====================================================================================
# v0.18.0 -- checks added after the 2026-10-02 session and a review of the documentation
#
# Every definition below comes from a script or rule the team already wrote down, NOT from
# an observation made while debugging. That matters: two things were called "confirmed
# duplicates" in that session on the strength of a flat count, and the team's own
# TF_90A.09 says in its header that a flat count is wrong. These checks use the team's
# definitions, and each one reports the control group (the legitimate cases it did NOT
# flag) so a reader can see what was ruled out as well as what was found.
# =====================================================================================
import re as _re


def _v18_chunks(seq, n):
    seq = list(seq)
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def _v18_in(ids):
    """A SOQL IN-list. Ids come back from Salesforce, but strip quotes anyway."""
    return ",".join("'%s'" % str(i).replace("'", "") for i in ids)


def _v18_num(v, default=None):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


# ------------------------------------------------------------------ deliveries vs bundles
_V18_DELIVERY = ("WorkOrder WHERE Order__r.SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s' "
                 "AND WorkType.Name = 'Delivery'" % B)


def _v18_delivery_vs_bundles(c):
    """
    TF_90A.09's rule, not a flat count. An Order can legitimately have two storage bundles at
    two jobsites and SHOULD get two deliveries (Contract 00533582, UMB-0116). The test is
    whether deliveries EXCEED the distinct bundle roots (NF_BundleId__c) on the Order's WOLIs.
    """
    try:
        n_del = c.n("SELECT COUNT() FROM " + _V18_DELIVERY)
        groups = c.q("SELECT Order__c, COUNT(Id) n FROM " + _V18_DELIVERY +
                     " AND Status NOT IN ('Canceled','Cancelled') GROUP BY Order__c HAVING COUNT(Id) > 1")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read Delivery Work Orders: %s" % str(e)[:200])

    count_by_order = {g.get("Order__c"): int(_v18_num(g.get("n"), 0))
                      for g in groups if g.get("Order__c")}
    cand = sorted(count_by_order)
    bundles, wos = {}, {}
    for chunk in _v18_chunks(cand, 100):
        ids = _v18_in(chunk)
        try:
            for r in c.q("SELECT WorkOrder.Order__c, NF_BundleId__c FROM WorkOrderLineItem "
                         "WHERE WorkOrder.Order__c IN (%s) AND NF_BundleId__c != null" % ids):
                oid, root = r.get("WorkOrder.Order__c"), r.get("NF_BundleId__c")
                if oid and root:
                    bundles.setdefault(oid, set()).add(root)
            for r in c.q("SELECT Id, WorkOrderNumber, Order__c, Order__r.OrderNumber, Status, "
                         "StartDate FROM WorkOrder WHERE Order__c IN (%s) "
                         "AND WorkType.Name = 'Delivery' AND Status NOT IN ('Canceled','Cancelled')" % ids):
                wos.setdefault(r.get("Order__c"), []).append(r)
        except Exception as e:                               # noqa: BLE001
            return Evidence(unprovable="Could not read bundle roots or deliveries: %s"
                                       % str(e)[:200])

    suspects, legit, excess = [], 0, 0
    for oid in cand:
        d, nb = count_by_order[oid], len(bundles.get(oid, ()))
        if d <= max(nb, 1):
            legit += 1                  # the control group: more than one delivery, explained
            continue
        wl = wos.get(oid, [])
        excess += d - max(nb, 1)
        suspects.append({
            "order_id": oid,
            "order_number": (wl[0].get("Order__r.OrderNumber") if wl else ""),
            "deliveries": d, "distinct_bundles": nb,
            "work_orders": "; ".join("%s(%s, %s)" % (w.get("WorkOrderNumber"), w.get("Status"),
                                                      w.get("StartDate")) for w in wl),
            "same_start_date": bool(wl) and len({w.get("StartDate") for w in wl}) < len(wl),
            "issue": "more Delivery Work Orders than distinct bundle roots"})

    note = ""
    if suspects or legit:
        note = ("%d Order(s) have more Delivery Work Orders than distinct bundle roots -- a "
                "REVIEW list, not a failure list. %d other Order(s) have more than one delivery "
                "that their bundles explain (NOT flagged). Canceled deliveries are not counted. "
                "A true duplicate usually shows the same date with one New and one Completed. "
                "Do not bulk-delete: removing a Work Order cascades to Service Appointments and "
                "WOLIs, and Work Order deletion was failing hourly in this org via "
                "FSL.TR001_Service_BeforeUpdate (TF_90A.09 header, 2026-10-02)."
                % (len(suspects), legit))
    return Evidence(rows=suspects, processed=len(cand), note=note,
                    metric=Metric("Orders with several deliveries that a bundle explains",
                                  ((len(cand) - len(suspects)) / len(cand)) if cand else 1.0, "ratio",
                                  len(cand) - len(suspects), len(cand)))


CHECKS.append(Check(
    id="WO.DELIVERY_EXCEEDS_BUNDLES", name="Orders with more Delivery Work Orders than bundles",
    stage="tf_35", sequence=115, sobject="WorkOrder", severity=WARNING,
    requires=("WorkOrderLineItem.NF_BundleId__c",),
    rule="An Order has no more Delivery Work Orders than it has distinct bundle roots",
    rule_source="TF_90A.09_Check_For_Duplicate_Deliveries.apex (RO 33). Its header: a flat 'more "
                "than one Delivery' count is WRONG -- Contract 00533582 legitimately has two "
                "storage bundles at two jobsites and SHOULD produce two deliveries",
    canary=lambda c: c.n("SELECT COUNT() FROM " + _V18_DELIVERY),
    run=_v18_delivery_vs_bundles,
    proves="No Order has more deliveries than the bundles it contains",
    cannot_prove="That a flagged Order IS a duplicate -- a person compares StartDate and Status "
                 "on the listed Work Orders. Nor can it see a duplicate hidden by a bundle "
                 "count that is itself wrong."))

BINDINGS["WO.DELIVERY_EXCEEDS_BUNDLES"] = dict(runbook_order=33, blocks=(),
  remediation=_R(summary="Review each flagged Order against its bundles; do not bulk-delete.",
    runbook_order=33,
    script="24_umb0116_missing_workorders/TF_90A.09_Check_For_Duplicate_Deliveries.apex",
    writes=False, approval="Whoever owns the Order",
    steps=["Run TF_90A.09 for the same batch: it prints each suspect with its Work Order "
           "numbers, statuses and dates.",
           "Compare StartDate and Status. Same date with one New and one Completed is the "
           "signature of a true duplicate.",
           "Record the decision per Order. Do NOT delete in bulk -- deletion cascades through "
           "FSL automation and is currently unreliable in this org.",
           "If it is a true duplicate, the same Order's WOLIs are probably doubled too -- "
           "see WOLI.EXCEEDS_SOURCE_QUANTITY before TF_55.05 creates Asset Locations and "
           "BIQs from them."],
    note="Added after a flat count was reported as 'confirmed duplicates' on 2026-10-02. "
         "That was the wrong test; this is the team's."))


# ------------------------------------------------------------------ WOLIs vs source quantity
_V18_WOLI = ("WorkOrderLineItem WHERE WorkOrder.Order__r.SBQQ__Quote__r."
             "USS_Migration_Batch__r.Name = '%s' AND Order_Line_Item__c != null" % B)
_V18_GROUP_CAP = 2000


def _v18_woli_vs_source(c):
    """
    The same source Order Line Item appearing twice on one Work Order is NOT, by itself, a
    duplicate: an OrderItem with Quantity 2 may legitimately expand to two WOLIs of 1 each.
    It is a duplicate when the UNITS delivered exceed the source quantity. So compare.
    """
    try:
        groups = c.q("SELECT WorkOrderId, Order_Line_Item__c, COUNT(Id) n FROM " + _V18_WOLI +
                     " GROUP BY WorkOrderId, Order_Line_Item__c HAVING COUNT(Id) > 1")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not group WOLIs by source line: %s" % str(e)[:200])
    wanted = {(g.get("WorkOrderId"), g.get("Order_Line_Item__c")) for g in groups
              if g.get("WorkOrderId") and g.get("Order_Line_Item__c")}
    wo_ids = sorted({w for w, _ in wanted})
    by_key = {}
    sub_ok = True                          # can each WOLI be judged against its OWN subscription?
    for chunk in _v18_chunks(wo_ids, 150):
        recs = None
        if sub_ok:
            try:
                recs = c.q("SELECT Id, WorkOrderId, Order_Line_Item__c, Order_Line_Item__r.Quantity, "
                           "USF_Confirmed_Quantity__c, Subscription__c, "
                           "Subscription__r.SBQQ__Quantity__c FROM WorkOrderLineItem WHERE "
                           "WorkOrderId IN (%s) AND Order_Line_Item__c != null" % _v18_in(chunk))
            except Exception as e:                           # noqa: BLE001
                if not any(t in str(e).upper() for t in ("INVALID_FIELD", "NO SUCH COLUMN", "INVALID_TYPE")):
                    return Evidence(unprovable="Could not read WOLI subscriptions: %s" % str(e)[:200])
                sub_ok = False             # no Subscription__c here: fall back to the source line
        if recs is None:
            try:
                recs = c.q("SELECT Id, WorkOrderId, Order_Line_Item__c, Order_Line_Item__r.Quantity, "
                           "USF_Confirmed_Quantity__c FROM WorkOrderLineItem WHERE WorkOrderId IN "
                           "(%s) AND Order_Line_Item__c != null" % _v18_in(chunk))
            except Exception as e:                           # noqa: BLE001
                return Evidence(unprovable="Could not read WOLI quantities: %s" % str(e)[:200])
        for r in recs:
            by_key.setdefault((r.get("WorkOrderId"), r.get("Order_Line_Item__c")), []).append(r)

    def units_of(lst):
        qs = [_v18_num(r.get("USF_Confirmed_Quantity__c")) for r in lst]
        known = all(q is not None for q in qs)
        return (sum(qs) if known else float(len(lst))), known

    over, explained, unjudged, ancillary = [], 0, 0, 0
    for key in sorted(wanted):
        lst = by_key.get(key, [])
        if len(lst) < 2:
            continue                       # changed between the two reads
        # A source line is often the PARENT of a bundle: the restroom and the hand sanitizer
        # attached to it each deliver 1 against a source line of 1. Compare each WOLI with the
        # subscription it was made from, not with that shared parent. Only when every WOLI names
        # its subscription can that be done.
        if sub_ok and sum(1 for r in lst if r.get("Subscription__c")) >= 1 and \
                len([r for r in lst if not r.get("Subscription__c")]) <= 1:
            # WOLIs that name a subscription are judged on it; at most one without cannot be a
            # repeat of anything, so it is left out rather than dragging the group back to the parent.
            subs = {}
            for r in [x for x in lst if x.get("Subscription__c")]:
                subs.setdefault(r.get("Subscription__c"), []).append(r)
            bad_sub = None
            blind = False
            for sid, sl in subs.items():
                sq = _v18_num(sl[0].get("Subscription__r.SBQQ__Quantity__c"))
                if sq is None:
                    blind = True
                    continue
                u, known = units_of(sl)
                if u > sq:
                    bad_sub = (sid, sq, sl, u, known)
                    break
            if bad_sub:
                sid, sq, sl, u, known = bad_sub
                over.append({"work_order_id": key[0], "source_line_id": key[1],
                             "subscription_id": sid, "subscription_quantity": sq,
                             "wolis": len(sl), "units_delivered": u,
                             "units_basis": ("sum of USF_Confirmed_Quantity__c" if known
                                             else "WOLI count (quantity not populated)"),
                             "woli_ids": ", ".join(str(r.get("Id")) for r in sl),
                             "judged_against": "the subscription these WOLIs were made from",
                             "issue": "units delivered exceed this subscription's quantity"})
            elif blind:
                unjudged += 1
            else:
                explained += 1
                if len(subs) > 1:
                    ancillary += 1         # different products sharing one parent line
            continue
        src = _v18_num(lst[0].get("Order_Line_Item__r.Quantity"))
        units, known = units_of(lst)
        if src is None:
            unjudged += 1
            continue
        if units > src:
            over.append({"work_order_id": key[0], "source_line_id": key[1],
                         "source_quantity": src, "wolis": len(lst), "units_delivered": units,
                         "units_basis": ("sum of USF_Confirmed_Quantity__c" if known
                                         else "WOLI count (quantity not populated)"),
                         "woli_ids": ", ".join(str(r.get("Id")) for r in lst),
                         "judged_against": "the source Order Line (subscription not available)",
                         "issue": "units delivered exceed the source line's quantity"})
        else:
            explained += 1                 # the control group

    note = ""
    if wanted:
        note = ("%d source line(s) appear on a Work Order more than once. In %d the units "
                "delivered EXCEED the source quantity (REVIEW). %d are explained by a source "
                "quantity large enough for the split (NOT flagged). %d could not be judged "
                "because the source quantity was unreadable.%s"
                % (len(wanted), len(over), explained, unjudged,
                   (" %d of the explained ones are different products (e.g. a bundle's add-ons) "
                    "that share one parent line; each was compared with its own subscription."
                    % ancillary) if ancillary else ""))
    judged = len(wanted) - unjudged
    if not sub_ok and wanted:
        note += (" Subscriptions were not available, so every group was compared with its source "
                 "Order Line: add-ons that share a parent line may be over-reported.")
    return Evidence(rows=over, processed=len(wanted), note=note,
                    metric=Metric("Repeated source lines explained by quantity",
                                  (judged - len(over)) / judged if judged else 1.0,
                                  "ratio", max(judged - len(over), 0), judged))


CHECKS.append(Check(
    id="WOLI.EXCEEDS_SOURCE_QUANTITY",
    name="Work Order Line Items delivering more units than the source line",
    stage="tf_35", sequence=116, sobject="WorkOrderLineItem", severity=WARNING,
    requires=("WorkOrderLineItem.Order_Line_Item__c", "WorkOrderLineItem.USF_Confirmed_Quantity__c"),
    rule="For one Work Order, the units on the WOLIs made from one subscription do not exceed that "
         "subscription's Quantity (the source Order Line's Quantity only where the subscription is "
         "not available). Add-ons that share a bundle's parent line are judged on their own",
    rule_source="2026-10-02: 103 groups shared a WorkOrder and a source line and were first "
                "reported as 'confirmed duplicates' WITHOUT comparing to the source quantity. "
                "TF_90A.09's own warning applies: a repeat is not a duplicate until the "
                "expected count has been compared",
    canary=lambda c: c.n("SELECT COUNT() FROM " + _V18_WOLI),
    run=_v18_woli_vs_source,
    proves="No Work Order delivers more units of a source line than were ordered",
    cannot_prove="That a per-unit split is intended -- it compares to the source quantity, so a "
                 "split that fits is not flagged. Also blind to a WOLI duplicated across TWO "
                 "Work Orders, which this grouping cannot see."))

BINDINGS["WOLI.EXCEEDS_SOURCE_QUANTITY"] = dict(runbook_order=33, blocks=(),
  remediation=_R(summary="Settle against the source quantity before deleting anything.",
    runbook_order=33, script="", writes=False, approval="Whoever owns the Order",
    steps=["Open a flagged Work Order and its source Order Line Item; compare Quantity with "
           "the sum of the WOLIs.",
           "If the WOLIs total more than the source quantity it is a real duplicate. If not, it "
           "is a per-unit split and nothing is wrong.",
           "Real duplicates matter downstream: TF_55.05 creates Asset Locations and BIQs from "
           "WOLIs, so a doubled WOLI can bill twice. Settle these before RO 45.",
           "Do not delete in bulk -- Work Order deletion cascades through FSL automation."],
    note="Evidence from 2026-10-02 showed Ordered_Quantity__c = 2 on the parent Work Orders. "
         "That does not distinguish a duplicate from a quantity-2 line; this check does."))


# ------------------------------------------------------------------ duplicate Contracts
_V18_CONTRACT = ("Contract WHERE USS_Migration_Batch__r.Name = '%s' AND SBQQ__Order__c != null" % B)


def _v18_duplicate_contracts(c):
    """
    The run book's standing rule: overlapping day-of-week or frequency is NOT evidence of a
    duplicate Contract. A duplicate must share a non-null source. This is the Order half of
    that gate: two Contracts created from the same Order.
    """
    try:
        n = c.n("SELECT COUNT() FROM " + _V18_CONTRACT)
        groups = c.q("SELECT SBQQ__Order__c, COUNT(Id) n FROM " + _V18_CONTRACT +
                     " GROUP BY SBQQ__Order__c HAVING COUNT(Id) > 1")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not group Contracts by Order: %s" % str(e)[:200])
    orders = sorted({g.get("SBQQ__Order__c") for g in groups if g.get("SBQQ__Order__c")})
    members = {}
    for chunk in _v18_chunks(orders, 150):
        try:
            for r in c.q("SELECT Id, ContractNumber, Status, SBQQ__Order__c, "
                         "SBQQ__Order__r.OrderNumber FROM Contract WHERE SBQQ__Order__c IN (%s)"
                         % _v18_in(chunk)):
                members.setdefault(r.get("SBQQ__Order__c"), []).append(r)
        except Exception as e:                               # noqa: BLE001
            return Evidence(unprovable="Could not read the Contracts: %s" % str(e)[:200])
    rows = []
    for oid in orders:
        ms = members.get(oid, [])
        rows.append({"order_id": oid,
                     "order_number": (ms[0].get("SBQQ__Order__r.OrderNumber") if ms else ""),
                     "contracts": len(ms) or 2,
                     "contract_numbers": ", ".join(str(m.get("ContractNumber")) for m in ms),
                     "statuses": ", ".join(sorted({str(m.get("Status")) for m in ms})),
                     "issue": "more than one Contract was created from this one Order"})
    return Evidence(rows=rows, processed=n,
                    note=("%d Order(s) produced more than one Contract." % len(rows)) if rows else "",
                    metric=Metric("Contracts not duplicated from the same Order",
                                  (n - sum(r["contracts"] for r in rows) + len(rows)) / n if n else 0.0,
                                  "ratio", max(n - sum(r["contracts"] for r in rows) + len(rows), 0), n))


CHECKS.append(Check(
    id="CONTRACT.DUPLICATE_PER_ORDER", name="Orders that produced more than one Contract",
    stage="tf_35", sequence=117, sobject="Contract", severity=WARNING,
    requires=("Contract.SBQQ__Order__c",),
    rule="One Order produces one Contract",
    rule_source="UMB Master Run Book, Standing Rules: 'Duplicate-Contract detection needs a "
                "source gate -- require flagged Contracts to share a non-null SBQQ__Quote__c or "
                "SBQQ__Order__c.' See TF_40.03_Remediate_Duplicate_Contract_Proposal_Repeatable_v3",
    canary=lambda c: c.n("SELECT COUNT() FROM " + _V18_CONTRACT),
    run=_v18_duplicate_contracts,
    proves="No Order in this batch was contracted twice",
    cannot_prove="Contracts that share a Quote but not an Order -- only the Order half of the "
                 "run book's source gate is checked -- or Contracts with a null batch link "
                 "(SCOPE.CONTRACT_NO_BATCH counts those)"))

BINDINGS["CONTRACT.DUPLICATE_PER_ORDER"] = dict(runbook_order=38, blocks=(),
  remediation=_R(summary="Run the v3 duplicate-Contract classifier; it separates real duplicates.",
    runbook_order=38,
    script="11_claude_review_tooling/03_Remediate_Duplicate_Contract_Proposal_Repeatable_v3.apex",
    writes=False, approval="Whoever owns the Contract",
    steps=["Run the v3 script: it classifies each multi-Contract account as CONFIRMED_CANDIDATE, "
           "CLEARED or NEEDS_MANUAL_REVIEW.",
           "Overlap in weekday or frequency alone is not evidence. Only a shared Order or Quote is."]))


# ------------------------------------------------------------------ polygon twins
def _v18_polygon_twins(c):
    """
    Two things that go wrong around a repoint, and the reconciliation file's method cannot see
    either: it matched a dead polygon to a live TERRITORY of the same name, never checking
    whether a live POLYGON of that name already existed. TOM-D (2026-10-02) was repointed and
    found to have a same-named live twin.
    """
    try:
        n_terr = c.n("SELECT COUNT() FROM ServiceTerritory")
        n_poly = c.n("SELECT COUNT() FROM FSL__Polygon__c WHERE FSL__Service_Territory__c != null")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not count territories or polygons: %s" % str(e)[:200])
    if n_terr > TERR_CAP or n_poly > POLY_CAP:
        return Evidence(unprovable=(
            "This org has %d territories and %d polygons but this check reads at most %d and %d. "
            "Liveness is judged by ABSENCE from the territory list, so a partial read would "
            "invent findings. Raise TERR_CAP / POLY_CAP and re-run." % (n_terr, n_poly, TERR_CAP, POLY_CAP)))
    try:
        terrs = c.q("SELECT Id FROM ServiceTerritory")
        polys = c.q("SELECT Id, Name, FSL__Service_Territory__c FROM FSL__Polygon__c "
                    "WHERE FSL__Service_Territory__c != null")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read territories or polygons: %s" % str(e)[:200])
    if not terrs or not polys:
        return Evidence(unprovable="No ServiceTerritory or FSL__Polygon__c records readable.")

    live = {t.get("Id") for t in terrs}
    by_name = {}
    for p in polys:
        nm = str(p.get("Name") or "").strip().upper()
        if nm:
            by_name.setdefault(nm, []).append(p)

    rows, suffix_pairs = [], 0
    for nm, ps in sorted(by_name.items()):
        live_ps = [p for p in ps if p.get("FSL__Service_Territory__c") in live]
        dead_ps = [p for p in ps if p.get("FSL__Service_Territory__c") not in live]
        if len(live_ps) >= 2:
            rows.append({"kind": "DUPLICATE -- same name, both live", "polygon": ps[0].get("Name"),
                         "polygon_ids": ", ".join(str(p.get("Id")) for p in live_ps),
                         "territory_ids": ", ".join(sorted({str(p.get("FSL__Service_Territory__c"))
                                                            for p in live_ps})),
                         "issue": "two live polygons carry one name; if their boundaries overlap, "
                                  "which one an address resolves to is ambiguous"})
        if live_ps and dead_ps:
            for d in dead_ps:
                rows.append({"kind": "RETIRE, DO NOT REPOINT -- a live polygon of this name exists",
                             "polygon": d.get("Name"), "polygon_id": d.get("Id"),
                             "dead_territory_id": d.get("FSL__Service_Territory__c"),
                             "live_twin_id": live_ps[0].get("Id"),
                             "live_twin_territory_id": live_ps[0].get("FSL__Service_Territory__c"),
                             "issue": "repointing this one would create a duplicate"})
    bases = {}
    for nm in by_name:
        bases.setdefault(_re.sub(r"_\d+$", "", nm), set()).add(nm)
    suffix_pairs = sum(1 for v in bases.values() if len(v) > 1)

    n_dup = len([r for r in rows if r["kind"].startswith("DUPLICATE")])
    n_ret = len(rows) - n_dup
    note = ""
    if rows or suffix_pairs:
        note = ("%d same-name live duplicate(s); %d dead polygon(s) whose name already has a live "
                "polygon (retire, do not repoint). %d name(s) differ only by a _<n> suffix "
                "(e.g. GNV-B / GNV-B_2) -- often a legitimate second polygon for a non-contiguous "
                "area, so NOT flagged."
                % (n_dup, n_ret, suffix_pairs))
    return Evidence(rows=rows, processed=len(polys), note=note)


CHECKS.append(Check(
    id="FSL.DUPLICATE_POLYGONS", name="Map polygons duplicated by name, or about to be",
    stage="pre", sequence=185, sobject="ServiceTerritory", severity=WARNING,
    requires=("FSL__Polygon__c.FSL__Service_Territory__c",),
    rule="Each polygon name appears once among live polygons, and a dead polygon is repointed "
         "only if no live polygon already carries its name",
    rule_source="2026-10-02: TOM-D was repointed and found to have a live same-named twin "
                "(a1ZVD000000dWA92AM). Polygon_Territory_Reconciliation_HANDOFF row GNV-B_2 "
                "raises the same question and leaves it open",
    canary=lambda c: c.n("SELECT COUNT() FROM FSL__Polygon__c"),
    run=_v18_polygon_twins,
    proves="No two live polygons share a name, and no pending repoint would create a twin",
    cannot_prove="Whether two polygons' BOUNDARIES overlap -- that needs the geometry, which a "
                 "query cannot compare. It finds the pairs a person should look at."))

BINDINGS["FSL.DUPLICATE_POLYGONS"] = dict(runbook_order=29, blocks=(),
  remediation=_R(summary="Retire a dead polygon that has a live twin; repoint only the rest.",
    runbook_order=29,
    script="29_umb0117_dead_polygons/TF_90A.05_Repoint_Dead_Service_Territory_Polygons.apex",
    writes=False, approval="A person decides each pair",
    steps=["Run this BEFORE applying the remaining repoints. Every 'RETIRE, DO NOT REPOINT' row "
           "is a polygon the reconciliation file would turn into a duplicate.",
           "For a same-name live pair, compare the two boundaries on the FSL map. Overlap means "
           "retire one; a deliberate split means leave both.",
           "A _<n> suffix pair is not flagged: it is often a legitimate second polygon."],
    note="The reconciliation file's 'HIGH - exact live name match' confidence checks the "
         "territory, not the polygon. This is the missing half."))


# ------------------------------------------------------------------ logged generation errors
_V18_LOG_CAP = 500
_V18_LOG_FAMILY = ("(Related_Object__c LIKE 'ContractOrders%' OR Related_Object__c IN "
                   "('Work Order','ServiceAppointment','WorkOrderLineItem'))")
_V18_LOG_CAUSES = (
    ("DateTimeUtility.convertTimeZone",
     "NullPointerException reading a timezone: the Work Order was being built against a "
     "ServiceTerritory that is null. Usually a map polygon pointing at a DELETED territory "
     "(FSL.DEAD_POLYGONS) or an address no polygon contains (JOBSITE.NO_GEOCODE)."),
    ("INVALID_CROSS_REFERENCE_KEY",
     "An external system pushed a Work Order whose lookup names an Id that does not exist here. "
     "The ServiceAppointment and WOLI errors that follow are collateral. The request payload is "
     "not captured, so the bad field cannot be named from Salesforce."),
    ("TR001_Service_BeforeInsert",
     "FSL's own trigger failed on a ServiceAppointment -- almost always collateral of the "
     "Work Order failing first."),
    ("Foreign key external ID",
     "A child record named its parent Work Order by External_Id__c, and that Work Order was "
     "never created."),
)


def _v18_logged_errors(c):
    """
    BatchContractOrders catches its own exceptions and writes them to Log__c, so AsyncApexJob
    reports 'Completed, 0 errors' while Work Orders silently fail to appear. This is where the
    cause is written down.
    """
    win = _batch_window(c)
    if not win.get("ok"):
        return Evidence(unprovable="%s Log__c has no batch link, so rows can only be attributed by "
                                   "the batch's time window." % win.get("why", ""))
    where = _V18_LOG_FAMILY + " AND CreatedDate >= " + win["lo"]
    if win.get("hi"):
        where += " AND CreatedDate <= " + win["hi"]
    try:
        total = c.n("SELECT COUNT() FROM Log__c WHERE " + where)
        recs = c.q("SELECT Id, CreatedDate, Log_Type__c, Related_Object__c, Message__c, "
                   "Stack_Trace__c, Error_Status_Code__c FROM Log__c WHERE " + where +
                   " ORDER BY CreatedDate")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read Log__c: %s" % str(e)[:200])

    rows, tally, ignored = [], {}, 0
    for r in recs:
        text = " ".join(str(r.get(k) or "") for k in
                        ("Message__c", "Stack_Trace__c", "Error_Status_Code__c"))
        low = text.lower()
        looks_like_error = bool(r.get("Error_Status_Code__c")) or "exception" in low or "error" in low \
            or "fail" in low or str(r.get("Log_Type__c") or "").lower() in ("error", "exception", "fatal")
        if not looks_like_error:
            ignored += 1                   # an informational row from the same family is not an error
            continue
        cause = next((why for key, why in _V18_LOG_CAUSES if key in text),
                     "Unclassified -- open the record and read the stack trace.")
        frame = _re.search(r"Class\.([A-Za-z0-9_.]+): line \d+", text)
        rel = str(r.get("Related_Object__c") or "")
        rows.append({"log_id": r.get("Id"), "created": r.get("CreatedDate"),
                     "log_type": r.get("Log_Type__c"), "related": rel,
                     "family": ("BatchContractOrders (caught and swallowed)"
                                if rel.startswith("ContractOrders") else "external Work Order push"),
                     "first_frame": frame.group(1) if frame else "", "cause": cause})
        tally[cause[:48]] = tally.get(cause[:48], 0) + 1
    note = ""
    if rows:
        note = ("%d error(s) logged while this batch ran (window %s; %d informational row(s) ignored). %s%s"
                % (len(rows), win.get("label", ""), ignored,
                   "; ".join("%d x %s..." % (v, k) for k, v in sorted(tally.items(), key=lambda x: -x[1])),
                   (" Only %d of %d were read." % (len(rows), total)) if total > len(rows) else ""))
    return Evidence(rows=rows, processed=total, note=note, ran_from=win["lo"],
                    ran_to=win.get("hi", ""))


CHECKS.append(Check(
    id="LOG.WORKORDER_GENERATION_ERRORS", name="Errors logged while Work Orders were generated",
    stage="tf_35", sequence=112, sobject="Log__c", severity=WARNING,
    requires=("Log__c.Related_Object__c", "Log__c.Message__c", "Log__c.Log_Type__c"),
    rule="Work Order generation logs no errors in the batch's window",
    rule_source="2026-10-02: Log__c a1vVD00000JEUPt (NullPointerException in "
                "DateTimeUtility.convertTimeZone, via BatchContractOrders.finish) and "
                "a1vVD00000JEz7B/C/D (external Work Order push cascade). AsyncApexJob showed 0 "
                "errors throughout because BatchContractOrders catches the exception",
    canary=lambda c: c.n("SELECT COUNT() FROM Log__c"),
    run=_v18_logged_errors,
    proves="Nothing that generates Work Orders wrote an error to Log__c during the batch",
    cannot_prove="That every failure was logged -- an exception thrown before the logger runs "
                 "leaves no record. Log__c has no batch link, so rows are attributed by time "
                 "window and logger name; the external-push rows can include other teams' errors."))

BINDINGS["LOG.WORKORDER_GENERATION_ERRORS"] = dict(runbook_order=28, blocks=(),
  remediation=_R(summary="Read the logged cause before regenerating Work Orders.",
    runbook_order=28,
    script="24_umb0116_missing_workorders/TF_90A.04_Classify_Orders_Missing_Work_Orders.apex",
    writes=False, approval="",
    steps=["Each row carries the first stack frame and a plain-language cause. Group by cause: "
           "different causes need different fixes.",
           "A convertTimeZone NullPointerException means a null ServiceTerritory. Run "
           "FSL.DEAD_POLYGONS and apply the repoints; regenerating first just fails again.",
           "An INVALID_CROSS_REFERENCE_KEY cascade is an external system's bad payload. The "
           "payload is not stored here -- ask whoever owns that integration.",
           "WO.ORDERS_MISSING_WOS says WHAT is missing; this says WHY."],
    note="Added because the cause was found in Log__c only after hours of elimination."))


# ------------------------------------------------------------------ steps that are done by hand
# Two run book steps leave NOTHING the other checks can see if they are skipped. Both rules below
# are quoted from the run book's own description of the step; neither is invented here.

def _goose_weekday_gap(c):
    """
    RO 37. The run book gives the exact gap-isolating query: 'What lands on this row is only the
    gap the stored procedure declines to fix.' Rows still matching it are Maintenance Plans whose
    new weekday / start date nobody has supplied yet.
    """
    sfid = c.sf_batch_id()
    if not sfid:
        return Evidence(unprovable="Could not resolve the Salesforce Id of %s, so Goose cannot be "
                                   "scoped to it." % c.batch)
    try:
        mb = c.gq("SELECT TOP 1 mb.ID AS ID FROM dbo.MigrationBatch mb "
                  "WHERE mb.SalesforceUssMigrationBatchID = '%s'" % sfid)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read this batch from Goose: %s" % str(e)[:200])
    if not mb or mb[0].get("ID") in (None, ""):
        return Evidence(unprovable="Goose has no MigrationBatch for %s." % c.batch)
    gid = str(mb[0]["ID"]).strip()
    gid = gid if gid.lstrip("-").isdigit() else "'%s'" % gid.replace("'", "''")
    base = "FROM Goose.dbo.SFDC_MaintenancePlan WHERE MigrationBatchID = %s" % gid
    try:
        total = c.gn("SELECT COUNT_BIG(*) AS C " + base)
        rows = c.gq("SELECT SalesforceMaintenancePlanID AS Id, Day_of_Week__c, StartDate, "
                    "New_Day_of_Week__c, New_StartDate, SFDC_AccountID, SFDC_OrderID " + base +
                    " AND (New_Day_of_Week__c IS NULL OR LEN(LTRIM(RTRIM(New_Day_of_Week__c))) = 0 "
                    "OR New_StartDate IS NULL)")
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read SFDC_MaintenancePlan from Goose: %s" % str(e)[:200])
    if not total:
        return Evidence(unprovable="Goose has no SFDC_MaintenancePlan rows for this batch, so there "
                                   "is nothing to compare.")
    note = ("%d of %d Maintenance Plan(s) in Goose still have no New_Day_of_Week__c or "
            "New_StartDate. These are the ones the stored procedure declines to fix, so a person "
            "has to supply them (RO 37)." % (len(rows), total)) if rows else ""
    return Evidence(rows=rows, processed=int(total), note=note)


CHECKS.append(Check(
    id="GOOSE.MP_WEEKDAY_GAP", name="Maintenance Plans still missing a corrected weekday / start date",
    stage="tf_40", sequence=105, sobject="MaintenancePlan", severity=WARNING, needs_goose=True,
    rule="After 'Fix MPs with incorrect weekdays', no Maintenance Plan in Goose is left with a null "
         "New_Day_of_Week__c or New_StartDate",
    rule_source="Run book RO 37 (TF_40.Fix MPs with incorrect weekdays): the stored procedure fixes "
                "~95.83% of Day_of_Week__c and ~89.06% of StartDate; the remainder is manual. The "
                "query is the run book's own",
    canary=lambda c: c.gn("SELECT COUNT_BIG(*) AS C FROM Goose.dbo.SFDC_MaintenancePlan"),
    run=_goose_weekday_gap,
    proves="Nothing is left in the gap the run book assigns to a person",
    cannot_prove="That the values that WERE supplied are correct, or that the sync has copied them "
                 "to Salesforce yet. Column names and the MigrationBatchID = Goose MigrationBatch.ID "
                 "scoping come from the run book text and have not been confirmed against Goose."))


def _goose_batch_gid(c):
    """-> (goose batch id as SQL literal, None) or (None, Evidence explaining why not)."""
    sfid = c.sf_batch_id()
    if not sfid:
        return None, Evidence(unprovable="Could not resolve the Salesforce Id of %s, so Goose cannot be "
                                         "scoped to it." % c.batch)
    try:
        mb = c.gq("SELECT TOP 1 mb.ID AS ID FROM dbo.MigrationBatch mb "
                  "WHERE mb.SalesforceUssMigrationBatchID = '%s'" % sfid)
    except Exception as e:                                   # noqa: BLE001
        return None, Evidence(unprovable="Could not read this batch from Goose: %s" % str(e)[:200])
    if not mb or mb[0].get("ID") in (None, ""):
        return None, Evidence(unprovable="Goose has no MigrationBatch for %s." % c.batch)
    gid = str(mb[0]["ID"]).strip()
    return (gid if gid.lstrip("-").isdigit() else "'%s'" % gid.replace("'", "''")), None


def _customer_owned_flag(c):
    """
    Touch point 135: operators complete then un-complete a Work Order by hand to make billing
    generate for customer-owned units. Suspected cause: IsCustomerOwned is hardcoded to 0 in the
    Navision transformation. The guide's test: is the flag the same value on every row?
    """
    gid, bad = _goose_batch_gid(c)
    if bad:
        return bad
    out, notes, uniform_zero, seen, stg_seen = [], [], [], 0, 0
    for table, col in (("STG_OrderLineItem", "IsCustomerOwned"), ("STG_Order", "IsCustomerOwned"),
                       ("SFDC_Quote_Line", "CustomerOwned__c")):
        try:
            cols = {str(r.get("COLUMN_NAME") or "").lower() for r in c.gq(
                "SELECT COLUMN_NAME FROM Goose.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'dbo' "
                "AND TABLE_NAME = '%s'" % table)}
        except Exception as e:                               # noqa: BLE001
            return Evidence(unprovable="Could not read the columns of %s: %s" % (table, str(e)[:160]))
        if col.lower() not in cols:
            notes.append("%s has no %s column." % (table, col)); continue
        bcol = next((x for x in ("migrationbatchid",) if x in cols), None)
        where = (" WHERE MigrationBatchID = %s" % gid) if bcol else ""
        try:
            grp = c.gq("SELECT %s AS V, COUNT_BIG(*) AS N FROM Goose.dbo.%s%s GROUP BY %s"
                       % (col, table, where, col))
        except Exception as e:                               # noqa: BLE001
            return Evidence(unprovable="Could not read %s: %s" % (table, str(e)[:160]))
        seen += sum(int(g.get("N") or 0) for g in grp)
        if table.startswith("STG_") and grp:
            stg_seen += 1
        vals = {str(g.get("V")) for g in grp}
        if not bcol:
            notes.append("%s has no MigrationBatchID, so this is the whole table, not just this batch." % table)
        if table.startswith("STG_") and grp and vals <= {"0", "False", "false", "None"}:
            uniform_zero.append(table)
            for g in grp:
                out.append({"table": table, "column": col, "value": g.get("V"), "rows": g.get("N"),
                            "issue": "every row says the unit is NOT customer-owned"})
        if table == "SFDC_Quote_Line" and len(vals) > 1:
            notes.append("SFDC_Quote_Line.CustomerOwned__c carries real, mixed values -- the smaller "
                         "fix point (guide step 3B).")
    if not stg_seen:
        return Evidence(unprovable="Neither STG_OrderLineItem nor STG_Order could be read (or they have no "
                                   "IsCustomerOwned column / no rows), so the flag cannot be judged. "
                                   + " ".join(notes))
    note = ""
    if uniform_zero:
        note = ("IsCustomerOwned is 0 on every row of %s. That is what a hardcoded flag looks like "
                "(guide issue 1). It is only legitimate if this batch has no customer-owned units. %s"
                % (" and ".join(uniform_zero), " ".join(notes)))
    return Evidence(rows=out, processed=seen, note=note)


CHECKS.append(Check(
    id="GOOSE.CUSTOMER_OWNED_FLAG", name="Customer-owned flag is the same on every staged row",
    stage="tf_55", sequence=190, sobject="WorkOrder", severity=WARNING, needs_goose=True,
    rule="IsCustomerOwned in STG_OrderLineItem and STG_Order is not 0 on every row when customer-owned "
         "units exist",
    rule_source="Manual Touch Points guide, issue 1 (run book step 135): operators complete then "
                "un-complete a Work Order by hand because the flag is suspected hardcoded to 0 "
                "([IsCustomerOwned] = 0 in vw_Order / vw_OrderLineItem). Column names are the guide's "
                "and have not been confirmed against Goose",
    canary=lambda c: c.gn("SELECT COUNT_BIG(*) AS C FROM Goose.dbo.STG_OrderLineItem"),
    run=_customer_owned_flag,
    proves="Whether the staged flag carries any customer-owned units at all",
    cannot_prove="That a uniform 0 is wrong -- a batch with no customer-owned units looks the same. "
                 "A person decides that. It also cannot say which units SHOULD be customer-owned."))

BINDINGS["GOOSE.CUSTOMER_OWNED_FLAG"] = dict(runbook_order=43, blocks=(),
  remediation=_R(summary="Confirm whether the flag is hardcoded; if so, fix it at the source or at the Quote Line.",
    runbook_order=43, script="", writes=False, approval="Whoever owns the Navision extraction",
    steps=["If the rows show only 0: ask the owner of the Navision extraction what the real source of "
           "customer-owned is (a business question).",
           "If SFDC_Quote_Line.CustomerOwned__c has real values, redirect the BIQ logic to read it (smaller fix).",
           "Optionally ask whether SFDC_WorkOrder.CompleteWO / ResetStatusTo were meant to drive this."]))


def _mp_null_account(c):
    """Guide issue 2, step 1: every Maintenance Plan in Goose with no Account, with the Account it should have."""
    gid, bad = _goose_batch_gid(c)
    if bad:
        return bad
    try:
        total = c.gn("SELECT COUNT_BIG(*) AS C FROM Goose.dbo.SFDC_MaintenancePlan WHERE MigrationBatchID = %s" % gid)
        rows = c.gq("SELECT mp.SalesforceMaintenancePlanID AS Id, mp.StartDate, mp.SFDC_OrderID, "
                    "o.SFDC_AccountID AS ShouldBeAccountID FROM Goose.dbo.SFDC_MaintenancePlan mp "
                    "LEFT JOIN Goose.dbo.SFDC_Order o ON o.Id = mp.SFDC_OrderID "
                    "WHERE mp.MigrationBatchID = %s AND mp.SFDC_AccountID IS NULL "
                    "ORDER BY mp.SFDC_OrderID, mp.StartDate" % gid)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read SFDC_MaintenancePlan from Goose: %s" % str(e)[:200])
    if not total:
        return Evidence(unprovable="Goose has no SFDC_MaintenancePlan rows for this batch.")
    note = ("%d of %d Maintenance Plan(s) in Goose have no Account. ShouldBeAccountID is the Account on "
            "their Order. Whether a blank Account is what stops Work Orders generating is NOT proven "
            "(it was falsified on UMB-0116)." % (len(rows), total)) if rows else ""
    return Evidence(rows=rows, processed=int(total), note=note)


CHECKS.append(Check(
    id="GOOSE.MP_NULL_ACCOUNT", name="Maintenance Plans in Goose with no Account",
    stage="tf_40", sequence=106, sobject="MaintenancePlan", severity=WARNING, needs_goose=True,
    rule="Every Maintenance Plan in Goose has an Account (SFDC_AccountID)",
    rule_source="Manual Touch Points guide, issue 2 (run book step 129): every plan that needs a manual "
                "deactivate/reactivate also has a blank Account. The guide's own Step 1 query. Column "
                "names are the guide's and have not been confirmed against Goose",
    canary=lambda c: c.gn("SELECT COUNT_BIG(*) AS C FROM Goose.dbo.SFDC_MaintenancePlan"),
    run=_mp_null_account,
    proves="Which plans have no Account in Goose, and which Account they should have",
    cannot_prove="That the blank Account is why a plan does not generate Work Orders. On UMB-0116 5 of "
                 "1,027 active plans had it and none of the failing ones did."))

BINDINGS["GOOSE.MP_NULL_ACCOUNT"] = dict(runbook_order=41, blocks=(),
  remediation=_R(summary="Test the theory on ONE plan before fixing them all.",
    runbook_order=41, script="", writes=True, approval="Whoever owns the Maintenance Plan mapping (m_15)",
    steps=["Pick one plan from the list; set its Account to ShouldBeAccountID in Salesforce.",
           "If a Work Order generates by itself the cause is confirmed; if not, the fix is at plan creation.",
           "Only then choose: batch-patch, hand operators the list, or fix the sync timing upstream."]))


# ------------------------------------------------------------------ re-verify in Salesforce
# The three Goose-side findings above describe STAGING data. Once the load step has run, the question
# that matters is whether the same problem is in Salesforce. These ask Salesforce directly, so a gap
# that Goose showed and the load fixed (or a gap Goose did not show) is visible.
def _sf_mp_null_account(c):
    mps = c.q("SELECT Id, MaintenancePlanNumber, AccountId, Contract__c FROM MaintenancePlan "
              "WHERE Contract__r.USS_Migration_Batch__r.Name = '%s' AND AccountId = null" % B)
    total = c.n("SELECT COUNT() FROM MaintenancePlan WHERE Contract__r.USS_Migration_Batch__r.Name = '%s'" % B)
    if not total:
        return Evidence(unprovable="No Maintenance Plans in this batch.")
    return Evidence(rows=mps, processed=int(total),
                    note=("%d of %d Maintenance Plan(s) have no Account in Salesforce. Whether that is "
                          "why Work Orders do not generate is not proven." % (len(mps), total)) if mps else "")


def _sf_mp_weekday_gap(c):
    mps = c.q("SELECT Id, MaintenancePlanNumber, Day_of_Week__c, StartDate FROM MaintenancePlan "
              "WHERE Contract__r.USS_Migration_Batch__r.Name = '%s' AND Active__c = true "
              "AND Day_of_Week__c = null" % B)
    total = c.n("SELECT COUNT() FROM MaintenancePlan WHERE Contract__r.USS_Migration_Batch__r.Name = '%s' "
                "AND Active__c = true" % B)
    if not total:
        return Evidence(unprovable="No Active Maintenance Plans in this batch.")
    return Evidence(rows=mps, processed=int(total),
                    note=("%d of %d Active Maintenance Plan(s) still have no Day_of_Week__c in Salesforce "
                          "(the field the run book uses; DayoftheWeek__c is a dead field)." % (len(mps), total))
                    if mps else "")


def _sf_customer_owned(c):
    grp = c.q("SELECT CustomerOwned__c v, COUNT(Id) n FROM SBQQ__QuoteLine__c WHERE "
              "SBQQ__Quote__r.USS_Migration_Batch__r.Name = '%s' GROUP BY CustomerOwned__c" % B)
    total = sum(int(g.get("n") or 0) for g in grp)
    if not total:
        return Evidence(unprovable="No Quote Lines in this batch.")
    yes = sum(int(g.get("n") or 0) for g in grp if str(g.get("v")).lower() == "true")
    if yes:
        return Evidence(rows=[], processed=total)
    return Evidence(rows=[{"object": "SBQQ__QuoteLine__c", "field": "CustomerOwned__c", "value": g.get("v"),
                           "quote_lines": g.get("n"),
                           "issue": "no Quote Line is marked customer-owned"} for g in grp],
                    processed=total,
                    note="CustomerOwned__c is not true on any of %d Quote Line(s). Legitimate only if the batch "
                         "has no customer-owned units." % total)


CHECKS.append(Check(
    id="MP.SF_NULL_ACCOUNT", name="Maintenance Plans in Salesforce with no Account",
    stage="tf_40", sequence=107, sobject="MaintenancePlan", severity=WARNING,
    rule="Every Maintenance Plan in the batch has an Account once loaded",
    rule_source="Manual Touch Points guide, issue 2: re-asks in Salesforce what GOOSE.MP_NULL_ACCOUNT "
                "asks in Goose",
    canary=lambda c: c.n("SELECT COUNT() FROM MaintenancePlan WHERE "
                         "Contract__r.USS_Migration_Batch__r.Name='%s'" % B),
    run=_sf_mp_null_account,
    proves="Which loaded plans have no Account",
    cannot_prove="That a blank Account stops Work Orders generating -- not established"))
CHECKS.append(Check(
    id="MP.SF_WEEKDAY_GAP", name="Active Maintenance Plans in Salesforce with no weekday",
    stage="tf_40", sequence=108, sobject="MaintenancePlan", severity=WARNING,
    requires=("MaintenancePlan.Day_of_Week__c",),
    rule="Every Active Maintenance Plan has Day_of_Week__c once the weekday fix has run and synced",
    rule_source="Run book RO 37 and guide issue 3: re-asks in Salesforce what GOOSE.MP_WEEKDAY_GAP asks "
                "in Goose. Day_of_Week__c, not the dead DayoftheWeek__c",
    canary=lambda c: c.n("SELECT COUNT() FROM MaintenancePlan WHERE "
                         "Contract__r.USS_Migration_Batch__r.Name='%s' AND Active__c = true" % B),
    run=_sf_mp_weekday_gap,
    proves="Which loaded Active plans still have no weekday",
    cannot_prove="That the weekday present is the RIGHT one"))
CHECKS.append(Check(
    id="QL.SF_CUSTOMER_OWNED", name="Customer-owned flag on Quote Lines in Salesforce",
    stage="tf_55", sequence=191, sobject="SBQQ__QuoteLine__c", severity=WARNING,
    requires=("SBQQ__QuoteLine__c.CustomerOwned__c",),
    rule="CustomerOwned__c is true on at least one Quote Line when the batch has customer-owned units",
    rule_source="Manual Touch Points guide, issue 1 (step 135): re-asks in Salesforce what "
                "GOOSE.CUSTOMER_OWNED_FLAG asks in Goose. Field name is the staging column's and has not "
                "been confirmed on the Salesforce object",
    canary=lambda c: c.n("SELECT COUNT() FROM SBQQ__QuoteLine__c WHERE "
                         "SBQQ__Quote__r.USS_Migration_Batch__r.Name='%s'" % B),
    run=_sf_customer_owned,
    proves="Whether any loaded Quote Line carries the customer-owned flag",
    cannot_prove="That a uniform false is wrong -- a batch with no customer-owned units looks the same"))
BINDINGS["MP.SF_NULL_ACCOUNT"] = dict(runbook_order=41, blocks=(), remediation=_R(
    summary="Test the theory on ONE plan before fixing them all.", runbook_order=41, script="",
    writes=True, approval="Whoever owns the Maintenance Plan mapping (m_15)",
    steps=["Set the Account on one flagged plan and see whether a Work Order generates by itself."]))
BINDINGS["MP.SF_WEEKDAY_GAP"] = dict(runbook_order=37, blocks=(), remediation=_R(
    summary="Supply the weekday for the plans the procedure left, then re-sync.", runbook_order=37,
    script="", writes=True, approval="Whoever owns the Maintenance Plan schedule",
    steps=["Fix in Goose, re-run m_30 -> m_45 -> m_50, then re-check."]))
BINDINGS["QL.SF_CUSTOMER_OWNED"] = dict(runbook_order=43, blocks=(), remediation=_R(
    summary="Confirm whether the customer-owned flag is being set at all.", runbook_order=43, script="",
    writes=False, approval="Whoever owns the Navision extraction",
    steps=["See GOOSE.CUSTOMER_OWNED_FLAG for the source-side test."]))


def _presnapshot_file(c):
    """
    RO 42. 'Saves a JSON Salesforce File on USS_Migration_Batch__c capturing the pre-change state.'
    If the step was skipped there is no such file, and nothing else in the org shows it.
    """
    sfid = c.sf_batch_id()
    if not sfid:
        return Evidence(unprovable="Could not resolve the Salesforce Id of %s." % c.batch)
    try:
        rows = c.q("SELECT ContentDocumentId, ContentDocument.Title, ContentDocument.FileExtension, "
                   "ContentDocument.CreatedDate FROM ContentDocumentLink "
                   "WHERE LinkedEntityId = '%s'" % sfid)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read the files attached to the batch: %s" % str(e)[:200])
    js = [r for r in rows if str(r.get("ContentDocument.FileExtension") or "").lower() == "json"
          or str(r.get("ContentDocument.Title") or "").lower().endswith(".json")]
    for r in js:
        r["file"] = r.get("ContentDocument.Title")
        r["created"] = r.get("ContentDocument.CreatedDate")
    other = len(rows) - len(js)
    return Evidence(rows=js, processed=len(rows),
                    note=("%d JSON file(s) are attached to %s -- the pre-change snapshot exists."
                          % (len(js), c.batch)) if js else
                         ("No JSON file is attached to %s (%d other file(s) are). TF_55.01 saves its "
                          "pre-change snapshot as a JSON file here, so it was probably not run. "
                          "Run it BEFORE TF_55.02, or the before/after audit trail does not exist."
                          % (c.batch, other)))


CHECKS.append(Check(
    id="BATCH.PRESNAPSHOT_FILE", name="Pre-change snapshot file attached to the batch",
    stage="tf_55", sequence=107, sobject="USS_Migration_Batch__c", severity=WARNING,
    finds_problems=False,
    rule="A JSON file saved by TF_55.01 is attached to the migration batch before the bulk-complete",
    rule_source="Run book RO 42 (TF_55.01_Create_Pre_Snapshot.apex): 'Saves a JSON Salesforce File on "
                "USS_Migration_Batch__c capturing the pre-change state'",
    canary=lambda c: 1,
    run=_presnapshot_file,
    proves="A JSON file is attached to the batch, so a snapshot was saved",
    cannot_prove="That the file is TF_55.01's, that it is complete, or that it was saved BEFORE the "
                 "changes -- it matches on file type only, because the file name is not documented"))

BINDINGS["GOOSE.MP_WEEKDAY_GAP"] = dict(runbook_order=37, blocks=(),
  remediation=_R(summary="Supply the missing weekday / start date for the Maintenance Plans the procedure left.",
    runbook_order=37, script="", writes=True, approval="Whoever owns the Maintenance Plan schedule",
    steps=["Open the records: each row is a plan whose New_Day_of_Week__c or New_StartDate is still empty.",
           "These are the ones the stored procedure declines to fix; fix them by hand in Goose.",
           "Re-run the chain (m_30 -> m_45 -> m_50) so the values reach Salesforce, then re-check."]))
BINDINGS["BATCH.PRESNAPSHOT_FILE"] = dict(runbook_order=42, blocks=(),
  remediation=_R(summary="Run TF_55.01_Create_Pre_Snapshot.apex before the bulk complete.",
    runbook_order=42, script="", writes=True, approval="Whoever runs the Salesforce Apex steps for this batch",
    steps=["If TF_55.02 has not run yet, run TF_55.01 first.",
           "If TF_55.02 already ran, the true 'before' state is gone: note that in the batch record."]))


# ------------------------------------------------------------------ Goose batch status
def _v18_goose_batch_status(c):
    """
    CJ, via the Goose README: 'Salesforce and Goose disagree on batch status ... the pipeline
    acts on the Goose value, not the one visible in Salesforce.' Every vw_SFDC_OpenBatch_* view
    filters BatchStatus = 'Open' and takes MAX(ID), so a batch that is Canceled in Goose is
    invisible: Goose-side steps run, report success, and process nothing.
    """
    sfid = c.sf_batch_id()
    if not sfid:
        return Evidence(unprovable="Could not resolve the Salesforce Id of batch %s, which is the "
                                   "only key Goose's MigrationBatch carries." % c.batch)
    try:
        g = c.gq("SELECT TOP 1 mb.ID AS ID, mb.BatchStatus AS BatchStatus "
                 "FROM dbo.MigrationBatch mb WHERE mb.SalesforceUssMigrationBatchID = '%s'" % sfid)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Goose MigrationBatch query failed: %s" % str(e)[:300])
    if not g:
        return Evidence(unprovable="Goose has no MigrationBatch for the Salesforce batch %s (%s), so it is "
                                   "invisible to the pipeline." % (c.batch, sfid))
    try:
        s = c.q("SELECT Batch_Status__c FROM USS_Migration_Batch__c WHERE Name = '%s'" % B)
    except Exception as e:                                   # noqa: BLE001
        return Evidence(unprovable="Could not read the Salesforce batch status: %s" % str(e)[:200])
    sf_status = str((s or [{}])[0].get("Batch_Status__c") or "").strip()
    g_status = str(g[0].get("BatchStatus") or "").strip()
    active = sf_status.lower() in ("open", "processing")
    bad = active and g_status.lower() != "open"
    row = {"salesforce_status": sf_status, "goose_status": g_status, "goose_batch_id": g[0].get("ID"),
           "issue": "the batch is still active in Salesforce but Goose will not serve it to the pipeline"}
    note = ("Salesforce %s, Goose %s." % (sf_status or "(blank)", g_status or "(blank)"))
    if not active and g_status.lower() != "open":
        note += (" Both are terminal, so nothing is stranded. Open question for CJ: is 'Canceled' "
                 "the intended terminal state? No NAV batch has ever reached 'Complete'.")
    return Evidence(rows=[row] if bad else [], processed=1, note=note)


CHECKS.append(Check(
    id="GOOSE.BATCH_STATUS", name="Batch is still served by the Goose pipeline",
    stage="pre", sequence=5, sobject="USS_Migration_Batch__c", severity=BLOCKER,
    needs_goose=True,
    rule="While a batch is active in Salesforce its Goose MigrationBatch is Open",
    rule_source="28_goose_sql_definitions README, 'Two things to raise with CJ'; Run Book Standing "
                "Rule 'Verify the batch itself first' (RO 1). On UMB-0116 Goose was Canceled and "
                "Salesforce Closed",
    canary=lambda c: c.gn("SELECT COUNT_BIG(*) AS C FROM dbo.MigrationBatch"),
    run=_v18_goose_batch_status,
    proves="The batch Goose-side steps act on is the batch being worked",
    cannot_prove="Whether a higher-numbered Open batch for the same acquisition code is the one "
                 "the views actually serve (MAX(ID) picks it) -- that needs the view itself"))

BINDINGS["GOOSE.BATCH_STATUS"] = dict(runbook_order=1, blocks=(),
  remediation=_R(summary="Open the batch in Goose, or accept that Goose-side steps will do nothing.",
    runbook_order=1, script="28_goose_sql_definitions/vw_GOOSE_OpenMigrationBatches.sql",
    writes=False, approval="CJ",
    steps=["Every vw_SFDC_OpenBatch_* view filters BatchStatus = 'Open' and takes MAX(ID). A "
           "Canceled batch is invisible to all of them.",
           "TF_75 and every other Goose-fed step will run, report success, and process zero rows.",
           "Ask CJ whether the batch should be reopened or the Goose-side work done another way."],
    note="Goose is unreachable in most runs, in which case this reports UNPROVEN, not a pass."))
