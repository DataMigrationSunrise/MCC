"""
The words this tool uses, in one place.

Four different things used to share the words "error" and "blocked", which is why a run could
read "10,039 errors" when one check, on one batch's staging, accounted for 7,910 of them.
Each word now means exactly one thing:

  FINDING   what a CHECK concluded                 Clear / Issue / Unproven
  IMPACT    how much an issue matters              Blocker / Review / Note
  STATUS    whether you may go past a run book step Ready / Review / Blocked / Held / Unproven
  ERROR     the TOOL or a JOB failed -- never a finding about the data

These are DISPLAY labels. The stored values (verdict FAIL, severity WARNING, ...) are
unchanged, so history written by an earlier version still opens and still means the same.
"""
from __future__ import annotations

# stored severity -> the word shown
SEVERITY_LABEL = {"BLOCKER": "BLOCKER", "WARNING": "REVIEW", "INFO": "NOTE",
                  "UNPROVEN": "UNPROVEN"}

# WHAT A CHECK'S NUMBER COUNTS. Only "record" checks add to a failing-records total or an object
# tile: those rows are Salesforce records, each with an Id. Everything else counts something
# different -- a job, a staged row that is not in Salesforce yet, a log entry, a batch -- and
# adding it to the records total is how 10,039 "failing records" came to include 47 async jobs,
# 7,910 staged-data issues and a single marker row.
_UNITS = (
    ("GOOSE.MP_WEEKDAY_GAP", "record", "records"),       # rows are Maintenance Plans (by Salesforce Id)
    ("GOOSE.MP_NULL_ACCOUNT", "record", "records"),      # rows are Maintenance Plans (by Salesforce Id)
    ("GOOSE.CUSTOMER_OWNED_FLAG", "staged value group", "staged value groups"),
    ("QL.SF_CUSTOMER_OWNED", "value group", "value groups"),
    ("RAN.GOOSE_ERRORLOG", "Goose error row", "Goose error rows"),
    ("RAN.STEP_NOT_FINISHED", "async job", "async jobs"),
    ("RAN.", "step that produced nothing", "steps that produced nothing"),
    ("PREDICT.", "staged row", "staged rows"),
    ("LOG.", "log entry", "log entries"),
    ("GOOSE.BIQ_PARITY", "count mismatch", "count mismatches"),
    ("GOOSE.", "batch", "batches"),
    ("BATCH.", "batch", "batches"),
    ("SCHEMA.", "field", "fields"),
)


def unit_of(check_id: str):
    """-> (one, many) for what this check counts. ('record','records') for Salesforce records."""
    for prefix, one, many in _UNITS:
        if str(check_id).startswith(prefix):
            return one, many
    return "record", "records"


def is_record(check_id: str) -> bool:
    return unit_of(check_id)[0] == "record"


# what to call the COUNT of wrong records. Not "errors": an error is a fault in the tool.
FAILING = "failing"

GLOSSARY = [
    ("What a check found", [
        ("Clear", "The check ran and found nothing wrong."),
        ("Issue", "The check ran and found records that are wrong. The number is "
                  "<b>failing records</b>."),
        ("Unproven", "The check could not run (no access, a hidden field, Goose down). "
                     "<b>Not a pass.</b> Nothing is known either way."),
    ]),
    ("How much an issue matters", [
        ("Blocker", "Going past this step would give a wrong or harmful result. "
                    "Fix it first."),
        ("Review", "Wrong, but later steps can still run. A person decides what to do. "
                   "Was called a warning or an exception."),
        ("Note", "For information only."),
    ]),
    ("Whether you can pass a run book step", [
        ("Ready", "Checked, nothing in the way."),
        ("Review", "Passable, but this step has issues to look at."),
        ("Blocked", "This step has a blocker of its own. Fix it here."),
        ("Held", "Nothing wrong at this step, but a blocker elsewhere stops you reaching "
                 "it. Fix the step named under it, not this one."),
        ("Unproven", "Could not be checked."),
        ("Not checked / Not run", "No check covers it yet, or no run has been made."),
    ]),
    ("Error", [
        ("Error", "Reserved for the <b>tool or a job failing</b>: a query that failed, an "
                  "Informatica job that stopped. It says nothing about the data."),
    ]),
]


def glossary_html() -> str:
    out = ["<details class='gloss'><summary>What these words mean</summary><div class='gb'>"]
    for head, items in GLOSSARY:
        out.append("<div class='gh'>%s</div>" % head)
        for term, meaning in items:
            out.append("<div class='gi'><span class='gt'>%s</span><span>%s</span></div>"
                       % (term, meaning))
    out.append("</div></details>")
    return "".join(out)


def sev(severity: str) -> str:
    return SEVERITY_LABEL.get(severity, severity)
