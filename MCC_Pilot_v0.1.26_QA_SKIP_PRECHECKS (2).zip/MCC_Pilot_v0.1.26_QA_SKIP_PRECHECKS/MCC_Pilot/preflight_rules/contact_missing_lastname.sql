SELECT CC.ID AS SourceRecordId,
       'Contact missing required LastName' AS Reason
FROM dbo.STG_CustomerContact CC
INNER JOIN dbo.TRFM_Transformation T ON T.ID = CC.TransformationID
WHERE T.MigrationBatchID = {{GOOSE_BATCH_ID}}
  AND (CC.LastName IS NULL OR LTRIM(RTRIM(CC.LastName)) = '')
  AND ISNULL(CC.SFDC_Goose_ExclusionReason, '') = ''
