"""
Live connections. The pilot reuses what the team already runs:

  Salesforce   sf CLI (same as the MCC Preflight Monitor and control_center.py)
  Goose        Sunrise goose_live.invoke_query (same binding as the MCC Preflight Monitor)
  Informatica  Sunrise informatica_live (run_and_wait, else start_taskflow + get_run_status)
  SnapLogic    Triggered Task URL with a bearer token, or the operator runs it by hand
  Jira         optional REST comment with the run summary

No secret is ever read from config.json. Tokens come from environment variables whose
NAMES are in config.json.
"""
from __future__ import annotations

import base64
import inspect
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path


class AdapterError(RuntimeError):
    pass


# ------------------------------------------------------------------ Salesforce
def _sf() -> str:
    exe = shutil.which("sf") or shutil.which("sf.cmd")
    if not exe:
        raise AdapterError("Salesforce CLI (sf) not found on PATH.")
    return exe


def _sf_json(args: list[str], timeout: int) -> dict:
    cp = subprocess.run([_sf()] + args + ["--json"], capture_output=True, text=True,
                        timeout=timeout)
    try:
        payload = json.loads(cp.stdout or "{}")
    except json.JSONDecodeError as e:
        raise AdapterError("sf returned non-JSON: %s %s" % (cp.stdout[-500:], cp.stderr[-500:])) from e
    if cp.returncode != 0 and not payload.get("result"):
        raise AdapterError(payload.get("message") or cp.stderr[-800:] or "sf failed")
    return payload.get("result") or {}


class Salesforce:
    def __init__(self, alias: str, allowed_hosts: list[str]):
        self.alias = alias
        self.allowed_hosts = [h.lower() for h in allowed_hosts]

    def verify_sandbox(self) -> str:
        """Refuse anything that is not an allowed QA sandbox. Returns a description."""
        info = _sf_json(["org", "display", "--target-org", self.alias], 120)
        url = (info.get("instanceUrl") or "").lower()
        host = re.sub(r"^https?://", "", url).split("/")[0]
        rows = self.query("SELECT IsSandbox, Name FROM Organization")
        is_sb = bool(rows and rows[0].get("IsSandbox"))
        if not is_sb:
            raise AdapterError("REFUSED: %s is not a sandbox. The pilot only runs on QA." % self.alias)
        if self.allowed_hosts and host not in self.allowed_hosts:
            raise AdapterError("REFUSED: %s is not in AllowedOrgHosts %s" % (host, self.allowed_hosts))
        return "%s (%s, sandbox, %s)" % (self.alias, host, info.get("username", ""))

    def query(self, soql: str, timeout: int = 180) -> list[dict]:
        if not soql.strip().upper().startswith("SELECT"):
            raise AdapterError("Only SELECT queries are allowed through query().")
        # SOQL goes through a file: names with & | ^ break the Windows command line, and long
        # IN lists hit the command-length limit (WinError 206).
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "pilot.soql"
            f.write_text(soql, encoding="utf-8")
            res = _sf_json(["data", "query", "--file", str(f), "--target-org", self.alias], timeout)
        return res.get("records") or []

    def run_apex(self, code: str, timeout: int = 900) -> dict:
        """Anonymous Apex. Returns {ok, error, debug: [lines], raw}."""
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "pilot.apex"
            f.write_text(code, encoding="utf-8")
            res = _sf_json(["apex", "run", "--file", str(f), "--target-org", self.alias], timeout)
        ok = bool(res.get("success")) and bool(res.get("compiled", True))
        err = res.get("compileProblem") or res.get("exceptionMessage") or ""
        return dict(ok=ok, error=err, debug=debug_lines(res.get("logs") or ""), raw=res.get("logs") or "")


_DBG = re.compile(r"\|USER_DEBUG\|\[\d+\]\|\w+\|(.*)$")
_LOGLINE = re.compile(r"^\d{2}:\d{2}:\d{2}\.\d+ \(")


def debug_lines(log: str) -> list[str]:
    """USER_DEBUG messages from an Apex log, multi-line messages kept together."""
    out, cur = [], None
    for line in log.splitlines():
        m = _DBG.search(line)
        if m:
            if cur is not None:
                out.append(cur)
            cur = m.group(1)
        elif cur is not None and not _LOGLINE.match(line):
            cur += "\n" + line
        elif cur is not None:
            out.append(cur)
            cur = None
    if cur is not None:
        out.append(cur)
    return out


# ------------------------------------------------------------------ Sunrise discovery
def find_sunrise(explicit: str) -> Path | None:
    """The folder that holds goose_live/goose_live.py, at the path or up to 4 levels below."""
    roots = [Path(p) for p in (explicit, os.environ.get("SUNRISE_APP", "")) if p]
    for root in roots:
        if not root.exists():
            continue
        frontier, seen = [(root, 0)], 0
        while frontier and seen < 4000:
            cur, depth = frontier.pop(0)
            if (cur / "goose_live" / "goose_live.py").is_file():
                return cur
            if depth >= 4:
                continue
            try:
                for k in cur.iterdir():
                    if k.is_dir() and not k.name.startswith(".") and k.name not in (
                            "node_modules", "__pycache__", "AppData", "venv"):
                        seen += 1
                        frontier.append((k, depth + 1))
            except (OSError, PermissionError):
                pass
    return None


def _bind_path(app_dir: str) -> Path:
    root = find_sunrise(app_dir)
    if root is None:
        raise AdapterError("Sunrise app not found under %r. Set SunriseAppDir in config.json." % app_dir)
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    return root


# ------------------------------------------------------------------ Goose
class Goose:
    def __init__(self, app_dir: str, server: str, database: str):
        root = _bind_path(app_dir)
        try:
            from goose_live import goose_live as gl  # type: ignore
        except Exception as e:  # noqa: BLE001
            raise AdapterError("Found Sunrise at %s but goose_live failed to import: %s" % (root, e)) from e
        for fn in ("invoke_query",):
            if not hasattr(gl, fn):
                raise AdapterError("goose_live.%s is missing; Sunrise's interface changed." % fn)
        self.gl, self.server, self.database = gl, server, database

    def result_sets(self, sql: str, timeout: int = 600, read_only: bool = False) -> list[list[dict]]:
        """Run a script and return every result set it produced.

        Uses MCC's own runner: Sunrise's invoke_query returns only the FIRST result set (generator
        scripts lost their Apex set) and passes the SQL on the command line (WinError 206)."""
        runner = Path(__file__).with_name("goose_runner.ps1")
        with tempfile.TemporaryDirectory() as td:
            src, out = Path(td) / "q.sql", Path(td) / "q.json"
            src.write_text(sql, encoding="utf-8")
            cp = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(runner),
                                 "-Server", self.server, "-Database", self.database or "Goose",
                                 "-SqlFile", str(src), "-OutputFile", str(out),
                                 "-CommandTimeoutSeconds", str(int(timeout))] + (["-ReadOnly"] if read_only else []),
                                capture_output=True, text=True, timeout=int(timeout) + 60)
            if cp.returncode != 0:
                raise AdapterError("Goose query failed: %s" % (cp.stderr or cp.stdout).strip()[-1500:])
            text = out.read_text(encoding="utf-8-sig") if out.exists() else "[]"
        return normalize_sets(json.loads(text or "[]"))


def normalize_sets(data) -> list[list[dict]]:
    """Accept the shapes a JSON query runner produces: rows, list of row lists, or tables."""
    if isinstance(data, dict):
        for key in ("Tables", "tables", "ResultSets", "resultSets", "results"):
            if key in data:
                return normalize_sets(data[key])
        if "Rows" in data or "rows" in data:
            return [data.get("Rows") or data.get("rows") or []]
        return [[data]]
    if isinstance(data, list):
        if not data:
            return []
        if all(isinstance(x, list) for x in data):
            return [list(x) for x in data]
        if all(isinstance(x, dict) and ("Rows" in x or "rows" in x) for x in data):
            return [x.get("Rows") or x.get("rows") or [] for x in data]
        return [data]
    return []


def substitute(text: str, batch_name: str, goose_id: int | None, sf_id: str) -> str:
    """Point a run-book script at this batch. Scripts ship with a sample batch hard-coded."""
    text = re.sub(r"(String\s+batchName\s*=\s*)'[^']*'", r"\g<1>'%s'" % batch_name, text)
    if goose_id is not None:
        text = re.sub(r"(DECLARE\s+@batch\s+int\s*=\s*)\d+", r"\g<1>%d" % goose_id, text, flags=re.I)
    if sf_id:
        text = re.sub(r"(DECLARE\s+@sfBatch\s+nvarchar\(\d+\)\s*=\s*N?)'[^']*'",
                      r"\g<1>'%s'" % sf_id, text, flags=re.I)
    return text


# ------------------------------------------------------------------ Informatica
def _call_flex(fn, **avail):
    """Call a Sunrise function whatever its exact parameter names are."""
    sig = inspect.signature(fn)
    aliases = {
        "state": ("state", "cfg", "config", "settings"),
        "session": ("session", "sess", "token"),
        "name": ("name", "taskflow", "taskflow_name", "flow", "task_name"),
        "timeout": ("timeout", "timeout_s", "timeout_seconds", "max_wait"),
        "run_id": ("run_id", "runid", "id"),
        "progress": ("progress_callback", "on_progress", "callback"),
    }
    kwargs = {}
    for p in sig.parameters.values():
        for key, names in aliases.items():
            if p.name in names and key in avail:
                kwargs[p.name] = avail[key]
    return fn(**kwargs)


class Informatica:
    def __init__(self, app_dir: str, state: dict):
        _bind_path(app_dir)
        try:
            import informatica_live as il  # type: ignore
        except Exception as e:  # noqa: BLE001
            raise AdapterError("informatica_live failed to import: %s" % e) from e
        self.il, self.state = il, state

    def describe(self) -> str:
        parts = []
        for fn in ("run_and_wait", "start_taskflow", "get_run_status", "login"):
            f = getattr(self.il, fn, None)
            parts.append("%s%s" % (fn, inspect.signature(f) if f else " MISSING"))
        return "; ".join(parts)

    def run(self, taskflow: str, timeout_s: int, say, on_run_id=None) -> dict:
        """Start a taskflow and wait. on_run_id(run_id) fires once, as soon as Informatica returns
        the run id, so the caller can checkpoint it and reattach after a restart."""
        il = self.il
        session = _call_flex(il.login, state=self.state) if hasattr(il, "login") else None
        if hasattr(il, "run_and_wait"):
            say("Starting %s and waiting (Sunrise run_and_wait)" % taskflow)
            seen = []

            def progress(status, last, elapsed):
                rid = (last or {}).get("runId") if isinstance(last, dict) else None
                if rid and not seen and on_run_id:
                    seen.append(rid)
                    on_run_id(str(rid))
            res = _call_flex(il.run_and_wait, state=self.state, session=session,
                             name=taskflow, timeout=timeout_s, progress=progress)
            return _informatica_result(res)
        if hasattr(il, "start_taskflow") and hasattr(il, "get_run_status"):
            say("Starting %s (Sunrise start_taskflow)" % taskflow)
            started = _call_flex(il.start_taskflow, state=self.state, session=session, name=taskflow)
            run_id = started.get("runId") if isinstance(started, dict) else started
            t0 = time.time()
            while time.time() - t0 < timeout_s:
                st = _informatica_result(_call_flex(il.get_run_status, state=self.state,
                                                    session=session, run_id=run_id))
                if st["done"]:
                    return st
                time.sleep(30)
            return dict(done=False, ok=False, status="TIMEOUT", run_id=run_id, detail="Still unresolved after %ds; do not restart automatically" % timeout_s)
        raise AdapterError("informatica_live has neither run_and_wait nor start_taskflow.")

    def watch(self, run_id: str, timeout_s: int, say) -> dict | None:
        """Follow a run that was started earlier (e.g. before MCC was closed). Returns its result,
        or None when Informatica has no record of the run (the caller may then start a new one)."""
        il = self.il
        session = _call_flex(il.login, state=self.state)
        try:
            st = _informatica_result(il.get_run_status(session, "", run_id))
        except Exception as e:  # noqa: BLE001
            say("      Run %s not found in Informatica (%s)" % (run_id, str(e)[:120]))
            return None
        say("Reattached to running Informatica run %s (%s)" % (run_id, st["status"]))
        t0 = time.time()
        while not st["done"] and time.time() - t0 < timeout_s:
            time.sleep(10)
            try:
                st = _informatica_result(il.get_run_status(session, "", run_id))
            except Exception as e:  # noqa: BLE001
                st = dict(done=False, ok=False, status="MONITOR_ERROR", detail=str(e)[:300], run_id=run_id)
        if not st["done"]:
            return dict(done=False, ok=False, status="TIMEOUT", run_id=run_id,
                        detail="Reattached run still unresolved after %ds; do not restart automatically" % timeout_s)
        st["run_id"] = run_id
        return st


def _informatica_result(res) -> dict:
    if isinstance(res, dict):
        status = str(res.get("status") or res.get("Status") or res.get("state") or "").upper()
    else:
        status = str(res).upper()
    done = status in ("SUCCESS", "SUCCEEDED", "COMPLETED", "FAILED", "FAULTED", "ERROR",
                      "SUSPENDED", "WARNING", "STOPPED", "ABORTED", "TIMEOUT")
    ok = status in ("SUCCESS", "SUCCEEDED", "COMPLETED")
    return dict(done=done, ok=ok, status=status or "UNKNOWN", detail=res, run_id=(res.get("runId") or res.get("run_id") or res.get("id")) if isinstance(res, dict) else None)


# ------------------------------------------------------------------ SnapLogic
class SnapLogic:
    def __init__(self, cfg: dict):
        self.cfg = cfg

    def run(self, key: str, timeout_s: int, say) -> dict:
        url = (self.cfg.get("TriggeredTaskUrls") or {}).get(key, "")
        token = os.environ.get(self.cfg.get("TokenEnvVar", "SNAPLOGIC_TOKEN"), "")
        if not url:
            raise AdapterError("No Triggered Task URL configured for %s." % key)
        if not token:
            raise AdapterError("Env var %s is not set." % self.cfg.get("TokenEnvVar"))
        say("Calling SnapLogic Triggered Task for %s" % key)
        req = urllib.request.Request(url, method="POST", data=b"{}",
                                     headers={"Authorization": "Bearer " + token,
                                              "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout_s) as r:
            body = r.read().decode("utf-8", "replace")
            return dict(ok=200 <= r.status < 300, status=str(r.status), detail=body[:2000])


class SunriseSnapLogic:
    """Trigger PL_05/PL_07/PL_10 exactly as Sunrise does (snaplogic_live.task_runner.trigger_task),
    using the Task URLs, per-stage token env vars and exact header pairs saved in Sunrise's
    control_center_state.json. No secret is read or stored here; Sunrise reads the env vars."""
    STAGES = {"PL_05": ("05", "PL_05_Pre-Process"), "PL_07": ("07", "PL_07_Accounts_and_Contacts"),
              "PL_10": ("10", "PL_10_AccountContactRelations")}

    def __init__(self, app_dir: str):
        root = Path(app_dir)
        state = root / "control_center" / "control_center_state.json"
        if not (root / "snaplogic_live" / "task_runner.py").is_file() or not state.is_file():
            raise AdapterError("Sunrise SnapLogic not found under %r (needs snaplogic_live/task_runner.py "
                               "and control_center/control_center_state.json)." % app_dir)
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        try:
            from snaplogic_live import task_runner  # type: ignore
        except Exception as e:  # noqa: BLE001
            raise AdapterError("Sunrise snaplogic_live failed to import: %s" % e) from e
        self.tr = task_runner
        self.state = json.loads(state.read_text(encoding="utf-8"))

    def run(self, key: str, timeout_s: int, say) -> dict:
        code, stage = self.STAGES[key]
        st = self.state
        url = st.get("SnapLogicTask%sUrl" % code, "")
        if not url:
            raise AdapterError("Sunrise has no Triggered Task URL saved for %s." % stage)
        say("Triggering %s through Sunrise snaplogic_live" % stage)
        # A triggered task answers only when the pipeline finishes (PL_05 ~17 min); Sunrise's
        # HTTP calls default to 60 s, which reported "read operation timed out" mid-run.
        for name in ("_request", "_request_authorization_header"):
            fn = getattr(self.tr, name, None)
            if fn and not getattr(fn, "_mcc_wrapped", False):
                def wrapped(*a, _fn=fn, **k):
                    k["timeout"] = timeout_s
                    return _fn(*a, **k)
                wrapped._mcc_wrapped = True
                setattr(self.tr, name, wrapped)
        folder, summary, _ = self.tr.trigger_task(
            stage, url, st.get("SnapLogicTask%sTokenEnv" % code) or "SNAPLOGIC_PL%s_TOKEN" % code,
            metadata={"caller": "MCC_Pilot"},
            auth_header_env=st.get("SnapLogicTask%sHeaderEnv" % code, ""),
            expected_pair_fingerprint=st.get("SnapLogicTask%sPairFingerprint" % code, ""))
        return dict(ok=bool(summary.get("Accepted")), status=str(summary.get("HttpStatus")),
                    detail="RUUID %s; evidence %s" % (summary.get("RUUID"), folder))


# ------------------------------------------------------------------ Jira
def jira_comment(cfg: dict, text: str) -> str:
    if not cfg.get("Enabled") or not cfg.get("IssueKey"):
        return "Jira posting is off."
    user = os.environ.get(cfg.get("UserEnvVar", "JIRA_USER"), "")
    token = os.environ.get(cfg.get("TokenEnvVar", "JIRA_TOKEN"), "")
    if not (user and token):
        return "Jira env vars not set; summary not posted."
    url = "%s/rest/api/2/issue/%s/comment" % (cfg["BaseUrl"].rstrip("/"), cfg["IssueKey"])
    auth = base64.b64encode(("%s:%s" % (user, token)).encode()).decode()
    req = urllib.request.Request(url, method="POST", data=json.dumps({"body": text}).encode(),
                                 headers={"Authorization": "Basic " + auth,
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return "Posted to %s (HTTP %s)." % (cfg["IssueKey"], r.status)
