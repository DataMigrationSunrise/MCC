"""Validated, per-run stopping points for the configured migration run book."""
from .pipeline import STEPS
from .extensions import load_extension


def all_steps(root):
    ext = load_extension(root / "runbook_extension.json")
    return STEPS + ext.get("steps", [])


def validate_target(steps, stop_after):
    """Blank means all configured steps, not an unknown step."""
    if stop_after is None:
        raise ValueError("Missing stop target")
    if not isinstance(stop_after, str):
        raise ValueError("Stop target must be a string")
    if stop_after and stop_after not in [s["id"] for s in steps]:
        raise ValueError("Unknown stop target: %s" % stop_after[:80])
    return stop_after


def selected_steps(steps, stop_after):
    validate_target(steps, stop_after)
    if not stop_after:
        return steps
    return steps[:next(i + 1 for i, s in enumerate(steps) if s["id"] == stop_after)]


def target_readiness(cfg, root, stop_after):
    """Structural readiness scoped to the requested prefix; never claim full-run readiness."""
    steps = all_steps(root)
    prefix = selected_steps(steps, stop_after)
    errors, warnings = [], []
    for step in prefix:
        kind, sid = step["kind"], step["id"]
        if kind in ("apex", "goose_sql", "goose_gen_check", "goose_gen_fix"):
            script = step.get("script")
            if not script or not (root / "scripts" / script).is_file():
                (warnings if step.get("optional") else errors).append("Missing script for %s: %s" % (sid, script))
        elif kind == "informatica" and sid not in cfg.get("Informatica", {}).get("Taskflows", {}):
            errors.append("Missing taskflow mapping for %s" % sid)
        elif kind == "snaplogic":
            sl = cfg.get("SnapLogic", {})
            if sl.get("Mode") == "rest" and not sl.get("TriggeredTaskUrls", {}).get(sid):
                errors.append("Missing SnapLogic trigger URL for %s" % sid)
            if sl.get("Mode") == "manual":
                warnings.append("%s requires operator Continue (SnapLogic manual mode)" % sid)
    if len({s["id"] for s in steps}) != len(steps):
        errors.append("Duplicate configured run-book step IDs")
    # Detect gaps after the pilot's TF_30 boundary without treating an unmapped
    # procedure as if it had run. A requested partial run must show those gaps.
    import json
    inventory = root / "downstream_runbook_inventory.json"
    if inventory.exists():
        listed = json.loads(inventory.read_text(encoding="utf-8"))
        included = {str(s.get("ro")) for s in prefix}
        last_ro = prefix[-1].get("ro", "")
        try:
            max_order = int(last_ro)
        except ValueError:
            max_order = 18
        gaps = [x for x in listed.get("rows", []) if int(x["order"]) <= max_order and str(x["order"]) not in included]
        if gaps:
            warnings.append("%d downstream run-book action(s) before %s have no executable mapping; they will NOT run" % (len(gaps), stop_after or "end"))
    return dict(ready=not errors, errors=errors, warnings=warnings,
                target=stop_after, planned_steps=len(prefix), full_run=False)
