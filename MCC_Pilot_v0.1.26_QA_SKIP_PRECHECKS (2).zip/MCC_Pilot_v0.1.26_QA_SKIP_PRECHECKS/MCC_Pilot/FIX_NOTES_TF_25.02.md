# TF_25.02 Jobsite Order Readiness — fix (on top of v0.1.18)

## Problem
RO 15 runs before TF_30, so the batch has no Orders yet. The old script printed
"No Orders yet" and returned. That output has no FAIL text, so the engine marked this
blocking step **PASS** without checking anything. It also only looked at geocode.

## Change
- `scripts/TF_25.02_Verify_Jobsite_Order_Readiness.apex`
  - **PART 1 (quote side, pre-conversion):** reads every `NF_Quoted_Jobsite__c` on the batch's
    quotes (`NF_Quote__r.USS_Migration_Batch__c`) and its `NF_USF_Address__c`.
    - Always blocking: no address, no coordinates, blank `USF_Address__c.Site_Name__c` (PWSTM-318).
    - Blocking while `ORDER_READY_BLOCKS = true` (default): `NF_Order_Ready__c` not true, with the
      cause split into `NF_Placement__c` blank / `NF_Has_GeoCode__c` false / not validated (PWSTM-401).
  - **No jobsites reach the batch → `UNPROVEN`** (engine blocks; a zero is not a clean result).
  - **PART 2 (order side):** the original Order geocode + WorkOrder territory check. It runs only
    once Orders exist; before TF_30 it reports "not applicable yet" instead of returning early.
  - Field-discovery PART 1 removed (fields are now known and verified in QA).
- `pilot/systems.py`: simulated TF_25.02 output updated to the new format.
- `pilot/test_offline.py`: `test_tf2502_judged_on_quote_side_jobsites` (UNPROVEN, FAIL,
  PASS WITH WARNINGS, and the early exit can't come back).

## Verified 2026-10-21 (QA, Sunrise-QA, read-only anonymous Apex)
| Batch | Jobsites | No coords | Blank Site Name | Not Order Ready (Placement blank) | Engine verdict |
|---|---|---|---|---|---|
| UMB-0123 | 949 | 424 | 2 | 942 (942) | FAIL |
| UMB-0122 | 947 | 889 | 3 | 947 (947) | FAIL |
| UMB-9999 (does not exist) | – | – | – | – | FAIL (ABORT) |

All 27 offline tests pass. The UNPROVEN path is tested offline only (no QA batch with zero jobsites was run).

## Expect this
Until PWSTM-401 (Placement mapping + geocoding) is fixed, **every batch will stop at RO 15**.
That is the gate working. To let runs continue while still reporting the count, set
`ORDER_READY_BLOCKS = false`; the step then ends `PASS WITH WARNINGS -- n of m jobsites not Order Ready`.
Missing coordinates and blank Site Names still block either way.
