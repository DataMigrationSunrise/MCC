"""Read-only: are the 62 stuck orders on the 16 repeat-customer accounts MCC linked tonight?"""
import json, sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = [o['id'] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']]
linked = set()
for line in (folder / 'preflight' / 'link_existing.jsonl').read_text(encoding='utf-8').splitlines():
    j = json.loads(line)
    if j.get('status') == 'LINK_ATTEMPT':
        linked.add(j['sf_account'][:15])
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
rows = []
for i in range(0, len(stuck), 100):
    ids = "','".join(stuck[i:i + 100])
    rows += sf.query("SELECT Id, AccountId, Account.Name, (SELECT Id FROM OrderItems) FROM Order WHERE Id IN ('%s')" % ids)
on_linked = [r for r in rows if (r.get('AccountId') or '')[:15] in linked]
items = sorted(((r.get('OrderItems') or {}).get('totalSize', 0)) for r in rows)
print('stuck orders:', len(rows), '| on a linked repeat-customer account:', len(on_linked), '| linked accounts:', len(linked))
print('order lines per stuck order: min', items[0] if items else 0, 'median', items[len(items) // 2] if items else 0,
      'max', items[-1] if items else 0)
accts = {}
for r in rows:
    n = (r.get('Account') or {}).get('Name') or r.get('AccountId')
    accts[n] = accts.get(n, 0) + 1
print('accounts with most stuck orders:', sorted(accts.items(), key=lambda kv: -kv[1])[:6])
