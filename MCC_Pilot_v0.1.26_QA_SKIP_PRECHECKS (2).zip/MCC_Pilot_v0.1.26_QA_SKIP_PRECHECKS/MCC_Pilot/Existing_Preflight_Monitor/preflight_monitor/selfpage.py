"""
The Self-test page: what the last self-test found, and the settings each problem is about.

The main page does not show self-test output any more. It lives here, with a form next to every
problem that a setting can fix. Settings are written to config.json (a .bak copy is kept) and
take effect on the next run -- no restart.
"""
from __future__ import annotations

import html
import json
from pathlib import Path

# key -> (label, kind, help).  kind: text | int | bool | map
SETTINGS = {
    "OrgAlias": ("Salesforce org alias", "text", "The alias from `sf org list` for the sandbox to check."),
    "InstanceUrl": ("Salesforce URL", "text", "Used for record links. Must be the SAME org as the alias."),
    "GooseServer": ("Goose SQL server", "text", "Leave blank to switch the Goose checks off (they report UNPROVEN)."),
    "GooseDatabase": ("Goose database", "text", "Normally Goose."),
    "SunriseAppDir": ("Sunrise folder", "text", "The folder holding the Sunrise preflight output. No check depends on it today."),
    "InformaticaLive": ("Read Informatica live", "bool", "Needs INFORMATICA_USERNAME / INFORMATICA_PASSWORD set on this computer."),
    "InformaticaProject": ("Informatica project", "text", ""),
    "InformaticaFolder": ("Informatica folder", "text", ""),
    "Workers": ("Parallel queries", "int", "1 to 16. More is faster until Salesforce starts refusing."),
    "FullSelfTestOnRun": ("Full self-test on every run", "bool", "Off: a run only does the quick connection check."),
    "LegacyIdFields": ("Legacy Id field per object", "map",
                       "One per line, e.g. Account=Legacy_Id__c. Used by Export issues."),
}

# stage -> (what it is, what to do, settings that can fix it)
STAGES = {
    "1 registry": ("The tool's own check definitions", "This is a defect in the tool, not your org. Send me this line.", []),
    "2 salesforce": ("Can the tool reach Salesforce", "Run `sf org list`, copy the alias of your QA sandbox, and log in with `sf org login web` if it is not listed.", ["OrgAlias", "InstanceUrl"]),
    "2 goose": ("Can the tool read Goose", "Goose checks report UNPROVEN until this works. Check the server name and that you can open it in SSMS.", ["GooseServer", "GooseDatabase"]),
    "2 informatica": ("Can the tool read Informatica", "Without it the Time column falls back to record timestamps. It never fails a check.", ["InformaticaLive", "InformaticaProject", "InformaticaFolder"]),
    "2 sunrise": ("Sunrise preflight output", "Only matters if a check depends on it. None does today.", ["SunriseAppDir"]),
    "3 batch scope": ("Does the batch exist exactly once", "Pick a batch that exists, or press Find batches under More.", []),
    "4 schema": ("Fields the checks need", "A hidden field makes its checks UNPROVEN. A tool setting cannot fix this: ask a Salesforce admin to give this user read access to the fields listed.", []),
    "4 schema: WorkOrder contract link": ("WorkOrder to Contract link", "If both links exist the checks use Contract__c. Informational.", []),
    "5 rule contradictions": ("Documented rules that disagree", "Resolve which rule is right; until then no check may assert PASS on those fields.", []),
    "6 canaries": ("Known-positive probes", "A canary that finds nothing means a zero from that check is a broken scope, not a clean result.", []),
}


def _e(x):
    return html.escape(str(x if x is not None else ""), quote=True)


def _value(cfg, key):
    v = cfg.get(key)
    kind = SETTINGS[key][1]
    if kind == "map":
        return "\n".join("%s=%s" % (o, ",".join(f) if isinstance(f, list) else f)
                         for o, f in sorted((v or {}).items()))
    if kind == "bool":
        return "true" if v else "false"
    return "" if v is None else str(v)


def _field(cfg, key):
    label, kind, hlp = SETTINGS[key]
    val = _value(cfg, key)
    if kind == "bool":
        inp = ("<select name='cfg_%s'><option value='true'%s>on</option>"
               "<option value='false'%s>off</option></select>"
               % (key, " selected" if val == "true" else "", " selected" if val == "false" else ""))
    elif kind == "map":
        inp = "<textarea name='cfg_%s' rows='3' placeholder='Account=Legacy_Id__c'>%s</textarea>" % (key, _e(val))
    else:
        inp = "<input name='cfg_%s' value='%s'%s>" % (key, _e(val), " type='number' min='1' max='16'" if kind == "int" else "")
    return ("<label class='sf'><span>%s</span>%s%s</label>"
            % (_e(label), inp, ("<small>%s</small>" % _e(hlp)) if hlp else ""))


def _form(cfg, keys, button="Save"):
    return ("<form method='post' action='/run' class='cfgform'><input type='hidden' name='what' value='saveconfig'>"
            + "".join(_field(cfg, k) for k in keys)
            + "<button type='submit'>%s</button></form>" % _e(button))


def render(cfg, store, running=False):
    taken, stages = store.last_selftest()
    conn_taken = store.last_selftest_conn_time()
    out = ["<div class='rec stp'>",
           "<a class='back' href='/'>&lsaquo; back to the run book</a>",
           "<h2>Self-test</h2>",
           "<div class='sub'>Checks that the tool can reach its sources and ask its questions. It reads, never writes.</div>",
           "<form method='post' action='/run'><input type='hidden' name='what' value='selftest'>"
           "<button type='submit'%s>%s</button></form>"
           % (" disabled" if running else "", "Running..." if running else "Run the full self-test now")]
    if not stages:
        out.append("<div class='cap'>No self-test has been run yet. Press the button above.</div>")
    else:
        out.append("<div class='tiny'>Full self-test: %s &middot; connection check on the last run: %s</div>"
                   % (_e((taken or "never")[:16].replace("T", " ")), _e((conn_taken or "never")[:16].replace("T", " "))))
        order = sorted(stages, key=lambda s: s["stage"])
        bad = [s for s in order if s["status"] not in ("OK",)]
        out.append("<div class='headline %s'>%s</div>" % (
            "bad" if bad else "ok",
            ("<b>%d</b> of %d stage(s) need attention" % (len(bad), len(order))) if bad
            else "All %d stages are fine" % len(order)))
        for s in order:
            what, todo, keys = STAGES.get(s["stage"], (s["stage"], "", []))
            cls = {"OK": "ok", "FAIL": "bad", "DEGRADED": "warn"}.get(s["status"], "skip")
            body = ("<div class='sd'>%s</div>" % _e(s["detail"]))
            if s["status"] != "OK":
                if todo:
                    body += "<div class='todo'><b>What to do:</b> %s</div>" % _e(todo)
                if keys:
                    body += "<div class='cfgbox'><b>Related settings</b>%s</div>" % _form(cfg, keys)
            out.append("<details class='fold stg %s'%s><summary><span class='st'>%s</span> <b>%s</b>"
                       " <span class='tiny'>%s</span></summary>%s</details>"
                       % (cls, " open" if s["status"] != "OK" else "", _e(s["status"]), _e(what),
                          _e(s["stage"]), body))
    out.append("<h3>Settings</h3><div class='cfgbox'>%s</div>"
               % _form(cfg, ["Workers", "FullSelfTestOnRun", "LegacyIdFields"], "Save settings"))
    out.append("</div>")
    return "".join(out)


def apply_config(cfg, cfg_path, form):
    """Validate the submitted settings, write config.json (keeping a .bak) and update `cfg` in place.
    -> (changed_keys, errors)"""
    changes, errors = {}, []
    for key, (label, kind, _h) in SETTINGS.items():
        raw = (form.get("cfg_%s" % key) or [None])[0]
        if raw is None:
            continue
        raw = raw.strip()
        if kind == "bool":
            val = raw.lower() == "true"
        elif kind == "int":
            try:
                val = int(raw)
            except ValueError:
                errors.append("%s must be a whole number." % label); continue
            if not 1 <= val <= 16:
                errors.append("%s must be between 1 and 16." % label); continue
        elif kind == "map":
            val = {}
            for line in raw.splitlines():
                if not line.strip():
                    continue
                o, sep, f = line.partition("=")
                fl = [x.strip() for x in f.split(",") if x.strip()]
                if not sep or not o.strip() or not fl:
                    errors.append("%s: '%s' is not Object=Field." % (label, line.strip()[:40])); val = None; break
                val[o.strip()] = fl[0] if len(fl) == 1 else fl
            if val is None:
                continue
        else:
            val = raw
            if key == "InstanceUrl" and val and not val.startswith("https://"):
                errors.append("Salesforce URL must start with https://"); continue
            if key == "OrgAlias" and (not val or " " in val):
                errors.append("Salesforce org alias cannot be blank or contain spaces."); continue
        if cfg.get(key) != val and not (kind == "text" and cfg.get(key) in (None, "") and val == ""):
            changes[key] = val
    if changes and not errors:
        p = Path(cfg_path)
        disk = json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}
        if p.is_file():
            p.with_suffix(p.suffix + ".bak").write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
        disk.update(changes)
        p.write_text(json.dumps(disk, indent=2), encoding="utf-8")
        cfg.update(changes)
    return (sorted(changes) if not errors else []), errors
