"""
Run book readiness.

The run book is the operator's mental model, so results are expressed in it: every failing
RECORD is placed at the Run Order where its problem occurs, and every Run Order carries a
readiness state. The question the tool answers is not "are there errors" but

    "can I advance past Run Order N, and if not, what exactly is holding me and how do I clear it?"
"""
from __future__ import annotations
import json
from pathlib import Path

import registry
import terms

HERE = Path(__file__).resolve().parent

# READY    nothing in the way.
# REVIEW   the step has issues, but none of them is a blocker: you may pass, a person looks.
# BLOCKED  the step has a BLOCKER of its own.
# HELD     nothing wrong HERE, but a blocker elsewhere stops you reaching it.
# (See terms.py. Before v0.20.0 a failing WARNING check also made a step BLOCKED, and a step
#  that merely sat downstream of a blocker was called BLOCKED too -- two different facts.)
READY, REVIEW, BLOCKED, HELD, UNPROVEN_RO, NOT_CHECKED, NOT_RUN = (
    "READY", "REVIEW", "BLOCKED", "HELD", "UNPROVEN", "NOT CHECKED", "NOT RUN")
STOPPED = (BLOCKED, HELD)          # states you cannot pass

_STEPS = None


def steps() -> list[dict]:
    global _STEPS
    if _STEPS is None:
        p = HERE / "runbook.json"
        _STEPS = json.loads(p.read_text(encoding="utf-8")) if p.is_file() else []
    return _STEPS


def step(order: int) -> dict | None:
    return next((s for s in steps() if s["order"] == order), None)


def checks_by_order() -> dict[int, list]:
    out = {}
    for c in registry.all_checks():
        if c.runbook_order:
            out.setdefault(c.runbook_order, []).append(c)
    return out


def blockers_by_order() -> dict[int, list]:
    """Run Order -> checks that BLOCK it while failing (may be validated elsewhere)."""
    out = {}
    for c in registry.all_checks():
        for ro in (c.blocks or ()):
            out.setdefault(ro, []).append(c)
    return out


# STEPS DONE BY HAND OR WITH SCRIPTS: what the data should look like once the step has been done.
# The step itself leaves no record, so a skipped step is only visible as its effect being absent.
# Each list is the checks whose finding is exactly that step's job (taken from the step's own
# description in the run book). If any of them fails, the step's work is still undone -- skipped,
# or run and not finished. If all pass, there is nothing left for the step to do, which is NOT proof
# that it ran: a step with nothing to fix passes the same way.
EFFECT_CHECKS = {
    26: ["ORDER.ACTIVATION_RATE"],
    27: ["WO.ORDERS_MISSING_WOS"],
    29: ["FSL.DEAD_POLYGONS"],
    30: ["WO.ORDERS_MISSING_WOS"],
    37: ["GOOSE.MP_WEEKDAY_GAP"],
    38: ["CONTRACT.DUPLICATE_PER_ORDER"],
    42: ["BATCH.PRESNAPSHOT_FILE"],
    49: ["CONTRACT.LASTBILLINGDATE_RULE", "SUB.FSC_FLAG_COVERAGE", "BIQ.COVERAGE"],
    51: ["CONTRACT.NONMONTHLY_NULL_LASTBILLINGDATE"],
    53: ["BIQ.COVERAGE"],
    57: ["BIQ.FSC_NULL_EFFECTIVE_DATE"],
}


def is_job(r) -> bool:
    """The steps that MOVE DATA: Informatica and SnapLogic RUN rows. Everything else is a script,
    a query or a manual step that the team wrote."""
    return ((r.get("stage") or "").strip().lower() in ("informatica", "snaplogic")
            and (r.get("action") or "").strip().upper() == "RUN")


def step_effect(ro: int, results: dict) -> dict:
    """-> dict(state, checks). state: UNDONE | DONE | UNKNOWN | '' (no effect check defined)."""
    ids = EFFECT_CHECKS.get(ro) or []
    seen = [(i, results[i]["verdict"]) for i in ids if i in results]
    if not ids or not results:
        return dict(state="", checks=[])
    if any(v == "FAIL" for _, v in seen):
        state = "UNDONE"
    elif len(seen) < len(ids) or any(v != "PASS" for _, v in seen):
        state = "UNKNOWN"
    else:
        state = "DONE"
    return dict(state=state, checks=seen)


def readiness(store, batch: str, run_id: str = "") -> list[dict]:
    """
    One row per Run Order: can you proceed past it?

    A step is BLOCKED when a check that validates it failed, OR when a check elsewhere
    declares it blocks this step. UNPROVEN is never READY -- the whole point.
    """
    # An explicit run_id is how a SNAPSHOT is viewed: the same rendering, reading a run
    # that is already stored, with no query of any kind.
    run_id = run_id or store.latest_run_id(batch)
    results = {r["check_id"]: r for r in store.results_for_run(run_id)} if run_id else {}
    own = checks_by_order()
    blk = blockers_by_order()

    rows = []
    for s in steps():
        ro = s["order"]
        validating = own.get(ro, [])
        gating = [c for c in blk.get(ro, []) if c.runbook_order != ro]

        fails, unprov, passes, upstream = [], [], [], []
        for c in validating:
            r = results.get(c.id)
            if r is None:
                continue
            if r["verdict"] == "FAIL":
                fails.append((c, r))
            elif r["verdict"] == "UNPROVEN":
                unprov.append((c, r))
            else:
                passes.append((c, r))
        for c in gating:
            r = results.get(c.id)
            if r is not None and r["verdict"] == "FAIL":
                upstream.append((c, r))

        own_block = [(c, r) for c, r in fails if c.severity == "BLOCKER"]

        if not validating and not gating:
            state = NOT_CHECKED
        elif not results:
            state = NOT_RUN
        elif own_block:
            state = BLOCKED
        elif upstream:
            state = HELD
        elif fails:                      # failing, but only REVIEW / NOTE severity
            state = REVIEW
        elif unprov:
            state = UNPROVEN_RO
        elif passes:
            state = READY
        else:
            state = NOT_RUN

        # ----- Record Count / Result, per check.
        # EXAMINED and ERRORS are different numbers and are never collapsed into one.
        # They are not summed across checks either: two checks at one step usually look
        # at the same population, so a sum would double-count it. The largest population
        # examined is the step's honest headline; the per-check rows carry the detail.
        counts = []
        for c, r in fails + unprov + passes:
            counts.append(dict(
                check=c.id, name=c.name,
                examined=int(r["processed"] or 0) if _has(r, "processed") else 0,
                errors=int(r["evidence_count"] or 0) if r["verdict"] == "FAIL" else 0,
                verdict=r["verdict"],
                inverted=not c.finds_problems,
                unit_one=terms.unit_of(c.id)[0], unit_many=terms.unit_of(c.id)[1],
                record=terms.is_record(c.id),
                metric=(r["metric_name"] or ""), metric_value=r["metric_value"],
                metric_unit=(r["metric_unit"] or ""),
                metric_num=r["metric_num"], metric_den=r["metric_den"]))

        # ----- Time: when the validated work RAN, not when we checked it.
        times = []
        for c, r in fails + unprov + passes:
            if not _has(r, "ran_from"):
                continue
            if not (r["ran_from"] or r["ran_to"]):
                continue
            times.append(dict(check=c.id, frm=r["ran_from"] or "", to=r["ran_to"] or "",
                              status=r["run_status"] or "", source=r["run_source"] or ""))

        # Only checks that count Salesforce RECORDS add to a step's failing / held totals; an
        # async-job count or a staged-row count is a different unit and is shown on its own.
        own_errors = sum(int(r["evidence_count"] or 0) for c, r in fails if terms.is_record(c.id))
        upstream_held = sum(int(r["evidence_count"] or 0) for c, r in upstream if terms.is_record(c.id))

        rows.append(dict(
            order=ro, stage=s["stage"], action=s.get("action", ""),
            step=s["step"], purpose=s.get("purpose", ""),
            verify=s.get("verify", ""), blocker=s.get("blocker", ""),
            state=state,
            effect=step_effect(ro, results),
            # the step has its own evidence of having run (a run window, or records measured)
            # Only a step that MOVES DATA can "already have run", and only a RAN.* output check
            # proves it -- the same test progress() uses for "confirmed run". A check that merely
            # measured records (staging, or ACRs that existed for years) is not proof: the first
            # version of this flag said "job already ran" on PL_05 and PL_10 for that reason,
            # while the page's own "Cannot confirm" list named PL_05.
            ran=((s.get("action") or "").strip().upper() == "RUN"
                 and any(str(c["check"]).startswith("RAN.") and c["examined"] > 0 for c in counts)),
            examined=max([c["examined"] for c in counts] or [0]),
            errors=own_errors,
            held=own_errors + upstream_held,
            counts=counts,
            times=times,
            # `records` kept so nothing downstream breaks: it is the OLD meaning
            # (errors at this step plus records held by upstream blockers).
            records=own_errors + upstream_held,
            failing=[dict(check=c.id, name=c.name, rows=int(r["evidence_count"] or 0),
                          examined=int(r["processed"] or 0) if _has(r, "processed") else 0,
                          inverted=not c.finds_problems,
                          unit_one=terms.unit_of(c.id)[0], unit_many=terms.unit_of(c.id)[1],
                          record=terms.is_record(c.id),
                          reason=r["reason"], severity=c.severity,
                          fix_order=(c.remediation.runbook_order if c.remediation else None),
                          fix=(c.remediation.summary if c.remediation else ""))
                     for c, r in fails],
            blocked_by=[dict(check=c.id, name=c.name, at=c.runbook_order,
                             rows=int(r["evidence_count"] or 0), record=terms.is_record(c.id),
                             fix_order=(c.remediation.runbook_order if c.remediation else None),
                             fix=(c.remediation.summary if c.remediation else ""))
                        for c, r in upstream],
            unproven=[dict(check=c.id, reason=r["reason"]) for c, r in unprov],
            checks=len(validating),
        ))
    return rows


def _has(row, col) -> bool:
    """A history DB written before a column existed still has to be readable."""
    try:
        return col in row.keys()
    except Exception:                                        # noqa: BLE001
        return False


def first_blocked(rows: list[dict]) -> dict | None:
    """The earliest step you cannot pass. This is the headline number."""
    return next((r for r in rows if r["state"] in STOPPED), None)


def record_routing(store, batch: str, run_id: str = "") -> list[dict]:
    """
    Every failing RECORD, placed where it occurs in the run book and where it gets fixed.

    This is the view that answers 'what is actually stuck, and at which step'.
    """
    run_id = run_id or store.latest_run_id(batch)
    if not run_id:
        return []
    by_id = {c.id: c for c in registry.all_checks()}
    out = []
    for r in store.results_for_run(run_id):
        if r["verdict"] != "FAIL":
            continue
        c = by_id.get(r["check_id"])
        if c is None:
            continue
        rem = c.remediation
        ev = store.db.execute(
            "SELECT payload FROM evidence WHERE run_id=? AND check_id=? ORDER BY seq",
            (run_id, c.id)).fetchall()
        sample = [json.loads(e["payload"]) for e in ev]
        out.append(dict(
            detected_at=c.runbook_order,
            detected_step=(step(c.runbook_order) or {}).get("step", ""),
            fix_at=(rem.runbook_order if rem else None),
            fix_step=((step(rem.runbook_order) or {}).get("step", "") if rem and rem.runbook_order
                      else ""),
            check=c.id, name=c.name, severity=c.severity,
            records=int(r["evidence_count"] or 0),
            sample=sample[:25],
            truncated=max(0, int(r["evidence_count"] or 0) - len(sample)),
            blocks=list(c.blocks or ()),
            fix_summary=(rem.summary if rem else ""),
            fix_script=(rem.script if rem else ""),
            fix_writes=(rem.writes if rem else False),
            fix_approval=(rem.approval if rem else ""),
            fix_steps=(rem.steps if rem else []),
            fix_note=(rem.note if rem else ""),
        ))
    out.sort(key=lambda x: (x["detected_at"] or 999, -x["records"]))
    return out


def distinct_blocking_records(rows: list[dict]) -> int:
    """
    Records held by BLOCKED steps, each blocking check counted ONCE.

    Summing the per-row `held` double-counts: a step blocked by an upstream failure carries
    that failure's records in its own `held`, so the same 5 records were counted at RO 38
    AND at every step it blocks (the example workbook read 2,334 for 774 real records).
    `held` stays correct as a per-row display value; it just must not be summed across rows.
    Keyed by check id, over both a row's own failures and the upstream blockers it names.
    """
    seen: dict[str, int] = {}
    for r in rows:
        if r["state"] not in STOPPED:
            continue
        for f in r.get("failing", []):
            if f.get("severity", "BLOCKER") != "BLOCKER":
                continue                 # review items do not hold anything
            if f.get("record", True):
                seen[f["check"]] = int(f["rows"] or 0)
        for b in r.get("blocked_by", []):
            if b.get("record", True):
                seen.setdefault(b["check"], int(b["rows"] or 0))
    return sum(seen.values())


def summary(rows: list[dict]) -> dict:
    fb = first_blocked(rows)
    return dict(
        total=len(rows),
        ready=len([r for r in rows if r["state"] == READY]),
        blocked=len([r for r in rows if r["state"] == BLOCKED]),
        held=len([r for r in rows if r["state"] == HELD]),
        review=len([r for r in rows if r["state"] == REVIEW]),
        unproven=len([r for r in rows if r["state"] == UNPROVEN_RO]),
        not_checked=len([r for r in rows if r["state"] == NOT_CHECKED]),
        records_blocked=distinct_blocking_records(rows),
        errors_total=sum(r["errors"] for r in rows),
        steps_with_errors=len([r for r in rows if r["errors"]]),
        # NOT a sum of `examined` across steps. The same 906 Orders are examined at a
        # dozen steps, so a sum would report tens of thousands of records that do not
        # exist. The per-step number is the only one that means anything.
        examined_max=max([r["examined"] for r in rows] or [0]),
        first_blocked_order=(fb["order"] if fb else None),
        first_blocked_step=(fb["step"] if fb else ""),
    )


def progress(rows: list[dict]) -> dict:
    """
    WHERE IS THIS BATCH RIGHT NOW?

    Derived from run TIMES, not from guesses. A step counts as having RUN when either the
    orchestrator reported a run window for it, or a check at that step actually measured
    records. The current step is then the first one you cannot pass:

        the earliest BLOCKED step, if any   -- you are stopped there
        otherwise the first step after the furthest one that has run

    `reached` is the furthest Run Order with real evidence of having run. Everything after
    it has not been loaded yet, which is what stops the object band counting an unstarted
    load as a failure.
    """
    # A step counts as HAVING RUN only on its OWN evidence: a reported run window, or a
    # check there that actually measured records. Being BLOCKED is not evidence -- a step
    # forty orders ahead is marked BLOCKED purely because something upstream failed, and
    # treating that as "reached" put the batch at Run Order 51 when it had not passed 2.
    ran = []
    for r in rows:
        if bool(r["times"]) or any(c["examined"] for c in r["counts"]):
            ran.append(r["order"])
    reached = max(ran) if ran else 0

    # WHERE THE BATCH IS is not the same fact as WHAT IS BLOCKING IT, and conflating them
    # put the marker on Run Order 2 -- a pre-flight validation -- while the batch had data
    # through Run Order 40. The earliest blocker is already the headline; this is the
    # position in the process, so it follows the work: the first step after the furthest
    # one that actually ran.
    nxt = [r for r in rows if r["order"] > reached]
    if nxt:
        cur = nxt[0]["order"]
        why = "next"
    elif reached:
        cur, why = reached, "done"
    else:
        cur = rows[0]["order"] if rows else 0
        why = "start"

    # ---- the orchestrator pipeline: Informatica and SnapLogic RUN steps only.
    # These are the steps that actually move data; everything else validates or fixes. How
    # far THEY have got is what decides whether a later finding is a defect or just data
    # that has not arrived.
    jobs, done, confirmed_at = [], [], {}
    for r in rows:
        st = (r["stage"] or "").strip().lower()
        act = (r["action"] or "").strip().upper()
        if st in ("informatica", "snaplogic") and act == "RUN":
            has_ran = any(str(c["check"]).startswith("RAN.") for c in r["counts"])
            ran_ok = any(str(c["check"]).startswith("RAN.") and c["examined"] > 0
                         for c in r["counts"])
            jobs.append(dict(order=r["order"], step=r["step"], stage=r["stage"],
                             confirmable=has_ran, ran=ran_ok,
                             times=r["times"]))
            if ran_ok:
                done.append(r["order"])
                confirmed_at[r["order"]] = r["step"]

    last_job = max(done) if done else 0
    last_job_step = confirmed_at.get(last_job, "")
    nxt = [j for j in jobs if j["order"] > last_job]
    unconfirmable = [j["order"] for j in jobs if not j["confirmable"]]

    fb = first_blocked(rows)
    blocked_at = fb["order"] if fb else None

    step = next((r for r in rows if r["order"] == cur), None)
    last_time = ""
    for r in rows:
        for t in r["times"]:
            if (t.get("to") or t.get("frm") or "") > last_time:
                last_time = t.get("to") or t.get("frm") or ""
    return dict(reached=reached, current=cur, why=why, blocked_at=blocked_at,
                last_job=last_job, last_job_step=last_job_step,
                jobs_total=len(jobs), jobs_done=len(done), jobs_left=len(jobs) - len(done),
                next_job=(nxt[0]["order"] if nxt else None),
                next_job_step=(nxt[0]["step"] if nxt else ""),
                next_job_stage=(nxt[0]["stage"] if nxt else ""),
                jobs_unconfirmable=unconfirmable,
                last_activity=last_time,
                current_step=(step or {}).get("step", ""),
                current_stage=(step or {}).get("stage", ""),
                current_state=(step or {}).get("state", ""),
                completed=len([r for r in rows if r["order"] <= reached
                               and r["state"] in (READY, REVIEW)]),
                total=len(rows))


SEV_ORDER = {"BLOCKER": 0, "WARNING": 1, "INFO": 2}


# Three kinds of finding, and conflating them is what makes an early-batch run look like a
# disaster:
#
#   NOT_YET    the step this check validates is BEYOND the last load. Its population does
#              not exist yet, so a "failure" here means nothing. Not an error.
#   PREDICTED  the data IS loaded and the check found a real problem, but every step it
#              would break is still ahead. This is the valuable one -- a defect you can see
#              before it costs anything, which is the entire point of a preflight.
#   CURRENT    loaded data, real problem, and it is already affecting steps that have run.
PHASE_NOT_YET, PHASE_PREDICTED, PHASE_CURRENT = "NOT YET", "PREDICTED", "CURRENT"
# A check that could not reach its evidence has no phase to report. It is NOT an error and
# NOT a clean step -- saying so plainly beats rendering a blank cell.
PHASE_UNPROVEN = "UNPROVEN"


def _phase(chk, order, edge) -> dict:
    """Where a finding sits relative to how far the load actually got."""
    if not edge:
        return dict(phase=PHASE_CURRENT, breaks_at=None)
    if order > edge:
        return dict(phase=PHASE_NOT_YET, breaks_at=None)
    blocks = sorted(chk.blocks or ()) if chk is not None else []
    ahead = [b for b in blocks if b > edge]
    if blocks and len(ahead) == len(blocks):
        # every step it would break is still in front of the load
        return dict(phase=PHASE_PREDICTED, breaks_at=ahead[0])
    return dict(phase=PHASE_CURRENT, breaks_at=(ahead[0] if ahead else None))


def issues(store, batch: str, run_id: str = "", rows: list[dict] | None = None,
           pending_objects: set | None = None) -> list[dict]:
    """
    Every issue in one list, worst first, with the records behind it.

    An object whose load step HAS NOT RUN contributes nothing here. A check that finds
    "0 of 0" on a step nobody has reached is not a finding, and letting those through is
    what makes an early-batch run look like a disaster.
    """
    rows = rows if rows is not None else readiness(store, batch, run_id)
    by_id = {c.id: c for c in registry.all_checks()}
    skip = pending_objects or set()
    pr = progress(rows)
    edge = pr["last_job"] or pr["reached"]
    out = []
    for r in rows:
        for f in r["failing"]:
            c = by_id.get(f["check"])
            if c is not None and c.sobject in skip:
                continue
            out.append(dict(kind="ISSUE", severity=(c.severity if c else "BLOCKER"),
                            order=r["order"], step=r["step"], stage=r["stage"],
                            check=f["check"], name=f["name"], records=f["rows"],
                            unit_one=f.get("unit_one", "record"), unit_many=f.get("unit_many", "records"),
                            is_record=f.get("record", True),
                            examined=f["examined"], inverted=f["inverted"],
                            reason=f["reason"], fix=f["fix"], fix_order=f["fix_order"],
                            sobject=(c.sobject if c else ""),
                            **_phase(c, r["order"], edge)))
        for u in r["unproven"]:
            c = by_id.get(u["check"])
            if c is not None and c.sobject in skip:
                continue
            out.append(dict(kind="UNPROVEN", severity="WARNING",
                            order=r["order"], step=r["step"], stage=r["stage"],
                            check=u["check"], name=(c.name if c else u["check"]),
                            records=0, examined=0, inverted=False,
                            reason=u["reason"], fix="", fix_order=None,
                            sobject=(c.sobject if c else ""),
                            phase=PHASE_UNPROVEN, breaks_at=None))
    # RUN ORDER first. The list is a worklist against the run book, so it reads in the
    # order the work happens; severity ranks only within a step.
    out.sort(key=lambda x: (x["order"], 0 if x["kind"] == "ISSUE" else 1,
                            SEV_ORDER.get(x["severity"], 9), -x["records"]))
    return out


def ids_of_factory(store, run_id: str):
    """check_id -> set of record Ids (15-char) its evidence names, or None if rows carry no Ids."""
    import verify
    cache = {}

    def ids_of(cid):
        if cid not in cache:
            try:
                rows = store.evidence(run_id, cid)
            except Exception:                                # noqa: BLE001
                rows = []
            ids = verify.record_ids(rows)
            cache[cid] = {i[:15] for i in ids} if rows and len(ids) == len(rows) else None
        return cache[cid]
    return ids_of


def issue_summary(items: list[dict], ids_of=None) -> dict:
    """
    `records` is DISTINCT Salesforce records that need a fix: only checks that count records,
    and a record flagged by two checks counted once (ids_of gives the Ids). Jobs, staged rows,
    log entries and the like are counted separately in `other` -- never added in.
    """
    err = [i for i in items if i["kind"] == "ISSUE"]
    rec_items = [i for i in err if i.get("is_record", True)]
    oth_items = [i for i in err if not i.get("is_record", True)]
    seen, loose = set(), 0
    for i in rec_items:
        ids = ids_of(i["check"]) if ids_of else None
        if ids is not None:
            seen |= ids
        else:
            loose += int(i["records"] or 0)
    distinct = len(seen) + loose
    other_units = {}
    for i in oth_items:
        k = i.get("unit_many", "items")
        other_units[k] = other_units.get(k, 0) + int(i["records"] or 0)
    unp = [i for i in items if i["kind"] == "UNPROVEN"]
    cur = [i for i in err if i.get("phase") == PHASE_CURRENT]
    pre = [i for i in err if i.get("phase") == PHASE_PREDICTED]
    nyt = [i for i in err if i.get("phase") == PHASE_NOT_YET]
    return dict(
        issues=len(err), errors=len(err),     # `errors` is the pre-0.20 name, kept for old callers
        unproven=len(unp),
        current=len(cur), predicted=len(pre), not_yet=len(nyt),
        current_records=sum(i["records"] for i in cur),
        predicted_records=sum(i["records"] for i in pre),
        records=distinct,
        records_summed=sum(i["records"] for i in rec_items),
        other=len(oth_items), other_units=other_units,
        blockers=len([i for i in err if i["severity"] == "BLOCKER"]),
        review=len([i for i in err if i["severity"] == "WARNING"]),
        notes=len([i for i in err if i["severity"] == "INFO"]),
        warnings=len([i for i in err if i["severity"] == "WARNING"]),   # pre-0.20 name
        steps=len({i["order"] for i in err}),
        objects=len({i.get("sobject") for i in err if i.get("sobject")}),
    )
