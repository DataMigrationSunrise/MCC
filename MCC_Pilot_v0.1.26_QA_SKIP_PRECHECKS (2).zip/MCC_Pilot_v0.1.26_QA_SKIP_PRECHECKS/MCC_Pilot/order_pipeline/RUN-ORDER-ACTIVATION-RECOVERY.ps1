﻿param([Parameter(Mandatory=$true)][string]$OrgAlias,[Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9]{15}([A-Za-z0-9]{3})?$')][string]$BatchId,[int]$MaxPasses=50,[int]$WaitSeconds=60)
$ErrorActionPreference='Stop'

# v0.17.179 — BatchId pins every query in this recovery run to that exact migration batch
# (SBQQ__Quote__r.USS_Migration_Batch__c=<Id>).
# v0.17.181 — BatchId used to be optional: without it, this script silently fell back to
# floating across every batch in Processing status (a WARNING was printed, but the run still
# proceeded and could recover/report on Orders outside the batch shown on screen). BatchId is
# now REQUIRED and format-validated as a Salesforce Id — PowerShell itself refuses to start
# this script without one, so there is no floating-scope code path left to fall into. The
# caller (execute() in live_touchpoint_automation.py) also hard-fails before invoking this
# script at all if it has no exact resolved batch id, so this is defense-in-depth, not the
# only guard.
$BatchWhere = "SBQQ__Quote__r.USS_Migration_Batch__c='$BatchId'"
Write-Host "Scope: pinned Batch Id $BatchId"

function Run-ApexTemplate($templateFile){
  $tmp=[System.IO.Path]::GetTempFileName()+'.apex'
  try {
    # No BOM: Windows PowerShell 5.1's Set-Content -Encoding UTF8 writes one, and the Apex compiler rejects it (line 1 col 1).
    [System.IO.File]::WriteAllText($tmp, ((Get-Content $templateFile -Raw) -replace '\{BATCH_WHERE\}',$BatchWhere), (New-Object System.Text.UTF8Encoding($false)))
    $out = sf apex run --file $tmp --target-org $OrgAlias 2>&1 | Out-String
    Write-Host $out
    if($LASTEXITCODE -ne 0){throw "Apex failed: $templateFile`n$out"}
    return $out
  } finally {
    Remove-Item $tmp -ErrorAction SilentlyContinue
  }
}

function Get-DebugInt($text,$tag){
  $m=[regex]::Match($text,[regex]::Escape($tag)+'=(-?\d+)')
  if(-not $m.Success){throw "Could not parse $tag from apex debug output — verification cannot be trusted, treating as failure. Raw output follows:`n$text"}
  return [int]$m.Groups[1].Value
}

Write-Host "[1/3] First-pass BatchContractOrders (once)"
Run-ApexTemplate "$PSScriptRoot\01_activate_non_contracted_once.apex" | Out-Null

for($i=1;$i -le $MaxPasses;$i++){
  Write-Host "Waiting $WaitSeconds sec for async work before recovery pass $i..."; Start-Sleep -Seconds $WaitSeconds
  $q="SELECT COUNT() FROM Order WHERE $BatchWhere AND Id NOT IN (SELECT Order__c FROM WorkOrder WHERE Order__c != null)"
  $raw=sf data query --query $q --target-org $OrgAlias --json | ConvertFrom-Json
  if($LASTEXITCODE -ne 0){throw 'Verification query failed'}
  # SELECT COUNT() returns its count in totalSize, not in records[0].expr0 (that always read 0).
  $remaining=[int]$raw.result.totalSize
  Write-Host "Orders without Work Orders: $remaining"
  if($remaining -eq 0){
    # v0.17.179 — reaching zero missing-Work-Order Orders used to be treated as full success.
    # It only proves one of three completion conditions. Run the real verification apex and
    # require NotActivated=0 AND NonContracted=0 AND WithoutWorkOrder=0 before exiting 0.
    Write-Host 'Missing-Work-Order count reached zero. Running full completion verification (activation + contracting + Work Order coverage)...'
    $verifyOut=Run-ApexTemplate "$PSScriptRoot\03_verify_order_completion.apex"
    $notActivated=Get-DebugInt $verifyOut 'SUNRISE_ORDER_REMAINING_NOT_ACTIVATED'
    $nonContracted=Get-DebugInt $verifyOut 'SUNRISE_ORDER_REMAINING_NONCONTRACTED'
    $missingWO=Get-DebugInt $verifyOut 'SUNRISE_ORDER_REMAINING_WITHOUT_WO'
    Write-Host "Verification: NotActivated=$notActivated NonContracted=$nonContracted WithoutWorkOrder=$missingWO"
    if($notActivated -eq 0 -and $nonContracted -eq 0 -and $missingWO -eq 0){
      Write-Host 'ORDER PIPELINE COMPLETE — verified zero remaining Not-Activated, Non-Contracted, and missing-Work-Order Orders.'
      exit 0
    }
    Write-Host "Missing-Work-Order count was zero but other gaps remain (NotActivated=$notActivated NonContracted=$nonContracted) — this is NOT success yet. Continuing recovery passes."
  }
  Run-ApexTemplate "$PSScriptRoot\02_recover_orders_without_workorders.apex" | Out-Null
}

$finalOut=Run-ApexTemplate "$PSScriptRoot\03_verify_order_completion.apex"
$finalNotActivated=Get-DebugInt $finalOut 'SUNRISE_ORDER_REMAINING_NOT_ACTIVATED'
$finalNonContracted=Get-DebugInt $finalOut 'SUNRISE_ORDER_REMAINING_NONCONTRACTED'
$finalMissingWO=Get-DebugInt $finalOut 'SUNRISE_ORDER_REMAINING_WITHOUT_WO'
throw "Order recovery did not reach zero after $MaxPasses passes. Remaining: NotActivated=$finalNotActivated NonContracted=$finalNonContracted WithoutWorkOrder=$finalMissingWO"
