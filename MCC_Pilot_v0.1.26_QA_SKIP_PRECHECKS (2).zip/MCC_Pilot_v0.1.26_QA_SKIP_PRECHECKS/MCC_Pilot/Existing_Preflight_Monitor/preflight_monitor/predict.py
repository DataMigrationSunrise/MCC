"""
PREDICTIVE validation -- which records will fail when you try to load them, and why,
before anyone runs the load.

This does NOT need the mapping registry. It reads the LIVE target schema (field types,
lengths, picklist values, createable/updateable/nillable flags) and validates candidate
records against it field by field. Any source of rows works: Goose staging views, a CSV,
or records already in Salesforce about to advance a stage.

Why schema-driven rather than mapping-driven: a mapping-driven predictor can only catch
what the mapping author anticipated. The schema is ground truth and does not share a
specification with the thing it is checking.

On the 2026-09-18 baseline, 84% of 1,459 predicted errors were ONE inactive picklist value.
This finds that class of problem.
"""
from __future__ import annotations
import json
import subprocess
from collections import Counter, defaultdict

import connections as cx

# Salesforce soft limits we can check without a load
_TEXT_TYPES = {"string", "textarea", "phone", "email", "url", "picklist", "multipicklist",
               "combobox", "encryptedstring"}
_NUM_TYPES = {"int", "double", "currency", "percent"}


def describe_full(alias: str, sobject: str) -> dict:
    """Full field metadata, including ACTIVE picklist values. Cached by the caller."""
    cp = subprocess.run([cx._sf_exe(), "sobject", "describe", "--sobject", sobject,
                         "--target-org", str(alias), "--json"],
                        capture_output=True, text=True, timeout=240)
    if cp.returncode != 0:
        raise cx.SalesforceError(((cp.stdout or "") + (cp.stderr or ""))[-2000:])
    data = json.loads(cp.stdout).get("result", {})
    out = {}
    for f in data.get("fields", []):
        name = f.get("name")
        out[name] = dict(
            name=name,
            type=f.get("type"),
            length=f.get("length") or 0,
            digits=f.get("digits") or 0,
            precision=f.get("precision") or 0,
            scale=f.get("scale") or 0,
            createable=bool(f.get("createable")),
            updateable=bool(f.get("updateable")),
            nillable=bool(f.get("nillable")),
            defaulted=bool(f.get("defaultedOnCreate")),
            restricted=bool(f.get("restrictedPicklist")),
            calculated=bool(f.get("calculated")),
            picklist={str(p.get("value")) for p in (f.get("picklistValues") or [])
                      if p.get("active")},
            reference_to=f.get("referenceTo") or [],
        )
    return out


def required_fields(meta: dict) -> list[str]:
    """Createable, not nillable, no default, not calculated -- i.e. it must be supplied."""
    return sorted(n for n, f in meta.items()
                  if f["createable"] and not f["nillable"] and not f["defaulted"]
                  and not f["calculated"] and n != "Id")


def validate_record(meta: dict, record: dict, operation: str = "CREATE") -> list[dict]:
    """
    Predict Salesforce's rejections for one record. Returns [] when it should load.

    Each issue: {field, type, severity, message, value}
    """
    issues = []
    op = (operation or "CREATE").upper()

    for field, value in (record or {}).items():
        if field in ("attributes", "Id") and op == "CREATE":
            continue
        f = meta.get(field)
        if f is None:
            issues.append(dict(field=field, type="FIELD_NOT_FOUND", severity="ERROR",
                               value=value,
                               message="%s is not a field on this object in the TARGET org. "
                                       "If it belongs to a managed package, confirm the package "
                                       "version matches before assuming it is absent." % field))
            continue

        if f["calculated"]:
            issues.append(dict(field=field, type="FIELD_CALCULATED", severity="ERROR", value=value,
                               message="%s is a formula/roll-up and cannot be written." % field))
            continue
        if op == "CREATE" and not f["createable"]:
            issues.append(dict(field=field, type="FIELD_NOT_CREATEABLE", severity="ERROR",
                               value=value, message="%s is not createable. Remove it from the "
                                                    "create payload." % field))
            continue
        if op == "UPDATE" and not f["updateable"]:
            issues.append(dict(field=field, type="FIELD_NOT_UPDATEABLE", severity="ERROR",
                               value=value, message="%s is not updateable." % field))
            continue

        if value in (None, ""):
            continue
        sval = str(value)

        if f["type"] in ("picklist", "multipicklist") and f["picklist"]:
            vals = [v.strip() for v in sval.split(";")] if f["type"] == "multipicklist" else [sval]
            for v in vals:
                if v and v not in f["picklist"]:
                    sev = "ERROR" if f["restricted"] else "WARNING"
                    issues.append(dict(
                        field=field, type="RESTRICTED_PICKLIST", severity=sev, value=v,
                        message="'%s' is not an ACTIVE picklist value for %s. Active: %s%s"
                                % (v, field, ", ".join(sorted(f["picklist"])[:8]),
                                   " ..." if len(f["picklist"]) > 8 else "")))

        if f["type"] in _TEXT_TYPES and f["length"] and len(sval) > f["length"]:
            issues.append(dict(field=field, type="VALUE_TOO_LONG", severity="ERROR", value=sval[:40],
                               message="%d characters exceeds the %d-character limit on %s."
                                       % (len(sval), f["length"], field)))

        if f["type"] in _NUM_TYPES:
            try:
                float(sval)
            except ValueError:
                issues.append(dict(field=field, type="NOT_NUMERIC", severity="ERROR", value=sval,
                                   message="%s is %s but the value is not numeric."
                                           % (field, f["type"])))

        if f["type"] == "boolean" and sval.lower() not in ("true", "false", "1", "0"):
            issues.append(dict(field=field, type="NOT_BOOLEAN", severity="ERROR", value=sval,
                               message="%s is boolean but the value is '%s'." % (field, sval)))

        if f["type"] == "date" and len(sval) >= 10:
            from datetime import date
            try:
                date.fromisoformat(sval[:10])
            except ValueError:
                issues.append(dict(field=field, type="BAD_DATE", severity="ERROR", value=sval,
                                   message="%s is a date but '%s' is not ISO yyyy-mm-dd."
                                           % (field, sval[:20])))

        if f["type"] == "reference" and sval and len(sval) not in (15, 18):
            issues.append(dict(field=field, type="BAD_REFERENCE_ID", severity="ERROR", value=sval,
                               message="%s is a lookup to %s but '%s' is not a 15/18-char Id."
                                       % (field, ", ".join(f["reference_to"]), sval[:25])))

    if op == "CREATE":
        for rf in required_fields(meta):
            if rf not in record or record.get(rf) in (None, ""):
                issues.append(dict(field=rf, type="REQUIRED_FIELD_MISSING", severity="ERROR",
                                   value="", message="%s is required on create and is missing "
                                                     "or blank." % rf))
    return issues


def predict_batch(meta: dict, records: list[dict], operation: str = "CREATE") -> dict:
    """
    Predict for a set of records. Returns per-record issues plus the rollup that matters:
    identical counts across records point at ONE decision, not N problems.
    """
    per_record, all_issues = [], []
    for i, rec in enumerate(records):
        iss = validate_record(meta, rec, operation)
        if iss:
            per_record.append(dict(index=i, record=rec, issues=iss,
                                   blocking=any(x["severity"] == "ERROR" for x in iss)))
            all_issues.extend(iss)

    by_pattern = Counter((x["type"], x["field"], str(x.get("value"))[:40]) for x in all_issues)
    by_field = Counter((x["type"], x["field"]) for x in all_issues)

    patterns = []
    for (typ, field), n in by_field.most_common():
        vals = [v for (t, f, v) in by_pattern if t == typ and f == field]
        patterns.append(dict(
            type=typ, field=field, count=n,
            share=(n / len(all_issues)) if all_issues else 0.0,
            distinct_values=len(set(vals)),
            example=sorted(set(vals))[:3],
            single_value_fix=(len(set(vals)) == 1)))

    return dict(
        records_checked=len(records),
        records_blocked=len([r for r in per_record if r["blocking"]]),
        total_issues=len(all_issues),
        patterns=patterns,
        per_record=per_record,
        headline=(("%d of %d record(s) will fail to load. %d issue(s), but only %d distinct "
                   "pattern(s) -- the top one is %.0f%% of them%s."
                   % (len([r for r in per_record if r["blocking"]]), len(records),
                      len(all_issues), len(patterns),
                      patterns[0]["share"] * 100 if patterns else 0,
                      " and is a SINGLE VALUE, so one decision clears it"
                      if patterns and patterns[0]["single_value_fix"] else ""))
                  if per_record else
                  "All %d record(s) validate against the live target schema." % len(records)))


# ----------------------------------------------------------------- logic gaps
def logic_issues(name: str, rows: list[dict], rule) -> list[dict]:
    """Apply a cross-field consistency rule. Returns the rows that violate it."""
    out = []
    for r in rows:
        why = rule(r)
        if why:
            d = dict(r)
            d["_logic_issue"] = why
            out.append(d)
    return out
