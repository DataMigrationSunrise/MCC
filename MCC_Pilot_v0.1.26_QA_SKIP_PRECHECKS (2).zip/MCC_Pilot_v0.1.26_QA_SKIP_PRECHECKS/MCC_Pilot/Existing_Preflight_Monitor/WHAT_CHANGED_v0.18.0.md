# MCC - Preflight Monitoring Tool — v0.18.0

Cumulative: includes everything in v0.17.1 (BIQ field name, `records_blocked`, one version
source). Six new checks, one fix to unreadable error messages, one run book binding corrected.
Still no write path to Salesforce.

## Read this first: two earlier claims were too strong

The 2026-10-02 session reported **4 Orders with duplicate Delivery Work Orders** and **103
duplicate WOLI groups** as "confirmed". Neither was tested against the team's own definition.

- **Deliveries.** The team's `TF_90A.09` says in its header that a flat "more than one Delivery"
  count is **wrong**: Contract 00533582 legitimately has two storage bundles at two jobsites and
  should get two deliveries. The test is whether deliveries *exceed distinct bundle roots*. The 4
  Orders were found with the flat count. They are **suspects**, not duplicates. Run `TF_90A.09`
  for UMB-0116 to settle them.
- **WOLIs.** The same source Order Line Item twice on one Work Order is not a duplicate if the
  source quantity is 2 and the line is split one WOLI per unit. Nobody compared against the source
  quantity. `Ordered_Quantity__c = 2` on the parent does not distinguish the two cases either.
  The 103 groups are **suspects**.

The new checks below use the correct definitions and report the control group (the legitimate
cases they did *not* flag).

## New checks

| Check | Run Order | Definition comes from | Flags | Deliberately does not flag |
|---|---|---|---|---|
| `WO.DELIVERY_EXCEEDS_BUNDLES` | 33 | `TF_90A.09` | Orders with more Delivery WOs than distinct bundle roots | Multi-delivery Orders matched by multiple bundles (reported as the control group) |
| `WOLI.EXCEEDS_SOURCE_QUANTITY` | 33 | `TF_90A.09`'s warning | Units delivered > source line quantity | A per-unit split that fits; an unreadable source quantity (counted, never guessed) |
| `CONTRACT.DUPLICATE_PER_ORDER` | 38 | Run Book Standing Rule "duplicate-Contract detection needs a source gate" | More than one Contract from one Order | Overlapping weekday/frequency alone |
| `FSL.DUPLICATE_POLYGONS` | 29 | TOM-D (2026-10-02); reconciliation file row GNV-B_2 | Two live polygons with one name; a dead polygon whose name already has a live polygon ("retire, do not repoint") | `_<n>` suffix pairs such as GNV-B / GNV-B_2 — often a legitimate second polygon for a non-contiguous area; counted in the note |
| `LOG.WORKORDER_GENERATION_ERRORS` | 28 | Log__c `a1vVD00000JEUPt`, `a1vVD00000JEz7B/C/D` | Errors logged by `ContractOrders*` and the external Work Order push, in the batch's window, each with a plain-language cause | — |
| `GOOSE.BATCH_STATUS` | 1 | Goose README "Two things to raise with CJ"; Standing Rule "Verify the batch itself first" | Batch active (Open/Processing) in Salesforce but not Open in Goose | Closed in Salesforce + Canceled in Goose (terminal on both sides; the open question for CJ is recorded in the note) |

The five review-list checks are `WARNING` and block nothing. They find exceptions that need a
decision, not conditions that stop the batch. `GOOSE.BATCH_STATUS` is a `BLOCKER`, because a batch
Goose will not serve makes every Goose-fed step run, report success, and process nothing.

### Why `FSL.DUPLICATE_POLYGONS` matters before the next repoint
The reconciliation file's "HIGH - exact live name match" confidence checks the *territory*. It
never checks whether a live *polygon* of that name already exists, which is how TOM-D ended up
with a twin. Run this check before applying the remaining ~480 repoints: every "RETIRE, DO NOT
REPOINT" row is one the file would turn into a duplicate.

## Fixed: unreadable error messages
Failure reasons were cut mid-word (`tus__c' on entity 'Billing_Impacts_Queue__c'`), which is why
the wrong BIQ field name in v0.17.0 was not obvious. Cause: the CLI's JSON error has the message
at the head and a long stack at the end, and `connections.py` kept the last 3,000 characters. New
`cli_error_text()` keeps the message, drops the echoed query before `ERROR at Row`, and keeps the
error name that `friendly_sf_error()` matches on. All three CLI error sites use it.

## Corrected: run book binding
`LOGIC.MP_ACTIVE_NO_FREQUENCY` was bound to Run Order 33, the **Check_For_Duplicate_Deliveries**
step. Row 33 therefore showed an Active-Maintenance-Plan result under a duplicate-deliveries
title, and a PASS there read as if duplicates had been checked when no duplicate check existed.
Moved to RO 41 beside its sibling `WO.MP_NO_GENERATION`. *(This was previously described as a
run book problem. It was this tool's binding.)*

## Tests
`429` assertions (was `349` in v0.17.0), all passing. Every new check is tested with a scripted
connection that records the SQL it sends, including: the legitimate case it must not flag, the
hidden-field case (UNPROVEN), the empty-population case (UNPROVEN, not PASS), and the cap case.

**Mutation testing.** Twelve deliberate breakages of the implementation, each caught by a test:
flat delivery count; WOLI flagged without comparing quantity; polygon with no twin flagged; log
query without the class scope; Goose FAIL when both sides terminal; MP check back under RO 33; a CLI
error site back to the tail slice; echoed query kept; Contract and WOLI duplicate thresholds
changed; batch scope inverted on both. One survived the first pass (the Contract test did not
inspect the SQL it sent, and the WOLI test had the same blind spot), so both now assert on it and
three further mutants were added.

One existing assertion changed: "the pre-flight runs first" was `RO == 2`; it is now `RO in (1, 2)`
because RO 1 is the run book's own PRE-FLIGHT row and now has a check.

## Not verified — read before trusting
- **Nothing here was run against Salesforce or Goose.** The SOQL is built from field names
  confirmed in the 2026-10-02 session (`Log__c` fields, `WorkOrderLineItem.Order_Line_Item__c`,
  `NF_BundleId__c`, `Contract.SBQQ__Order__c`) and from the tool's own existing queries. If a query
  is rejected, the check reports UNPROVEN and — with the error fix above — shows which field.
- `GROUP BY ... HAVING COUNT(Id) > 1` and the relationship reads `Order_Line_Item__r.Quantity`
  and `Order__r.OrderNumber` have not been run in this org.
- Goose `dbo.MigrationBatch` columns `ID`, `BatchName`, `BatchStatus` come from the tool's own BIQ
  parity query and the Goose README. Goose is unreachable in most runs, so expect UNPROVEN there.
- `LOG.WORKORDER_GENERATION_ERRORS` attributes `Log__c` rows by time window and logger name only;
  `Log__c` has no batch link, so the external-push rows can include other teams' errors.

## Found in the documentation review, NOT built
- **`TF_90A.10` duplicate Service Appointments.** Its own header warns the batch path may differ
  between `Contract` and `Contract__c`. Needs that settled first.
- **`TF_90A.04` cause classification and `TF_90A.07` coverage gaps.** Both need FSL polygon
  geometry (Apex, CPU-bound); not expressible in SOQL.
- **`TF_40.02` weekday difference** (Reiter Pacific Farms, Sunday vs Wednesday). Needs Goose
  expected values.
- **BIQs created Salesforce-side that never reach Goose** (CJ's 39 BIQs, all 18 broken ones).
  `GOOSE.BIQ_PARITY` covers it when Goose is reachable.
- **Four permission-hidden checks** (`Account.USF_Department_Code__c` and the Quote billing fields)
  still need a permission-set change, not code.
