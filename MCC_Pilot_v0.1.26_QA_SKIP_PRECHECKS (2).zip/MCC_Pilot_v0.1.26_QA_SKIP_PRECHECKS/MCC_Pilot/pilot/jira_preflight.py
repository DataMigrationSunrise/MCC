"""Evidence-backed, READ-ONLY migration Jira regression predictor.

The registry is a snapshot of user-supplied Jira metadata, not a Jira sync.
Tests describe only the staged input or the exact pre-transform condition they
measure: neither Jira status nor source sanity implies a post-load fix.
"""
from __future__ import annotations

import csv
import json
import re
from datetime import datetime
from pathlib import Path

_SQL_START = re.compile(r'^\s*(?:--[^\n]*\n\s*)*SELECT\b', re.I)
_SQL_MUTATION = re.compile(r'\b(?:INSERT|UPDATE|DELETE|MERGE|EXEC|EXECUTE|DROP|ALTER|TRUNCATE|CREATE|GRANT|REVOKE|INTO|OPENROWSET|OPENDATASOURCE)\b|;', re.I)
_ALLOWED_RESULTS = {'SOURCE_INPUT_PASS', 'SOURCE_RISK', 'PREDICTED_FAILURE'}


def registry(root: Path):
    data = json.loads((root / 'jira_issue_registry.json').read_text(encoding='utf-8'))
    return data


def predict(goose, root: Path, batch_id: int, step: str, folder: Path | None = None,
            simulated: bool = False):
    """Return per-issue results and durable evidence, never mutate or exclude records.

    Only run the tests applicable to the requested step. Zero cohort rows is
    NOT_TESTABLE, never PASS. 1001 rows signals a partial sample, never PASS.
    """
    root = Path(root)
    batch_id = int(batch_id)
    if batch_id <= 0:
        raise ValueError('A valid Goose numeric batch ID is required')
    cfg = json.loads((root / 'jira_preflight_rules.json').read_text(encoding='utf-8'))
    issues = registry(root)['issues']
    tests = {}
    for rule in cfg['rules']:
        if step not in rule.get('steps', []) and '*' not in rule.get('steps', []):
            continue
        rid = rule['id']
        outcome = {'id': rid, 'issue': rule['issue'], 'step': step,
                   'meaning': rule['meaning'], 'rows_checked': 0,
                   'state': 'NOT_TESTABLE', 'examples': []}
        if simulated:
            outcome['state'] = 'SIMULATED_NOT_VERIFIED'
            outcome['reason'] = 'Simulation does not query Goose'
            tests[rid] = outcome
            continue
        try:
            name = rule['file']
            if Path(name).name != name or not name.endswith('.sql'):
                raise ValueError('Unsafe rule path')
            sql = (root / 'jira_preflight_rules' / name).read_text(encoding='utf-8')
            if not _SQL_START.match(sql) or _SQL_MUTATION.search(sql):
                raise ValueError('Rule is not a single read-only SELECT')
            if sql.count('{{GOOSE_BATCH_ID}}') != 1:
                raise ValueError('Rule must explicitly bind one Goose batch ID')
            # Preserve 1001th result to detect incomplete sampling.
            if not re.search(r'\bTOP\s*\(\s*1001\s*\)', sql, re.I):
                raise ValueError('Rule must cap result rows using TOP (1001)')
            result_sets = goose.result_sets(sql.replace('{{GOOSE_BATCH_ID}}', str(batch_id)))
            rows = [r for st in result_sets for r in st]
            outcome['rows_checked'] = len(rows)
            if len(rows) >= 1001:
                outcome['state'] = 'INCOMPLETE_SAMPLE'
                outcome['reason'] = 'At least 1001 matching rows; results not exhaustive'
            elif not rows:
                outcome['state'] = 'NOT_TESTABLE'
                outcome['reason'] = 'No matching staged source rows in this batch; no pass inferred'
            else:
                # Any invalid or unknown result makes a test unproven.
                labels = [str(r.get('TestResult', '')).upper() for r in rows]
                if any(label not in _ALLOWED_RESULTS for label in labels):
                    outcome['state'] = 'NOT_TESTABLE'
                    outcome['reason'] = 'Unrecognized SQL result status; cannot assert pass'
                elif 'PREDICTED_FAILURE' in labels:
                    outcome['state'] = 'PREDICTED_FAILURE'
                elif 'SOURCE_RISK' in labels:
                    outcome['state'] = 'SOURCE_RISK'
                else:
                    outcome['state'] = 'SOURCE_INPUT_PASS'
                outcome['counts'] = {label: labels.count(label) for label in _ALLOWED_RESULTS}
                outcome['examples'] = [dict(source_record_id=str(r.get('SourceRecordId', '')),
                                            source_key=str(r.get('SourceKey', '')),
                                            transformation_id=str(r.get('TransformationId', '')),
                                            result=str(r.get('TestResult', '')),
                                            reason=str(r.get('Reason', ''))[:400])
                                       for r in rows if r.get('TestResult') != 'SOURCE_INPUT_PASS'][:25]
        except Exception as e:
            outcome['state'] = 'NOT_TESTABLE'
            outcome['reason'] = 'SQL validation unavailable: %s' % str(e)[:350]
        tests[rid] = outcome
    issue_results = []
    for entry in issues:
        linked = [tests[t] for t in entry.get('tests', []) if t in tests]
        if linked:
            statuses = {t['state'] for t in linked}
            if 'PREDICTED_FAILURE' in statuses: result = 'PREDICTED_FAILURE'
            elif 'SOURCE_RISK' in statuses: result = 'SOURCE_RISK'
            elif 'INCOMPLETE_SAMPLE' in statuses: result = 'INCOMPLETE_SAMPLE'
            elif 'NOT_TESTABLE' in statuses: result = 'NOT_TESTABLE'
            elif 'SIMULATED_NOT_VERIFIED' in statuses: result = 'SIMULATED_NOT_VERIFIED'
            else: result = 'SOURCE_INPUT_PASS'
        else:
            result = 'NOT_CHECKED_THIS_STEP' if entry.get('tests') else 'NO_EXECUTABLE_CHECK'
        issue_results.append({**entry, 'prediction': result,
                              'checked_tests': [t['id'] for t in linked]})
    report = dict(batch_id=batch_id, step=step,
                  observed_at=datetime.now().isoformat(timespec='seconds'),
                  source='LIVE_GOOSE_STAGING' if not simulated else 'SIMULATED_NO_GOOSE',
                  jira_metadata_source='USER_PROVIDED_SNAPSHOT_NOT_LIVE_JIRA',
                  warning='Source input checks do not prove a Jira bug is fixed in Salesforce',
                  tests=list(tests.values()), issues=issue_results)
    if folder:
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        suffix=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        prefix=folder / ('jira_preflight_%s_%s' % (step, suffix))
        json_path=prefix.with_suffix('.json')
        json_path.write_text(json.dumps(report, indent=2, default=str), encoding='utf-8')
        csv_path=prefix.with_suffix('.csv')
        with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
            writer=csv.DictWriter(f,fieldnames=['key','title','assignee','jira_status','related_step','prediction','checked_tests'])
            writer.writeheader()
            for i in issue_results:
                writer.writerow({k:', '.join(i[k]) if isinstance(i.get(k),list) else i.get(k,'') for k in writer.fieldnames})
        report['evidence']={'json':str(json_path),'csv':str(csv_path)}
    return report
