"""
Six startup stages. The tool validates ITSELF before it validates anything else, and
refuses to report results if its own fixtures fail.

A tool that reports while its own checks are broken is worse than no tool.
"""
from __future__ import annotations

import connections as cx
import registry


def _safe_fields(conn, obj):
    try:
        return conn.fields(obj)
    except Exception:                                        # noqa: BLE001
        return set()


class SelfTest:
    def __init__(self):
        self.stages: list[dict] = []
        self.hard_fail = False

    def add(self, stage, status, detail="", fatal=False):
        self.stages.append(dict(stage=stage, status=status, detail=str(detail)))
        if fatal and status == "FAIL":
            self.hard_fail = True
        return status == "OK"

    @property
    def ok(self) -> bool:
        return not self.hard_fail


def run(cfg: dict, conn: cx.Conn, batch: str = "", store=None, quick: bool = False) -> SelfTest:
    st = SelfTest()

    # 1 -- registry integrity (before anything touches a network)
    errs = registry.validate()
    st.add("1 registry", "FAIL" if errs else "OK",
           "; ".join(errs) if errs else "%d checks registered, all declare rule source, "
           "proves, cannot_prove and a canary" % len(registry.all_checks()), fatal=True)

    # 2 -- connections
    ok, msg = cx.sf_test(conn.alias)
    st.add("2 salesforce", "OK" if ok else "FAIL", msg, fatal=True)

    if cfg.get("GooseServer"):
        gok, gmsg = cx.goose_test(conn.goose_server, conn.goose_db)
        conn.goose_ok = gok
        st.add("2 goose", "OK" if gok else "DEGRADED", gmsg)
    else:
        conn.goose_ok = False
        st.add("2 goose", "DEGRADED", "No GooseServer configured. Goose checks report UNPROVEN.")

    # Informatica: live API if credentials are in the environment, else captured history.
    # Never fatal, never DEGRADED-as-alarming: captured history is a legitimate source and
    # most machines will not have the credentials set.
    if conn.informatica_live:
        st.add("2 informatica", "OK", conn.informatica_note)
    else:
        st.add("2 informatica", "DEGRADED",
               (conn.informatica_note or "No live Informatica read.")
               + (" Captured history has %d run(s)." % len(conn.jobs.runs)
                  if conn.jobs.runs else " No captured history either, so the Time column"
                                         " will be blank. This never fails a check."))

    conn.sunrise_run = cx.latest_preflight_run(cfg.get("SunriseAppDir", ""))
    # Only a check that declares needs_sunrise can be affected by this, and today none does.
    # Say so: reporting DEGRADED for something that costs nothing teaches people to ignore the
    # DEGRADED lines that do matter.
    dependents = [c.id for c in registry.all_checks() if c.needs_sunrise]
    if conn.sunrise_run:
        st.add("2 sunrise", "OK", str(conn.sunrise_run))
    elif dependents:
        st.add("2 sunrise", "DEGRADED",
               "No Sunrise preflight output found, so these checks report UNPROVEN: %s"
               % ", ".join(dependents))
    else:
        st.add("2 sunrise", "OK",
               "No Sunrise preflight output (test_run_history/full_migration_preflight) found. "
               "Not used: no current check depends on it, so nothing is affected.")

    # Salesforce is dead -> every remaining stage needs it. Stop now rather than paying
    # ~20 more CLI process starts to produce the same error twenty more times.
    if not ok:
        st.add("3 batch scope", "SKIPPED", "Salesforce unreachable -- fix that first.")
        st.add("4 schema", "SKIPPED", "Salesforce unreachable -- fix that first.")
        st.add("6 canaries", "SKIPPED", "Salesforce unreachable -- fix that first.")
        return st

    # 3 -- batch scope resolves to exactly one
    if batch:
        try:
            rows = conn.q("SELECT Id, Name, Batch_Status__c FROM USS_Migration_Batch__c "
                          "WHERE Name = '%s'" % batch)
            if len(rows) == 1:
                st.add("3 batch scope", "OK", "%s -> %s (%s)" % (
                    batch, rows[0].get("Id"), rows[0].get("Batch_Status__c")))
            elif not rows:
                st.add("3 batch scope", "FAIL", "No batch named %s" % batch, fatal=True)
            else:
                st.add("3 batch scope", "FAIL",
                       "%d batches named %s -- ambiguous scope, refusing to run" % (len(rows), batch),
                       fatal=True)
        except Exception as e:                                  # noqa: BLE001
            st.add("3 batch scope", "FAIL", str(e)[:400], fatal=True)
    else:
        st.add("3 batch scope", "SKIPPED", "No batch pinned (populate mode resolves per batch)")

    if not quick:
        # 4 -- schema: every field every registered check depends on
        need = sorted({f for c in registry.all_checks() for f in c.requires})
        # One describe per OBJECT, not per field, and the objects in parallel. Each describe is
        # a separate `sf` process; serially this was most of a minute on its own.
        objs = sorted({f.split(".")[0] for f in need})
        for obj, res in zip(objs, cx.parallel(lambda o: _safe_fields(conn, o), objs,
                                              getattr(conn, "workers", 0))):
            pass                                     # warms conn's per-object field cache
        missing = []
        for f in need:
            try:
                if not conn.has_field(f):
                    missing.append(f)
            except Exception as e:                                  # noqa: BLE001
                missing.append("%s (describe failed: %s)" % (f, str(e)[:80]))
        st.add("4 schema", "DEGRADED" if missing else "OK",
               ("absent or FLS-hidden: " + ", ".join(missing)) if missing
               else "%d declared field(s) present and visible" % len(need))

        # 4b -- the WorkOrder Contract ambiguity, settled explicitly
        try:
            std = conn.has_field("WorkOrder.ContractId")
            cus = conn.has_field("WorkOrder.Contract__c")
            if std and cus:
                st.add("4 schema: WorkOrder contract link", "DEGRADED",
                       "BOTH ContractId and Contract__c exist. Checks use Contract__c (as "
                       "preflight_pipeline.py and AF60 do). If the two disagree, populations differ "
                       "between tools.")
            else:
                st.add("4 schema: WorkOrder contract link", "OK",
                       "Contract__c" if cus else ("ContractId" if std else "NEITHER -- investigate"))
        except Exception as e:                                      # noqa: BLE001
            st.add("4 schema: WorkOrder contract link", "DEGRADED", str(e)[:200])

    # 5 -- rule contradictions
    if store is not None:
        for r in registry.rules():
            store.register_rule(r)
        con = store.contradictions()
        if con:
            lines = []
            for c in con:
                lines.append("%s.%s: " % (c["sobject"], c["field"]) +
                             " | ".join("'%s' (%s)" % (x["assertion"], x["source"])
                                        for x in c["rules"]))
            st.add("5 rule contradictions", "DEGRADED",
                   "%d field(s) carry conflicting documented rules. No check may assert PASS on "
                   "them until resolved. %s" % (len(con), "  ||  ".join(lines)))
        else:
            st.add("5 rule contradictions", "OK", "No conflicting rules registered")

    if quick:
        pass    # canaries are skipped; the runner runs one only when a check finds nothing
    else:
        # 6 -- canaries
        if batch:
            todo = [c for c in registry.all_checks()
                    if c.canary is not None and not (c.needs_goose and not conn.goose_ok)]

            def one(c):
                n = int(c.canary(conn) or 0)
                # Cached so the checks themselves do not re-run the identical query. This was
                # the single biggest cost in the run: 47 canaries here, then the same queries
                # again from every check that found zero rows.
                conn.canary_cache[c.id] = n
                return n

            bad = []
            for c, res in zip(todo, cx.parallel(one, todo, getattr(conn, "workers", 0))):
                if isinstance(res, Exception):
                    bad.append("%s (%s)" % (c.id, str(res)[:60]))
                elif res <= 0:
                    bad.append(c.id)
            st.add("6 canaries", "DEGRADED" if bad else "OK",
                   ("these canaries found nothing, so a zero result from them means BROKEN SCOPE, "
                    "not clean: " + ", ".join(bad)) if bad
                   else "all canaries returned rows")
        else:
            st.add("6 canaries", "SKIPPED", "No batch pinned")

    return st
