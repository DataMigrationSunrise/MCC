# MCC - Preflight Monitoring Tool v0.14.3

## Fixed: a truncated read could INVENT findings

`FSL.DEAD_POLYGONS` read `ServiceTerritory LIMIT 2000`. A polygon is judged dead by its
**absence** from that set — so if the org holds more than 2,000 territories, every polygon
pointing at territory 2,001 or beyond would be reported as broken. Not an under-count: pure
false positives, on a check that blocks four Run Orders.

Both populations are now counted first. If either exceeds what the check can read, it
reports **UNPROVEN** and says why, rather than producing a confident list of fictional
defects. Caps are `TERR_CAP` / `POLY_CAP` at the top of the check.

This is also the likely explanation for the live count (1,129 polygons) disagreeing with the
2026-10-01 reconciliation (502 broken of ~4,500). **Re-run and check whether RO 2 now
reports UNPROVEN** — if it does, raise the caps; if it gives a number, that number is sound.

## Your 2026-10-02 self-test found a flaw in the Run Order 15 checks

Three fields those checks depend on are **not visible to your user**:

```
SBQQ__Quote__c.Business_Type__c
SBQQ__Quote__c.Bill_Timing__c
SBQQ__Quote__c.Billing_Period__c
```

So `QUOTE.BUSINESS_TYPE_MISSING` and `QUOTE.BILLING_CONFIG_INCOMPLETE` are reporting
UNPROVEN and checking nothing. I took those names from the org's own field snapshot
(`salesforce_field_constraints.csv`, 2026-09-21), which lists all three on
`SBQQ__Quote__c` — your live org disagrees.

**All three are visible on `Account` and `Contract`.** A field present on sibling objects
but not this one is far more likely hidden by field-level security than genuinely absent —
and that is the difference between a permission grant and a deployment.

The message now says so instead of stopping at "absent or FLS-hidden", and hands over the
Apex that settles it. Grant read on those three for your profile, re-run, and both checks
come alive. The other five Run Order 15 checks are unaffected and already working.

## New: the Sunrise path is forgiving

It required the exact `app` folder, so a reasonable answer like *"my Downloads folder"*
silently did nothing. It now searches up to 4 levels beneath whatever you point it at for
`goose_live\goose_live.py`. Bounded on purpose — depth 4, a few thousand directories — so a
large folder cannot turn startup into a disk crawl. A folder with no Sunrise under it
reports NOT FOUND; it never guesses.

## New: results are flagged when they go stale

A run describes the org **at the moment it ran**. Your 13:11 run on 2026-10-02 reported
clean zeros on Service Appointments that did not exist until 14:16. It was not wrong — it
was old, and nothing on screen said so.

Results older than 30 minutes now carry a banner:

> **These results are 3 hours old.** They describe the org as it was when the checks ran,
> not as it is now. Anything created or changed since is not reflected — a clean result here
> is only as current as the run.

A stale clean result is the most dangerous thing this tool can show, and it was the one
state it had no words for.

---

# Where this stands

48 checks, ~200 regression tests, run book v43, repo v45.

## Needs you, not me

1. **`SunriseAppDir` is pre-set to `C:\Users\VChiraf\Downloads`.** It no longer has to be
   the exact `app` folder — point it at anything Sunrise sits under and it searches up to 4
   levels down for the folder holding `goose_live\goose_live.py`. Change it only if Sunrise
   lives somewhere other than Downloads. Press **Self-test** and look for
   *"Bound to Sunrise goose_live at ..."*.

   This switches on three checks that are otherwise dead, including
   `PREDICT.LOAD_FAILURES` — the **only** check that catches problems *before* a load rather
   than after — and fills the Time column with real Informatica/SnapLogic run windows
   instead of record-timestamp proxies.

   If it is under OneDrive, the files must be downloaded locally, not online-only, or the
   search cannot see them.

2. **Re-run the checks.** Your stored run is from v0.7.0. Re-running fixes the "48 of 41"
   display, captures up to 2,000 records per finding instead of 200, and builds the object
   band.

3. **The three Service Appointment queries** from earlier. They measure how much of the
   null-territory damage is dead polygons versus ungeocoded addresses — the split that must
   happen before either fix runs.

## Known gaps, honestly

- **Source-data coverage is thin.** 3 of 48 checks touch Goose; 70 query sites against
  Salesforce versus 4 against the source. This validates what landed far better than what is
  about to land.
- **"Lots of pricing validation failures"** has no check anywhere. It needs the Validation
  Workbook price baseline, which was never wired in.
- **The self-test does not flag the `ServiceAppointment.ParentRecordId` vs `Work_Order__c`
  ambiguity** the way it does for `WorkOrder.ContractId` vs `Contract__c`. Both fields are
  populated in your org today, so nothing is wrong now — but if they ever diverge, the
  appointment counts go quietly wrong.
- **The 11 null-batch Contracts** are confirmed and unexplained.
- **Whether a migrated Order should be Order Ready** is still an open business question. It
  decides whether RO 15 hard-blocks.

## v0.14.3

`runbook.json` re-synced from run book **v44**, which adds the field-visibility caveat at
Run Order 15, the truncation guard at Run Order 2, a staleness requirement on the final
gate, and five standing rules that were previously only implicit.

---

# v0.15.0 — it was slow because every query was a separate process

## The measurement

From a real run, 2026-10-02:

```
17:16:05  started
17:16:05  running self-test
17:22:07  self-test finished
```

**Six minutes before the first check ran.** Not one slow query — 53 separate `sf` CLI
processes, one after another. Each starts Node, authenticates and round-trips: roughly 5-8
seconds of almost pure waiting, 53 times.

- 6 describes (one per object a check declares a field on)
- 47 canaries — and every one of those got run **a second time** by the check itself,
  because a check runs its canary whenever it finds zero rows

## Three changes

**1. Queries run on a small pool.** They are independent and spend nearly all their time
waiting, so 6 at a time collapses the wall clock without putting any more load on the org —
the same queries, just not single file.

**2. Canaries are run once per run, not twice.** The self-test caches each result and the
checks reuse it. That removes 47 duplicate CLI processes on its own.

**3. The check pack runs on the pool too**, with results returned in **registry order**
regardless of completion order — the run book is read in order, and a shuffled list would be
unreadable.

Expect the self-test to drop from roughly six minutes to under one, and the full run to
improve by a similar factor.

## Correctness first

Speed is worthless if it changes an answer, so the tests assert both:

- results come back in the original order, every time
- one failing query does not kill the batch — the other 47 answers still arrive
- every check still produces a result, and every result is still persisted
- progress fires exactly once per check
- **`"Workers": 1` gives identical verdicts** — a strictly serial run, same answers, slower

`Workers` is in `config.json`, default 6. Set it to 1 if you ever want to rule parallelism
out while diagnosing something.

## v0.15.1 — checks run in Run Order

They ran in **source-file definition order**: 2, 2, 2, 2, 18, 51, 50, 54, 55, 28, 41, 9,
55, 16... with `PREDICT.LOAD_FAILURES` — Run Order 3 — running **23rd of 48**.

This changed no answer. Checks are independent, none reads another's result, and readiness
is computed from the stored results afterwards. But it made the progress log impossible to
follow, and it meant a broken pre-flight was discovered only after minutes spent checking
Run Order 55.

Execution and reporting now follow the run book. Definitions stay grouped by subject in
`checks.py`, because that is how they are read and maintained — only the order they run in
changed. An unbound check sorts **last**, so one nobody remembered to bind cannot quietly
pose as a pre-flight.

With `Workers` above 1 the log still interleaves slightly, since six checks are in flight at
once — but it now moves broadly down the run book instead of jumping about.

## v0.16.0 — an absence is not a record list

Clicking through on **"TF_35 produced Activated Contracts"** gave a one-row table restating
the headline. The complaint was fair: it promised records and delivered none.

**The reason is the finding itself.** That check reports an *absence* — TF_35 produced
nothing for this batch — so there are no failing records, because no records were created.
The row shown was a marker the check writes to record the observation, not a Salesforce
record. Rendering it as a record table was a display bug.

Three fixes:

**The issue list no longer says "1".** A "did the job run" check with nothing produced now
reads **"none produced"**, so nothing invites a click that can only return the headline
again.

**The drill-down says so plainly.** An absence finding opens with: *"There are no failing
records to show, and that is the finding. This check reports an ABSENCE: the step produced
nothing for this batch, so no records exist to list."*

**And it points at where the records actually are.** A step that produced nothing failed on
some upstream population, and those records exist under a different check:

| Produced nothing | The records are at | Which are |
|---|---|---|
| `RAN.TF_30_ORDERS` | RO 16 `QUOTE.MISSING_PRICEBOOK_ENTRY` | Quote Lines that cannot convert |
| `RAN.TF_35_CONTRACTS` | RO 16 `ORDER.ACTIVATION_RATE` | Orders not Activated/Contracted |
| `RAN.TF_40_MPS` | RO 41 `WO.MP_NO_GENERATION` | Active MPs generating no Work Orders |
| `RAN.TF_55_WORKORDERS` | RO 28 `WO.ORDERS_MISSING_WOS` | Orders with no Work Orders |
| `RAN.TF_60_BIQS` | RO 54 `BIQ.COVERAGE` | Contracts with no BIQs |

A record list is still rendered in full wherever real records exist — the distinction is
drawn on whether the rows carry a Salesforce Id, not on the check's name.
