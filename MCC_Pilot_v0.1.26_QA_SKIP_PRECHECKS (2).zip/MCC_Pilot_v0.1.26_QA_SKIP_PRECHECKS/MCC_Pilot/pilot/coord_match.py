"""READ-ONLY: match blank Goose address coordinates to geocoded Salesforce addresses.

Goose gets no coordinates from NAV (97% of batch 468's SFDC_USF_Address rows are blank),
so TF_15 loads addresses that cannot resolve a service territory. Salesforce already holds
geocoded copies of most of them. Matching uses the same two-policy rule SnapLogic uses for
accounts (mct07_Buildable_Spec_FuzzyMatch.md): an EXACT key and a SOUNDEX name check must
BOTH pass, and ambiguous candidates are reported, never proposed.

    Policy 1 (exact)   : ZIP5 + state + city, normalized
    Policy 2 (soundex) : same house number AND (same normalized street OR same Soundex of
                         the street name)
    Ambiguity          : candidates whose coordinates disagree by more than MAX_SPREAD
                         degrees (~110 m) are AMBIGUOUS

This module only reads and reports (phase 1 of the spec). Writing the matches to Goose is a
separate, approved step.
"""
from __future__ import annotations

import csv
import json
import re
from datetime import datetime
from pathlib import Path

MAX_SPREAD = 0.001
SUFFIX = {"STREET": "ST", "AVENUE": "AVE", "AV": "AVE", "ROAD": "RD", "DRIVE": "DR", "BOULEVARD": "BLVD",
          "LANE": "LN", "COURT": "CT", "PLACE": "PL", "HIGHWAY": "HWY", "PARKWAY": "PKWY", "CIRCLE": "CIR",
          "TERRACE": "TER", "TRAIL": "TRL", "WAY": "WAY", "SQUARE": "SQ", "EXPRESSWAY": "EXPY", "FREEWAY": "FWY"}
DIRECTION = {"NORTH": "N", "SOUTH": "S", "EAST": "E", "WEST": "W", "NORTHEAST": "NE", "NORTHWEST": "NW",
             "SOUTHEAST": "SE", "SOUTHWEST": "SW"}
UNIT = re.compile(r"\b(STE|SUITE|UNIT|APT|BLDG|BUILDING|FL|FLOOR|RM|ROOM)\b.*$|#.*$")


def norm_street(s) -> str:
    s = UNIT.sub("", re.sub(r"[^A-Z0-9# ]", " ", str(s or "").upper()))
    return " ".join(DIRECTION.get(w, SUFFIX.get(w, w)) for w in s.split())


def norm_text(s) -> str:
    return " ".join(re.sub(r"[^A-Z0-9 ]", " ", str(s or "").upper()).split())


def zip5(z) -> str:
    m = re.match(r"\s*(\d{5})", str(z or ""))
    return m.group(1) if m else ""


def soundex(word: str) -> str:
    codes = {**dict.fromkeys("BFPV", "1"), **dict.fromkeys("CGJKQSXZ", "2"), **dict.fromkeys("DT", "3"),
             "L": "4", **dict.fromkeys("MN", "5"), "R": "6"}
    w = re.sub(r"[^A-Z]", "", word.upper())
    if not w:
        return ""
    out, prev = w[0], codes.get(w[0], "")
    for ch in w[1:]:
        c = codes.get(ch, "")
        if c and c != prev:
            out += c
        if ch not in "HW":
            prev = c
    return (out + "000")[:4]


def split_street(s) -> tuple[str, str]:
    """House number and the street-name core (no number, suffix or direction)."""
    words = norm_street(s).split()
    number = words[0] if words and re.match(r"^\d+[A-Z]?$", words[0]) else ""
    core = [w for w in words[1 if number else 0:] if w not in SUFFIX.values() and w not in DIRECTION.values()]
    return number, " ".join(core)


def _largest_cluster(pts: list[tuple]) -> list[tuple]:
    """Points within MAX_SPREAD of the point that has the most such neighbours."""
    best = []
    for p in pts:
        near = [q for q in pts if abs(q[0] - p[0]) <= MAX_SPREAD and abs(q[1] - p[1]) <= MAX_SPREAD]
        if len(near) > len(best):
            best = near
    return best


def _key(r) -> tuple:
    return (zip5(r.get("USF_Zip_Code__c")), norm_text(r.get("USF_State__c")), norm_text(r.get("USF_City__c")))


def _coarse(v) -> bool:
    """4 or fewer decimals (~11 m+) - city/ZIP centroids, e.g. downtown LA 34.0522, -118.2437."""
    s = repr(float(v))
    return len(s.split(".")[1].rstrip("0")) <= 4 if "." in s else True


def _street_hits(g, rows):
    gnum, gcore = split_street(g.get("USF_Street__c"))
    gfull = norm_street(g.get("USF_Street__c"))
    exact, phonetic = [], []
    for r in rows:
        rnum, rcore = split_street(r.get("USF_Street__c"))
        if rnum != gnum:
            continue
        if norm_street(r.get("USF_Street__c")) == gfull:
            exact.append(r)
        elif soundex(rcore.replace(" ", "")) == soundex(gcore.replace(" ", "")):
            phonetic.append(r)
    return (exact, "EXACT_STREET") if exact else (phonetic, "SOUNDEX_STREET")


def _choose(cands):
    """Best agreed point among candidates, or (None, reason). Precise points beat centroids;
    a strict majority of >= 2 copies wins over outliers; anything else is ambiguous."""
    pts = [(float(r["Address_Latitude_Longitude__Latitude__s"]), float(r["Address_Latitude_Longitude__Longitude__s"]))
           for r in cands]
    precise = [p for p in pts if not (_coarse(p[0]) and _coarse(p[1]))]
    pool, tag = (precise, "") if precise else (pts, "_COARSE")
    cluster = _largest_cluster(pool)
    if len(cluster) == len(pool):
        agreed = cluster
    elif len(cluster) >= 2 and len(cluster) * 2 > len(pool):
        agreed, tag = cluster, tag + "_MAJORITY"
    else:
        return None, "AMBIGUOUS"
    return (round(sum(p[0] for p in agreed) / len(agreed), 6), round(sum(p[1] for p in agreed) / len(agreed), 6)), tag


def match(goose_rows: list[dict], sf_rows: list[dict]) -> list[dict]:
    """Classify each blank Goose address. Pure function: no I/O.

    Best source first (user rule 2026-10-22: look at the account, order and lines):
      ORDER   - the same NAV order's ship-to (parent) address in this batch, same street,
                already geocoded in Goose
      ACCOUNT - geocoded Salesforce addresses on the same Salesforce account
      ANY     - any geocoded Salesforce address
    A tier is used only if it yields an agreed point; an ambiguous tier falls through.
    """
    by_key: dict[tuple, list[dict]] = {}
    for r in sf_rows:
        if r.get("Address_Latitude_Longitude__Latitude__s") is None or r.get("Address_Latitude_Longitude__Longitude__s") is None:
            continue
        by_key.setdefault(_key(r), []).append(r)
    out = []
    for g in goose_rows:
        k = _key(g)
        gnum, gcore = split_street(g.get("USF_Street__c"))
        item = dict(goose_id=g.get("Id"), street=g.get("USF_Street__c"), city=g.get("USF_City__c"),
                    state=g.get("USF_State__c"), zip=g.get("USF_Zip_Code__c"),
                    account=g.get("SalesforceAccountID") or "", result="NO_MATCH", tier="",
                    confidence="", lat=None, lng=None, candidates=0, source_ids="")
        if not k[0] or not gnum or not gcore:
            item["result"] = "NOT_MATCHABLE"   # no ZIP or no house number: never guess
            out.append(item)
            continue
        parent = []
        if g.get("ParentLat") is not None and g.get("ParentLng") is not None and g.get("ParentId"):
            parent = [{"Id": "goose:%s" % g["ParentId"], "USF_Street__c": g.get("ParentStreet"),
                       "Address_Latitude_Longitude__Latitude__s": g["ParentLat"],
                       "Address_Latitude_Longitude__Longitude__s": g["ParentLng"]}]
        pool = by_key.get(k, [])
        acct = str(g.get("SalesforceAccountID") or "")[:15]
        tiers = [("ORDER", parent),
                 ("ACCOUNT", [r for r in pool if acct and str(r.get("USF_Account__c") or "")[:15] == acct]),
                 ("ANY", pool)]
        for tier, rows in tiers:
            cands, conf = _street_hits(g, rows)
            if not cands:
                continue
            point, tag = _choose(cands)
            item.update(tier=tier, candidates=len(cands), source_ids=",".join(r["Id"] for r in cands[:5]))
            if point is None:
                item.update(result="AMBIGUOUS", confidence=conf)
                continue                          # try a wider tier before giving up
            item.update(result="MATCH", confidence=conf + tag, lat=point[0], lng=point[1])
            break
        out.append(item)
    return out


def find(goose, sf, batch_id: int) -> list[dict]:
    """Read-only: blank Goose addresses for the batch, matched to geocoded Salesforce addresses."""
    sets = goose.result_sets(
        "SELECT AD.Id, AD.USF_Street__c, AD.USF_City__c, AD.USF_State__c, AD.USF_Zip_Code__c, "
        "A.SalesforceAccountID, P.Id AS ParentId, P.USF_Street__c AS ParentStreet, "
        "P.Address_Latitude_Longitude__Latitude__s AS ParentLat, "
        "P.Address_Latitude_Longitude__Longitude__s AS ParentLng "
        "FROM dbo.SFDC_USF_Address AD "
        "LEFT JOIN dbo.SFDC_Account A ON A.ID = AD.SFDC_AccountID AND A.MigrationBatchID = AD.MigrationBatchID "
        "OUTER APPLY (SELECT TOP (1) PJ.Id, PJ.USF_Street__c, PJ.Address_Latitude_Longitude__Latitude__s, "
        "PJ.Address_Latitude_Longitude__Longitude__s FROM dbo.STG_OrderLineItem OLI "
        "JOIN dbo.STG_Order O ON O.ID = OLI.OrderID "
        "JOIN dbo.SFDC_USF_Address PJ ON PJ.STG_AddressID = O.ShipToAddressID "
        "AND PJ.MigrationBatchID = AD.MigrationBatchID "
        "WHERE OLI.ServiceAddressID = AD.STG_AddressID AND PJ.Id <> AD.Id "
        "AND PJ.Address_Latitude_Longitude__Latitude__s IS NOT NULL) P "
        "WHERE AD.MigrationBatchID = %d AND (AD.Address_Latitude_Longitude__Latitude__s IS NULL "
        "OR AD.Address_Latitude_Longitude__Longitude__s IS NULL)" % int(batch_id))
    goose_rows = [r for s in sets for r in s]
    zips = sorted({zip5(r.get("USF_Zip_Code__c")) for r in goose_rows} - {""})
    sf_rows = []
    for i in range(0, len(zips), 150):
        sf_rows += sf.query(
            "SELECT Id, USF_Account__c, USF_Street__c, USF_City__c, USF_State__c, USF_Zip_Code__c, "
            "Address_Latitude_Longitude__Latitude__s, Address_Latitude_Longitude__Longitude__s "
            "FROM USF_Address__c WHERE USF_Zip_Code__c IN (%s) "
            "AND Address_Latitude_Longitude__Latitude__s != null "
            "AND Address_Latitude_Longitude__Longitude__s != null" % ",".join("'%s'" % z for z in zips[i:i + 150]))
    return match(goose_rows, sf_rows)


def summarize(items: list[dict]) -> dict:
    counts: dict = {"blank": len(items)}
    for i in items:
        counts[i["result"]] = counts.get(i["result"], 0) + 1
    for i in items:
        if i["result"] == "MATCH":
            k = "match_%s_%s" % (i["tier"].lower(), i["confidence"].lower())
            counts[k] = counts.get(k, 0) + 1
    return counts


def fill(goose, items: list[dict], batch_id: int, journal: Path, chunk: int = 60) -> list[str]:
    """LIVE only. Write MATCH coordinates into blank SFDC_USF_Address rows; never overwrite.
    One transaction per chunk with OUTPUT readback. Returns the Goose Ids actually filled."""
    batch_id = int(batch_id)
    todo = [i for i in items if i["result"] == "MATCH"]
    for i in todo:
        if not (-90 <= float(i["lat"]) <= 90 and -180 <= float(i["lng"]) <= 180):
            raise ValueError("Coordinate out of range for Goose address %s" % i["goose_id"])
    journal.parent.mkdir(parents=True, exist_ok=True)
    filled: list[str] = []
    for n in range(0, len(todo), chunk):
        part = todo[n:n + chunk]
        with journal.open("a", encoding="utf-8") as f:   # evidence before the write
            f.write(json.dumps(dict(time=datetime.now().isoformat(), batch_id=batch_id, status="FILL_ATTEMPT",
                                    rows=[dict(goose_id=i["goose_id"], lat=i["lat"], lng=i["lng"]) for i in part])) + "\n")
        values = ",".join("(N'%s', %r, %r)" % (str(i["goose_id"]).replace("'", "''"), float(i["lat"]), float(i["lng"]))
                          for i in part)
        sql = ("SET XACT_ABORT ON; BEGIN TRANSACTION; DECLARE @Done TABLE (Id nvarchar(50)); "
               "UPDATE AD SET Address_Latitude_Longitude__Latitude__s = V.Lat, "
               "Address_Latitude_Longitude__Longitude__s = V.Lng "
               "OUTPUT CAST(inserted.Id AS nvarchar(50)) INTO @Done (Id) "
               "FROM dbo.SFDC_USF_Address AD JOIN (VALUES %s) V(Id, Lat, Lng) ON CAST(AD.Id AS nvarchar(50)) = V.Id "
               "WHERE AD.MigrationBatchID = %d AND AD.Address_Latitude_Longitude__Latitude__s IS NULL "
               "AND AD.Address_Latitude_Longitude__Longitude__s IS NULL; "
               "SELECT Id AS FilledId FROM @Done; COMMIT TRANSACTION;" % (values, batch_id))
        done = [str(r["FilledId"]) for s in goose.result_sets(sql) for r in s if "FilledId" in r]
        filled += done
        with journal.open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(time=datetime.now().isoformat(), batch_id=batch_id, status="FILLED",
                                    ids=done)) + "\n")
    return filled


def log_entries(items: list[dict], filled: set, step: str) -> list[dict]:
    """One GOOSE_ErrorLog entry per blank address: how MCC pushed it through."""
    from .fixlog import entry
    out = []
    for i in items:
        if str(i["goose_id"]) in filled:
            out.append(entry("MCC_FIXED", step, "SFDC_USF_Address", i["goose_id"],
                             "MCC FIX coordinates: blank -> %s,%s from %s (%s %s; %s)" % (
                                 i["lat"], i["lng"], i["source_ids"], i["tier"], i["confidence"], "mct07 rule"),
                             "USF_Address__c"))
        else:
            out.append(entry("MCC_PUSHED_THROUGH", step, "SFDC_USF_Address", i["goose_id"],
                             "MCC PUSH-THROUGH: loaded without coordinates (%s); no service territory expected"
                             % i["result"], "USF_Address__c"))
    return out


def write_report(items: list[dict], folder: Path) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    p = folder / ("coord_match_%s.csv" % datetime.now().strftime("%Y%m%d_%H%M%S"))
    with p.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, list(items[0].keys()) if items else ["goose_id"])
        w.writeheader()
        w.writerows(items)
    return p
