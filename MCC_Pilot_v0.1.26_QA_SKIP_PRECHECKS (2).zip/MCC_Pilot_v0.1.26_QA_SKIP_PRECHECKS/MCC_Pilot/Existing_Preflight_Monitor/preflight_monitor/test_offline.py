"""
Offline tests -- everything that does NOT need Salesforce or Goose.

Covers the logic most likely to be silently wrong: the evidence invariant, baseline
classification, fixture states, and the store round-trip. Run:  python test_offline.py
"""
from __future__ import annotations
import model
import dataclasses, os, sys, tempfile, traceback
from pathlib import Path

import baseline as bl
import registry
import runner
from model import (Check, Evidence, Metric, Result, PASS, FAIL, UNPROVEN, BLOCKER,
                   NORMAL, OUTLIER, FIRST_OF_KIND, REGRESSION)
from store import Store, new_run_id

FAILED = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILED.append(name)


class FakeConn:
    """Stands in for connections.Conn."""
    def __init__(self, rows=None, fields=None, goose_ok=True, raise_on_run=False):
        self.batch = "UMB-TEST"
        self.alias = "x"
        self.goose_server = "s"
        self.goose_db = "Goose"
        self.goose_ok = goose_ok
        self.sunrise_run = None
        self._rows = rows if rows is not None else []
        self._fields = fields if fields is not None else set()
        self.raise_on_run = raise_on_run

    def q(self, soql): return list(self._rows)
    def n(self, soql): return len(self._rows)
    def has_field(self, dotted): return dotted in self._fields
    def gq(self, sql): return []
    def gn(self, sql): return 0


def mk(run_fn, canary_fn=lambda c: 1, requires=(), finds=True, needs_goose=False):
    return Check(id="T.CHECK", name="t", stage="s", sequence=1, sobject="Contract",
                 severity=BLOCKER, rule="r", rule_source="src", proves="p",
                 cannot_prove="cp", run=run_fn, canary=canary_fn, requires=requires,
                 finds_problems=finds, needs_goose=needs_goose)


# ---------------------------------------------------------------- evidence invariant
def test_invariant():
    print("\nEVIDENCE INVARIANT")

    r = runner.run_check(mk(lambda c: Evidence(rows=[{"a": 1}])), FakeConn())
    check("rows>0 -> FAIL", r.verdict == FAIL, r.verdict)

    r = runner.run_check(mk(lambda c: Evidence(rows=[]), canary_fn=lambda c: 5), FakeConn())
    check("0 rows + canary found rows -> PASS", r.verdict == PASS, r.verdict)

    # THE important one: zero rows with a dead canary must NOT pass
    r = runner.run_check(mk(lambda c: Evidence(rows=[]), canary_fn=lambda c: 0), FakeConn())
    check("0 rows + canary found NOTHING -> UNPROVEN (not PASS)", r.verdict == UNPROVEN, r.verdict)
    check("  ...and says the scope is broken", "scope" in r.reason.lower(), r.reason)

    r = runner.run_check(mk(lambda c: Evidence(rows=[]), requires=("Contract.Nope__c",)),
                         FakeConn(fields=set()))
    check("missing required field -> UNPROVEN", r.verdict == UNPROVEN, r.verdict)
    check("  ...names the field", "Nope__c" in r.reason, r.reason)

    def boom(c): raise RuntimeError("kaboom")
    r = runner.run_check(mk(boom), FakeConn())
    check("check raises -> UNPROVEN, not crash", r.verdict == UNPROVEN, r.verdict)
    check("  ...captures the error", "kaboom" in r.reason, r.reason)

    r = runner.run_check(mk(lambda c: Evidence(rows=[]), needs_goose=True),
                         FakeConn(goose_ok=False))
    check("goose down -> UNPROVEN, not skipped", r.verdict == UNPROVEN, r.verdict)
    check("  ...says 'not skipped, not passed'", "not skipped" in r.reason.lower(), r.reason)

    r = runner.run_check(mk(lambda c: Evidence(rows=[]), canary_fn=lambda c: 1, finds=False),
                         FakeConn())
    check("healthy-population check, 0 rows -> FAIL", r.verdict == FAIL, r.verdict)

    r = runner.run_check(mk(lambda c: Evidence(rows=[{"a": 1}]), finds=False), FakeConn())
    check("healthy-population check, rows -> PASS", r.verdict == PASS, r.verdict)

    def dead_canary(c): raise RuntimeError("canary exploded")
    r = runner.run_check(mk(lambda c: Evidence(rows=[]), canary_fn=dead_canary), FakeConn())
    check("canary raises -> UNPROVEN", r.verdict == UNPROVEN, r.verdict)


# ---------------------------------------------------------------- baseline
def test_baseline():
    print("\nBASELINE")
    m = lambda v: Metric("x", v, "ratio", 0, 0)

    b = bl.compare(m(0.5), [("A", 0.5)])
    check("1 prior batch -> FIRST_OF_KIND", b.cls == FIRST_OF_KIND, b.cls)
    check("  ...refuses to invent a threshold", "no basis" in b.detail.lower(), b.detail)

    # the real case: 4.7% against 97.4% / 100% / 98.1%
    hist = [("UMB-0112", 0.981), ("UMB-0113", 0.974), ("UMB-0114", 1.0)]
    b = bl.compare(m(0.047), hist)
    check("4.7%% vs 97-100%% -> OUTLIER", b.cls == OUTLIER, "%s %s" % (b.cls, b.detail))
    check("  ...reports direction", "below" in b.detail, b.detail)

    b = bl.compare(m(0.979), hist)
    check("97.9%% vs same history -> NORMAL", b.cls == NORMAL, "%s %s" % (b.cls, b.detail))

    b = bl.compare(m(0.90), hist)
    check("90%% -> REGRESSION or OUTLIER, not NORMAL", b.cls in (REGRESSION, OUTLIER), b.cls)

    # identical history => sigma 0 => absolute tolerance
    b = bl.compare(m(0.80), [("A", 1.0), ("B", 1.0), ("C", 1.0)])
    check("flat history + drop -> OUTLIER", b.cls == OUTLIER, "%s %s" % (b.cls, b.detail))
    b = bl.compare(m(1.0), [("A", 1.0), ("B", 1.0), ("C", 1.0)])
    check("flat history + same -> NORMAL", b.cls == NORMAL, b.cls)

    b = bl.compare(m(1.0), hist)
    check("better-than-prior still flagged", b.cls in (OUTLIER, NORMAL, REGRESSION), b.cls)

    check("no metric -> no comparison", bl.compare(None, hist) is None)

    # count metrics (lower is better) -- finds_problems checks pass higher_is_better=False
    b = bl.compare(Metric("bad rows", 18, "count", 18, 0),
                   [("A", 0.0), ("B", 0.0), ("C", 0.0)], higher_is_better=False)
    check("18 bad rows vs history of 0 -> OUTLIER", b.cls == OUTLIER, "%s %s" % (b.cls, b.detail))


# ---------------------------------------------------------------- store
def test_store():
    print("\nSTORE")
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd); os.unlink(path)
    s = Store(path)
    try:
        s.upsert_batch("UMB-0113", "a", "1", "Complete", "Complete", 100)
        s.upsert_batch("UMB-0116", "b", "2", "Closed", "Canceled", 786)
        bs = {b["name"]: b for b in s.batches()}
        check("batches persisted", len(bs) == 2, list(bs))
        check("status agreement recorded", bs["UMB-0113"]["status_agrees"] == 1)
        check("status DISAGREEMENT recorded", bs["UMB-0116"]["status_agrees"] == 0,
              "SF Closed vs Goose Canceled must be flagged")

        for i, (b, v) in enumerate([("UMB-0112", .981), ("UMB-0113", .974), ("UMB-0114", 1.0)]):
            rid = "R%d" % i
            s.start_run(rid, b, "POPULATE", "0.1", "x", "s", True, "")
            s.save_result(rid, Result(check_id="BIQ.COVERAGE", batch=b, verdict=PASS,
                                      metric=Metric("BIQ coverage", v, "ratio", 1, 1),
                                      evidence_count=0, ran_at="2026-10-0%d" % (i + 1)))
            s.finish_run(rid)
        hist = s.metric_history("BIQ.COVERAGE")
        check("metric history returns all batches", len(hist) == 3, hist)
        check("exclude_batch works", len(s.metric_history("BIQ.COVERAGE", "UMB-0114")) == 2)

        rid = "R9"
        s.start_run(rid, "UMB-0116", "GATE", "0.1", "x", "s", True, "")
        s.save_result(rid, Result(check_id="BIQ.COVERAGE", batch="UMB-0116", verdict=FAIL,
                                  evidence_count=750,
                                  evidence_sample=[{"ContractNumber": "C%d" % i} for i in range(400)],
                                  metric=Metric("BIQ coverage", .047, "ratio", 36, 786)))
        s.finish_run(rid)
        ev = s.db.execute("SELECT COUNT(*) c FROM evidence WHERE run_id=?", (rid,)).fetchone()["c"]
        # 400 sample rows now ALL survive: the cap is 2000, so "show me the records that
        # failed" is answerable. The exact count (750) is stored separately regardless.
        check("evidence retained up to the cap, not truncated at 200", ev == 400, ev)
        res = s.results_for_run(rid)[0]
        check("  ...and the exact count is kept alongside it", res["evidence_count"] == 750,
              str(res["evidence_count"]))
        check("latest_run_id finds it", s.latest_run_id("UMB-0116") == rid)

        s.upsert_fixture("BIQ.COVERAGE", "UMB-0116", 750, "PRESENT", "proven")
        res = [Result(check_id="BIQ.COVERAGE", batch="UMB-0116", verdict=FAIL, evidence_count=750)]
        out = runner.check_fixtures(s, "UMB-0116", res)
        check("fixture still present", out[0]["state"] == "PRESENT", out)

        res = [Result(check_id="BIQ.COVERAGE", batch="UMB-0116", verdict=PASS, evidence_count=0)]
        out = runner.check_fixtures(s, "UMB-0116", res)
        check("fixture gone -> FIXED_OR_BROKEN (never auto-resolved)",
              out[0]["state"] == "FIXED_OR_BROKEN", out)
        check("  ...refuses to guess", "will not guess" in out[0]["message"], out[0]["message"])

        res = [Result(check_id="BIQ.COVERAGE", batch="UMB-0116", verdict=FAIL, evidence_count=700)]
        out = runner.check_fixtures(s, "UMB-0116", res)
        check("fixture changed -> CHANGED with delta", out[0]["state"] == "CHANGED"
              and "-50" in out[0]["message"], out[0]["message"])

        for r in registry.rules():
            s.register_rule(r)
        con = s.contradictions()
        fields = {(c["sobject"], c["field"]) for c in con}
        check("LastBillingDate contradiction detected",
              ("Contract", "LastBillingDate__c") in fields, fields)
        check("FSC Effective Date contradiction detected",
              ("Billing_Impacts_Queue__c", "Effective_Date__c") in fields, fields)
    finally:
        s.close()
        try: os.unlink(path)
        except OSError: pass


# ---------------------------------------------------------------- registry
def test_registry():
    print("\nREGISTRY")
    errs = registry.validate()
    check("all registered checks valid", not errs, errs)
    ids = [c.id for c in registry.all_checks()]
    check("ids unique", len(ids) == len(set(ids)))
    check("every check declares rule_source",
          all(c.rule_source.strip() for c in registry.all_checks()))
    check("every check declares cannot_prove",
          all(c.cannot_prove.strip() for c in registry.all_checks()))
    check("every problem-finding check has a canary",
          all(c.canary for c in registry.all_checks() if c.finds_problems))
    check("spine has 20 objects", len(registry.spine()) == 20, len(registry.spine()))

    bad = Check(id="", name="", stage="", sequence=0, sobject="", severity="NOPE",
                rule="", rule_source="", proves="", cannot_prove="", run=lambda c: None)
    check("malformed check is rejected", len(bad.validate()) >= 5, bad.validate())


def test_coverage():
    print("\nCOVERAGE AUDIT")
    cov = runner.coverage_audit(registry.all_checks(), registry.spine())
    gaps = [c for c in cov if c["gap"]]
    check("audit returns one row per spine object", len(cov) == 20, len(cov))
    check("audit reports gaps (it should -- we don't cover all 20)", len(gaps) > 0, len(gaps))
    print("       %d of 20 objects currently have no check: %s"
          % (len(gaps), ", ".join(g["sobject"] for g in gaps[:8])))


def test_summary():
    print("\nVERDICT SUMMARY")
    rs = [Result(check_id="a", batch="b", verdict=FAIL),
          Result(check_id="b", batch="b", verdict=UNPROVEN),
          Result(check_id="c", batch="b", verdict=PASS)]
    s = runner.verdict_summary(rs)
    check("counts correct", s["failed"] == 1 and s["unproven"] == 1 and s["passed"] == 1, s)
    check("no single score key", "score" not in s and "health" not in s, list(s))


# ---------------------------------------------------------------- predictive
def _meta():
    """A synthetic target schema with the real failure shapes from the 2026-09-18 baseline."""
    def f(**kw):
        d = dict(name="", type="string", length=255, digits=0, precision=0, scale=0,
                 createable=True, updateable=True, nillable=True, defaulted=False,
                 restricted=False, calculated=False, picklist=set(), reference_to=[])
        d.update(kw); return d
    return {
        "Name": f(name="Name", type="string", length=80, nillable=False),
        "SBQQ__SubscriptionType__c": f(name="SBQQ__SubscriptionType__c", type="picklist",
                                       restricted=True, picklist={"Renewable", "Evergreen"}),
        "PO_Number_Conga__c": f(name="PO_Number_Conga__c", createable=False),
        "Total__c": f(name="Total__c", type="currency"),
        "Active__c": f(name="Active__c", type="boolean"),
        "StartDate": f(name="StartDate", type="date"),
        "AccountId": f(name="AccountId", type="reference", reference_to=["Account"]),
        "Margin__c": f(name="Margin__c", type="double", calculated=True),
        "Short__c": f(name="Short__c", type="string", length=5),
    }


def test_predict():
    print("\nPREDICTIVE LOAD VALIDATION")
    import predict as pr
    m = _meta()

    ok = pr.validate_record(m, {"Name": "Acme", "SBQQ__SubscriptionType__c": "Renewable",
                                "Total__c": "12.50", "Active__c": "true",
                                "StartDate": "2026-01-01",
                                "AccountId": "001VD00000swsKH"}, "CREATE")
    check("a clean record predicts no failures", ok == [], ok)

    def types(iss): return {i["type"] for i in iss}

    i = pr.validate_record(m, {"Name": "x", "SBQQ__SubscriptionType__c": "One-Time"}, "CREATE")
    check("inactive picklist value caught", "RESTRICTED_PICKLIST" in types(i), types(i))
    check("  ...names the active values",
          any("Renewable" in x["message"] for x in i if x["type"] == "RESTRICTED_PICKLIST"))

    i = pr.validate_record(m, {"Name": "x", "PO_Number_Conga__c": "PO-1"}, "CREATE")
    check("non-createable field caught", "FIELD_NOT_CREATEABLE" in types(i), types(i))

    i = pr.validate_record(m, {"Name": "x", "Margin__c": "5"}, "CREATE")
    check("formula field caught", "FIELD_CALCULATED" in types(i), types(i))

    i = pr.validate_record(m, {"Name": "x", "Nope__c": "v"}, "CREATE")
    check("unknown field caught", "FIELD_NOT_FOUND" in types(i), types(i))

    i = pr.validate_record(m, {"Name": "x", "Short__c": "way too long"}, "CREATE")
    check("over-length value caught", "VALUE_TOO_LONG" in types(i), types(i))

    i = pr.validate_record(m, {"Name": "x", "Total__c": "abc"}, "CREATE")
    check("non-numeric in currency caught", "NOT_NUMERIC" in types(i), types(i))

    i = pr.validate_record(m, {"Name": "x", "StartDate": "01/02/2026"}, "CREATE")
    check("non-ISO date caught", "BAD_DATE" in types(i), types(i))

    i = pr.validate_record(m, {"Name": "x", "AccountId": "nope"}, "CREATE")
    check("bad lookup Id caught", "BAD_REFERENCE_ID" in types(i), types(i))

    i = pr.validate_record(m, {"SBQQ__SubscriptionType__c": "Renewable"}, "CREATE")
    check("missing required field caught", "REQUIRED_FIELD_MISSING" in types(i), types(i))

    i = pr.validate_record(m, {"Name": "x", "PO_Number_Conga__c": "PO-1"}, "UPDATE")
    check("createable-only rule not applied on UPDATE",
          "FIELD_NOT_CREATEABLE" not in types(i), types(i))

    # the pattern rollup -- the whole point
    recs = [{"Name": "n%d" % k, "SBQQ__SubscriptionType__c": "One-Time"} for k in range(610)]
    recs += [{"Name": "ok%d" % k, "SBQQ__SubscriptionType__c": "Renewable"} for k in range(90)]
    res = pr.predict_batch(_meta(), recs, "CREATE")
    check("blocked count correct", res["records_blocked"] == 610, res["records_blocked"])
    check("rolls up to ONE pattern", len(res["patterns"]) == 1, res["patterns"])
    check("pattern flagged as a single-value fix", res["patterns"][0]["single_value_fix"] is True)
    check("headline says one decision clears it",
          "SINGLE VALUE" in res["headline"], res["headline"])
    print("       %s" % res["headline"])

    check("required_fields finds the non-nillable one",
          pr.required_fields(_meta()) == ["Name"], pr.required_fields(_meta()))


def test_sf_count_shapes():
    """
    SELECT COUNT() is an AGGREGATE query -- Salesforce returns totalSize with an EMPTY
    records array. Reading records[0] returns 0 for every count in the tool, which turns
    every canary into "found nothing" and every clean check into UNPROVEN. This broke the
    first live run; it must not regress.
    """
    print("\nSALESFORCE COUNT SHAPES")
    import connections as cx
    orig = cx.sf_query_raw
    try:
        for label, result, want in (
            ("SELECT COUNT()  (empty records, totalSize)",
             {"totalSize": 114, "records": []}, 114),
            ("SELECT COUNT(Id) c  (aggregate row)",
             {"totalSize": 1, "records": [{"attributes": {}, "c": 786}]}, 786),
            ("plain SELECT  (real rows)",
             {"totalSize": 2, "records": [{"attributes": {}, "Id": "a"},
                                          {"attributes": {}, "Id": "b"}]}, 2),
            ("genuinely zero",
             {"totalSize": 0, "records": []}, 0),
        ):
            cx.sf_query_raw = lambda a, q, t=180, _r=result: _r
            got = cx.sf_count("x", "SELECT COUNT() FROM Y")
            check("%s -> %s" % (label, want), got == want, "got %s" % got)
    finally:
        cx.sf_query_raw = orig


def test_remediation_required():
    print("\nREMEDIATION")
    import registry
    bad = [c.id for c in registry.all_checks()
           if c.finds_problems and c.remediation is None]
    check("every FAIL-capable check carries a fix", not bad, bad)
    noorder = [c.id for c in registry.all_checks()
               if c.remediation and c.remediation.runbook_order is None]
    check("remediation names a run book step (or is explicitly manual)",
          len(noorder) == 0, noorder)
    writes = [c.id for c in registry.all_checks()
              if c.remediation and c.remediation.writes and not c.remediation.approval]
    check("every WRITING fix names who approves", not writes, writes)



# ============================================================ the UMB-0117 regressions
class ScriptedConn(FakeConn):
    """
    A conn that answers specific queries, so a check's SOQL is tested rather than mocked
    away. `routes` is a list of (substring, result); first match wins.
    """
    def __init__(self, routes, fields=None, **kw):
        super().__init__(**kw)
        self.routes = routes
        self.fields = set(fields or ())
        self.asked = []
        self.jobs_by_label = {}

    def _route(self, sql):
        self.asked.append(" ".join(str(sql).split()))
        for frag, res in self.routes:
            if frag.lower() in " ".join(str(sql).split()).lower():
                if isinstance(res, Exception):
                    raise res
                return res
        return None

    def q(self, sql):
        r = self._route(sql)
        return r if isinstance(r, list) else []

    def n(self, sql):
        r = self._route(sql)
        return int(r) if isinstance(r, (int, float)) else 0

    def has_field(self, dotted): return dotted in self.fields
    def job_run(self, label): return self.jobs_by_label.get(label)


def test_blind_spot_window():
    """
    THE false positive: an org-wide 'WHERE Contract__c = null' in a sandbox returns the
    sandbox's ordinary business records, and the tool reported 22,027 of them as a
    blocking migration blind spot on UMB-0117.
    """
    print("\nBLIND SPOT -- org-wide vs this batch's window")
    import checks

    # 22,027 org-wide, but NONE written while this batch ran -> not a finding
    c = ScriptedConn([
        ("count(id) c, min(createddate) mn, max(createddate) mx from sbqq__quote__c",
         [{"c": 906, "mn": "2026-09-30T08:00:00.000+0000", "mx": "2026-09-30T19:00:00.000+0000"}]),
        ("createddate >=", 0),                       # windowed count -- must be asked FIRST
        ("from workorder where contract__c = null", 22027),
    ])
    ev = checks._blind(c, "WorkOrder", "Contract__c = null", "WorkOrders with no Contract")
    check("org-wide 22,027 with none in-window -> NO rows (not a blocker)",
          ev.count == 0, "rows=%d" % ev.count)
    check("  ...but the org-wide number is still reported as context",
          "22027" in ev.note, ev.note[:120])
    check("  ...and the note says it is NOT a finding",
          "not a finding" in ev.note.lower(), ev.note[:160])
    check("  ...and names the window it used", "2026-09-29" in ev.note or "09-29" in ev.note,
          ev.note[:200])

    # genuine blind spot: records WERE written in-window with a null link
    c2 = ScriptedConn([
        ("count(id) c, min(createddate) mn, max(createddate) mx from sbqq__quote__c",
         [{"c": 906, "mn": "2026-09-30T08:00:00.000+0000", "mx": "2026-09-30T19:00:00.000+0000"}]),
        ("createddate >=", 31),
        ("from workorder where contract__c = null", 22027),
    ])
    ev2 = checks._blind(c2, "WorkOrder", "Contract__c = null", "WorkOrders with no Contract")
    check("31 written in-window -> IS a finding", ev2.count >= 1, "rows=%d" % ev2.count)
    check("  ...reports the in-window count, not the org-wide one",
          ev2.metric.value == 31.0, str(ev2.metric.value))
    check("  ...keeps org-wide separately for context",
          ev2.rows[0].get("org_wide") == 22027, str(ev2.rows[0]))

    # The real records, not a one-row summary. A summary row made evidence_count 1 while
    # the note said 11 -- so an 11-record finding displayed as "1 error" with no Ids.
    c2b = ScriptedConn([
        ("count(id) c, min(createddate) mn, max(createddate) mx from sbqq__quote__c",
         [{"c": 906, "mn": "2026-10-01T08:00:00.000+0000", "mx": "2026-10-03T19:00:00.000+0000"}]),
        ("select id, createddate from contract",
         [{"Id": "800VD0000%02d" % i, "CreatedDate": "2026-10-02T10:00:00.000+0000"}
          for i in range(11)]),
        ("createddate >=", 11),
        ("from contract where uss_migration_batch__c = null", 414),
    ])
    ev2b = checks._blind(c2b, "Contract",
                         "USS_Migration_Batch__c = null AND Status = 'Activated'", "x")
    check("an 11-record finding reports ELEVEN errors, not one summary row",
          ev2b.count == 11, "count=%d" % ev2b.count)
    check("  ...and hands over the actual record Ids",
          ev2b.rows[0].get("Id", "").startswith("800VD"), str(ev2b.rows[0])[:90])
    check("  ...while 'examined' stays the org-wide population", ev2b.processed == 414,
          str(ev2b.processed))

    # no window derivable -> UNPROVEN, never a 22,027-row blocker
    c3 = ScriptedConn([
        ("from sbqq__quote__c", []),
        ("from uss_migration_batch__c", []),
        ("from workorder where contract__c = null", 22027),
    ])
    ev3 = checks._blind(c3, "WorkOrder", "Contract__c = null", "x")
    check("no derivable window -> UNPROVEN, not a blocker", bool(ev3.unprovable), ev3.unprovable[:90])
    check("  ...and refuses to call business records a blind spot",
          "blind spot" in ev3.unprovable.lower(), ev3.unprovable[:140])


def test_account_scoping():
    """
    PL_07/PL_10 scoped through Account.USS_Migration_Batch__c, which is null on every
    Account in an acquisition onboarding -- so the count was always 0 and the tool
    reported 'PL_07 produced NOTHING' on a batch where PL_07 was fine.
    """
    print("\nACCOUNT SCOPING -- PL_07 / PL_10")
    import checks
    by_id = {c.id: c for c in registry.all_checks()}
    sql = {i: s for _ro, i, _l, _o, s, _j in checks.STEP_OUTPUTS}

    for cid in ("RAN.PL_07_ACCOUNTS", "RAN.PL_07_CONTACTS", "RAN.PL_10_ACR"):
        q = sql[cid]
        check("%s no longer scopes through Account.USS_Migration_Batch__r" % cid,
              "account.uss_migration_batch__r" not in q.lower(), q)
        check("  ...scopes through the batch's Quotes instead",
              "sbqq__quote__c" in q.lower() and "uss_migration_batch__r.name" in q.lower(), q)
        check("  ...and is still registered", cid in by_id)


def test_job_timing():
    print("\nJOB RUN TIMES")
    import checks, jobruns

    q = "SELECT COUNT() FROM Contract WHERE USS_Migration_Batch__r.Name = '{B}' AND Status = 'Activated'"

    # the orchestrator's own record wins
    c = ScriptedConn([("count(id) c, min(createddate)",
                       [{"c": 786, "mn": "2026-10-01T14:10:00.000+0000",
                         "mx": "2026-10-01T14:49:00.000+0000",
                         "lm": "2026-10-01T14:49:00.000+0000"}])])
    c.jobs_by_label["Informatica TF_35 Activate FSL Order"] = dict(
        system="Informatica", job="TF_35", tokens={"TF_35"}, status="SUCCESS", succeeded=True,
        started="2026-10-01T14:05:11Z", ended="2026-10-01T14:52:40Z", run_id="9", source="r.json")
    ev = checks._made("TF_35 produced Activated Contracts", q,
                      "Informatica TF_35 Activate FSL Order")(c)
    check("produced 786 -> no error rows", ev.count == 0, str(ev.rows))
    check("  ...processed carries the record count", ev.processed == 786, str(ev.processed))
    check("  ...uses the API window, not record stamps",
          ev.ran_from == "2026-10-01T14:05:11Z" and "API" in ev.run_source, ev.run_source)
    check("  ...reports the orchestrator status", ev.run_status == "SUCCESS", ev.run_status)

    # API says SUCCESS but nothing was produced -- ran against the wrong batch
    c2 = ScriptedConn([("count(id) c, min(createddate)", [{"c": 0, "mn": "", "mx": "", "lm": ""}])])
    c2.jobs_by_label["Informatica TF_35 Activate FSL Order"] = dict(
        system="Informatica", job="TF_35", tokens={"TF_35"}, status="SUCCESS", succeeded=True,
        started="2026-10-01T14:05:11Z", ended="2026-10-01T14:52:40Z", run_id="9", source="r.json")
    ev2 = checks._made("x", q, "Informatica TF_35 Activate FSL Order")(c2)
    check("0 produced but API says SUCCESS -> flagged", ev2.count == 1, str(ev2.rows))
    check("  ...and says it ran against a different batch",
          "different batch" in ev2.note.lower(), ev2.note[:150])

    # API says FAILED while records exist -- the worst case
    c3 = ScriptedConn([("count(id) c, min(createddate)",
                        [{"c": 400, "mn": "2026-10-01T14:10:00.000+0000",
                          "mx": "2026-10-01T14:20:00.000+0000", "lm": ""}])])
    c3.jobs_by_label["Informatica TF_35 Activate FSL Order"] = dict(
        system="Informatica", job="TF_35", tokens={"TF_35"}, status="FAILED", succeeded=False,
        started="2026-10-01T14:05:11Z", ended="2026-10-01T14:20:40Z", run_id="9", source="r.json")
    ev3 = checks._made("x", q, "Informatica TF_35 Activate FSL Order")(c3)
    check("FAILED job with partial output -> flagged", ev3.count == 1, str(ev3.rows))
    check("  ...calls partial output the worst case",
          "worst case" in ev3.note.lower(), ev3.note[:150])

    # no API record -> record stamps, labelled as a proxy
    c4 = ScriptedConn([("count(id) c, min(createddate)",
                        [{"c": 786, "mn": "2026-10-01T14:10:00.000+0000",
                          "mx": "2026-10-01T14:49:00.000+0000", "lm": ""}])])
    ev4 = checks._made("x", q, "Informatica TF_35 Activate FSL Order")(c4)
    check("no API record -> falls back to record stamps",
          ev4.ran_from.startswith("2026-10-01T14:10"), ev4.ran_from)
    check("  ...and says stamps are NOT the job clock",
          "not the job clock" in ev4.run_source.lower(), ev4.run_source)

    # aggregate rewrite + the COUNT() trap
    w = jobruns.window_from_stamps(c4, q.replace("{B}", "UMB-TEST"))
    check("COUNT() is rewritten to an ALIASED aggregate (empty-records trap)",
          any("count(id) c" in a.lower() for a in c4.asked), str(c4.asked[-1])[:90])
    check("  ...and returns the count from the aggregate row", w["count"] == 786, str(w["count"]))

    # token matching, incl. the sub-step -> parent fallback
    h = jobruns.JobHistory("")
    h.runs = [dict(system="Informatica", job="TF_60", tokens=jobruns.tokens("TF_60"),
                   status="SUCCESS", succeeded=True, started="a", ended="b", run_id="1",
                   source="s")]
    check("sub-step TF_60.04b falls back to its parent taskflow TF_60",
          (h.find("TF_60.04b_Compare_EffectiveDate_Rules") or {}).get("job") == "TF_60")
    check("an unrelated step does NOT match", h.find("TF_15_OpportunitiesToQuotes") is None)
    check("a step with no token matches nothing", h.find("All systems") is None)


def test_processed_vs_errors():
    print("\nEXAMINED vs ERRORS")
    ev = Evidence(rows=[{"a": 1}] * 447, metric=Metric("r", 0.5, "ratio", 459, 906))
    check("errors = offending rows", ev.count == 447, str(ev.count))
    check("examined falls back to the metric denominator", ev.examined == 906, str(ev.examined))
    r = runner.run_check(mk(lambda c: ev), FakeConn())
    check("runner carries BOTH numbers", r.evidence_count == 447 and r.processed == 906,
          "%s/%s" % (r.evidence_count, r.processed))

    # a presence check that found nothing must not report "0 row(s)"
    r2 = runner.run_check(mk(lambda c: Evidence(rows=[]), finds=False), FakeConn())
    check("presence check with no population -> FAIL", r2.verdict == FAIL, r2.verdict)
    check("  ...and says empty IS the failure", "empty is the failure" in r2.reason.lower(),
          r2.reason)

    # unprovable still keeps what it established
    r3 = runner.run_check(mk(lambda c: Evidence(processed=22027, unprovable="no window")),
                          FakeConn())
    check("UNPROVEN still reports what it examined", r3.processed == 22027, str(r3.processed))


def test_store_migration():
    print("\nSTORE MIGRATION")
    import sqlite3
    pth = tempfile.mktemp(suffix=".db")
    # a pre-0.7 database: result table WITHOUT the new columns
    old = sqlite3.connect(pth)
    old.execute("""CREATE TABLE result(run_id TEXT, check_id TEXT, batch TEXT, verdict TEXT,
                   reason TEXT, evidence_count INTEGER, metric_name TEXT, metric_value REAL,
                   metric_unit TEXT, metric_num INTEGER, metric_den INTEGER,
                   baseline_class TEXT, baseline_detail TEXT, duration_ms INTEGER, ran_at TEXT,
                   PRIMARY KEY(run_id, check_id))""")
    old.commit(); old.close()

    st = Store(pth)
    cols = {r["name"] for r in st.db.execute("PRAGMA table_info(result)").fetchall()}
    for c in ("processed", "ran_from", "ran_to", "run_status", "run_source"):
        check("existing DB gains '%s'" % c, c in cols)
    rid = new_run_id()
    st.start_run(rid, "B", "GATE", "0.7.0", "a", "", False, "")
    st.save_result(rid, Result(check_id="C", batch="B", verdict=FAIL, evidence_count=5,
                               processed=99, ran_from="x", run_status="SUCCESS"))
    st.finish_run(rid)
    row = st.results_for_run(rid)[0]
    check("  ...and round-trips the new fields",
          row["processed"] == 99 and row["run_status"] == "SUCCESS", dict(row).__str__()[:120])
    st.close(); os.unlink(pth)


def test_runbook_columns():
    print("\nRUN BOOK COLUMNS")
    import runbook as rbk, server
    check("the UI has the run book's ten columns in order",
          [h for h, _ in server.HEADS] ==
          ["Run Order", "Stage", "Action", "Step", "Script Purpose", "Status",
           "Record Count / Result", "Time", "Verification Method", "Next Action / What's in the way"],
          str([h for h, _ in server.HEADS]))
    need = {"order", "stage", "action", "step", "purpose", "verify", "blocker"}
    missing = [s["order"] for s in rbk.steps() if not need <= set(s)]
    check("every run book step carries all ten columns' source data", not missing, str(missing[:5]))

    pth = tempfile.mktemp(suffix=".db")
    st = Store(pth)
    rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.7.0", "a", "", False, "")
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="UMB-0117", verdict=FAIL,
                               reason="447 of 906", evidence_count=447, processed=906,
                               metric=Metric("Orders Activated", 0.506, "ratio", 459, 906)))
    st.save_result(rid, Result(check_id="RAN.TF_35_CONTRACTS", batch="UMB-0117", verdict=PASS,
                               reason="786", evidence_count=0, processed=786,
                               ran_from="2026-10-01T14:05:11Z", ran_to="2026-10-01T14:52:40Z",
                               run_status="SUCCESS", run_source="Informatica API"))
    st.finish_run(rid)
    rows = {r["order"]: r for r in rbk.readiness(st, "UMB-0117")}
    check("examined and errors are separate on the step", 
          rows[16]["examined"] == 906 and rows[16]["errors"] == 447,
          "%s/%s" % (rows[16]["examined"], rows[16]["errors"]))
    check("the Time column gets the job's run window",
          rows[19]["times"] and rows[19]["times"][0]["status"] == "SUCCESS",
          str(rows[19]["times"]))
    s = rbk.summary(rbk.readiness(st, "UMB-0117"))
    check("summary totals errors and counts the steps carrying them",
          s["errors_total"] == 447 and s["steps_with_errors"] >= 1,
          "%s/%s" % (s["errors_total"], s["steps_with_errors"]))
    check("  ...and does NOT sum examined across steps (the same records recur)",
          "examined_total" not in s and s["examined_max"] == 906, str(s.get("examined_max")))
    html = server.table(st, "UMB-0117")
    check("the rendered page labels examined and failing",
          "examined" in html and "failing" in html)
    check("  ...and never calls either of them 'Records'",
          ">Records<" not in html)
    st.close(); os.unlink(pth)



def _jobsite_row(**over):
    r = {"Id": "a1", "Name": "JS-1", "NF_Quote__c": "q1", "NF_Quote__r.Name": "Q-1",
         "NF_Site_Name__c": "ACME Yard", "NF_Site_Complete__c": True, "NF_Site_Contact__c": "c1",
         "NF_USF_Address__c": "ad1", "NF_USF_Address__r.Name": "A1",
         "NF_USF_Address__r.Site_Name__c": "ACME Yard",
         "NF_USF_Address__r.Address_Validated__c": True,
         "NF_USF_Address__r.NF_Order_Ready__c": True,
         "NF_USF_Address__r.NF_Site_Contact__c": "c1",
         "NF_USF_Address__r.Address_Latitude_Longitude__Latitude__s": 39.7,
         "NF_USF_Address__r.Address_Latitude_Longitude__Longitude__s": -104.9,
         "NF_Quote__r.Business_Type__c": "Construction",
         "NF_Quote__r.Billing_Period__c": "28 Day Bill Period",
         "NF_Quote__r.Bill_Timing__c": "In Advance",
         "NF_Quote__r.SBQQ__PaymentTerms__c": "Net 30"}
    r.update(over); return r


def test_jobsite_readiness():
    """
    The six findings Santhosh hit by hand on Order 800VD00000grfWLYAY, 2026-10-01.
    Every one of them was invisible to this tool until now -- RO 15 had NO check at all.
    """
    print("\nJOBSITE ORDER READINESS (Run Order 15)")
    import checks as ck

    def run(cid, rows):
        c = ScriptedConn([("from nf_quoted_jobsite__c", rows),
                          ("from sbqq__quote__c", rows)])
        c._jobsite_rows = None
        return registry.by_id(cid).run(c)

    good = [_jobsite_row(), _jobsite_row(Id="a2")]

    # clean batch -> nothing found
    for cid in ("JOBSITE.NO_GEOCODE", "JOBSITE.ADDRESS_NOT_VALIDATED",
                "JOBSITE.NOT_ORDER_READY", "JOBSITE.SITE_NAME_MISSING",
                "JOBSITE.NO_SITE_CONTACT"):
        ev = run(cid, list(good))
        check("%s clean -> no rows" % cid, ev.count == 0, "%d %s" % (ev.count, ev.rows[:1]))
        check("  ...and reports what it examined", ev.processed == 2, str(ev.processed))

    # each defect caught, one at a time
    cases = [
      ("JOBSITE.NO_GEOCODE",
       _jobsite_row(Id="bad", **{"NF_USF_Address__r.Address_Latitude_Longitude__Latitude__s": None}),
       "never geocoded"),
      ("JOBSITE.NO_GEOCODE", _jobsite_row(Id="bad", NF_USF_Address__c=None), "NO address"),
      ("JOBSITE.ADDRESS_NOT_VALIDATED",
       _jobsite_row(Id="bad", **{"NF_USF_Address__r.Address_Validated__c": False}), "never validated"),
      ("JOBSITE.NOT_ORDER_READY",
       _jobsite_row(Id="bad", **{"NF_USF_Address__r.NF_Order_Ready__c": False}), "not true"),
      ("JOBSITE.SITE_NAME_MISSING",
       _jobsite_row(Id="bad", NF_Site_Name__c=None, **{"NF_USF_Address__r.Site_Name__c": None}),
       "blank"),
      ("JOBSITE.NO_SITE_CONTACT",
       _jobsite_row(Id="bad", NF_Site_Contact__c=None,
                    **{"NF_USF_Address__r.NF_Site_Contact__c": None}), "contact"),
    ]
    for cid, bad_row, needle in cases:
        ev = run(cid, [_jobsite_row(), bad_row])
        check("%s catches: %s" % (cid, needle), ev.count == 1, "%d rows" % ev.count)
        check("  ...names the jobsite and its quote",
              ev.rows and ev.rows[0].get("quote") == "Q-1", str(ev.rows[:1]))

    # empty population -> UNPROVEN, never a clean pass
    ev = run("JOBSITE.NO_GEOCODE", [])
    check("no jobsites reach the batch -> UNPROVEN (not a clean zero)", bool(ev.unprovable),
          ev.unprovable[:80])

    # quote-side checks
    qc = ScriptedConn([("from sbqq__quote__c",
                        [{"Id": "q1", "Name": "Q-1", "Business_Type__c": None,
                          "SBQQ__Account__r.Name": "ACME"},
                         {"Id": "q2", "Name": "Q-2", "Business_Type__c": "Construction",
                          "SBQQ__Account__r.Name": "ACME"}])])
    ev = registry.by_id("QUOTE.BUSINESS_TYPE_MISSING").run(qc)
    check("QUOTE.BUSINESS_TYPE_MISSING catches the blank one", ev.count == 1, str(ev.rows))
    check("  ...and calls it a MAPPING gap, not missing source data",
          "mapping" in ev.note.lower(), ev.note[:120])

    bc = ScriptedConn([("from sbqq__quote__c",
                        [{"Id": "q1", "Name": "Q-1", "Billing_Period__c": None,
                          "Bill_Timing__c": "In Advance", "SBQQ__PaymentTerms__c": "Net 30",
                          "SBQQ__Account__r.Name": "ACME"},
                         {"Id": "q2", "Name": "Q-2", "Billing_Period__c": "28 Day Bill Period",
                          "Bill_Timing__c": "In Advance", "SBQQ__PaymentTerms__c": "Net 30",
                          "SBQQ__Account__r.Name": "ACME"}])])
    ev = registry.by_id("QUOTE.BILLING_CONFIG_INCOMPLETE").run(bc)
    check("QUOTE.BILLING_CONFIG_INCOMPLETE catches a partial set", ev.count == 1, str(ev.rows))
    check("  ...and names WHICH field is blank",
          "Billing_Period__c" in str(ev.rows[0]["issue"]), str(ev.rows[0]))

    # these must gate CONVERSION, not report after it
    for cid in ("JOBSITE.NO_GEOCODE", "JOBSITE.ADDRESS_NOT_VALIDATED", "QUOTE.BUSINESS_TYPE_MISSING"):
        c = registry.by_id(cid)
        check("%s runs BEFORE TF_30 converts (RO 15 < RO 17)" % cid, c.runbook_order == 15)
        check("  ...and blocks RO 17", 17 in (c.blocks or ()), str(c.blocks))


def test_workorder_bundle_flags():
    print("\nWORKORDER BUNDLE FLAGS (CJ, 2026-10-02)")
    import checks as ck

    class DescConn(FakeConn):
        def __init__(self, visible): super().__init__(); self.visible = visible
        def fields(self, obj): return set(self.visible)

    # a REAL describe that simply lacks the four -- not an empty one. An empty describe
    # means the describe itself failed, and the check reports UNPROVEN for that, correctly.
    REAL = ["id", "status", "contract__c", "workordernumber", "serviceterritoryid"]
    ev = ck._workorder_bundle_flags(DescConn(REAL))
    check("all four invisible -> all four reported", ev.count == 4, str(ev.count))
    check("  ...names every one", all(f in str(ev.rows) for f in ck.BUNDLE_FLAGS))
    check("  ...refuses to guess absent vs FLS",
          "absent" in ev.note.lower() and "hidden" in ev.note.lower(), ev.note[:140])
    check("  ...and says a describe cannot separate them",
          "cannot" in ev.note.lower(), ev.note[:160])

    ev = ck._workorder_bundle_flags(DescConn(REAL + [f.lower() for f in ck.BUNDLE_FLAGS]))
    check("all four visible -> nothing reported", ev.count == 0, str(ev.rows))

    ev = ck._workorder_bundle_flags(DescConn(REAL + ["is_power__c", "is_storage__c"]))
    check("partial visibility -> only the missing two", ev.count == 2, str(ev.count))

    ev = ck._workorder_bundle_flags(DescConn([]))
    check("an EMPTY describe is UNPROVEN, not 'all four missing'", bool(ev.unprovable),
          ev.unprovable[:80])

    c = registry.by_id("SCHEMA.WORKORDER_BUNDLE_FLAGS")
    check("runs at the PRE-FLIGHT (RO 2), before anything writes", c.runbook_order == 2)
    check("  ...and blocks the steps that create Work Orders",
          {19, 30} <= set(c.blocks or ()), str(c.blocks))
    rem = " ".join(c.remediation.steps)
    check("  ...remediation hands over Apex that SETTLES it",
          "isAccessible" in rem and "NOT IN THIS ORG" in rem)
    check("  ...and distinguishes a deployment gap from a permission gap",
          "DEPLOYMENT gap" in rem and "FLS" in rem)


def test_cj_issue_coverage():
    """The eight issues from the 2026-10-02 thread. One was covered before; seven are new."""
    print("\nCOVERAGE OF THE 2026-10-02 THREAD")
    ids = {c.id for c in registry.all_checks()}
    for issue, cid in [
        ("1 PricebookEntryId on conversion",      "QUOTE.MISSING_PRICEBOOK_ENTRY"),
        ("2 WorkOrder bundle flags inaccessible", "SCHEMA.WORKORDER_BUNDLE_FLAGS"),
        ("3 Business Type blank",                 "QUOTE.BUSINESS_TYPE_MISSING"),
        ("4 Jobsite not Order Ready",             "JOBSITE.NOT_ORDER_READY"),
        ("5 Site Name blank",                     "JOBSITE.SITE_NAME_MISSING"),
        ("6 address never Google-validated",      "JOBSITE.ADDRESS_NOT_VALIDATED"),
        ("7 jobsite contacts missing",            "JOBSITE.NO_SITE_CONTACT"),
        ("8 Billing Configuration incomplete",    "QUOTE.BILLING_CONFIG_INCOMPLETE"),
    ]:
        check("%-40s -> %s" % (issue, cid), cid in ids)
    import runner
    gaps = {r["sobject"] for r in runner.coverage_audit(registry.all_checks(), registry.spine())
            if r["gap"]}
    check("USF_Address__c is no longer an uncovered object", "USF_Address__c" not in gaps,
          str(sorted(gaps)))



def test_object_tally():
    """Loaded vs errors per object, and the rule that an unstarted load is NOT a failure."""
    print("\nOBJECT TALLY")
    import tally as tal

    class TConn:
        batch = "UMB-TEST"
        def __init__(self, counts): self.counts = counts
        def q(self, sql):
            for obj, n in self.counts.items():
                if (" from %s " % obj.lower()) in (" " + " ".join(sql.lower().split()) + " "):
                    return [{"c": n, "mn": "2026-10-01T08:00:00.000+0000",
                             "mx": "2026-10-01T18:00:00.000+0000", "lm": ""}]
            return [{"c": 0, "mn": "", "mx": "", "lm": ""}]
        def n(self, sql): return 0

    counts = {"SBQQ__Quote__c": 906, "Order": 906, "Contract": 0, "MaintenancePlan": 0,
              "Billing_Impacts_Queue__c": 0}
    res = [Result(check_id="ORDER.ACTIVATION_RATE", batch="UMB-TEST", verdict=FAIL,
                  evidence_count=447, processed=906)]
    # reached RO 19: Contracts are DUE (19<=19) but Maintenance Plans (35) and BIQs (48)
    # have not been reached yet
    rows = tal.collect(TConn(counts), res, None, reached_ro=19)
    by = {r["sobject"]: r for r in rows}
    check("every spine object gets a row", len(rows) == 20, str(len(rows)))
    check("Orders report what loaded", by["Order"]["loaded"] == 906, str(by["Order"]["loaded"]))
    check("  ...and the errors their checks found", by["Order"]["errors"] == 447,
          str(by["Order"]["errors"]))
    check("Maintenance Plans (RO 35, not reached) -> PENDING",
          by["MaintenancePlan"]["state"] == "PENDING" and by["MaintenancePlan"]["pending"])
    check("BIQs (RO 48, not reached) -> PENDING", by["Billing_Impacts_Queue__c"]["pending"])
    check("Contracts (RO 19, DUE and empty) -> a real gap, not pending",
          not by["Contract"]["pending"] and "real gap" in by["Contract"]["note"],
          by["Contract"]["note"][:70])
    check("AssignedResource has no batch path -> UNSCOPED, never a zero",
          by["AssignedResource"]["state"] == "UNSCOPED")

    t = tal.totals(rows)
    check("totals EXCLUDE pending objects' errors", t["errors"] == 447, str(t["errors"]))
    check("  ...and count the pending ones separately", t["pending"] >= 2, str(t["pending"]))

    # a pending object must contribute NOTHING even if a check failed on it
    res2 = res + [Result(check_id="BIQ.COVERAGE", batch="UMB-TEST", verdict=FAIL,
                         evidence_count=999, processed=0)]
    rows2 = tal.collect(TConn(counts), res2, None, reached_ro=19)
    by2 = {r["sobject"]: r for r in rows2}
    check("a FAIL on a not-yet-loaded object is zeroed, not counted",
          by2["Billing_Impacts_Queue__c"]["errors"] == 0,
          str(by2["Billing_Impacts_Queue__c"]["errors"]))
    check("  ...and the total ignores it too", tal.totals(rows2)["errors"] == 447,
          str(tal.totals(rows2)["errors"]))


def test_progress_and_issues():
    print("\nCURRENT STEP + ISSUE SUMMARY")
    import runbook as rbk, server
    pth = tempfile.mktemp(suffix=".db")
    st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "0.9.0", "a", "", False, "")
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="B", verdict=FAIL,
                               reason="447 of 906", evidence_count=447, processed=906,
                               metric=Metric("Orders Activated", .5, "ratio", 459, 906)))
    st.save_result(rid, Result(check_id="RAN.TF_15_QUOTES", batch="B", verdict=PASS,
                               reason="906", evidence_count=0, processed=906,
                               ran_from="2026-10-01T08:02:11Z", ran_to="2026-10-01T08:41:03Z",
                               run_status="SUCCESS", run_source="Informatica API"))
    st.finish_run(rid)
    rows = rbk.readiness(st, "B", rid)
    pr = rbk.progress(rows)
    # WHERE THE BATCH IS and WHAT IS BLOCKING IT are different facts. Returning the first
    # blocker as "current" marked Run Order 2 -- a pre-flight validation -- on a batch
    # whose work had reached Run Order 40.
    check("current step FOLLOWS THE WORK: the next step after the furthest one that ran",
          pr["current"] == 17, str(pr["current"]))
    check("  ...labelled as what comes next, not as a blockage", pr["why"] == "next", pr["why"])
    check("  ...and the blocker is reported SEPARATELY", pr["blocked_at"] == 16,
          str(pr["blocked_at"]))
    check("'reached' uses OWN evidence, not being blocked by an upstream step",
          pr["reached"] == 16, str(pr["reached"]))
    check("  ...and picks up the job's last activity",
          pr["last_activity"].startswith("2026-10-01"), pr["last_activity"])

    items = rbk.issues(st, "B", rid, rows, set())
    sm = rbk.issue_summary(items)
    check("issues lists the failure", sm["errors"] >= 1 and sm["records"] == 447,
          str(sm))
    check("  ...worst first", items[0]["kind"] == "ISSUE", items[0]["kind"])
    # excluding an object removes its issues entirely
    items2 = rbk.issues(st, "B", rid, rows, {"Order"})
    check("a pending object's issues are excluded from the list",
          rbk.issue_summary(items2)["records"] == 0,
          str(rbk.issue_summary(items2)["records"]))

    hero, busy, cur = server.hero_and_log(st, "B", rid)
    html = hero + server.table(st, "B", rid)
    check("run book rows are NOT highlighted",
          "class='now'" not in html and "nowtag" not in html)
    check("the 'How far can it advance' banner is gone", "How far can" not in html)
    check("  ...the &quot;where this batch is&quot; panel carries it instead", "Where this batch is" in html)
    check("no cell can stretch its row", ".clamp{max-height" in server.CSS)
    check("the object band renders when a tally exists (none here -> omitted)",
          "Records in Salesforce" not in html)
    check("all three sections present", "Where this batch is" in html and "Issues in this batch" in html)
    st.close(); os.unlink(pth)


def test_record_drilldown():
    """'Show me the exact records that failed and why.'"""
    print("\nRECORD DRILL-DOWN")
    import server, registry
    pth = tempfile.mktemp(suffix=".db")
    st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "0.10.0", "a", "", False, "")
    sample = [{"Id": "801VD0000%04d" % i, "OrderNumber": "007588%02d" % i,
               "Status": "Activated"} for i in range(250)]
    st.save_result(rid, Result(check_id="WO.ORDERS_MISSING_WOS", batch="B", verdict=FAIL,
                               reason="906 of 906 Order(s) have no Work Orders.",
                               evidence_count=906, processed=906,
                               evidence_sample=sample))
    st.finish_run(rid)

    ev = st.evidence(rid, "WO.ORDERS_MISSING_WOS")
    check("records are retained past the old 200 cap", len(ev) == 250, str(len(ev)))
    check("  ...with the real Salesforce Ids",
          ev[0]["Id"].startswith("801VD"), str(ev[0]))

    html = server.records_page(st, "B", rid, "WO.ORDERS_MISSING_WOS")
    check("the page names the check", "Orders with no Work Orders" in html)
    check("  ...states WHY they failed", "Why these failed" in html and "no Work Orders" in html)
    check("  ...shows the rule and its source", "Rule:" in html and "Source:" in html)
    check("  ...names the fix step", "Fix at RO" in html)
    check("  ...renders every retained record", html.count("<tr><td>") == 250,
          str(html.count("<tr><td>")))
    check("  ...one column per field", "<th>Id</th>" in html and "<th>OrderNumber</th>" in html)
    check("ADMITS the sample is short of the true count",
          "Showing 250 of 906" in html, "cap banner missing")
    check("  ...and says the COUNT is the reliable number",
          "count is exact" in html)

    csvtxt = server.records_csv(st, "B", rid, "WO.ORDERS_MISSING_WOS")
    check("CSV has a header plus every record", len(csvtxt.splitlines()) == 251,
          str(len(csvtxt.splitlines())))
    check("  ...with the same columns", csvtxt.splitlines()[0] == "Id,OrderNumber,Status",
          csvtxt.splitlines()[0])

    # a check that retained nothing must say so, not render an empty table
    st.save_result(rid, Result(check_id="QUOTE.NOT_ORDERED", batch="B", verdict=FAIL,
                               reason="x", evidence_count=5, evidence_sample=[]))
    h2 = server.records_page(st, "B", rid, "QUOTE.NOT_ORDERED")
    check("a check with no retained rows says so", "No individual records were retained" in h2)

    # the issue list links to it
    import runbook as rbk
    rows = rbk.readiness(st, "B", rid)
    items = rbk.issues(st, "B", rid, rows, set())
    h3 = server.issues_section(st, "B", rid, rows, set(), items, rbk.issue_summary(items))
    check("the issue list links through to the records",
          "/records?check=WO.ORDERS_MISSING_WOS" in h3)

    st.close(); os.unlink(pth)


def test_evidence_cap_configurable():
    print("\nEVIDENCE CAP")
    import store as st_mod
    check("default cap is no longer 200", st_mod.EVIDENCE_CAP >= 2000,
          str(st_mod.EVIDENCE_CAP))
    pth = tempfile.mktemp(suffix=".db")
    s1 = Store(pth, 5); rid = new_run_id()
    s1.start_run(rid, "B", "GATE", "x", "a", "", False, "")
    s1.save_result(rid, Result(check_id="C", batch="B", verdict=FAIL, evidence_count=99,
                               evidence_sample=[{"Id": str(i)} for i in range(50)]))
    s1.finish_run(rid)
    check("a configured cap is honoured", len(s1.evidence(rid, "C")) == 5,
          str(len(s1.evidence(rid, "C"))))
    r = s1.results_for_run(rid)[0]
    check("  ...while the COUNT stays exact", r["evidence_count"] == 99,
          str(r["evidence_count"]))
    s1.close(); os.unlink(pth)


def test_dead_polygons():
    """502 polygons pointing at deleted territories -- org-wide, blocks every batch."""
    print("\nDEAD MAP POLYGONS")
    import checks as ck

    TERRS = [{"Id": "0HhLIVE001", "Name": "ALP-A", "IsActive": True},
             {"Id": "0HhLIVE002", "Name": "SJO-P", "IsActive": True},
             {"Id": "0HhLIVE003", "Name": "LKC-E", "IsActive": False}]
    POLYS = [
        {"Id": "p1", "Name": "ALP-A", "FSL__Service_Territory__c": "0HhDEAD001"},
        {"Id": "p2", "Name": "SJO-P", "FSL__Service_Territory__c": "0HhLIVE002"},
        {"Id": "p3", "Name": "LKC-E", "FSL__Service_Territory__c": "0HhDEAD003"},
        {"Id": "p4", "Name": "Rt1",   "FSL__Service_Territory__c": "0HhDEAD004"},
    ]
    c = ScriptedConn([("from serviceterritory", TERRS), ("from fsl__polygon__c", POLYS)])
    ev = ck._fsl_dead_polygons(c)

    check("healthy polygons are skipped", ev.count == 3, "%d flagged of 4" % ev.count)
    check("  ...and it reports every polygon examined", ev.processed == 4, str(ev.processed))
    by = {r["polygon"]: r for r in ev.rows}
    check("exact name match -> mechanical", "Mechanical" in by["ALP-A"]["resolution"],
          by["ALP-A"]["resolution"])
    check("inactive target is NOT treated as a fix",
          "IsActive = false" in by["LKC-E"]["resolution"], by["LKC-E"]["resolution"])
    check("  ...and says repointing at it solves nothing",
          "solves nothing" in by["LKC-E"]["resolution"])
    check("no name match -> needs a human", "NO MATCH" in by["Rt1"]["resolution"],
          by["Rt1"]["resolution"])
    check("the note splits the three dispositions",
          "MECHANICALLY" in ev.note and "INACTIVE" in ev.note and "NO match" in ev.note,
          ev.note[:140])
    check("  ...and says it is ORG-WIDE, not this batch's problem",
          "ORG-WIDE" in ev.note and "every batch" in ev.note)

    # all healthy -> nothing flagged
    ev2 = ck._fsl_dead_polygons(ScriptedConn([
        ("from serviceterritory", TERRS),
        ("from fsl__polygon__c", [{"Id": "p9", "Name": "ALP-A",
                                   "FSL__Service_Territory__c": "0HhLIVE001"}])]))
    check("a clean org flags nothing", ev2.count == 0, str(ev2.rows))

    # no territories readable -> UNPROVEN, never "all polygons are dead"
    ev3 = ck._fsl_dead_polygons(ScriptedConn([("from serviceterritory", []),
                                          ("from fsl__polygon__c", POLYS)]))
    check("no territories readable -> UNPROVEN, not 'everything is broken'",
          bool(ev3.unprovable), ev3.unprovable[:80])

    c4 = registry.by_id("FSL.DEAD_POLYGONS")
    check("runs at the PRE-FLIGHT (RO 2)", c4.runbook_order == 2)
    check("  ...and blocks the steps that create Work Orders",
          {19, 25, 27, 30} <= set(c4.blocks or ()), str(c4.blocks))
    check("  ...declares the field it needs, so a wrong name is UNPROVEN not zero",
          "FSL__Polygon__c.FSL__Service_Territory__c" in c4.requires, str(c4.requires))
    rem = " ".join(c4.remediation.steps)
    check("  ...warns against eyeballing the name (the SJO-P mistake)",
          "SJO-P" in rem and "ROUTE-level" in rem)
    check("  ...and warns the fix takes several runs", "several runs" in rem)


def test_collapsible_and_totals():
    """Both top sections minimise, and the band can never disagree with the headline."""
    print("\nCOLLAPSIBLE SECTIONS + TOTAL AGREEMENT")
    import server, runbook as rbk, tally as tal
    pth = tempfile.mktemp(suffix=".db")
    st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "0.12.0", "a", "", False, "")
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="B", verdict=FAIL,
                               reason="x", evidence_count=906, processed=906))
    # a check on an object that has NO card: dead polygons live on ServiceTerritory
    st.save_result(rid, Result(check_id="FSL.DEAD_POLYGONS", batch="B", verdict=FAIL,
                               reason="y", evidence_count=501, processed=4987))
    st.finish_run(rid)
    trows = [dict(sequence=110, sobject="Order", label="Orders", loaded=906, state="OK",
                  first="", last="", modified="", errors=906, error_checks="", note="",
                  produced_at=17, pending=False)]
    st.save_tally(rid, trows)

    rows = rbk.readiness(st, "B", rid)
    items = rbk.issues(st, "B", rid, rows, set())
    ism = rbk.issue_summary(items)
    band = server.object_band(st, rid, ism)
    check("the band quotes the AUTHORITATIVE total, not just its cards",
          "<b>1,407</b> failing record(s)" in band, "ism=%d" % ism["records"])
    check("  ...and says how many sit outside the cards",
          "501 of them on org-wide infrastructure" in band, band[-400:])

    check("the object band is collapsible", "<details class='band'" in band)
    check("  ...folded by default (the headline says it first), summary keeps the numbers",
          "id='sec-band'>" in band and "id='sec-band' open" not in band)
    check("  ...and its summary still carries the numbers when collapsed",
          "failing record(s)</span>" in band.split("</summary>")[0])

    iss = server.issues_section(st, "B", rid, rows, set(), items, ism)
    check("the issues section is collapsible", "<details class='sec'" in iss)
    check("  ...open by default", "id='sec-issues' open" in iss)
    check("  ...summary carries the counts when collapsed",
          "must fix" in iss.split("</summary>")[0])

    pg = server.page(band + iss)
    check("collapse state is persisted", "pm.collapsed.v1" in pg)
    check("  ...and a blocked-storage browser cannot blank the page",
          pg.count("catch (e)") >= 2)
    check("  ...storing COLLAPSED so a new section defaults to open",
          "state[d.id] = !d.open" in pg)
    st.close(); os.unlink(pth)


def test_no_shadowed_check_functions():
    """
    Two check functions with the same name silently become ONE.

    `WO.DEAD_POLYGON` and `FSL.DEAD_POLYGONS` both ran `lambda c: _dead_polygons(c)`, which
    resolves at CALL time -- so the second definition replaced the first and both checks
    reported identical numbers from the same query. Caught only because the UI listed the
    same finding twice.
    """
    print("\nNO SHADOWED FUNCTIONS")
    import re, collections
    src = open("checks.py").read()
    names = re.findall(r"^def (_[A-Za-z0-9_]+)\(", src, re.M)
    dupes = [n for n, k in collections.Counter(names).items() if k > 1]
    check("no module-level check function is defined twice", not dupes, str(dupes))

    ids = {c.id for c in registry.all_checks()}
    check("the duplicate dead-polygon check is gone", "WO.DEAD_POLYGON" not in ids)
    check("  ...one remains, at the pre-flight", "FSL.DEAD_POLYGONS" in ids)

    # and no two checks share both object and name, which is what made the dupe visible
    seen = {}
    clash = []
    for c in registry.all_checks():
        key = (c.sobject, c.name.lower())
        if key in seen:
            clash.append("%s / %s" % (seen[key], c.id))
        seen[key] = c.id
    check("no two checks report the same finding on the same object", not clash, str(clash))


def test_examined_never_exceeds_errors():
    """'46 errors of 39 examined' -- more errors than records looked at, on every run."""
    print("\nEXAMINED vs ERRORS, SANITY")
    # a COUNT metric's numerator is the FINDING, not the population
    ev = Evidence(rows=[{"i": i} for i in range(46)],
                  metric=Metric("Async jobs in flight", 39.0, "count", 39, 0))
    check("a count metric does NOT become an 'examined' population", ev.examined == 0,
          str(ev.examined))
    check("  ...so the UI shows the error count alone", ev.count == 46, str(ev.count))

    # a ratio metric still reports its denominator
    ev2 = Evidence(rows=[{"i": i} for i in range(447)],
                   metric=Metric("Orders Activated", .5, "ratio", 459, 906))
    check("a ratio metric still reports its denominator", ev2.examined == 906, str(ev2.examined))

    # explicit processed always wins
    ev3 = Evidence(rows=[], processed=4987,
                   metric=Metric("x", .9, "ratio", 4486, 4987))
    check("explicit processed wins", ev3.examined == 4987, str(ev3.examined))

    # the invariant itself, across every shape
    for e in (ev, ev2, ev3):
        check("  errors never exceed examined (or examined is 0)",
              e.examined == 0 or e.count <= e.examined,
              "%d of %d" % (e.count, e.examined))


def test_issues_ordered_by_run_order():
    print("\nISSUE LIST ORDER")
    import runbook as rbk
    pth = tempfile.mktemp(suffix=".db")
    st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "0.12.2", "a", "", False, "")
    st.save_result(rid, Result(check_id="WO.ORDERS_MISSING_WOS", batch="B", verdict=FAIL,
                               reason="x", evidence_count=906, processed=906))
    st.save_result(rid, Result(check_id="FSL.DEAD_POLYGONS", batch="B", verdict=FAIL,
                               reason="y", evidence_count=501, processed=4987))
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="B", verdict=FAIL,
                               reason="z", evidence_count=201, processed=906))
    st.finish_run(rid)
    items = rbk.issues(st, "B", rid, rbk.readiness(st, "B", rid), set())
    orders = [i["order"] for i in items]
    check("the list reads in Run Order", orders == sorted(orders), str(orders))
    check("  ...smallest first, so it works as a worklist", orders[0] == min(orders),
          str(orders[:4]))
    st.close(); os.unlink(pth)


def test_table_fits_and_counts_are_blocked():
    print("\nLAYOUT: FITS THE SCREEN, ONE BLOCK PER CHECK")
    import server
    css = server.CSS
    check("the table no longer forces a 1740px horizontal scroll", "min-width:1740px" not in css)
    check("  ...it uses a fixed layout with percentage widths",
          "table-layout:fixed" in css and ".c-purp{width:1" in css)
    check("  ...and the wrapper hides horizontal overflow", "overflow-x:hidden" in css)
    check("every cell wraps rather than widening", "overflow-wrap:anywhere" in css)
    check("  ...but HEADERS break at spaces only (not 'RUN ORDE/R')",
          "word-break:normal" in css)
    check("the Action pill can wrap, so 'RUN AUTOMATION' sets no floor",
          ".act{" in css and "white-space:nowrap;background:#eef1f5" not in css)

    # percentage widths must total 100 or the table cannot fit
    import re
    pcts = [int(m) for m in re.findall(r"\.c-[a-z]+\{width:(\d+)%", css)]
    check("column widths total 100%%", sum(pcts) == 100, "sum=%d from %s" % (sum(pcts), pcts))

    check("each check gets its own block in Record Count", ".cblk{" in css)
    check("  ...with a divider between blocks", ".cblk + .cblk{border-top" in css)
    check("  ...and each number on its own line", ".cblk .ln{display:block" in css)

    r = dict(state="BLOCKED", held=0, errors=0,
             counts=[dict(check="A", name="a", examined=414, errors=1, verdict="FAIL",
                          inverted=False, metric="", metric_value=None, metric_unit="",
                          metric_num=None, metric_den=None),
                     dict(check="B", name="b", examined=1129, errors=501, verdict="FAIL",
                          inverted=False, metric="Polygons pointing at a live territory",
                          metric_value=0.56, metric_unit="ratio", metric_num=628,
                          metric_den=1129)])
    html = server._count_cell(r)
    check("two checks render as TWO blocks", html.count("<div class='cblk'>") == 2,
          str(html.count("<div class='cblk'>")))
    check("  ...examined and errors on separate lines",
          html.count("class='ln'") >= 4, str(html.count("class='ln'")))
    check("  ...thousands separated", "1,129" in html, html[:200])
    check("  ...a count of wrong records is called 'failing', never 'error'",
          ">failing<" in html and "error" not in html.lower(), html[:200])
    check("  ...and the ratio shown as its own meta line",
          "56% Polygons pointing at a live territory" in html)


def test_truncation_never_invents_findings():
    """A capped read must not turn 'I did not look' into 'these are broken'."""
    print("\nTRUNCATION GUARDS")
    import checks as ck

    # more territories than the cap -> UNPROVEN, never a list of false dead polygons
    c = ScriptedConn([("count() from serviceterritory", ck.TERR_CAP + 1)])
    ev = ck._fsl_dead_polygons(c)
    check("more territories than the cap -> UNPROVEN", bool(ev.unprovable), ev.unprovable[:70])
    check("  ...and says WHY it would be false positives",
          "false" in ev.unprovable.lower() and "absence" in ev.unprovable.lower(),
          ev.unprovable[:160])

    # more polygons than were read -> UNPROVEN
    TERRS = [{"Id": "0HhLIVE1", "Name": "ALP-A", "IsActive": True}]
    POLYS = [{"Id": "p1", "Name": "ALP-A", "FSL__Service_Territory__c": "0HhDEAD1"}]
    c2 = ScriptedConn([("count() from serviceterritory", 10),
                       ("count() from fsl__polygon__c", 9999),
                       ("from serviceterritory", TERRS),
                       ("from fsl__polygon__c", POLYS)])
    ev2 = ck._fsl_dead_polygons(c2)
    check("a partial polygon read -> UNPROVEN", bool(ev2.unprovable), ev2.unprovable[:70])

    # within the caps -> it judges normally
    c3 = ScriptedConn([("count() from serviceterritory", 1),
                       ("count() from fsl__polygon__c", 1),
                       ("from serviceterritory", TERRS),
                       ("from fsl__polygon__c", POLYS)])
    ev3 = ck._fsl_dead_polygons(c3)
    check("within the caps it judges normally", ev3.count == 1 and not ev3.unprovable,
          str(ev3.rows))


def test_stale_run_warning():
    """A 13:11 run reported clean zeros on records that did not exist until 14:16."""
    print("\nSTALE RUN WARNING")
    import server
    from datetime import datetime, timezone, timedelta
    pth = tempfile.mktemp(suffix=".db")
    st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "0.14.0", "a", "", False, "")
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="B", verdict=FAIL,
                               reason="x", evidence_count=1, processed=10))
    st.finish_run(rid)

    # a run that just finished must NOT nag
    hero, _, _ = server.hero_and_log(st, "B", rid)
    check("a fresh run is not flagged as stale", "results are" not in hero)

    # backdate it three hours
    old = (datetime.now(timezone.utc) - timedelta(hours=3)).isoformat(timespec="seconds")
    st.db.execute("UPDATE run SET finished=? WHERE run_id=?", (old, rid)); st.db.commit()
    check("age is computed from the stored finish time",
          2.9 < server._run_age_hours(st, rid) < 3.1, str(server._run_age_hours(st, rid)))
    hero2, _, _ = server.hero_and_log(st, "B", rid)
    check("a 3-hour-old run IS flagged", "results are 3 hours old" in hero2, hero2[:200])
    check("  ...and says a clean result is only as current as the run",
          "only as current as the run" in hero2)
    check("  ...and tells you how to refresh it", "Run checks" in hero2)

    for h, want in ((0.2, "12 minutes"), (1, "1 hour"), (26, "26 hours"), (60, "2 days")):
        check("  %s reads as '%s'" % (h, want), server._age_words(h) == want,
              server._age_words(h))
    st.close(); os.unlink(pth)


def test_sunrise_path_is_forgiving():
    """'Can I just point it at Downloads?' -- yes, and that should not need a rebuild."""
    print("\nSUNRISE PATH DISCOVERY")
    import connections as cx, pathlib, time
    root = pathlib.Path(tempfile.mkdtemp()) / "Downloads"
    app = root / "Sunrise_v0.17.185_QA_READY" / "app"
    (app / "goose_live").mkdir(parents=True)
    (app / "goose_live" / "goose_live.py").write_text("# stub")
    (root / "node_modules" / "deep").mkdir(parents=True)
    (root / ".hidden" / "deep").mkdir(parents=True)

    check("a parent folder (Downloads) finds the app folder beneath it",
          cx._find_sunrise(str(root)) == app, str(cx._find_sunrise(str(root))))
    check("  ...so does the Sunrise folder itself",
          cx._find_sunrise(str(root / "Sunrise_v0.17.185_QA_READY")) == app)
    check("  ...and the exact app folder still works", cx._find_sunrise(str(app)) == app)
    check("  ...a quoted path is tolerated", cx._find_sunrise('"%s"' % root) == app)
    check("a folder with no Sunrise returns None, it does not guess",
          cx._find_sunrise(str(root.parent / "elsewhere")) is None)

    t0 = time.time(); cx._find_sunrise(str(root.parent)); dt = time.time() - t0
    check("the search is bounded, not a disk crawl", dt < 2.0, "%.2fs" % dt)
    check("  ...depth and budget are capped in code",
          "max_depth" in open("connections.py").read()
          and "budget" in open("connections.py").read())

    # too deep -> not found, rather than an unbounded hunt
    deep = root / "a" / "b" / "c" / "d" / "e" / "f" / "app"
    (deep / "goose_live").mkdir(parents=True)
    (deep / "goose_live" / "goose_live.py").write_text("# stub")
    import shutil
    shutil.rmtree(app.parent)
    check("beyond the depth cap it reports NOT FOUND rather than hunting forever",
          cx._find_sunrise(str(root)) is None, str(cx._find_sunrise(str(root))))


def test_fls_hint_points_at_the_fix():
    """
    'absent or FLS-hidden' is a dead end -- the two causes need opposite fixes.

    Vince's 2026-10-02 self-test reported SBQQ__Quote__c.Business_Type__c,
    Bill_Timing__c and Billing_Period__c as absent-or-hidden, silencing two Run Order 15
    checks. All three are visible on Account and Contract, which makes FLS far more likely
    than a missing field -- and that is the difference between a one-click permission grant
    and a deployment.
    """
    print("\nHIDDEN-FIELD DIAGNOSIS")
    import runner

    class Org(FakeConn):
        """Hidden on Quote, visible on the siblings -- exactly his org."""
        def has_field(self, d): return not d.startswith("SBQQ__Quote__c.")

    hint = runner._fls_hint(Org(), ["SBQQ__Quote__c.Business_Type__c"])
    check("a field visible on a sibling object is called out",
          "visible on Account" in hint, hint[:90])
    check("  ...and named as LIKELY FLS, not a missing field",
          "FIELD-LEVEL SECURITY" in hint and "not a missing field" in hint)
    check("  ...with the Apex that settles it",
          "getMap()" in hint and "NOT IN THIS ORG" in hint)

    class Bare(FakeConn):
        def has_field(self, d): return False

    hint2 = runner._fls_hint(Bare(), ["SBQQ__Quote__c.Nope__c"])
    check("a field on NO object does not claim FLS", "FIELD-LEVEL SECURITY" not in hint2)
    check("  ...it says it may genuinely be absent", "genuinely" in hint2, hint2[:80])

    # end to end: the check still reports UNPROVEN, but now says what to do
    chk = mk(lambda c: Evidence(rows=[]), requires=("SBQQ__Quote__c.Business_Type__c",))
    r = runner.run_check(chk, Org())
    check("the check is still UNPROVEN, never a silent zero", r.verdict == UNPROVEN, r.verdict)
    check("  ...and its reason now carries the next step",
          "FIELD-LEVEL SECURITY" in r.reason, r.reason[:110])


def test_parallelism_is_faster_and_still_correct():
    """
    The self-test fired 53 serial `sf` processes and took six minutes before the first
    check ran. Speed is worthless if it changes an answer, so this asserts BOTH.
    """
    print("\nPARALLEL EXECUTION")
    import connections as cx, runner, time, threading

    # --- order and failure isolation
    out = cx.parallel(lambda x: x * 2, range(20), workers=6)
    check("results come back in the ORIGINAL order", out == [x * 2 for x in range(20)])

    def boom(x):
        if x == 3:
            raise ValueError("nope")
        return x
    r = cx.parallel(boom, range(6), workers=4)
    check("one failure does not kill the batch",
          isinstance(r[3], Exception) and r[0] == 0 and r[5] == 5, str(r))

    # --- it is actually concurrent
    def slow(x):
        time.sleep(0.2); return x
    t0 = time.time(); cx.parallel(slow, range(12), workers=6); par = time.time() - t0
    check("12 x 0.2s tasks finish well under the 2.4s serial cost",
          par < 1.2, "%.2fs" % par)

    # --- a canary is never run twice in one run
    calls = []
    class C(FakeConn):
        workers = 4
        canary_cache = {}
        def __init__(self): super().__init__(); self.canary_cache = {}
    conn = C()
    def counting_canary(c):
        calls.append(1); return 5
    chk = mk(lambda c: Evidence(rows=[]), canary_fn=counting_canary)
    conn.canary_cache[chk.id] = 5                      # as the self-test would leave it
    r1 = runner.run_check(chk, conn)
    check("a check reuses the self-test's canary rather than re-querying",
          not calls and r1.verdict == PASS, "calls=%d verdict=%s" % (len(calls), r1.verdict))

    conn2 = C()
    r2 = runner.run_check(chk, conn2)
    check("  ...but still runs it when nothing cached it", len(calls) == 1, str(len(calls)))
    check("  ...and caches it for the rest of the run", conn2.canary_cache.get(chk.id) == 5)

    # --- the pack: same results, same order, every one persisted
    pth = tempfile.mktemp(suffix=".db")
    st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "x", "a", "", False, "")
    checks = []
    for i in range(12):
        c = dataclasses.replace(mk(lambda c, _i=i: Evidence(rows=[{"n": _i}] * (_i % 3))),
                                id="T.CHK%02d" % i)
        checks.append(c)
    class PConn(FakeConn):
        workers = 6
        def __init__(self): super().__init__(); self.canary_cache = {}
    seen = []
    res = runner.run_pack(checks, PConn(), st, rid,
                          lambda i, n, c: seen.append(c.id))
    check("every check produced a result", len(res) == 12, str(len(res)))
    check("  ...in REGISTRY order, not completion order",
          [r.check_id for r in res] == [c.id for c in checks],
          str([r.check_id for r in res][:4]))
    check("  ...every one persisted", len(st.results_for_run(rid)) == 12,
          str(len(st.results_for_run(rid))))
    check("  ...and progress fired once per check", len(seen) == 12, str(len(seen)))

    # serial mode still works, and agrees
    class SConn(PConn):
        workers = 1
    rid2 = new_run_id()
    st.start_run(rid2, "B", "GATE", "x", "a", "", False, "")
    res2 = runner.run_pack(checks, SConn(), st, rid2)
    check("Workers=1 gives identical verdicts",
          [r.verdict for r in res2] == [r.verdict for r in res],
          "%s vs %s" % ([r.verdict for r in res2][:4], [r.verdict for r in res][:4]))
    st.close(); os.unlink(pth)


def test_checks_run_in_run_book_order():
    """
    They used to run in SOURCE-FILE order: 2, 2, 18, 51, 50, 54, 55, 28, 41, 9, 55, 16...
    with PREDICT.LOAD_FAILURES (Run Order 3) running 23rd of 48.
    """
    print("\nEXECUTION ORDER")
    cs = registry.all_checks()
    ros = [c.runbook_order if c.runbook_order else 10_000 for c in cs]
    check("checks are ordered by RUN ORDER, not by source file", ros == sorted(ros),
          str(ros[:12]))
    check("  ...the pre-flight runs first", cs[0].runbook_order in (1, 2),   # RO 1 IS the pre-flight
          str(cs[0].runbook_order))
    check("  ...PREDICT.LOAD_FAILURES is near the front, not 23rd",
          [c.id for c in cs].index("PREDICT.LOAD_FAILURES") < 10,
          str([c.id for c in cs].index("PREDICT.LOAD_FAILURES")))
    # compare against the source list, not a magic number that goes stale every time a
    # check is added
    import checks as _ck
    check("  ...and nothing was dropped by the sort", len(cs) == len(_ck.CHECKS),
          "%d bound vs %d defined" % (len(cs), len(_ck.CHECKS)))

    # an UNBOUND check must sort last, never first
    import dataclasses as dc
    from model import Check
    unbound = [c for c in cs if not c.runbook_order]
    if unbound:
        first_unbound = [c.id for c in cs].index(unbound[0].id)
        bound_after = [c for c in cs[first_unbound:] if c.runbook_order]
        check("an unbound check sorts LAST, it cannot pose as a pre-flight",
              not bound_after, str([c.id for c in bound_after][:3]))
    else:
        check("every check is bound to a Run Order", True)

    # the run book view still agrees
    import runbook as rbk
    own = {}
    for c in cs:
        if c.runbook_order:
            own.setdefault(c.runbook_order, []).append(c.id)
    check("every bound Run Order exists in the run book",
          all(rbk.step(ro) is not None for ro in own),
          str([ro for ro in own if rbk.step(ro) is None]))


def test_absence_findings_are_not_record_lists():
    """
    'TF_35 produced NOTHING' has no failing records -- that IS the finding. The issue list
    said "1", the drill-down rendered a one-row table, and clicking through returned a
    restatement of the headline dressed as a record.
    """
    print("\nABSENCE vs RECORD LIST")
    import server, runbook as rbk
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "x", "a", "", False, "")
    st.save_result(rid, Result(check_id="RAN.TF_35_CONTRACTS", batch="B", verdict=FAIL,
        reason="Informatica TF_35 Activate FSL Order produced NOTHING for this batch.",
        evidence_count=1, processed=0,
        evidence_sample=[{"job": "Informatica TF_35 Activate FSL Order", "produced": 0,
                          "orchestrator_status": "no record"}]))
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="B", verdict=FAIL,
        reason="201 of 906 Order(s) are not Activated/Contracted.",
        evidence_count=201, processed=906,
        evidence_sample=[{"Id": "801VD%05d" % i, "OrderNumber": "0075%04d" % i}
                         for i in range(201)]))
    st.finish_run(rid)

    a = server.records_page(st, "B", rid, "RAN.TF_35_CONTRACTS")
    check("an absence says there are no records, and that IS the finding",
          "no failing records to show" in a)
    check("  ...and explains nothing was created", "produced" in a and "ABSENCE" in a)
    check("  ...and points at the check that DOES hold records",
          "Run Order 16" in a and "ORDER.ACTIVATION_RATE" in a, a[-400:])

    b = server.records_page(st, "B", rid, "ORDER.ACTIVATION_RATE")
    check("a real record list is NOT mislabelled as an absence",
          "no failing records to show" not in b)
    check("  ...and still renders every record", b.count("<tr><td>") == 201,
          str(b.count("<tr><td>")))

    rows = rbk.readiness(st, "B", rid)
    items = rbk.issues(st, "B", rid, rows, set())
    html = server.issues_section(st, "B", rid, rows, set(), items,
                                 rbk.issue_summary(items))
    check("an absence reads 'produced nothing', not '1 record'",
          "produced nothing" in html and "1 steps" not in html and " 1 record" not in html)
    check("  ...and real findings keep their real counts (here folded under 'matter later': the load has not reached them)",
          "201 records" in html and "Will matter later" in html, html[:300])
    st.close(); os.unlink(pth)


def test_salesforce_links():
    print("\nSALESFORCE RECORD LINKS")
    import server
    CFG = {"InstanceUrl": "https://ussprod--qa.sandbox.lightning.force.com"}

    link = server._sf_link(CFG, "a1Z6O000005VUzEUAW", "FSL__Polygon__c")
    check("a custom-object Id links to the record",
          "/lightning/r/FSL__Polygon__c/a1Z6O000005VUzEUAW/view" in link, link[:110])
    check("  ...opening in a new tab, safely",
          "target='_blank'" in link and "rel='noopener'" in link)
    check("a standard Id names its object from the key prefix",
          "/lightning/r/Order/801VD00000tqhNoYAI/view" in server._sf_link(CFG, "801VD00000tqhNoYAI"))
    check("  ...and ServiceTerritory too",
          "/lightning/r/ServiceTerritory/0Hh6O0000008bTRSAY/view"
          in server._sf_link(CFG, "0Hh6O0000008bTRSAY"))

    check("an Order NUMBER is not mistaken for an Id",
          server._sf_link(CFG, "00758836") == "00758836")
    check("  ...nor a status value", server._sf_link(CFG, "Activated") == "Activated")
    check("  ...nor a date", server._sf_link(CFG, "2026-10-02T14:00:00") == "2026-10-02T14:00:00")
    check("no InstanceUrl configured -> plain text, no broken link",
          server._sf_link({}, "a1Z6O000005VUzEUAW") == "a1Z6O000005VUzEUAW")

    # end to end on a record page
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "x", "a", "", False, "")
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="B", verdict=FAIL,
        reason="x", evidence_count=2, processed=10,
        evidence_sample=[{"Id": "801VD00000tqhNoYAI", "OrderNumber": "00758836",
                          "Status": "Activated"},
                         {"Id": "801VD00000tqC9pYAE", "OrderNumber": "00758970",
                          "Status": "Activated"}]))
    st.finish_run(rid)
    html = server.records_page(st, "B", rid, "ORDER.ACTIVATION_RATE", CFG)
    check("the record table links every Id", html.count("class='sfid'") == 2,
          str(html.count("class='sfid'")))
    check("  ...and leaves the other columns alone",
          ">00758836<" in html and ">Activated<" in html)
    nolink = server.records_page(st, "B", rid, "ORDER.ACTIVATION_RATE", {})
    check("without a configured org, nothing is linked", "class='sfid'" not in nolink)
    st.close(); os.unlink(pth)


def test_findings_classified_against_the_load():
    """
    Everything downstream of the last load is not yet an error. Everything upstream that is
    already wrong but breaks a step still ahead is a PREDICTION -- fixable for free.
    """
    print("\nFINDINGS vs HOW FAR THE LOAD GOT")
    import runbook as rbk
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "B", "GATE", "x", "a", "", False, "")
    # TF_15 and TF_30 ran; nothing after
    st.save_result(rid, Result(check_id="RAN.TF_15_QUOTES", batch="B", verdict=PASS,
                               evidence_count=0, processed=906))
    st.save_result(rid, Result(check_id="RAN.TF_30_ORDERS", batch="B", verdict=PASS,
                               evidence_count=0, processed=906))
    # loaded data, already wrong, breaks a step still ahead -> PREDICTED
    st.save_result(rid, Result(check_id="ORDER.ACTIVATION_RATE", batch="B", verdict=FAIL,
                               reason="x", evidence_count=201, processed=906))
    # a step the load has not reached -> NOT YET
    st.save_result(rid, Result(check_id="BIQ.COVERAGE", batch="B", verdict=FAIL,
                               reason="y", evidence_count=750, processed=786))
    st.finish_run(rid)

    rows = rbk.readiness(st, "B", rid)
    pr = rbk.progress(rows)
    check("the last ORCHESTRATOR step that ran is identified",
          pr["last_job"] == 17 and "TF_30" in pr["last_job_step"],
          "%s %s" % (pr["last_job"], pr["last_job_step"]))
    check("  ...with the next job named", pr["next_job"] == 19, str(pr["next_job"]))
    check("  ...and how many load jobs remain",
          pr["jobs_left"] == pr["jobs_total"] - pr["jobs_done"] and pr["jobs_left"] > 0,
          "%d of %d left" % (pr["jobs_left"], pr["jobs_total"]))
    check("  ...and which jobs cannot be confirmed at all",
          isinstance(pr["jobs_unconfirmable"], list))

    items = {i["check"]: i for i in rbk.issues(st, "B", rid, rows, set())}
    check("a finding BEYOND the load is NOT YET, not an error",
          items["BIQ.COVERAGE"]["phase"] == "NOT YET", str(items["BIQ.COVERAGE"]["phase"]))
    check("a finding in loaded data that breaks a later step is PREDICTED",
          items["ORDER.ACTIVATION_RATE"]["phase"] == "PREDICTED",
          str(items["ORDER.ACTIVATION_RATE"]["phase"]))
    check("  ...and names the step it will break",
          items["ORDER.ACTIVATION_RATE"]["breaks_at"] == 25,
          str(items["ORDER.ACTIVATION_RATE"]["breaks_at"]))

    sm = rbk.issue_summary(list(items.values()))
    check("the summary splits current from predicted from not-yet",
          sm["predicted"] >= 1 and sm["not_yet"] >= 1, str(sm))
    st.close(); os.unlink(pth)


# ---------------------------------------------------------------- v0.17.1 regressions
class RecordingConn(FakeConn):
    """FakeConn ignores the SOQL it is given, so a check could query a field that does not
    exist and every offline test would still pass. This one keeps every query."""
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.sent = []
    def q(self, soql):
        self.sent.append(soql); return super().q(soql)
    def n(self, soql):
        self.sent.append(soql); return super().n(soql)


def test_no_check_queries_a_nonexistent_biq_field():
    """
    BIQ.ERROR_STATUS and BIQ.FSC_NULL_EFFECTIVE_DATE selected `Status__c`. The field on
    Billing_Impacts_Queue__c is `Processing_Status__c`, so both came back UNPROVEN with
    INVALID_FIELD in a real run (UMB-0116, 2026-10-02) and the offline suite could not see it.
    """
    print("\nBIQ FIELD NAMES (v0.17.1)")
    import re
    bad = re.compile(r"(?<![A-Za-z_])Status__c")
    sent_biq, ran = [], 0
    for c in registry.all_checks():
        conn = RecordingConn()
        try:
            c.run(conn); ran += 1
        except Exception:                                        # noqa: BLE001
            pass                  # a check may need real rows; what it SENT before that counts
        sent_biq += [q for q in conn.sent if "Billing_Impacts_Queue__c" in q]
    check("the BIQ checks actually emitted queries to inspect", len(sent_biq) >= 3, str(len(sent_biq)))
    offenders = [q[:110] for q in sent_biq if bad.search(q)]
    check("no BIQ query selects or filters on a bare Status__c", not offenders, str(offenders))
    check("  ...and the real field name is the one being used",
          any("Processing_Status__c" in q for q in sent_biq))
    src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "checks.py")).read()
    check("  ...source agrees (no bare Status__c anywhere in checks.py)",
          not [l for l in src.splitlines() if bad.search(l)
               and "SBQQ__Status__c" not in l and "Batch_Status__c" not in l])


def test_records_blocked_counts_each_check_once():
    """
    Summing per-row `held` counted one root failure at every step it blocks: the example
    workbook read 2,334 for 774 real records.
    """
    print("\nRECORDS BLOCKED IS DISTINCT (v0.17.1)")
    import runbook as rb
    def row(ro, state, errors, upstream, failing=(), blocked_by=()):
        return dict(order=ro, step="s%d" % ro, state=state, errors=errors, examined=0,
                    held=errors + upstream,
                    failing=[dict(check=c, rows=n) for c, n in failing],
                    blocked_by=[dict(check=c, rows=n) for c, n in blocked_by])
    B = rb.BLOCKED
    rows = [row(38, B, 5, 0, failing=[("WO.MP_NO_GENERATION", 5)]),
            row(39, B, 0, 5, blocked_by=[("WO.MP_NO_GENERATION", 5)]),
            row(51, B, 750, 0, failing=[("BIQ.COVERAGE", 750)]),
            row(52, B, 18, 0, failing=[("BIQ.FSC_NULL_EFFECTIVE_DATE", 18)]),
            row(54, B, 0, 18, blocked_by=[("BIQ.FSC_NULL_EFFECTIVE_DATE", 18)]),
            row(55, B, 1, 768, failing=[("GOOSE.BIQ_PARITY", 1)],
                blocked_by=[("BIQ.COVERAGE", 750), ("BIQ.FSC_NULL_EFFECTIVE_DATE", 18)]),
            row(57, B, 0, 769, blocked_by=[("BIQ.COVERAGE", 750),
                                           ("BIQ.FSC_NULL_EFFECTIVE_DATE", 18),
                                           ("GOOSE.BIQ_PARITY", 1)])]
    old = sum(r["held"] for r in rows if r["state"] == B)
    sm = rb.summary(rows)
    check("the old formula really did over-count here (guards the test itself)", old == 2334, str(old))
    check("records_blocked = distinct records (5+750+18+1)", sm["records_blocked"] == 774,
          str(sm["records_blocked"]))
    check("  ...errors_total agrees with it", sm["errors_total"] == 774, str(sm["errors_total"]))
    only_blocked_by = [row(9, B, 0, 40, blocked_by=[("X.UPSTREAM", 40)])]
    check("an upstream blocker named only in blocked_by is still counted once",
          rb.summary(only_blocked_by)["records_blocked"] == 40)
    check("non-BLOCKED rows contribute nothing",
          rb.summary([row(1, rb.READY, 0, 0, failing=[("A.B", 9)])])["records_blocked"] == 0)


def test_one_version_source_and_it_matches_the_changelog():
    """Every run was stamped 0.1.0 in a 0.17.0 build, because two constants had drifted."""
    print("\nVERSION (v0.17.1)")
    import re, pathlib, importlib
    here = pathlib.Path(os.path.dirname(os.path.abspath(__file__)))
    srv = importlib.import_module("server")
    check("the UI version is read from runner.TOOL_VERSION, not a second literal",
          srv.VERSION == runner.TOOL_VERSION, "%s vs %s" % (srv.VERSION, runner.TOOL_VERSION))
    found = []
    for f in here.parent.glob("WHAT_CHANGED_v*.md"):
        m = re.match(r"WHAT_CHANGED_v(\d+)\.(\d+)\.(\d+)\.md", f.name)
        if m:
            found.append(tuple(int(x) for x in m.groups()))
    newest = ".".join(str(x) for x in max(found)) if found else ""
    check("a changelog file exists to compare against", bool(found))
    check("TOOL_VERSION equals the newest WHAT_CHANGED_v*.md", runner.TOOL_VERSION == newest,
          "%s vs %s" % (runner.TOOL_VERSION, newest))
    check("the stamped version is not the old 0.1.0 placeholder", runner.TOOL_VERSION != "0.1.0")



# ---------------------------------------------------------------- v0.18.0 checks
class RoutedConn(RecordingConn):
    """Answers each query from the first route whose key appears in it, and keeps every query."""
    def __init__(self, routes=(), counts=(), grows=(), gcounts=(), **k):
        super().__init__(**k)
        self.routes, self.counts = list(routes), list(counts)
        self.grows, self.gcounts = list(grows), list(gcounts)

    @staticmethod
    def _pick(table, text, default):
        for key, val in table:
            if key in text:
                return val
        return default

    def q(self, soql):
        self.sent.append(soql); return [dict(r) for r in self._pick(self.routes, soql, [])]

    def n(self, soql):
        self.sent.append(soql); return self._pick(self.counts, soql, 0)

    def gq(self, sql):
        self.sent.append(sql); return [dict(r) for r in self._pick(self.grows, sql, [])]

    def gn(self, sql):
        self.sent.append(sql); return self._pick(self.gcounts, sql, 0)

    # the production implementation, so the fake cannot drift from it
    sf_batch_id = __import__("connections").Conn.sf_batch_id


def _chk(cid):
    return next(c for c in registry.all_checks() if c.id == cid)


def test_delivery_check_uses_the_teams_rule():
    """TF_90A.09: a flat 'more than one delivery' count is WRONG. Compare to bundle roots."""
    print("\nDELIVERIES VS BUNDLES (v0.18.0)")
    chk = _chk("WO.DELIVERY_EXCEEDS_BUNDLES")
    F = {"WorkOrderLineItem.NF_BundleId__c"}

    def conn(groups, bundles, wos, fields=F):
        return RoutedConn(routes=[("GROUP BY Order__c", groups),
                                    ("FROM WorkOrderLineItem", bundles),
                                    ("SELECT Id, WorkOrderNumber", wos)],
                            counts=[("WorkType.Name = 'Delivery'", 6)], fields=fields)

    groups = [{"Order__c": "801A", "n": "2"}, {"Order__c": "801B", "n": 2}]
    bundles = [{"WorkOrder.Order__c": "801A", "NF_BundleId__c": "R1"},
               {"WorkOrder.Order__c": "801A", "NF_BundleId__c": "R2"},     # 2 bundles -> legit
               {"WorkOrder.Order__c": "801B", "NF_BundleId__c": "R3"},
               {"WorkOrder.Order__c": "801B", "NF_BundleId__c": "R3"}]     # 1 bundle -> suspect
    wos = [{"Id": "0WO1", "WorkOrderNumber": "1", "Order__c": "801A", "Order__r.OrderNumber": "A1",
            "Status": "New", "StartDate": "2026-10-01"},
           {"Id": "0WO2", "WorkOrderNumber": "2", "Order__c": "801A", "Order__r.OrderNumber": "A1",
            "Status": "New", "StartDate": "2026-10-05"},
           {"Id": "0WO3", "WorkOrderNumber": "3", "Order__c": "801B", "Order__r.OrderNumber": "B1",
            "Status": "New", "StartDate": "2026-10-01"},
           {"Id": "0WO4", "WorkOrderNumber": "4", "Order__c": "801B", "Order__r.OrderNumber": "B1",
            "Status": "Completed", "StartDate": "2026-10-01"}]

    check("a flat count would flag BOTH orders (guards the test itself)", len(groups) == 2)
    cn0 = conn(groups, bundles, wos)
    ev = chk.run(cn0)
    check("only the Order with more deliveries than bundles is flagged",
          [r["order_id"] for r in ev.rows] == ["801B"], str([r["order_id"] for r in ev.rows]))
    check("  ...with both numbers shown",
          ev.rows[0]["deliveries"] == 2 and ev.rows[0]["distinct_bundles"] == 1)
    check("  ...and the same-date signature of a true duplicate surfaced",
          ev.rows[0]["same_start_date"] is True)
    check("  ...and the legitimate multi-bundle Order is reported as the control group",
          "1 other Order(s)" in ev.note and "NOT flagged" in ev.note, ev.note[:120])
    check("the aggregate query that ran is scoped to the batch and to Delivery only",
          any("GROUP BY Order__c HAVING COUNT(Id) > 1" in q and "{BATCH}" in q
              and "WorkType.Name = 'Delivery'" in q for q in cn0.sent), str(cn0.sent[:2]))
    cn = conn(groups, bundles, wos); r = runner.run_check(chk, cn)
    check("run through the runner: FAIL", r.verdict == FAIL, r.verdict)
    check("  ...and its scoping query really carried the batch placeholder",
          any("{BATCH}" in q for q in cn.sent))

    r = runner.run_check(chk, conn([groups[0]], bundles, wos))
    check("only the legitimate shape present -> PASS, not FAIL", r.verdict == PASS, r.verdict)
    r = runner.run_check(chk, conn(groups, bundles, wos, fields=set()))
    check("bundle field hidden -> UNPROVEN, not a silent zero", r.verdict == UNPROVEN, r.verdict)
    r = runner.run_check(chk, RoutedConn(fields=F))
    check("no deliveries at all -> UNPROVEN (the canary), not PASS", r.verdict == UNPROVEN, r.verdict)


def test_woli_check_compares_to_source_quantity():
    """A repeated source line is not a duplicate until it is compared with the source quantity."""
    print("\nWOLI VS SOURCE QUANTITY (v0.18.0)")
    chk = _chk("WOLI.EXCEEDS_SOURCE_QUANTITY")
    F = {"WorkOrderLineItem.Order_Line_Item__c", "WorkOrderLineItem.USF_Confirmed_Quantity__c"}
    groups = [{"WorkOrderId": "WO1", "Order_Line_Item__c": "OI1", "n": 2},
              {"WorkOrderId": "WO2", "Order_Line_Item__c": "OI2", "n": 2},
              {"WorkOrderId": "WO3", "Order_Line_Item__c": "OI3", "n": 2},
              {"WorkOrderId": "WO4", "Order_Line_Item__c": "OI4", "n": 2}]

    def w(i, wo, oi, src, qty):
        return {"Id": i, "WorkOrderId": wo, "Order_Line_Item__c": oi,
                "Order_Line_Item__r.Quantity": src, "USF_Confirmed_Quantity__c": qty}
    detail = [w("L1", "WO1", "OI1", 2, 1), w("L2", "WO1", "OI1", 2, 1),     # qty 2 split in two: legit
              w("L3", "WO2", "OI2", 1, 1), w("L4", "WO2", "OI2", 1, 1),     # qty 1 delivered twice
              w("L5", "WO3", "OI3", None, None), w("L6", "WO3", "OI3", None, None),   # unjudgeable
              w("L7", "WO4", "OI4", 1, None), w("L8", "WO4", "OI4", 1, None)]  # no qty: count basis
    cn = RoutedConn(routes=[("GROUP BY WorkOrderId", groups),
                              ("FROM WorkOrderLineItem WHERE WorkOrderId IN", detail)],
                      counts=[("Order_Line_Item__c != null", 8)], fields=F)
    ev = chk.run(cn)
    agg = [q for q in cn.sent if "GROUP BY WorkOrderId" in q]
    check("the grouping query is scoped to the batch, to lines with a source, and to REPEATS only",
          bool(agg) and "USS_Migration_Batch__r.Name = '{BATCH}'" in agg[0]
          and "Order_Line_Item__c != null" in agg[0] and "HAVING COUNT(Id) > 1" in agg[0], str(agg))
    flagged = sorted(r["work_order_id"] for r in ev.rows)
    check("grouping alone would call all 4 'duplicates' (guards the test itself)", len(groups) == 4)
    check("only the ones that EXCEED the source quantity are flagged",
          flagged == ["WO2", "WO4"], str(flagged))
    check("  ...a quantity-2 line split into two WOLIs is NOT flagged",
          "WO1" not in flagged)
    check("  ...an unreadable source quantity is not guessed at",
          "WO3" not in flagged and "1 could not be judged" in ev.note, ev.note[:200])
    wo4 = next(r for r in ev.rows if r["work_order_id"] == "WO4")
    check("  ...an unpopulated quantity falls back to the WOLI count and says so",
          "WOLI count" in wo4["units_basis"], wo4["units_basis"])
    check("the control group is reported", "1 are explained" in ev.note, ev.note[:200])
    r = runner.run_check(chk, RoutedConn(routes=[("GROUP BY WorkOrderId", groups[:1]),
                         ("FROM WorkOrderLineItem WHERE WorkOrderId IN", detail[:2])],
                         counts=[("Order_Line_Item__c != null", 8)], fields=F))
    check("only an explained split present -> PASS", r.verdict == PASS, r.verdict)
    r = runner.run_check(chk, RoutedConn(routes=[("GROUP BY WorkOrderId", groups),
                         ("FROM WorkOrderLineItem WHERE WorkOrderId IN", detail)],
                         counts=[("Order_Line_Item__c != null", 8)], fields=set()))
    check("hidden field -> UNPROVEN", r.verdict == UNPROVEN, r.verdict)


def test_duplicate_contracts_per_order():
    print("\nDUPLICATE CONTRACTS (v0.18.0)")
    chk = _chk("CONTRACT.DUPLICATE_PER_ORDER")
    F = {"Contract.SBQQ__Order__c"}
    groups = [{"SBQQ__Order__c": "801X", "n": 2}]
    members = [{"Id": "800a", "ContractNumber": "C1", "Status": "Activated", "SBQQ__Order__c": "801X",
                "SBQQ__Order__r.OrderNumber": "O9"},
               {"Id": "800b", "ContractNumber": "C2", "Status": "Draft", "SBQQ__Order__c": "801X",
                "SBQQ__Order__r.OrderNumber": "O9"}]
    mk_ = lambda g: RoutedConn(routes=[("GROUP BY SBQQ__Order__c", g), ("FROM Contract WHERE SBQQ__Order__c IN", members)],
                                 counts=[("SBQQ__Order__c != null", 40)], fields=F)
    cnc = mk_(groups)
    ev = chk.run(cnc)
    agg = [q for q in cnc.sent if "GROUP BY SBQQ__Order__c" in q]
    check("the grouping query is scoped to the batch, to Contracts with an Order, and to REPEATS only",
          bool(agg) and "USS_Migration_Batch__r.Name = '{BATCH}'" in agg[0]
          and "SBQQ__Order__c != null" in agg[0] and "HAVING COUNT(Id) > 1" in agg[0], str(agg))
    check("two Contracts from one Order -> one finding", len(ev.rows) == 1 and ev.rows[0]["contracts"] == 2)
    check("  ...naming both Contracts", "C1" in ev.rows[0]["contract_numbers"] and "C2" in ev.rows[0]["contract_numbers"])
    check("one Contract per Order -> PASS", runner.run_check(chk, mk_([])).verdict == PASS)
    check("no Contracts with an Order -> UNPROVEN, not PASS",
          runner.run_check(chk, RoutedConn(fields=F)).verdict == UNPROVEN)


def test_polygon_twins():
    """TOM-D: a repointed polygon found to have a live same-named twin."""
    print("\nPOLYGON TWINS (v0.18.0)")
    chk = _chk("FSL.DUPLICATE_POLYGONS")
    F = {"FSL__Polygon__c.FSL__Service_Territory__c"}
    terrs = [{"Id": t} for t in ("T1", "T2", "T3", "T4", "T5")]
    P = lambda i, n, t: {"Id": i, "Name": n, "FSL__Service_Territory__c": t}
    polys = [P("p1", "TOM-D", "T1"), P("p2", "TOM-D", "T1"),                 # both live: duplicate
             P("p3", "ANT-A", "T9"), P("p4", "ANT-A", "T2"),                 # dead + live twin
             P("p5", "GNV-B", "T3"), P("p6", "GNV-B_2", "T4"),               # suffix pair: not flagged
             P("p7", "SJO-P", "T5")]
    mk_ = lambda **k: RoutedConn(routes=[("FROM ServiceTerritory", terrs), ("FROM FSL__Polygon__c", polys)],
                                   counts=[("FROM ServiceTerritory", 5), ("FROM FSL__Polygon__c", 7)],
                                   fields=F, **k)
    ev = chk.run(mk_())
    kinds = sorted(r["kind"].split(" -- ")[0] for r in ev.rows)
    check("a same-name live pair and a dead polygon with a live twin are both found",
          kinds == ["DUPLICATE", "RETIRE, DO NOT REPOINT"], str(kinds))
    check("  ...the dead one is told to be retired, not repointed",
          any(r.get("polygon_id") == "p3" and "DO NOT REPOINT" in r["kind"] for r in ev.rows))
    check("a _<n> suffix pair (GNV-B / GNV-B_2) is counted but NOT flagged",
          not any("GNV" in str(r.get("polygon")) for r in ev.rows) and "1 name(s) differ only by" in ev.note, ev.note[:200])
    check("a polygon with no twin is left alone", not any(r.get("polygon") == "SJO-P" for r in ev.rows))
    check("run through the runner: FAIL", runner.run_check(chk, mk_()).verdict == FAIL)

    big = RoutedConn(routes=[("FROM ServiceTerritory", terrs), ("FROM FSL__Polygon__c", polys)],
                       counts=[("FROM ServiceTerritory", 9000000), ("FROM FSL__Polygon__c", 7)], fields=F)
    r = runner.run_check(chk, big)
    check("a territory list past the read cap -> UNPROVEN (a partial read would INVENT dead polygons)",
          r.verdict == UNPROVEN, r.verdict)
    clean = RoutedConn(routes=[("FROM ServiceTerritory", terrs), ("FROM FSL__Polygon__c", polys[6:])],
                         counts=[("FROM ServiceTerritory", 5), ("FROM FSL__Polygon__c", 1)], fields=F)
    check("no twins -> PASS", runner.run_check(chk, clean).verdict == PASS)


def test_logged_generation_errors():
    """Where the cause was written down all along. AsyncApexJob said 0 errors."""
    print("\nLOGGED ERRORS (v0.18.0)")
    chk = _chk("LOG.WORKORDER_GENERATION_ERRORS")
    F = {"Log__c.Related_Object__c", "Log__c.Message__c", "Log__c.Log_Type__c"}
    win = [{"c": 10, "mn": "2026-09-30T14:54:12.000+0000", "mx": "2026-09-30T14:55:22.000+0000"}]
    logs = [{"Id": "a1vL1", "CreatedDate": "2026-09-30T18:00:00.000+0000",
             "Log_Type__c": "System.NullPointerException", "Related_Object__c": "ContractOrders.finish10",
             "Message__c": "Error Message : Script-thrown exception , Stack Trace : (System Code) "
                           "Class.DateTimeUtility.convertTimeZone: line 19, column 1 "
                           "Class.CPQOrdersDecorator.updateWODateTime: line 527",
             "Stack_Trace__c": None, "Error_Status_Code__c": None},
            {"Id": "a1vL2", "CreatedDate": "2026-09-30T18:05:00.000+0000", "Log_Type__c": "Error",
             "Related_Object__c": "Work Order", "Message__c": "invalid cross reference id",
             "Stack_Trace__c": "INVALID_CROSS_REFERENCE_KEY", "Error_Status_Code__c": None},
            {"Id": "a1vL3", "CreatedDate": "2026-09-30T18:05:01.000+0000", "Log_Type__c": "Error",
             "Related_Object__c": "ServiceAppointment",
             "Message__c": "FSL.TR001_Service_BeforeInsert: execution of BeforeInsert caused by: NPE",
             "Stack_Trace__c": "CANNOT_INSERT_UPDATE_ACTIVATE_ENTITY", "Error_Status_Code__c": None}]
    mk_ = lambda n=3, rows=logs: RoutedConn(routes=[("FROM SBQQ__Quote__c", win), ("FROM Log__c", rows)],
                                              counts=[("FROM Log__c", n)], fields=F)
    cn = mk_()
    ev = chk.run(cn)
    check("all three logged errors are returned", len(ev.rows) == 3, str(len(ev.rows)))
    check("the swallowed NullPointerException is classified as a null ServiceTerritory",
          ev.rows[0]["cause"].startswith("NullPointerException reading a timezone")
          and ev.rows[0]["first_frame"] == "DateTimeUtility.convertTimeZone", str(ev.rows[0]))
    check("  ...and its family says it was caught and swallowed",
          ev.rows[0]["family"] == "BatchContractOrders (caught and swallowed)")
    check("the external push cascade is classified, and called collateral",
          "INVALID" not in ev.rows[1]["cause"] and "external system" in ev.rows[1]["cause"]
          and "collateral" in ev.rows[2]["cause"], ev.rows[2]["cause"][:80])
    sent = " ".join(q for q in cn.sent if "FROM Log__c" in q)
    check("the query is scoped to the logger's class name",
          "Related_Object__c LIKE 'ContractOrders%'" in sent)
    check("  ...and to the batch's own time window (derived from its Quotes, padded a day)",
          "CreatedDate >= 2026-09-29T14:54:12Z" in sent and "CreatedDate <= 2026-10-01T14:55:22Z" in sent, sent[:260])
    check("run through the runner: FAIL", runner.run_check(chk, mk_()).verdict == FAIL)
    check("an empty Log__c -> UNPROVEN, not a clean pass",
          runner.run_check(chk, mk_(0, [])).verdict == UNPROVEN)
    check("no Quotes to define the window -> UNPROVEN, not org-wide noise",
          runner.run_check(chk, RoutedConn(routes=[("FROM Log__c", logs)], counts=[("FROM Log__c", 3)],
                                             fields=F)).verdict == UNPROVEN)


def test_goose_batch_status():
    """CJ, via the Goose README: the pipeline acts on the Goose status, not Salesforce's."""
    print("\nGOOSE BATCH STATUS (v0.18.0)")
    chk = _chk("GOOSE.BATCH_STATUS")
    mk_ = lambda sf, g, up=True: RoutedConn(
        routes=[("FROM USS_Migration_Batch__c", [{"Id": "aFOVD0000001SdN4AU", "Batch_Status__c": sf}])],
        grows=[("FROM dbo.MigrationBatch", [{"ID": 456, "BatchStatus": g}])],
        gcounts=[("dbo.MigrationBatch", 400)], goose_ok=up)
    check("active in Salesforce, Canceled in Goose -> FAIL (the pipeline cannot see it)",
          runner.run_check(chk, mk_("Processing", "Canceled")).verdict == FAIL)
    check("active in Salesforce, Open in Goose -> PASS", runner.run_check(chk, mk_("Processing", "Open")).verdict == PASS)
    ev = chk.run(mk_("Closed", "Canceled"))
    check("Closed in Salesforce, Canceled in Goose is terminal on both sides -> not a FAIL",
          ev.rows == [], str(ev.rows))
    check("  ...but the open question for CJ is recorded, not dropped", "CJ" in ev.note, ev.note)
    r = runner.run_check(chk, mk_("Processing", "Canceled", up=False))
    check("Goose unreachable -> UNPROVEN, 'not skipped, not passed'",
          r.verdict == UNPROVEN and "not skipped" in r.reason.lower(), r.reason[:80])
    check("no Goose row for the batch -> UNPROVEN",
          runner.run_check(chk, RoutedConn(routes=[("FROM USS_Migration_Batch__c", [{"Id": "aFOVD0000001SdN4AU", "Batch_Status__c": "Open"}])],
                                             gcounts=[("dbo.MigrationBatch", 400)])).verdict == UNPROVEN)
    # The real table has no BatchName (discovery failed live on exactly this). Goose is keyed by
    # the Salesforce Id through SalesforceUssMigrationBatchID.
    import inspect, actions as _act
    src = inspect.getsource(sys.modules["checks"]) + inspect.getsource(_act)
    check("no Goose query references a BatchName column the table does not have",
          "BatchName" not in src.replace("no Goose query references a BatchName", ""))
    cn = mk_("Processing", "Open"); chk.run(cn)
    gsent = " ".join(q for q in cn.sent if "dbo.MigrationBatch" in q)
    check("the Goose lookup is keyed by SalesforceUssMigrationBatchID with the batch's Salesforce Id",
          "SalesforceUssMigrationBatchID = 'aFOVD0000001SdN4AU'" in gsent, gsent[:200])
    check("no Salesforce Id for the batch -> UNPROVEN, never a guess by name",
          runner.run_check(chk, RoutedConn(routes=[("FROM USS_Migration_Batch__c", [{"Batch_Status__c": "Open"}])],
                                           grows=[("FROM dbo.MigrationBatch", [{"ID": 1, "BatchStatus": "Open"}])],
                                           gcounts=[("dbo.MigrationBatch", 400)])).verdict == UNPROVEN)


def test_object_tiles_open_a_detail_page():
    """Every tile in the band is a link, and the page behind it says what we can and cannot show."""
    print("\nOBJECT TILES (v0.20.0)")
    import server, tally as tal
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.20.0", "a", "", False, "")
    ev = [{"Id": "0WO000000000%03dAAA" % i, "WorkOrderNumber": str(i)} for i in range(1, 8)]
    st.save_result(rid, Result(check_id="SCOPE.WO_NO_CONTRACT", batch="UMB-0117", verdict=FAIL,
                               reason="2 WorkOrders", evidence_count=2, processed=100,
                               evidence_sample=ev[:2]))
    st.save_result(rid, Result(check_id="JOBSITE.NO_SITE_CONTACT", batch="UMB-0117", verdict=PASS,
                               evidence_count=0, processed=934))
    def trow(seq, obj, label, loaded, state, errors=0, pending=False, **k):
        d = dict(sequence=seq, sobject=obj, label=label, loaded=loaded, state=state, first="",
                 last="", modified="", errors=errors, error_checks="", note="",
                 produced_at=k.get("produced_at", 0), pending=pending)
        d.update(k); return d
    st.save_tally(rid, [
        trow(160, "WorkOrder", "Work Orders", 2034, "OK", errors=2, produced_at=19,
             first="2026-10-02T12:19:00Z", last="2026-10-03T01:26:00Z", modified="2026-10-03T02:00:00Z"),
        trow(100, "NF_Quoted_Jobsite__c", "Quoted Jobsites", 934, "OK", produced_at=11),
        trow(20, "Account", "Accounts", 608, "OK", note="Reached through this batch's Quotes."),
        trow(50, "USF_Address__c", "Addresses", 912, "OK", produced_at=10),
        trow(190, "AssignedResource", "Assigned Resources", None, "UNSCOPED"),
        trow(200, "Billing_Impacts_Queue__c", "BIQs", 0, "PENDING", pending=True, produced_at=48)])
    st.finish_run(rid)
    cfg = {"InstanceUrl": "https://example.my.salesforce.com"}
    band = server.object_band(st, rid)
    check("every tile is a link to /object", band.count("<a class='obj") == 6
          and "/object?object=WorkOrder&run=" in band, band[:200])
    check("  ...none is left as a dead div", "<div class='obj " not in band and "<div class='obj'" not in band)
    pg = server.object_page(st, "UMB-0117", rid, "WorkOrder", cfg)
    check("the page shows loaded, failing and the window", "2,034" in pg and "2026-10-02 12:19:00" in pg
          and "RO 19" in pg, pg[:200])
    check("  ...lists the checks on that object, with this run's verdict", "SCOPE.WO_NO_CONTRACT" in pg
          and "ISSUE" in pg)
    check("  ...links to the failing records and shows first Ids as Salesforce links",
          "/records?check=SCOPE.WO_NO_CONTRACT" in pg and "lightning/r/WorkOrder/0WO000000000001AAA" in pg)
    check("  ...gives the count query and a list query, each labelled READ ONLY and Workbench",
          pg.count("READ ONLY") >= 2 and "Workbench" in pg and "SELECT Id FROM WorkOrder" in pg
          and "LIMIT" not in pg and "{BATCH}" not in pg and "UMB-0117" in pg)
    check("  ...labels sit OUTSIDE the code block", "<pre class='q'>Tool" not in pg)
    check("  ...says what it can and cannot show", "What this page can show" in pg
          and "What it cannot show" in pg and "full list of records that loaded" in pg)
    ac = server.object_page(st, "UMB-0117", rid, "Account", cfg)
    check("an object the batch only UPDATES says 'touched', not created", "UPDATED" in ac)
    un = server.object_page(st, "UMB-0117", rid, "AssignedResource", cfg)
    check("an unscoped object says it cannot give a count, rather than showing zero",
          "no batch path" in un and "reports none rather than a zero" in un)
    pe = server.object_page(st, "UMB-0117", rid, "Billing_Impacts_Queue__c", cfg)
    check("a not-yet-loaded object says why it is dimmed", "not loaded yet" in pe and "has not run" in pe)
    check("an unknown object does not crash",
          "stored no tally" in server.object_page(st, "UMB-0117", rid, "Nope__c", cfg))
    clean = server.object_page(st, "UMB-0117", rid, "USF_Address__c", cfg)
    check("a clean object with a check shows CLEAR and no records link",
          "CLEAR" in clean and "see records" not in clean)
    check("an object NO check covers says the tile is a count only, nothing tested",
          "count only" in server.object_page(st, "UMB-0117", rid, "NF_Quoted_Jobsite__c", cfg))
    st.close(); os.unlink(pth)


def test_run_book_filters():
    """Buttons to show the full process, only the data-moving jobs, one system, a type, a status."""
    print("\nRUN BOOK FILTERS (v0.21.0)")
    import re, server, runbook as rbk
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.21.0", "a", "", False, "")
    st.save_result(rid, Result(check_id="FSL.DEAD_POLYGONS", batch="UMB-0117", verdict=FAIL,
                               reason="x", evidence_count=2, processed=100))
    st.finish_run(rid)
    html = server.table(st, "UMB-0117")
    steps = rbk.steps()
    trs = re.findall(r"<tr class='[^']*' data-sys='([^']*)' data-act='([^']*)' data-st='([^']*)' data-job='(\d)'", html)
    check("every run book row carries its filter attributes", len(trs) == len(steps), "%d/%d" % (len(trs), len(steps)))
    jobs = [s for s in steps if (s["stage"] or "").strip().lower() in ("informatica", "snaplogic")
            and (s["action"] or "").strip().upper() == "RUN"]
    check("'Data-moving jobs' is exactly the Informatica and SnapLogic RUN steps",
          sum(1 for t in trs if t[3] == "1") == len(jobs) and len(jobs) > 0, "%d" % len(jobs))
    check("  ...and its chip shows that count", "data-v='jobs'>Data-moving jobs<i>%d</i>" % len(jobs) in html)
    for key, label in (("informatica", "Informatica"), ("snaplogic", "SnapLogic"),
                       ("goose", "Goose"), ("salesforce", "Salesforce")):
        n = sum(1 for t in trs if key in t[0].split())
        check("system filter '%s' matches %d rows and its chip says so" % (key, n),
              n > 0 and ("data-v='%s'>%s<i>%d</i>" % (key, label, n)) in html)
    check("a 'Goose + Salesforce' step is under BOTH systems",
          any(t[0] == "goose salesforce" for t in trs))
    check("Multi / All-systems steps belong to no single system (they show under Full process only)",
          any(t[0] == "multi" for t in trs))
    check("the type chips are the actions the run book really has",
          all(("data-g='act' data-v='%s'" % a) in html for a in ("run", "validation", "auto-fix", "run-automation")))
    check("status chips exist, incl. Needs attention / Held / Review",
          all(w in html for w in ("Needs attention", ">Held<", ">Review<", ">Blocked<", "Not run / not checked")))
    check("the script comes AFTER the rows it filters (before them it finds none)",
          html.index("<script>") > html.index("</tbody>") and html.count("<script>") == 1)
    check("a Reset button and a live 'Showing N of M' counter exist", "data-reset='1'" in html and "id='rbcount'" in html)
    check("state slugs match what the script tests for (notrun / notchecked)",
          any(t[2] in ("notrun", "notchecked") for t in trs) and any(t[2] == "blocked" for t in trs))
    check("the filter remembers its choice but never fails without storage",
          "localStorage" in server.FILTER_JS and "catch (e) {}" in server.FILTER_JS)
    st.close(); os.unlink(pth)


def test_terminology():
    """Blocker / Review / Held / Error each mean ONE thing (terms.py), and the screens obey."""
    print("\nTERMINOLOGY (v0.20.0)")
    import runbook as rbk, server, terms, report
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.20.0", "a", "", False, "")
    for cid, v, n in (("FSL.DEAD_POLYGONS", FAIL, 2),              # BLOCKER at RO 2, blocks 19/25/27/30
                      ("CONTRACT.BRANCH_CODE_BLANK", FAIL, 40),   # WARNING at RO 22
                      ("JOBSITE.NO_SITE_CONTACT", PASS, 0)):      # clean at RO 15
        st.save_result(rid, Result(check_id=cid, batch="UMB-0117", verdict=v, reason="x",
                                   evidence_count=n, processed=100))
    st.finish_run(rid)
    rows = {r["order"]: r for r in rbk.readiness(st, "UMB-0117")}
    check("a failing BLOCKER check makes its own step BLOCKED", rows[2]["state"] == "BLOCKED", rows[2]["state"])
    check("a step that only sits downstream of a blocker is HELD, not BLOCKED",
          rows[25]["state"] == "HELD" and rows[27]["state"] == "HELD", rows[25]["state"])
    check("a failing WARNING check is REVIEW -- it does not stop the step",
          rows[22]["state"] == "REVIEW", rows[22]["state"])
    check("a clean step is READY", rows[15]["state"] == "READY", rows[15]["state"])
    sm = rbk.summary(list(rows.values()))
    check("summary counts the states separately",
          sm["blocked"] == 1 and sm["held"] >= 2 and sm["review"] == 1,
          "%s/%s/%s" % (sm["blocked"], sm["held"], sm["review"]))
    check("records held by blockers count the blocker's 2 records, not the 40 review items",
          sm["records_blocked"] == 2, str(sm["records_blocked"]))
    check("the earliest step you cannot pass is still found", sm["first_blocked_order"] == 2)
    items = rbk.issues(st, "UMB-0117")
    isum = rbk.issue_summary(items)
    check("issues are kind ISSUE; blockers and review are counted apart",
          all(i["kind"] == "ISSUE" for i in items) and isum["blockers"] == 1 and isum["review"] == 1,
          str(isum))
    check("a WARNING issue is shown with the word REVIEW", terms.sev("WARNING") == "REVIEW"
          and terms.sev("BLOCKER") == "BLOCKER" and terms.sev("INFO") == "NOTE")
    html = server.table(st, "UMB-0117")
    check("the run book table shows HELD and REVIEW states", "st HELD" in html and "st REVIEW" in html)
    check("  ...says a held step is fixed elsewhere", "fix elsewhere" in html)
    # A RUN step is only "already ran" on RAN.* evidence, the same proof progress() uses.
    st2 = Store(tempfile.mktemp(suffix=".db")); rid2 = new_run_id()
    st2.start_run(rid2, "UMB-0117", "GATE", "0.22.1", "a", "", False, "")
    st2.save_result(rid2, Result(check_id="PREDICT.LOAD_FAILURES", batch="UMB-0117", verdict=FAIL,
                                 reason="x", evidence_count=7910, processed=1000))      # RO 3, staging
    st2.save_result(rid2, Result(check_id="RAN.TF_30_ORDERS", batch="UMB-0117", verdict=PASS,
                                 reason="909", evidence_count=0, processed=909,
                                 ran_from="2026-10-02T11:35:00Z", ran_to="2026-10-02T19:53:00Z",
                                 run_status="SUCCESS", run_source="records"))           # RO 17
    st2.finish_run(rid2)
    r2 = {r["order"]: r for r in rbk.readiness(st2, "UMB-0117")}
    check("a SnapLogic step whose only evidence is a staging check is NOT said to have run",
          r2[3]["state"] == "BLOCKED" and not r2[3]["ran"], str(r2[3]["ran"]))
    check("  ...a step with RAN.* output evidence is", r2[17]["ran"])
    pj = rbk.progress(list(r2.values()))
    check("  ...and the flag agrees with the page's own 'Cannot confirm' list (no contradiction)",
          3 in pj["jobs_unconfirmable"] and all(r2[o]["ran"] == any(j["order"] == o and j["ran"] for j in
              [dict(order=r["order"], ran=r["ran"]) for r in r2.values()]) for o in (3, 17)))
    st2.close()
    check("a validation step that merely measured records is not said to have 'already run'",
          not rows[2]["ran"] and "job already ran" not in html.split("RO 2")[0], str(rows[2]["ran"]))
    check("  ...and carries the glossary that defines every word",
          all(w in html for w in ("What these words mean", "Blocker", "Review", "Held", "Unproven")))
    check("  ...a count of wrong records is never labelled 'errors'",
          "<span class='lb'>errors</span>" not in html and "<span class='lb'>error</span>" not in html)
    check("  ...the held/blocker wording replaced 'held by an earlier step'",
          "held by an earlier step" not in html)
    sec = server.issues_section(st, "UMB-0117", None, list(rows.values()), set())
    check("the issues section says how many records need a fix, in plain words",
          "need a fix" in sec and "REVIEW" in sec and "warning(s)" not in sec
          and "error record(s)" not in sec, sec[:300])
    check("'error' is kept for faults: an object whose query failed still says 'query failed'",
          "query failed" in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "server.py"),
                                 encoding="utf-8").read())
    # stored values unchanged, so history from earlier versions still opens and means the same
    from model import BLOCKER as _B, WARNING as _W, INFO as _I
    check("stored severities and verdicts are untouched",
          (_B, _W, _I) == ("BLOCKER", "WARNING", "INFO") and (PASS, FAIL, UNPROVEN) == ("PASS", "FAIL", "UNPROVEN"))
    st.close(); os.unlink(pth)


def test_goose_batch_discovery_maps_by_salesforce_id():
    """Live: 'Goose batch discovery failed' -- the query named a BatchName column that is not there."""
    print("\nGOOSE BATCH DISCOVERY (v0.19.1)")
    import actions as _a
    cn = RoutedConn(routes=[("FROM USS_Migration_Batch__c", [
                        {"Id": "aFOVD0000001SdN4AU", "Name": "UMB-0117", "Batch_Status__c": "Processing"},
                        {"Id": "aFOVD0000001AAAAAA", "Name": "UMB-0116", "Batch_Status__c": "Closed"}])],
                    grows=[("FROM dbo.MigrationBatch", [
                        {"ID": 901, "BatchStatus": "Open", "SalesforceUssMigrationBatchID": "aFOVD0000001SdN"},
                        {"ID": 902, "BatchStatus": "Canceled", "SalesforceUssMigrationBatchID": "aFOVD0000001AAAAAA"},
                        {"ID": 903, "BatchStatus": "Open", "SalesforceUssMigrationBatchID": "a00NOTINSF0000000"}])],
                    goose_ok=True)
    out = {b["name"]: b for b in _a.discover_batches(cn)}
    check("Goose rows land on the right batch by Salesforce Id (15-char form still matches)",
          out["UMB-0117"]["goose_id"] == "901" and out["UMB-0116"]["goose_id"] == "902", str(out))
    check("  ...and carry Goose's status", out["UMB-0117"]["goose_status"] == "Open"
          and out["UMB-0116"]["goose_status"] == "Canceled")
    check("a Goose batch Salesforce has never heard of is not invented into the list",
          set(out) == {"UMB-0117", "UMB-0116"}, str(sorted(out)))
    sent = " ".join(q for q in cn.sent if "dbo.MigrationBatch" in q)
    check("the discovery query selects only columns the table has",
          "SalesforceUssMigrationBatchID" in sent and "BatchName" not in sent, sent)


def test_goose_errorlog_is_scoped_to_the_batch():
    """v0.22.2: RO 4 counted all 54,358 error rows in the table and blocked RO 5/7/8."""
    print("\nGOOSE ERROR LOG SCOPE (v0.22.2)")
    cols = [{"COLUMN_NAME": n, "DATA_TYPE": "int"} for n in ("ErrorID", "MigrationBatchID", "Status")]
    sf = [("FROM USS_Migration_Batch__c", [{"Id": "aFOVD0000001SdN4AU"}])]
    mb = [("FROM dbo.MigrationBatch", [{"ID": 901, "MigrationID": 5}])]
    ic = ("INFORMATION_SCHEMA", cols)
    ck = _chk("RAN.GOOSE_ERRORLOG")

    cn = RoutedConn(routes=sf, grows=[ic] + mb, gcounts=[("MigrationBatchID = 901", 3), ("GOOSE_ErrorLog", 54358)],
                    goose_ok=True)
    ev = ck.run(cn)
    sql = [q for q in cn.sent if "COUNT_BIG" in q and "GOOSE_ErrorLog" in q]
    check("the count is filtered to this batch's Goose id", sql and "MigrationBatchID = 901" in sql[0], str(sql))
    check("  ...so the answer is this batch's 3, not the table's 54,358", ev.metric and ev.metric.value == 3.0)

    ev = ck.run(RoutedConn(routes=sf, grows=[("INFORMATION_SCHEMA", [{"COLUMN_NAME": "ErrorID"}, {"COLUMN_NAME": "Status"}])],
                           gcounts=[("GOOSE_ErrorLog", 54358)], goose_ok=True))
    check("no batch column: unprovable, never a whole-table failure", bool(ev.unprovable) and not ev.rows)

    ev = ck.run(RoutedConn(routes=[], grows=[ic] + mb, gcounts=[("GOOSE_ErrorLog", 54358)], goose_ok=True))
    check("Salesforce batch Id unresolved: unprovable", bool(ev.unprovable))

    ev = ck.run(RoutedConn(routes=sf, grows=[ic], gcounts=[("GOOSE_ErrorLog", 54358)], goose_ok=True))
    check("batch not in Goose: unprovable", bool(ev.unprovable))

    check("RO 5 async check is a review item, not a blocker (it is org-wide)",
          _chk("RAN.STEP_NOT_FINISHED").severity == model.WARNING)


def test_verification_against_salesforce():
    """v0.23.0: a second opinion on every result -- scope, limits, duplicates, sample re-read, fields."""
    print("\nVERIFY AGAINST SALESFORCE (v0.23.0)")
    import connections as cx, verify, server, snapshot
    from pathlib import Path

    # --- the query ledger on the real Conn
    sent = []
    real_q, real_n = cx.sf_query, cx.sf_count
    cx.sf_query = lambda alias, soql, timeout=180: (sent.append(soql) or
                  ([{"Id": "aFOVD0000001SdN4AU"}] if "USS_Migration_Batch__c" in soql else [{"Id": "x"}] * 3))
    cx.sf_count = lambda alias, soql, timeout=180: (sent.append(soql) or 7)
    try:
        c = cx.Conn({"OrgAlias": "a"}, "UMB-1")
        c.audit_begin("T")
        c.q("SELECT Id FROM Contract WHERE Batch__r.Name = '{BATCH}' LIMIT 3")
        c.n("SELECT COUNT() FROM Order")
        c.sf_batch_id()
        ents = c.audit_end()
    finally:
        cx.sf_query, cx.sf_count = real_q, real_n
    check("the ledger keeps each query a check sent", len(ents) == 2, str(ents))
    check("  ...marks the batch-filtered one as scoped and the bare one as not",
          ents[0]["scoped"] and not ents[1]["scoped"])
    check("  ...and looking up the batch id is NOT recorded (it must not make a check look scoped)",
          not any("USS_Migration_Batch__c" in e["sql"] for e in ents))
    check("  ...the ledger is also kept by check id", "T" in c.audit_log)

    sc, fl = verify._scope_and_limits(ents)
    check("a query that returns exactly its LIMIT is flagged TRUNCATED",
          any(f["code"] == "TRUNCATED" for f in fl), str(fl))
    check("scope: any batch-tied query makes the check BATCH-scoped", sc == "BATCH")
    sc2, _ = verify._scope_and_limits([dict(kind="soql", sql="SELECT Id FROM Order", scoped=False,
                                            rows=3, ms=1, error="")])
    check("scope: no batch-tied query anywhere is ORG-WIDE", sc2 == "ORG-WIDE")

    # --- verify_run on a fake org
    class V:
        audit_log = {}
        def fields(self, o): return {"id", "name", "real__c"}
        def tq(self, soql):
            if "EntityDefinition" in soql:
                return [{"KeyPrefix": "801", "QualifiedApiName": "Order"}]
            if "CustomField" in soql:
                return [{"DeveloperName": "Hidden_One", "NamespacePrefix": "", "TableEnumOrId": "Order"}]
            return []
        def q(self, soql):
            self.asked = soql
            return [{"Id": "801000000000001AAA"}]
    cn = V()
    cn.audit_log = {"A": [dict(kind="soql", sql="SELECT Id FROM Order", scoped=False, rows=5, ms=1, error="")]}
    def mk(cid, fn_src):
        return Check(id=cid, name=cid, stage="pre", sequence=1, sobject="Order", severity=BLOCKER,
                     rule="r", rule_source="s", proves="p", cannot_prove="c",
                     run=lambda c: Evidence(), canary=lambda c: 1)
    ca = mk("A", "")
    ids = ["801000000000001AAA", "801000000000002AAA", "801000000000002AAA"]
    ra = Result(check_id="A", batch="B", verdict=FAIL, evidence_count=3, processed=2,
                evidence_sample=[{"Id": i} for i in ids])
    out = verify.verify_run(cn, [ca], [ra])["A"]
    codes = {f["code"] for f in out["flags"]}
    check("org-wide + duplicate + over-examined + missing sample are all caught",
          {"ORG_WIDE", "DUPLICATE_IDS", "OVER_EXAMINED", "SAMPLE_MISSING"} <= codes, str(codes))
    check("  ...so the status is SUSPECT", out["status"] == "SUSPECT")
    check("  ...the sample was looked up on the object its Id prefix names (Order), not guessed",
          "FROM Order WHERE Id IN" in cn.asked, cn.asked)

    cn.audit_log = {"A": [dict(kind="soql", sql="SELECT Id FROM Order WHERE B = 'x'", scoped=True,
                               rows=1, ms=1, error="")]}
    ok = verify.verify_run(cn, [ca], [Result(check_id="A", batch="B", verdict=FAIL, evidence_count=1,
                          processed=10, evidence_sample=[{"Id": ids[0]}])])["A"]
    check("a scoped failing check whose sample exists is VERIFIED", ok["status"] == "VERIFIED", str(ok))
    p = verify.verify_run(cn, [ca], [Result(check_id="A", batch="B", verdict=PASS)])["A"]
    check("a passing check is never called verified", p["status"] == "")

    # --- schema audit
    def ghost(c):
        return c.q("SELECT Id, Ghost_Field__c, Real__c, Hidden_One__c FROM Order")
    cg = Check(id="G", name="g", stage="pre", sequence=1, sobject="Order", severity=BLOCKER,
               rule="r", rule_source="s", proves="p", cannot_prove="c", run=ghost, canary=lambda c: 1)
    sa = verify.schema_audit(cn, [cg]).get("G", [])
    byc = {f["code"]: f["text"] for f in sa}
    check("a field the org does not have is FIELD_MISSING", "Ghost_Field__c" in byc.get("FIELD_MISSING", ""), str(sa))
    check("  ...a deployed-but-invisible field is FIELD_HIDDEN, not missing",
          "Hidden_One__c" in byc.get("FIELD_HIDDEN", "") and "Hidden_One__c" not in byc.get("FIELD_MISSING", ""))
    check("  ...a visible field raises nothing", "Real__c" not in " ".join(byc.values()))
    pv = verify.verify_run(cn, [cg], [Result(check_id="G", batch="B", verdict=PASS)])["G"]
    check("  ...and a PASS on a missing field is SUSPECT (an empty column reads as clean)",
          pv["status"] == "SUSPECT")

    # --- stored, shown, exported
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.23.0", "a", "", False, "")
    st.save_result(rid, ra); st.finish_run(rid)
    st.save_verification(rid, {"A": out})
    check("verification round-trips through the history db", st.verification(rid)["A"]["status"] == "SUSPECT")
    strip = server.verify_strip(st, "UMB-0117", rid)
    check("the run book carries a one-line strip linking to the details",
          "to treat with caution" in strip and "/verify?run=" in strip, strip)
    page = server.verify_page(st, "UMB-0117", rid)
    check("the verification page lists the flags in words", "Not tied to this batch" in page
          and "Same record counted more than once" in page)
    check("  ...and every query the check sent", "queries this check sent" in page)
    rp = server.records_page(st, "UMB-0117", rid, "A", {})
    check("the records page shows the verdict on its own number", "Treat this number with caution" in rp)
    item = dict(check="A", name="n", step="s", order=2, kind="ISSUE", severity="BLOCKER", records=3,
                examined=2, inverted=False, fix="f", fix_order=2, reason="", phase="")
    sm = dict(blockers=1, review=0, unproven=0, records=3, steps=1, objects=1)
    sec = server.issues_section(st, "UMB-0117", rid, [], [], items=[item], sm=sm)
    main = sec.split("<details class='fold'>")[0]
    check("a number that is not tied to this batch is NOT in the main issue list",
          "<b>n</b>" not in main and "No confirmed issues" in main, main[-300:])
    check("  ...it is folded away with the reason in plain words",
          "Not about this batch, or not confirmed" in sec and "Not tied to this batch" in sec, sec[-500:])
    st.save_verification(rid, {"A": dict(status="VERIFIED", flags=[], scope="BATCH",
                                         samples=[dict(id="x", found=True)])})
    sec2 = server.issues_section(st, "UMB-0117", rid, [], [], items=[item], sm=sm)
    check("  ...a verified one IS in the main list, tagged verified",
          "<b>n</b>" in sec2.split("<details class='fold'>")[0] and "verified" in sec2 and "MUST FIX" in sec2)
    st.save_verification(rid, {})
    check("  ...no 'Checked' column on a run that has no verification",
          ">Checked<" not in server.issues_section(st, "UMB-0117", rid, [], [], items=[item], sm=sm))
    st.save_verification(rid, {"A": out})
    snap = Path(tempfile.mktemp(suffix=".json"))
    snapshot.export_run(st, rid, snap)
    st2 = Store(tempfile.mktemp(suffix=".db")); snapshot.import_run(st2, snap)
    check("verification travels with a saved snapshot", st2.verification(rid).get("A", {}).get("status") == "SUSPECT")
    check("a run without verification says so instead of showing nothing",
          "no verification" in server.verify_page(st2, "UMB-9999", "nope").lower()
          or "no verification" in server.verify_page(Store(tempfile.mktemp(suffix=".db")), "X", "").lower())


def test_predict_counts_records_in_this_batch_and_no_record_limits():
    """v0.23.2: 7,910 'failing' of 1,000 examined was issues, from a 500-row sample, of the OPEN batch."""
    print("\nPREDICT + NO RECORD LIMITS (v0.23.2)")
    import predict as pr, re, pathlib
    ck = _chk("PREDICT.LOAD_FAILURES")
    sf = [("FROM USS_Migration_Batch__c", [{"Id": "aFOVD0000001SdN4AU"}])]
    staged = [{"x": i} for i in range(500)]
    def issues(n):
        return [dict(field="F%d" % k, type="T%d" % k, severity="ERROR", value="v", message="m") for k in range(n)]
    def fake_batch(meta, recs, op="CREATE", blocked=None, nis=14, npat=16):
        per = [dict(index=i, record=r, issues=issues(nis), blocking=True) for i, r in enumerate(recs)]
        if blocked is not None:
            per = per[:blocked]
        pats = [dict(type="T%d" % k, field="F%d" % k, count=1, share=.1, distinct_values=1, example=[], single_value_fix=True)
                for k in range(npat)]
        return dict(records_checked=len(recs), records_blocked=len(per), total_issues=len(per) * nis,
                    patterns=pats, per_record=per, headline="h")
    rd, rb = pr.describe_full, pr.predict_batch
    pr.describe_full = lambda alias, o: {}
    def mkc(status, **k):
        cn = RoutedConn(routes=sf, grows=[("MigrationBatch", [{"BatchStatus": status}]),
                                          ("dbo.vw_QL", staged)], goose_ok=True)
        cn.cfg = {"PredictTargets": {"SBQQ__QuoteLine__c": "vw_QL"}}
        return cn
    try:
        pr.predict_batch = lambda m, r, op="CREATE": fake_batch(m, r, op, blocked=100, nis=14, npat=3)
        cn = mkc("Open"); ev = ck.run(cn)
        check("failing counts RECORDS (100), not issues (1,400)", len(ev.rows) == 100, str(len(ev.rows)))
        check("  ...of all 500 staged rows, so examined is 500", ev.examined == 500, str(ev.examined))
        check("  ...and every staged row is read: no TOP 500 in the query",
              not any("TOP 500" in q for q in cn.sent) and any("FROM dbo.vw_QL" in q for q in cn.sent))
        check("  ...failing can never exceed examined", len(ev.rows) <= ev.examined)

        ev = ck.run(mkc("Closed"))
        check("a batch that is not Open in Goose is not judged by the Open-batch views",
              bool(ev.unprovable) and "not Open" in ev.unprovable and not ev.rows, ev.unprovable)
        cn2 = RoutedConn(routes=[], grows=[], goose_ok=True); cn2.cfg = {"PredictTargets": {"X": "v"}}
        check("batch not resolvable: unprovable, not a finding", bool(ck.run(cn2).unprovable))

        pr.predict_batch = lambda m, r, op="CREATE": fake_batch(m, r, op, nis=14, npat=16)
        ev = ck.run(mkc("Open"))
        check("every row failing for 16 different reasons is NOT counted as 500 failures",
              bool(ev.unprovable) and "different patterns" in ev.unprovable and not ev.rows, ev.unprovable[:160])
    finally:
        pr.describe_full, pr.predict_batch = rd, rb

    src = "".join(pathlib.Path(__file__).with_name(f).read_text(encoding="utf-8")
                  for f in ("checks.py", "server.py", "runner.py"))
    code = re.sub(r"#[^\n]*", "", src)
    check("no check query still carries a record LIMIT (only LIMIT 1 lookups remain)",
          not re.search(r"LIMIT\s+(?!1\b)(\d+|%d)", code.replace("LIMIT 1\"", "")), 
          str(re.findall(r".{30}LIMIT\s+(?!1\b)(?:\d+|%d).{10}", code)[:3]))
    import store as _st
    check("every offending record is kept, not the first 2,000", _st.EVIDENCE_CAP >= 1000000)


def test_ui_numbers_are_in_one_unit_and_counted_once():
    """v0.23.3 audit: 10,039 'failing records' summed records, jobs, staged issues and a marker row."""
    print("\nUI NUMBERS ARE HONEST (v0.23.3)")
    import terms, tally as tal, server, runbook as rb, jobruns
    check("units: a job, a staged row, a log entry and a step are NOT records",
          not any(terms.is_record(c) for c in ("RAN.STEP_NOT_FINISHED", "PREDICT.LOAD_FAILURES",
                                               "LOG.WORKORDER_GENERATION_ERRORS", "RAN.TF_35_CONTRACTS",
                                               "RAN.GOOSE_ERRORLOG")))
    check("  ...and ordinary data checks are", terms.is_record("FSL.DEAD_POLYGONS")
          and terms.is_record("QUOTE.NOT_ORDERED"))

    ids = lambda p, n: [{"Id": "%s%012dAAA" % (p, i)} for i in range(n)]
    pol = ids("a0P", 482)
    def R(cid, verdict, n, rows, processed=0):
        return Result(check_id=cid, batch="UMB-0117", verdict=verdict, reason="r", evidence_count=n,
                      processed=processed, evidence_sample=rows)
    results = [R("FSL.DEAD_POLYGONS", FAIL, 482, pol, 1128),
               R("FSL.DUPLICATE_POLYGONS", FAIL, 482, pol, 1128),      # the SAME 482 records
               R("QUOTE.NOT_ORDERED", FAIL, 1, ids("a0Q", 1), 910),
               R("PREDICT.LOAD_FAILURES", FAIL, 7910, [{"record_index": i} for i in range(50)], 1000),
               R("RAN.STEP_NOT_FINISHED", FAIL, 47, [{"Id": "707%012dAAA" % i} for i in range(47)])]
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.23.3", "a", "", False, "")
    for r in results:
        st.save_result(rid, r)
    st.finish_run(rid)

    class C:
        batch = "UMB-0117"
        def n(self, q): return 4946 if "QuoteLine" in q else 910
    real = jobruns.window_from_stamps
    jobruns.window_from_stamps = lambda c, q: {}
    try:
        rows = tal.collect(C(), results, None, 99)
    finally:
        jobruns.window_from_stamps = real
    by = {r["sobject"]: r for r in rows}
    check("a job count and a staged-row count do not land on an object tile",
          by["SBQQ__QuoteLine__c"]["errors"] == 0 and by["USS_Migration_Batch__c"]["errors"] == 0,
          str({k: v["errors"] for k, v in by.items() if v["errors"]}))

    items = rb.issues(st, "UMB-0117", rid, rb.readiness(st, "UMB-0117", rid), set())
    sm = rb.issue_summary(items, rb.ids_of_factory(st, rid))
    check("headline: the same 482 polygons flagged twice count once", sm["records"] == 483, str(sm["records"]))
    check("  ...(482 polygons + 1 quote), while the naive sum would have been 965",
          sm["records_summed"] == 965, str(sm["records_summed"]))
    check("  ...the 47 jobs and 7,910 staged issues are NOT added in",
          sm["records"] < 7910 and sm["other_units"].get("async jobs") == 47
          and sm["other_units"].get("staged rows") == 7910, str(sm["other_units"]))
    sec = server.issues_section(st, "UMB-0117", rid, rb.readiness(st, "UMB-0117", rid), set())
    main = sec.split("<details class='fold'>")[0]
    check("the page says 483 records need a fix; the others sit under 'Other signals' in their own units",
          "<b>483</b> records need a fix" in main and "47 async jobs" in sec and "7,910 staged rows" in sec
          and "Other signals" in sec and "async jobs" not in main, main[:400])
    check("  ...the same 482 polygons are ONE row, naming the second check",
          main.count("class='ro'") == 2 and "same records also flagged by" in main, main[:700])
    check("  ...and a job/staged row is never labelled a 'failing record'",
          "47 failing record" not in sec and "7,910 failing record" not in sec)

    # a tile whose failing count exceeds its loaded count says so
    st.save_tally(rid, [dict(sequence=90, sobject="SBQQ__QuoteLine__c", label="Quote Lines", loaded=100,
                             state="OK", first="", last="", modified="", errors=250, error_checks="X",
                             note="", produced_at=11, pending=False)])
    band = server.object_band(st, rid)
    check("a tile with more failing than loaded is flagged, not presented as a share",
          "&#9888;" in band and "More failing than loaded" in band, band[:300])
    st.save_tally(rid, [dict(sequence=90, sobject="SBQQ__QuoteLine__c", label="Quote Lines", loaded=100,
                             state="OK", first="", last="", modified="", errors=25, error_checks="X",
                             note="", produced_at=11, pending=False)])
    check("  ...and a normal tile carries no warning", "&#9888;" not in server.object_band(st, rid))

    # run book: a step's failing count excludes jobs / staged rows
    row5 = next(r for r in rb.readiness(st, "UMB-0117", rid) if r["order"] == 5)
    row3 = next(r for r in rb.readiness(st, "UMB-0117", rid) if r["order"] == 3)
    check("RO 3 / RO 5: staged rows and async jobs are not counted as that step's failing records",
          row5["errors"] == 0 and row3["errors"] == 0, "%s %s" % (row5["errors"], row3["errors"]))
    cell = server._count_cell(row5)
    check("  ...and the cell names the unit (async jobs), not 'failing'",
          "async jobs" in cell and ">failing<" not in cell, cell[:300])
    st.close()


def test_hand_done_steps_are_checked_by_their_effect():
    """v0.23.4: a step done by hand leaves no record; the only sign it was skipped is its effect."""
    print("\nSKIPPED-STEP EFFECTS (v0.23.4)")
    import runbook as rb, terms, server
    sf = [("FROM USS_Migration_Batch__c", [{"Id": "aFOVD0000001SdN4AU"}])]
    gap = [{"Id": "0%02d000000000001AAA" % i, "New_Day_of_Week__c": None} for i in range(3)]
    ck = _chk("GOOSE.MP_WEEKDAY_GAP")
    cn = RoutedConn(routes=sf, grows=[("dbo.MigrationBatch mb", [{"ID": 901}]), ("SFDC_MaintenancePlan", gap)],
                    gcounts=[("SFDC_MaintenancePlan", 40)], goose_ok=True)
    r = runner.run_check(ck, cn)
    sql = " ".join(q for q in cn.sent if "SFDC_MaintenancePlan" in q)
    check("RO 37: plans still missing a corrected weekday FAIL the check", r.verdict == FAIL and r.evidence_count == 3, r.verdict)
    check("  ...scoped to this batch's Goose id, using the run book's own columns",
          "MigrationBatchID = 901" in sql and "New_Day_of_Week__c IS NULL" in sql and "New_StartDate IS NULL" in sql, sql[:200])
    check("  ...counted against 40 examined, as records", r.processed == 40 and terms.is_record(ck.id))
    cn2 = RoutedConn(routes=sf, grows=[("dbo.MigrationBatch mb", [{"ID": 901}]), ("SFDC_MaintenancePlan", [])],
                     gcounts=[("SFDC_MaintenancePlan", 40)], goose_ok=True)
    check("  ...nothing left in the gap -> PASS", runner.run_check(ck, cn2).verdict == PASS)
    cn3 = RoutedConn(routes=sf, grows=[("dbo.MigrationBatch mb", [])], goose_ok=True)
    check("  ...batch not in Goose -> UNPROVEN, not a pass", runner.run_check(ck, cn3).verdict == UNPROVEN)

    ck2 = _chk("BATCH.PRESNAPSHOT_FILE")
    files = [{"ContentDocumentId": "069A", "ContentDocument.Title": "notes.csv", "ContentDocument.FileExtension": "csv"}]
    r2 = runner.run_check(ck2, RoutedConn(routes=sf + [("FROM ContentDocumentLink", files)], goose_ok=True))
    check("RO 42: a batch with no JSON file attached -> FAIL (snapshot step probably skipped)",
          r2.verdict == FAIL and "probably not run" in r2.reason, r2.reason[:120])
    files.append({"ContentDocumentId": "069B", "ContentDocument.Title": "pre_snapshot", "ContentDocument.FileExtension": "json",
                  "ContentDocument.CreatedDate": "2026-10-03"})
    r3 = runner.run_check(ck2, RoutedConn(routes=sf + [("FROM ContentDocumentLink", files)], goose_ok=True))
    check("  ...a JSON file present -> PASS", r3.verdict == PASS, r3.reason[:120])
    r4 = runner.run_check(ck2, RoutedConn(routes=[], goose_ok=True))
    check("  ...cannot find the batch -> UNPROVEN", r4.verdict == UNPROVEN)

    R = lambda v: {"verdict": v}
    e = rb.step_effect(49, {"CONTRACT.LASTBILLINGDATE_RULE": R("PASS"), "SUB.FSC_FLAG_COVERAGE": R("FAIL"),
                            "BIQ.COVERAGE": R("PASS")})
    check("TF_60.01: if the flag step's effect is missing, the step reads UNDONE", e["state"] == "UNDONE", str(e))
    e = rb.step_effect(49, {"CONTRACT.LASTBILLINGDATE_RULE": R("PASS"), "SUB.FSC_FLAG_COVERAGE": R("PASS"),
                            "BIQ.COVERAGE": R("PASS")})
    check("  ...all three effects present -> DONE ('nothing left to do')", e["state"] == "DONE")
    e = rb.step_effect(49, {"CONTRACT.LASTBILLINGDATE_RULE": R("PASS"), "SUB.FSC_FLAG_COVERAGE": R("UNPROVEN"),
                            "BIQ.COVERAGE": R("PASS")})
    check("  ...an unproven effect is UNKNOWN, never DONE", e["state"] == "UNKNOWN")
    check("  ...a validation-only step has no effect tag", rb.step_effect(50, {})["state"] == "")
    row = dict(state="READY", effect=dict(state="UNDONE", checks=[("SUB.FSC_FLAG_COVERAGE", "FAIL")]))
    note = server._state_note(row)
    check("the run book says 'work still undone' on that step",
          "work still undone" in note and "SUB.FSC_FLAG_COVERAGE" in note, note)
    check("  ...and never claims the step 'ran' from a passing effect",
          "ran" not in server._state_note(dict(state="READY", effect=dict(state="DONE", checks=[("X", "PASS")]))).split("title=")[0])
    import registry
    ids = {c.id: c for c in registry.all_checks()}
    check("every effect check named in the run book exists",
          all(i in ids for v in rb.EFFECT_CHECKS.values() for i in v))


def test_run_book_export_separates_jobs_from_team_steps():
    """v0.25.0: Informatica / SnapLogic steps on one sheet, the team's own steps on another."""
    print("\nRUN BOOK EXPORT (v0.25.0)")
    import report, runbook as rbk, server, openpyxl
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.25.0", "a", "", False, "")
    st.save_result(rid, Result(check_id="WO.ORDERS_MISSING_WOS", batch="UMB-0117", verdict=FAIL,
        reason="3 Orders have no Work Orders", evidence_count=3, processed=100,
        evidence_sample=[{"Id": "801%012dAAA" % i} for i in range(3)]))
    st.save_result(rid, Result(check_id="RAN.TF_35_CONTRACTS", batch="UMB-0117", verdict=PASS, processed=50,
        evidence_count=0, ran_from="2026-10-03T01:00:00Z", ran_to="2026-10-03T01:20:00Z", run_status="Completed"))
    st.finish_run(rid)
    out = Path(tempfile.mkdtemp())
    p = report.build_runbook(st, "UMB-0117", out, rid)
    wb = openpyxl.load_workbook(p)
    check("the workbook has a sheet for jobs, one for team steps, and the full list",
          wb.sheetnames == ["Summary", "Informatica & SnapLogic", "Our Steps", "Full Run Book"], str(wb.sheetnames))
    def col(ws, n, hdr_row=2):
        return [ws.cell(row=r, column=n).value for r in range(hdr_row + 1, ws.max_row + 1)]
    jobs_ws, our_ws, all_ws = wb["Informatica & SnapLogic"], wb["Our Steps"], wb["Full Run Book"]
    jsys = {str(x).lower() for x in col(jobs_ws, 2)}
    check("the jobs sheet holds only Informatica and SnapLogic steps", jsys <= {"informatica", "snaplogic"} and jsys, str(jsys))
    check("  ...and the team sheet holds none of them",
          not ({str(x).lower() for x in col(our_ws, 3)} & {"informatica", "snaplogic"}))
    n_jobs, n_our, n_all = len(col(jobs_ws, 1)), len(col(our_ws, 1)), len(col(all_ws, 1))
    steps = rbk.steps()
    check("every run book step is on exactly one of the two sheets", n_jobs + n_our == n_all == len(steps),
          "%d + %d vs %d vs %d" % (n_jobs, n_our, n_all, len(steps)))
    check("  ...the numbers match the screen's own definition of a job",
          n_jobs == sum(1 for s_ in steps if rbk.is_job(s_)))
    blob = " ".join(str(c.value) for row in our_ws.iter_rows() for c in row if c.value)
    check("a team step shows its failing count and what is in the way", "3 failing" in blob and "no Work Orders" in blob, blob[:200])
    jb = " ".join(str(c.value) for row in jobs_ws.iter_rows() for c in row if c.value)
    check("a job shows when it ran", "2026-10-03" in jb or "01:00" in jb, jb[:300])
    check("the screen links to the download for the SELECTED batch and run",
          "/runbook.xlsx?run=%s&batch=UMB-0117" % rid in server._filter_bar(rbk.readiness(st, "UMB-0117", rid), rid, "UMB-0117"))
    # a second batch with different results: each export carries its own batch's numbers
    rid2 = new_run_id(); st.start_run(rid2, "UMB-0116", "GATE", "0.25.0", "a", "", False, "")
    st.save_result(rid2, Result(check_id="WO.ORDERS_MISSING_WOS", batch="UMB-0116", verdict=PASS, processed=777))
    st.finish_run(rid2)
    p2 = report.build_runbook(st, "UMB-0116", out, rid2)
    t2 = " ".join(str(c.value) for ws_ in openpyxl.load_workbook(p2) for row in ws_.iter_rows() for c in row if c.value)
    check("exporting another batch gives that batch's results, not the first one's",
          "UMB-0116" in p2.name and "777" in t2 and "3 failing" not in t2 and "UMB-0117" not in t2)
    try:
        report.build_runbook(st, "UMB-NONE", out, ""); raised = False
    except SystemExit:
        raised = True
    check("a batch with no run says so instead of writing an empty file", raised)
    hd = server.header({"KnownBatches": ["UMB-0117"]}, st, "UMB-0117", "")
    check("the header has an always-visible Export run book button for the selected batch",
          "Export run book" in hd and "/runbook.xlsx?run=%s&batch=UMB-0117" % rid in hd, hd[-400:])
    st.close()


def test_sunrise_notice_only_alarms_when_a_check_depends_on_it():
    print("\nSUNRISE NOTICE (v0.25.2)")
    import selftest, connections as cx
    class Cn:
        alias = "x"; goose_server = ""; goose_db = "Goose"; goose_ok = False; sunrise_run = None
        informatica_live = True; informatica_note = "n"; jobs = type("J", (), {"runs": []})()
        batch = ""; workers = 1
        canary_cache = {}
    real = (cx.sf_test, cx.latest_preflight_run)
    cx.sf_test = lambda a: (False, "down"); cx.latest_preflight_run = lambda d="": None
    try:
        res = selftest.run({}, Cn(), "", None)
    finally:
        cx.sf_test, cx.latest_preflight_run = real
    s = next(x for x in res.stages if x["stage"] == "2 sunrise")
    check("with no check depending on the Sunrise output, its absence is not a warning",
          s["status"] == "OK" and "Not used" in s["detail"], str(s))
    check("  ...and the old 'cross-check checks report UNPROVEN' claim is gone", "UNPROVEN" not in s["detail"])
    check("really no check depends on it today", not any(c.needs_sunrise for c in registry.all_checks()))


def test_v18_bindings_and_first_step():
    """Row 33 showed an MP-frequency result under a step called Check_For_Duplicate_Deliveries."""
    print("\nRUN BOOK BINDINGS (v0.18.0)")
    import json, pathlib
    steps = {s["order"]: s["step"] for s in
             json.load(open(pathlib.Path(__file__).with_name("runbook.json")))}
    by_id = {c.id: c for c in registry.all_checks()}
    at33 = [c.id for c in registry.all_checks() if c.runbook_order == 33]
    check("RO 33 is the duplicate-deliveries step", "Duplicate_Deliveries" in steps[33], steps[33])
    check("  ...and the checks bound to it are duplicate checks",
          "WO.DELIVERY_EXCEEDS_BUNDLES" in at33 and "WOLI.EXCEEDS_SOURCE_QUANTITY" in at33, str(at33))
    check("  ...an MP-frequency check no longer sits under a duplicate-deliveries title",
          "LOGIC.MP_ACTIVE_NO_FREQUENCY" not in at33, str(at33))
    check("  ...it moved next to its sibling, the Active-MPs-with-no-Work-Orders step",
          by_id["LOGIC.MP_ACTIVE_NO_FREQUENCY"].runbook_order == by_id["WO.MP_NO_GENERATION"].runbook_order)
    new = ["WO.DELIVERY_EXCEEDS_BUNDLES", "WOLI.EXCEEDS_SOURCE_QUANTITY", "CONTRACT.DUPLICATE_PER_ORDER",
           "FSL.DUPLICATE_POLYGONS", "LOG.WORKORDER_GENERATION_ERRORS", "GOOSE.BATCH_STATUS"]
    check("every new check is bound to a run book step that exists",
          all(by_id[i].runbook_order in steps for i in new), str([(i, by_id[i].runbook_order) for i in new]))
    check("none of the review-list checks BLOCK a later step (they are exceptions, not stoppers)",
          all(not by_id[i].blocks for i in new if by_id[i].severity != BLOCKER), "")
    check("the Goose batch check is bound to the run book's own PRE-FLIGHT row (RO 1)",
          by_id["GOOSE.BATCH_STATUS"].runbook_order == 1 and "PRE-FLIGHT" in steps[1].upper(), steps[1][:60])
    check("  ...and runs first", registry.all_checks()[0].id == "GOOSE.BATCH_STATUS")


def test_cli_errors_keep_the_part_that_names_the_problem():
    """A real run showed `tus__c' on entity 'Billing_Impacts_Queue__c'` where the column belonged."""
    print("\nCLI ERROR TEXT (v0.18.0)")
    import json, connections as cx
    msg = ("\nSELECT Id, Name, Status__c, Charge_Type__c, Effective_Date__c, Parent_USS_Order__r."
           "ContractNumber FROM Billing_Impacts_Queue__c WHERE Parent_USS_Order__r.USS_Migration_"
           "Batch__r.Name = 'UMB-0116' AND Status__c = 'Error'\n                    ^\nERROR at Row:1:"
           "Column:18\nNo such column 'Status__c' on entity 'Billing_Impacts_Queue__c'. If you are "
           "attempting to use a custom field, be sure to append the '__c' after the custom field "
           "name. Please reference your WSDL or the describe call for the appropriate names.")
    out = json.dumps({"status": 1, "name": "INVALID_FIELD", "message": msg,
                      "stack": "INVALID_FIELD: " + msg + "\n    at someFrame (file.js:1:1)" * 120,
                      "exitCode": 1, "warnings": []})
    check("the fixture is long enough to trigger the old tail-slice (guards the test itself)",
          len(out) > 3000, str(len(out)))
    check("the OLD behaviour (last 3000 chars, then the runner's first 300) lost the column name",
          "Status__c" not in out[-3000:][:300], out[-3000:][:120])
    t = cx.cli_error_text(out, "")
    check("the new text names the column", "Status__c" in t and "No such column" in t, t[:120])
    check("  ...names the object", "Billing_Impacts_Queue__c" in t)
    check("  ...keeps the error name friendly_sf_error() matches on", "INVALID_FIELD" in t)
    check("  ...and drops the echoed query", "SELECT Id, Name" not in t)
    check("  ...so the 300 characters the runner keeps are the useful ones",
          "Status__c" in t[:300], t[:300])
    check("  ...and the friendly translation still fires",
          cx.friendly_sf_error(t).startswith("A field in a query does not exist"))
    long_plain = "x" * 1500 + "THE-REAL-ERROR" + "y" * 1500
    t2 = cx.cli_error_text(long_plain, "")
    check("non-JSON output keeps BOTH ends, not just the tail", t2.startswith("xxx") and t2.endswith("yyy") and len(t2) < 800)
    check("short output is returned whole", cx.cli_error_text("boom", "") == "boom")
    src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "connections.py")).read()
    check("no call site still tail-slices a CLI error ([-3000:] / [-2000:])",
          "[-3000:]" not in src and "[-2000:]" not in src)
    check("  ...all three CLI error sites go through cli_error_text",
          src.count("SalesforceError(cli_error_text(") == 3, str(src.count("SalesforceError(cli_error_text(")))



def test_informatica_live_is_read_only_by_construction():
    """
    The adapter must never be able to START a taskflow. tf_90a deletes WorkOrders and
    MaintenancePlans BEFORE it notifies -- on 2026-10-02 it destroyed 81 records across
    11 runs. A pre-flight monitor that can launch taskflows is not a monitor.
    """
    print("\nINFORMATICA LIVE: READ ONLY BY CONSTRUCTION")
    import informatica as ia, re, pathlib as _pl, json as _json
    src = _pl.Path(ia.__file__).read_text(encoding="utf-8")
    code = re.sub(r'""".*?"""', "", src, flags=re.S)          # strip docstrings
    code = re.sub(r"#[^\n]*", "", code)                       # strip comments
    # drop the FORBIDDEN declaration itself -- naming them there is the point of the test
    code = re.sub(r"^FORBIDDEN\s*=\s*\([^)]*\)", "", code, flags=re.M | re.S)
    for fn in ("start_taskflow", "run_and_wait", "_invoke_advanced_taskflow"):
        check("adapter never calls %s" % fn, fn not in code)
    check("  ...and the three are declared so this test cannot drift",
          set(ia.FORBIDDEN) == {"start_taskflow", "run_and_wait", "_invoke_advanced_taskflow"})
    check("no HTTP stack of its own -- Sunrise's plumbing only",
          "urlopen" not in code and "http.client" not in code and "requests." not in code)
    # credential handling is DELEGATED to Sunrise -- this module must never touch the
    # environment or hold a value itself, so there is nowhere for a secret to leak.
    check("never reads the environment itself",
          "os.environ" not in code and "getenv" not in code)
    check("  ...and never imports os at all", not re.search(r"^import os\b", code, re.M))

    # config carries NAMES, never secrets
    cfg = _json.loads((_pl.Path(__file__).resolve().parent.parent / "config.json")
                      .read_text(encoding="utf-8-sig"))
    st = ia.state_from_cfg(cfg)
    check("state passed to Sunrise holds only env var names and locations",
          all(k.startswith("Informatica") for k in st), str(sorted(st)))
    check("  ...and no value looks like a secret",
          not any(len(str(v)) > 12 and " " not in str(v) and "://" not in str(v)
                  and not str(v).startswith("INFORMATICA_") for v in st.values()),
          str(st))


def test_informatica_live_degrades_without_credentials():
    print("\nINFORMATICA LIVE: DEGRADES QUIETLY")
    import connections as cx2, time
    t0 = time.time()
    rows, note = cx2.informatica_live_rows({"SunriseAppDir": "/definitely/not/here"})
    check("no Sunrise -> no rows, no exception", rows == [])
    check("  ...and it is fast (no network attempt)", time.time() - t0 < 2.0,
          "%.2fs" % (time.time() - t0))
    check("  ...and says what to fix", "SunriseAppDir" in note)
    rows, note = cx2.informatica_live_rows({"InformaticaLive": "false"})
    check("switched off is honoured", rows == [] and "switched off" in note.lower())


def test_informatica_live_read_against_a_scripted_session():
    """The live path end to end, with Sunrise's module replaced by a recorder."""
    print("\nINFORMATICA LIVE: SCRIPTED SESSION")
    import informatica as ia, types
    saved_il, saved_sess = ia._IL, ia._SESSION
    try:
        asked = []

        fake = types.SimpleNamespace()
        fake.credentials = lambda state: ("someone", "secret")
        fake.login = lambda state: {"session_id": "SID", "server_url": "https://pod.example/saas",
                                    "username": "someone"}
        fake._headers = lambda s: {"icSessionId": s["session_id"]}

        def _req(url, method="GET", headers=None, payload=None, timeout=45):
            asked.append(url)
            if "rowLimit" in url:
                raise RuntimeError("this pod rejects rowLimit")   # force the fallback
            return 200, {"activityLogEntry": [
                {"taskName": "tf_35_Activate_FSL_Order", "state": "FAILED",
                 "startTime": "2026-10-02T20:17:04Z", "endTime": "2026-10-02T20:20:56Z",
                 "runId": "36510", "successRows": 5751, "failedRows": 0}]}
        fake._json_request = _req

        ia._IL, ia._SESSION = fake, None
        rows = ia.recent_runs({"InformaticaProject": "p"}, limit=50)
        check("a run is read from the activity log", len(rows) == 1, str(len(rows)))
        check("  ...the rowLimit form is tried first", "rowLimit=50" in asked[0])
        check("  ...and a pod that rejects it falls back to the bare resource",
              len(asked) == 2 and "rowLimit" not in asked[1])

        import jobruns
        h = jobruns.JobHistory("", live_rows=rows)
        f = h.find("TF_35_Activate_FSL_Order")
        check("JobHistory resolves the step from the LIVE row", f is not None)
        check("  ...and marks its provenance", f and f["source"] == "live API", str(f and f["source"]))
        check("  ...with the real status and window",
              f and f["status"] == "FAILED" and f["ended"].startswith("2026-10-02T20:20"))
        check("JobHistory.live is true", h.live)

        # live wins over a stale captured row for the same step
        stale = dict(f, status="SUCCESS", source="old_file.json", started="2026-09-01T00:00:00Z")
        h2 = jobruns.JobHistory("", live_rows=rows)
        h2.runs = h2.runs + [stale]
        check("a stale captured row cannot override the live one",
              h2.find("TF_35_Activate_FSL_Order")["source"] == "live API")

        # one session only, however many reads
        ia._SESSION = None
        logins = []
        fake.login = lambda state: (logins.append(1) or
                                    {"session_id": "SID", "server_url": "https://pod.example/saas",
                                     "username": "someone"})
        ia.recent_runs({}); ia.recent_runs({}); ia.recent_runs({})
        check("three reads share one login", len(logins) == 1, "%d logins" % len(logins))
        ia.reset_session()
        ia.recent_runs({})
        check("  ...and reset_session forces a fresh one", len(logins) == 2)

        # a nameless entry is skipped, never guessed at
        n = jobruns.live_informatica_runs([{"state": "SUCCESS"}, {"taskName": "tf_99_Finish"}])
        check("an entry with no readable name is skipped, not guessed", len(n) == 1)
    finally:
        ia._IL, ia._SESSION = saved_il, saved_sess

def test_headline_and_more_menu():
    print("\nHEADLINE AND MORE MENU (v0.26.0)")
    import server, runbook as rbk
    check("no run book rows -> no headline", server.headline([], {"records": 0}) == "")
    real = rbk.progress
    base = dict(current=15, current_step="Load X", jobs_done=3, jobs_total=9, blocked_at=None)
    try:
        rbk.progress = lambda rows: dict(base, blocked_at=15)
        h = server.headline([1], {"records": 12})
        check("blocked: says where it stopped and the count",
              "Stopped at <b>RO 15</b>" in h and "<b>12</b> failing record(s)" in h and "bad" in h, h)
        rbk.progress = lambda rows: dict(base)
        h = server.headline([1], {"records": 0})
        check("clear: says so, no failing records", "Clear through <b>RO 15</b>" in h
              and "no failing records found" in h and "ok" in h, h)
        h = server.headline([1], {"records": 3})
        check("records failing without a block is not called clear", "Clear through" not in h, h)
    finally:
        rbk.progress = real
    d = tempfile.mkdtemp()
    st = Store(os.path.join(d, "t.db"))
    hd = server.header({"KnownBatches": ["UMB-0117"]}, st, "UMB-0117")
    check("More menu holds the rarely used buttons, Run checks and Export stay outside it",
          "moremenu" in hd and hd.index("Run checks") < hd.index("moremenu") <
          hd.index("Self-test") < hd.index("</details>") < hd.index("Export run book"), hd[:400])


def test_record_count_cannot_hold_the_run():
    print("\nRECORD COUNT TIME LIMIT (v0.26.1)")
    import tally as tal, time
    class Slow:
        batch = "B"
        def q(self, soql):
            if "FROM OrderItem" in soql:
                time.sleep(3)
            return [{"c": 5, "mn": "", "mx": "", "lm": ""}]
        def n(self, soql):
            return 5
    old = tal.TALLY_SECONDS
    tal.TALLY_SECONDS = 1
    seen = []
    try:
        t0 = time.time()
        rows = tal.collect(Slow(), [], seen.append, reached_ro=200)
        el = time.time() - t0
    finally:
        tal.TALLY_SECONDS = old
    by = {r["sobject"]: r for r in rows}
    check("a count that does not answer is reported ERROR with loaded=None, never 0",
          by["OrderItem"]["state"] == "ERROR" and by["OrderItem"]["loaded"] is None
          and "not zero" in by["OrderItem"]["note"], str(by["OrderItem"]))
    check("the other objects still count", by["Account"]["loaded"] == 5 and by["Order"]["loaded"] == 5)
    check("the run is not held up by the slow one", el < 2.8, "%.1fs" % el)
    check("deep tables use a semi-join, same rows, easier for Salesforce to plan",
          all("IN (SELECT Id FROM" in q for _, o, _, q in tal.TALLY
              if o in ("OrderItem", "SBQQ__Subscription__c", "WorkOrderLineItem", "ServiceAppointment")))


def test_issues_export_one_tab_per_issue():
    print("\nISSUES EXPORT (v0.27.0)")
    import report, openpyxl, registry
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.27.0", "a", "", False, "")
    ids = ["801%012dAAA" % i for i in range(3)]
    st.save_result(rid, Result(check_id="WO.ORDERS_MISSING_WOS", batch="UMB-0117", verdict=FAIL,
        reason="3 Orders have no Work Orders", evidence_count=3, processed=100,
        evidence_sample=[{"Id": i, "Status": "Activated"} for i in ids]))
    st.save_result(rid, Result(check_id="PREDICT.LOAD_FAILURES", batch="UMB-0117", verdict=FAIL,
        reason="1 staged row blocked", evidence_count=1, processed=9,
        evidence_sample=[{"record_index": 4, "source_id": "LEG-77", "issues": "Name (REQUIRED)", "failed_values": "Name = ''", "why": "Name is required"}]))
    st.save_result(rid, Result(check_id="BIQ.COVERAGE", batch="UMB-0117", verdict=UNPROVEN, reason="x"))
    st.finish_run(rid)
    chk = registry.by_id("WO.ORDERS_MISSING_WOS")
    class C:
        batch = "UMB-0117"
        def fields(self, o): return {"legacy_id__c", "name", "unrelated__c"}
        def q(self, soql):
            assert "legacy_id__c" in soql and "FROM %s" % chk.sobject in soql
            return [{"Id": i, "legacy_id__c": "LEG-%d" % k} for k, i in enumerate(ids)]
    cfg = {"InstanceUrl": "https://x.lightning.force.com"}
    p = report.build_issues(st, "UMB-0117", Path(tempfile.mkdtemp()), rid, cfg, C())
    wb = openpyxl.load_workbook(p)
    check("Summary first, then one tab per FAILING check (the unproven one gets none)",
          wb.sheetnames[0] == "Summary" and len(wb.sheetnames) == 3, str(wb.sheetnames))
    tab = next(n for n in wb.sheetnames if n != "Summary" and wb[n].cell(row=3, column=2).value == "WO.ORDERS_MISSING_WOS")
    ws = wb[tab]
    top = {ws.cell(row=r, column=1).value: ws.cell(row=r, column=2).value for r in range(1, 12)}
    check("each tab is headed by its run book step and the issue", "RO" in str(top.get("Run book step")) and top.get("Check") == "WO.ORDERS_MISSING_WOS", str(top))
    hdr = next(r for r in range(1, 20) if ws.cell(row=r, column=1).value == "Id")
    check("Salesforce Id first, then the legacy Id", ws.cell(row=hdr, column=2).value == "Legacy: legacy_id__c")
    check("the Salesforce Id is a hyperlink to the record", ws.cell(row=hdr + 1, column=1).hyperlink is not None
          and ids[0] in ws.cell(row=hdr + 1, column=1).hyperlink.target)
    check("the legacy Id is filled in per record", [ws.cell(row=hdr + 1 + k, column=2).value for k in range(3)] == ["LEG-0", "LEG-1", "LEG-2"])
    check("every failing record is listed", ws.max_row - hdr == 3)
    labels = [ws.cell(row=r, column=1).value for r in range(1, hdr)]
    check("each tab states the reason and the logic behind the rule",
          all(x in labels for x in ("Why it failed", "Rule (the logic)", "Rule comes from", "What this proves", "What it cannot prove")), str(labels))
    check("a record row says why it failed", "Why it failed" in [ws.cell(row=hdr, column=c_).value for c_ in range(1, 8)])
    check("the source values the check read are on the row", "Status" in [ws.cell(row=hdr, column=c_).value for c_ in range(1, 8)])
    pw = next(wb[n] for n in wb.sheetnames if n != "Summary" and wb[n].cell(row=3, column=2).value == "PREDICT.LOAD_FAILURES")
    check("a staged-row tab carries the source Id", "LEG-77" in " ".join(str(c.value) for row in pw.iter_rows() for c in row if c.value))
    sm = wb["Summary"]
    check("the Summary links to each tab", sm.cell(row=3, column=1).hyperlink is not None)
    p2 = report.build_issues(st, "UMB-0117", Path(tempfile.mkdtemp()), rid, cfg, None)
    check("with no connection it still exports (no legacy column)", len(openpyxl.load_workbook(p2).sheetnames) == 3)


def test_full_selftest_only_when_chosen():
    print("\nSELF-TEST ONLY WHEN CHOSEN (v0.28.0)")
    import selftest, connections as cx, actions
    calls = {"fields": 0, "canary": 0}
    class Cn:
        alias = "x"; goose_server = ""; goose_db = "Goose"; goose_ok = False; sunrise_run = None
        informatica_live = True; informatica_note = "n"; jobs = type("J", (), {"runs": []})()
        batch = "B"; workers = 1
        canary_cache = {}
        def q(self, soql): return [{"Id": "a0X000000000001", "Name": "B", "Batch_Status__c": "Processing"}]
        def fields(self, o): calls["fields"] += 1; return set()
        def has_field(self, f): calls["fields"] += 1; return True
    real = (cx.sf_test, cx.latest_preflight_run, cx.parallel)
    cx.sf_test = lambda a: (True, "ok"); cx.latest_preflight_run = lambda d="": None
    cx.parallel = lambda fn, items, w=0: [fn(i) for i in items]
    import registry as reg
    olds = {c.id: c.canary for c in reg.all_checks()}
    try:
        for c in reg.all_checks():
            if c.canary is not None:
                object.__setattr__(c, "canary", (lambda cid: (lambda conn: calls.__setitem__("canary", calls["canary"] + 1) or 1))(c.id))
        q = selftest.run({}, Cn(), "B", None, quick=True)
        qn = dict(calls)
        calls.update(fields=0, canary=0)
        f = selftest.run({}, Cn(), "B", None, quick=False)
    finally:
        cx.sf_test, cx.latest_preflight_run, cx.parallel = real
        for c in reg.all_checks():
            object.__setattr__(c, "canary", olds[c.id])
    names = [x["stage"] for x in q.stages]
    check("a quick run still checks registry, connections and the batch",
          "1 registry" in names and "2 salesforce" in names and "3 batch scope" in names, str(names))
    check("  ...but does no field describes and no canaries", qn == {"fields": 0, "canary": 0}, str(qn))
    check("the full self-test still does both", calls["fields"] > 0 and calls["canary"] > 0, str(calls))
    check("  ...and has the schema and canary stages", any(x["stage"] == "4 schema" for x in f.stages)
          and any(x["stage"] == "6 canaries" for x in f.stages))
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth)
    check("nothing remembered before a full self-test", st.last_selftest() == ("", []))
    st.save_last_selftest(f.stages)
    taken, old = st.last_selftest()
    check("a full self-test is remembered so a run can show it", taken and any(x["stage"] == "6 canaries" for x in old))
    import inspect
    src = inspect.getsource(actions.run_gate)
    check("a run is quick unless config.json asks for the full self-test",
          "quick=not full" in src and 'cfg.get("FullSelfTestOnRun")' in src)


def test_selftest_has_its_own_page_and_settings():
    print("\nSELF-TEST PAGE (v0.29.0)")
    import selfpage, actions, json as _json
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth)
    stages = [dict(stage="1 registry", status="OK", detail="59 checks"),
              dict(stage="2 goose", status="DEGRADED", detail="No GooseServer configured."),
              dict(stage="4 schema", status="DEGRADED", detail="absent or FLS-hidden: Account.USF_Department_Code__c"),
              dict(stage="6 canaries", status="OK", detail="all canaries returned rows")]
    st.save_last_selftest(stages, full=True)
    cfgp = Path(tempfile.mkdtemp()) / "config.json"
    cfgp.write_text(_json.dumps({"OrgAlias": "A", "Workers": 6, "_note": "keep me"}), encoding="utf-8")
    cfg = _json.loads(cfgp.read_text())
    h = selfpage.render(cfg, st)
    check("the page shows each stage and says how many need attention", "2</b> of 4 stage(s) need attention" in h and "Account.USF_Department_Code__c" in h)
    check("a problem with a setting shows that setting next to it", "name='cfg_GooseServer'" in h.split("2 goose")[1].split("</details>")[0])
    check("a field-permission problem says an admin must fix it, not offer a setting",
          "ask a Salesforce admin" in h and "cfg_OrgAlias" not in h.split("4 schema")[1].split("</details>")[0])
    check("a healthy stage is folded away", "<details class='fold stg ok'>" in h)
    ch, er = selfpage.apply_config(cfg, cfgp, {"cfg_GooseServer": ["SQL9"], "cfg_Workers": ["8"],
                                              "cfg_LegacyIdFields": ["Account=Legacy_Id__c\nContact=A__c,B__c"]})
    disk = _json.loads(cfgp.read_text())
    check("saving writes config.json, keeps other keys, and updates the running config",
          disk["GooseServer"] == "SQL9" and disk["Workers"] == 8 and disk["_note"] == "keep me"
          and cfg["Workers"] == 8 and disk["LegacyIdFields"]["Contact"] == ["A__c", "B__c"] and not er, str((disk, er)))
    check("  ...and keeps a .bak of the old file", cfgp.with_suffix(".json.bak").is_file())
    cfg2 = dict(cfg)
    ch2, er2 = selfpage.apply_config(cfg2, cfgp, {"cfg_Workers": ["99"], "cfg_InstanceUrl": ["http://x"], "cfg_GooseServer": ["BAD"]})
    check("bad values are refused with a reason and nothing is written",
          len(er2) == 2 and _json.loads(cfgp.read_text())["GooseServer"] == "SQL9", str(er2))
    check("unknown keys cannot be set", selfpage.apply_config(dict(cfg), cfgp, {"cfg_DbPath": ["x.db"]})[0] == [])
    # the run log no longer carries self-test output
    class FC: alias = "x"; batch = ""; goose_ok = False
    _stages = stages
    class FS:
        ok = True
        stages = _stages
    rc, ru = actions.cx.Conn, actions.st_mod.run
    ob = actions.bind
    actions.cx.Conn = lambda c, b: FC(); actions.st_mod.run = lambda *a, **k: FS(); actions.bind = lambda c, s=None: True
    try:
        quiet, loud = [], []
        actions.run_selftest({}, st, "B", lambda m, *a: quiet.append(str(m)), quick=True, quiet=True)
        actions.run_selftest({}, st, "B", lambda m, *a: loud.append(str(m)))
    finally:
        actions.cx.Conn, actions.st_mod.run, actions.bind = rc, ru, ob
    qj = " ".join(quiet)
    check("a run's log has no self-test stage lines", "DEGRADED" not in qj and "self-test" not in qj.lower(), qj)
    check("the Self-test button logs one summary line pointing at the page",
          len(loud) >= 1 and "2 need attention" in " ".join(loud) and "DEGRADED" not in " ".join(loud), str(loud))
    check("a quick run keeps the last full test's schema lines", any(x["stage"] == "4 schema" for x in st.last_selftest()[1]))


def test_mp_check_says_why_a_plan_was_flagged():
    print("\nMP NO-GENERATION (v0.30.0, rule fixed v0.32.0)")
    chk = _chk("WO.MP_NO_GENERATION")
    mps = [{"Id": "1MP%012dAAA" % i, "MaintenancePlanNumber": "MP-%d" % i, "Active__c": True,
            "Contract__c": "800%012dAAA" % i} for i in range(4)]
    cn = RoutedConn(routes=[
        ("SELECT MaintenancePlanId, IsGeneratedFromMaintenancePlan FROM WorkOrder",
         [{"MaintenancePlanId": mps[0]["Id"], "IsGeneratedFromMaintenancePlan": False}] * 2 +
         [{"MaintenancePlanId": mps[3]["Id"], "IsGeneratedFromMaintenancePlan": True}]),
        ("GROUP BY", [{"k": mps[1]["Contract__c"], "n": 5}]),
        ("FROM MaintenancePlan", mps)],
        fields={"WorkOrder.Contract__c", "MaintenancePlan.Active__c"})
    ev = chk.run(cn)
    by = {r["MaintenancePlanNumber"]: r for r in ev.rows}
    check("a plan with Work Orders naming it is covered even when none is flagged generated (the UMB-0117 case)",
          "MP-0" not in by and "MP-3" not in by and sorted(by) == ["MP-1", "MP-2"], str(sorted(by)))
    check("Work Orders only on the Contract are called out",
          by["MP-1"]["work_orders_on_its_contract"] == 5 and "linked to the Contract" in by["MP-1"]["likely_cause"])
    check("nothing anywhere says so", by["MP-2"]["likely_cause"] == "no Work Order on the plan or on its Contract")
    check("the note gives the breakdown", "Breakdown:" in ev.note and "2 of 4" in ev.note, ev.note)
    check("processed counts the plans examined", ev.processed == 4 and ev.metric.denominator == 4)
    big = [{"Id": "1MP%012dAAA" % i, "MaintenancePlanNumber": "MP-%d" % i, "Active__c": True,
            "Contract__c": "800%012dAAA" % i} for i in range(25)]
    r = runner.run_check(chk, RoutedConn(routes=[("FROM MaintenancePlan", big)], counts=[("FROM MaintenancePlan", 25)],
                                         fields={"WorkOrder.Contract__c", "MaintenancePlan.Active__c"}))
    check("every plan failing is a wrong rule, not 25 findings -> UNPROVEN", r.verdict == UNPROVEN and "rule" in r.reason, r.verdict)


def test_guide_checks_and_ancillary_fix():
    print("\nGUIDE CHECKS + ANCILLARY FIX (v0.31.0)")
    import terms
    # RO 33: add-ons sharing a bundle's parent line are judged against their own subscription
    chk = _chk("WOLI.EXCEEDS_SOURCE_QUANTITY")
    F = {"WorkOrderLineItem.Order_Line_Item__c", "WorkOrderLineItem.USF_Confirmed_Quantity__c"}
    groups = [{"WorkOrderId": "WO1", "Order_Line_Item__c": "OI1", "n": 2},
              {"WorkOrderId": "WO2", "Order_Line_Item__c": "OI2", "n": 2}]
    def w(i, wo, oi, src, qty, sub, sq):
        return {"Id": i, "WorkOrderId": wo, "Order_Line_Item__c": oi, "Order_Line_Item__r.Quantity": src,
                "USF_Confirmed_Quantity__c": qty, "Subscription__c": sub, "Subscription__r.SBQQ__Quantity__c": sq}
    detail = [w("L1", "WO1", "OI1", 1, 1, "S_restroom", 1), w("L2", "WO1", "OI1", 1, 1, "S_sanitizer", 1),
              w("L3", "WO2", "OI2", 1, 1, "S_same", 1), w("L4", "WO2", "OI2", 1, 1, "S_same", 1)]
    ev = chk.run(RoutedConn(routes=[("GROUP BY WorkOrderId", groups),
                                      ("FROM WorkOrderLineItem WHERE WorkOrderId IN", detail)],
                              counts=[("Order_Line_Item__c != null", 4)], fields=F))
    flagged = sorted(r["work_order_id"] for r in ev.rows)
    check("a restroom and its hand sanitizer (1 + 1 on a parent line of 1) are NOT flagged", "WO1" not in flagged, str(flagged))
    check("  ...the same subscription delivered twice still is", flagged == ["WO2"] and ev.rows[0]["subscription_id"] == "S_same", str(ev.rows))
    check("  ...and the note says add-ons were judged on their own", "different products" in ev.note, ev.note)
    # Goose: customer-owned flag
    sf = [("FROM USS_Migration_Batch__c", [{"Id": "aFOVD0000001SdN4AU"}])]
    def gc(stg_vals, ql_vals):
        cols = [{"COLUMN_NAME": "IsCustomerOwned"}, {"COLUMN_NAME": "MigrationBatchID"}, {"COLUMN_NAME": "CustomerOwned__c"}]
        return RoutedConn(routes=sf, goose_ok=True, grows=[
            ("dbo.MigrationBatch mb", [{"ID": 901}]), ("INFORMATION_SCHEMA", cols),
            ("FROM Goose.dbo.SFDC_Quote_Line", ql_vals), ("FROM Goose.dbo.STG_", stg_vals)],
            gcounts=[("STG_OrderLineItem", 500)])
    ck = _chk("GOOSE.CUSTOMER_OWNED_FLAG")
    r = runner.run_check(ck, gc([{"V": 0, "N": 500}], [{"V": 0, "N": 500}]))
    check("flag 0 on every staged row -> FAIL, with the hardcode wording", r.verdict == FAIL and "hardcoded" in r.reason.lower(), r.reason[:160])
    r = runner.run_check(ck, gc([{"V": 0, "N": 480}, {"V": 1, "N": 20}], [{"V": 1, "N": 20}]))
    check("  ...mixed values -> PASS", r.verdict == PASS, r.verdict)
    check("  ...counted as staged value groups, not records", not terms.is_record(ck.id))
    # Goose: MP with no account
    ck = _chk("GOOSE.MP_NULL_ACCOUNT")
    rows = [{"Id": "1MP%012dAAA" % i, "StartDate": "2026-10-01", "SFDC_OrderID": 7, "ShouldBeAccountID": "A%d" % i} for i in range(2)]
    cn = RoutedConn(routes=sf, goose_ok=True, grows=[("dbo.MigrationBatch mb", [{"ID": 901}]), ("SFDC_MaintenancePlan", rows)],
                    gcounts=[("SFDC_MaintenancePlan", 30)])
    r = runner.run_check(ck, cn)
    check("MPs with no Account in Goose -> FAIL, scoped to the batch, counted as records",
          r.verdict == FAIL and r.evidence_count == 2 and r.processed == 30 and terms.is_record(ck.id)
          and any("MigrationBatchID = 901" in q for q in cn.sent), r.verdict)
    check("  ...and says the theory is not proven", "NOT proven" in r.reason or "not proven" in r.reason.lower(), r.reason[:200])
    # Salesforce re-verification
    mp = [{"Id": "1MP000000000001AAA", "MaintenancePlanNumber": "MP-1", "AccountId": None}]
    r = runner.run_check(_chk("MP.SF_NULL_ACCOUNT"), RoutedConn(routes=sf + [("AccountId = null", mp)], counts=[("FROM MaintenancePlan", 9)]))
    check("Salesforce re-check: a plan with no Account -> FAIL", r.verdict == FAIL and r.processed == 9, r.verdict)
    r = runner.run_check(_chk("MP.SF_NULL_ACCOUNT"), RoutedConn(routes=sf, counts=[("FROM MaintenancePlan", 9)]))
    check("  ...none -> PASS", r.verdict == PASS, r.verdict)
    r = runner.run_check(_chk("MP.SF_WEEKDAY_GAP"), RoutedConn(routes=sf + [("Day_of_Week__c = null", mp)], counts=[("FROM MaintenancePlan", 9)],
                                                               fields={"MaintenancePlan.Day_of_Week__c"}))
    check("Salesforce re-check: weekday missing -> FAIL", r.verdict == FAIL, r.verdict)
    r = runner.run_check(_chk("MP.SF_WEEKDAY_GAP"), RoutedConn(routes=sf, counts=[("FROM MaintenancePlan", 9)], fields=set()))
    check("  ...field hidden -> UNPROVEN, not a pass", r.verdict == UNPROVEN, r.verdict)
    r = runner.run_check(_chk("QL.SF_CUSTOMER_OWNED"), RoutedConn(routes=sf + [("GROUP BY CustomerOwned__c", [{"v": False, "n": 40}])],
                         counts=[("SBQQ__QuoteLine__c", 40)], fields={"SBQQ__QuoteLine__c.CustomerOwned__c"}))
    check("Salesforce re-check: no Quote Line customer-owned -> FAIL as a value group", r.verdict == FAIL and not terms.is_record("QL.SF_CUSTOMER_OWNED"), r.verdict)
    r = runner.run_check(_chk("QL.SF_CUSTOMER_OWNED"), RoutedConn(routes=sf + [("GROUP BY CustomerOwned__c", [{"v": False, "n": 40}, {"v": True, "n": 3}])],
                         counts=[("SBQQ__QuoteLine__c", 43)], fields={"SBQQ__QuoteLine__c.CustomerOwned__c"}))
    check("  ...some true -> PASS", r.verdict == PASS, r.verdict)


def test_audit_fixes_nothing_falsely_reported():
    print("\nAUDIT FIXES (v0.32.0)")
    import terms, runbook as rbk, predict as pr
    sf = [("FROM USS_Migration_Batch__c", [{"Id": "aFOVD0000001SdN4AU"}])]
    # RO 2: ordinary records with no batch link are context, not blockers, and hold nothing up
    pth = tempfile.mktemp(suffix=".db"); st = Store(pth); rid = new_run_id()
    st.start_run(rid, "UMB-0117", "GATE", "0.32.0", "a", "", False, "")
    for cid in ("SCOPE.WO_NO_CONTRACT", "SCOPE.CONTRACT_NO_BATCH"):
        st.save_result(rid, Result(check_id=cid, batch="UMB-0117", verdict=FAIL, reason="x", evidence_count=5, processed=100))
    st.finish_run(rid)
    rows = {r["order"]: r for r in rbk.readiness(st, "UMB-0117")}
    check("WorkOrders with no Contract / Contracts with no batch no longer BLOCK or HOLD anything",
          rows[2]["state"] != "BLOCKED" and rows[25]["state"] != "HELD" and rows[37]["state"] != "HELD", rows[2]["state"] + "/" + rows[25]["state"])
    check("  ...they are notes", _chk("SCOPE.WO_NO_CONTRACT").severity == "INFO" and _chk("SCOPE.CONTRACT_NO_BATCH").severity == "INFO")
    # Orders missing Work Orders: by the Order link, Activated only
    orders = [{"Id": "801%012dAAA" % i, "OrderNumber": str(i), "Status": "Activated"} for i in range(3)]
    cn = RoutedConn(routes=[("SELECT Order__c FROM WorkOrder", [{"Order__c": orders[0]["Id"]}, {"Order__c": orders[1]["Id"]}]),
                            ("FROM Order WHERE", orders)])
    ev = _chk("WO.ORDERS_MISSING_WOS").run(cn)
    sent = " ".join(cn.sent)
    check("an Order is judged by Work Orders that name it, even with no Contract link; only Activated Orders",
          [r["Id"] for r in ev.rows] == [orders[2]["Id"]] and "Status = 'Activated'" in sent
          and "Order__c IN (SELECT Id FROM Order" in sent and "Contract" not in sent.split("SELECT Order__c FROM WorkOrder")[1], sent[:300])
    # Monthly LastBillingDate: nothing to compare is not a pass
    r = runner.run_check(_chk("CONTRACT.LASTBILLINGDATE_RULE"), RoutedConn(routes=sf + [("Billing_Period__c = 'Monthly Bill Period'",
                         [{"Id": "800A", "StartDate": "2026-10-01", "LastBillingDate__c": None}])], counts=[("FROM Contract", 9)]))
    check("no Monthly Contract has both dates -> UNPROVEN, not PASS", r.verdict == UNPROVEN, r.verdict)
    # Serviceable ZIP: ZIP+4 is the same ZIP
    q = [{"Id": "a1", "Name": "Q", "Shipping_Address__r.USF_Zip_Code__c": "12345-6789", "Serviceable_Zip_Code__c": "z1",
          "Serviceable_Zip_Code__r.Zip_Code__c": "12345"}]
    ev = _chk("QUOTE.SERVICEABLE_ZIP").run(RoutedConn(routes=[("FROM SBQQ__Quote__c", q)], fields=set()))
    check("12345-6789 vs 12345 is not a mismatch", not ev.rows, str(ev.rows))
    # BIQ parity wording follows the sign
    ev = _chk("GOOSE.BIQ_PARITY").run(RoutedConn(routes=sf, counts=[("Billing_Impacts_Queue__c", 100)], goose_ok=True,
                                                 gcounts=[("SFDC_BillingImpactQueue", 140)], grows=[("dbo.MigrationBatch", [{"ID": 901}])]))
    check("Goose larger than Salesforce says so", ev.rows and "Goose has 40 more" in ev.rows[0]["meaning"], str(ev.rows))
    # Log check: informational rows of the same family are not errors
    import connections as cx
    logs = [{"Id": "L1", "CreatedDate": "2026-10-02", "Log_Type__c": "Info", "Related_Object__c": "Work Order", "Message__c": "synced 5 records"},
            {"Id": "L2", "CreatedDate": "2026-10-02", "Log_Type__c": "Error", "Related_Object__c": "Work Order",
             "Message__c": "INVALID_CROSS_REFERENCE_KEY", "Error_Status_Code__c": "INVALID_CROSS_REFERENCE_KEY"}]
    import checks as ck_mod
    real_win = ck_mod._batch_window
    ck_mod._batch_window = lambda c: dict(ok=True, lo="2026-10-01T00:00:00Z", hi="2026-10-04T00:00:00Z", label="w", source="t")
    try:
        ev = _chk("LOG.WORKORDER_GENERATION_ERRORS").run(RoutedConn(routes=[("FROM Log__c", logs)], counts=[("Log__c", 2)],
                                                         fields={"Log__c.Log_Type__c"}))
    finally:
        ck_mod._batch_window = real_win
    check("an informational log row is ignored, the error row counts", [r["log_id"] for r in ev.rows] == ["L2"] and "1 informational" in ev.note, str(ev.note))
    # RO 33 fallback: only a missing field falls back; other errors are UNPROVEN
    class Boom(RoutedConn):
        msg = "INVALID_FIELD: No such column 'Subscription__c'"
        def q(self, soql):
            if "Subscription__c" in soql and "GROUP BY" not in soql:
                raise RuntimeError(self.msg)
            return super().q(soql)
    F = {"WorkOrderLineItem.Order_Line_Item__c", "WorkOrderLineItem.USF_Confirmed_Quantity__c"}
    groups = [{"WorkOrderId": "WO1", "Order_Line_Item__c": "OI1", "n": 2}]
    detail = [{"Id": "L1", "WorkOrderId": "WO1", "Order_Line_Item__c": "OI1", "Order_Line_Item__r.Quantity": 1, "USF_Confirmed_Quantity__c": 1},
              {"Id": "L2", "WorkOrderId": "WO1", "Order_Line_Item__c": "OI1", "Order_Line_Item__r.Quantity": 1, "USF_Confirmed_Quantity__c": 1}]
    routes = [("GROUP BY WorkOrderId", groups), ("FROM WorkOrderLineItem WHERE WorkOrderId IN", detail)]
    ev = _chk("WOLI.EXCEEDS_SOURCE_QUANTITY").run(Boom(routes=routes, counts=[("Order_Line_Item__c", 2)], fields=F))
    check("a missing Subscription field falls back, and says add-ons may be over-reported",
          len(ev.rows) == 1 and "may be over-reported" in ev.note, ev.note)
    Boom.msg = "REQUEST_LIMIT_EXCEEDED: transient"
    ev = _chk("WOLI.EXCEEDS_SOURCE_QUANTITY").run(Boom(routes=routes, counts=[("Order_Line_Item__c", 2)], fields=F))
    check("any other error is UNPROVEN, not a silent switch to the parent-line comparison", bool(ev.unprovable), str(ev.rows))
    # Delivery check: Orders are the unit, Canceled deliveries are not counted
    cn = RoutedConn(routes=[("GROUP BY Order__c", [{"Order__c": "O1", "n": 2}]), ("FROM WorkOrderLineItem", []),
                            ("SELECT Id, WorkOrderNumber", [])], counts=[("WorkType.Name = 'Delivery'", 2)],
                    fields={"WorkOrderLineItem.NF_BundleId__c"})
    ev = _chk("WO.DELIVERY_EXCEEDS_BUNDLES").run(cn)
    check("the delivery check counts Orders against Orders and leaves Canceled deliveries out",
          ev.examined == 1 and len(ev.rows) == 1 and ev.metric.denominator == 1 and
          all("NOT IN ('Canceled','Cancelled')" in q for q in cn.sent if "GROUP BY Order__c" in q or "SELECT Id, WorkOrderNumber" in q))
    # customer-owned: Quote Line rows alone cannot make a verdict
    cols = [{"COLUMN_NAME": "IsCustomerOwned"}, {"COLUMN_NAME": "MigrationBatchID"}, {"COLUMN_NAME": "CustomerOwned__c"}]
    cn = RoutedConn(routes=sf, goose_ok=True, grows=[("dbo.MigrationBatch mb", [{"ID": 901}]), ("INFORMATION_SCHEMA", cols),
                    ("FROM Goose.dbo.SFDC_Quote_Line", [{"V": 1, "N": 9}]), ("FROM Goose.dbo.STG_", [])], gcounts=[("STG_OrderLineItem", 5)])
    r = runner.run_check(_chk("GOOSE.CUSTOMER_OWNED_FLAG"), cn)
    check("if neither staging table could be read the flag is UNPROVEN, not PASS", r.verdict == UNPROVEN, r.verdict)
    # prediction: one pattern on every row is a mapping question
    ck = _chk("PREDICT.LOAD_FAILURES")
    staged = [{"x": i} for i in range(500)]
    rd, rb = pr.describe_full, pr.predict_batch
    pr.describe_full = lambda alias, o: {}
    def fb(meta, recs, op="CREATE", blocked=None):
        per = [dict(index=i, record=r_, issues=[dict(field="F", type="FIELD_NOT_FOUND", severity="ERROR", value="v", message="m")], blocking=True)
               for i, r_ in enumerate(recs)]
        per = per[:blocked] if blocked else per
        return dict(records_checked=len(recs), records_blocked=len(per), total_issues=len(per),
                    patterns=[dict(type="FIELD_NOT_FOUND", field="F", count=len(per), share=1, distinct_values=1, example=[], single_value_fix=True)],
                    per_record=per, headline="h")
    def mk():
        cn = RoutedConn(routes=sf, grows=[("MigrationBatch", [{"BatchStatus": "Open"}]), ("dbo.vw_QL", staged)], goose_ok=True)
        cn.cfg = {"PredictTargets": {"SBQQ__QuoteLine__c": "vw_QL"}}
        return cn
    try:
        pr.predict_batch = lambda m, r_, op="CREATE": fb(m, r_)
        ev = ck.run(mk())
        check("every staged row failing for ONE reason is a mapping question, not 500 findings", bool(ev.unprovable) and not ev.rows, str(ev.unprovable)[:100])
        pr.predict_batch = lambda m, r_, op="CREATE": fb(m, r_, blocked=40)
        ev = ck.run(mk())
        check("  ...but 40 of 500 failing for that reason is still reported", len(ev.rows) == 40 and not ev.unprovable)
    finally:
        pr.describe_full, pr.predict_batch = rd, rb


if __name__ == "__main__":
    for t in (test_registry, test_invariant, test_baseline, test_store,
              test_coverage, test_summary, test_predict, test_sf_count_shapes,
              test_remediation_required, test_blind_spot_window,
              test_account_scoping, test_job_timing, test_processed_vs_errors,
              test_store_migration, test_runbook_columns, test_jobsite_readiness,
              test_object_tally, test_progress_and_issues,
              test_record_drilldown, test_evidence_cap_configurable,
              test_dead_polygons, test_collapsible_and_totals,
              test_no_shadowed_check_functions, test_examined_never_exceeds_errors,
              test_issues_ordered_by_run_order, test_table_fits_and_counts_are_blocked,
              test_truncation_never_invents_findings, test_stale_run_warning,
              test_sunrise_path_is_forgiving, test_fls_hint_points_at_the_fix,
              test_parallelism_is_faster_and_still_correct,
              test_checks_run_in_run_book_order,
              test_absence_findings_are_not_record_lists,
              test_salesforce_links,
              test_informatica_live_is_read_only_by_construction,
              test_informatica_live_degrades_without_credentials,
              test_informatica_live_read_against_a_scripted_session, test_findings_classified_against_the_load,
              test_workorder_bundle_flags, test_cj_issue_coverage,
              test_no_check_queries_a_nonexistent_biq_field,
              test_records_blocked_counts_each_check_once,
              test_one_version_source_and_it_matches_the_changelog,
              test_delivery_check_uses_the_teams_rule, test_woli_check_compares_to_source_quantity,
              test_duplicate_contracts_per_order, test_polygon_twins, test_logged_generation_errors,
              test_goose_batch_status, test_goose_batch_discovery_maps_by_salesforce_id,
              test_terminology, test_object_tiles_open_a_detail_page, test_run_book_filters,
              test_goose_errorlog_is_scoped_to_the_batch, test_verification_against_salesforce,
              test_predict_counts_records_in_this_batch_and_no_record_limits,
              test_ui_numbers_are_in_one_unit_and_counted_once,
              test_hand_done_steps_are_checked_by_their_effect, test_run_book_export_separates_jobs_from_team_steps,
              test_sunrise_notice_only_alarms_when_a_check_depends_on_it,
              test_headline_and_more_menu, test_record_count_cannot_hold_the_run, test_issues_export_one_tab_per_issue, test_full_selftest_only_when_chosen, test_selftest_has_its_own_page_and_settings, test_mp_check_says_why_a_plan_was_flagged, test_guide_checks_and_ancillary_fix, test_audit_fixes_nothing_falsely_reported,
              test_v18_bindings_and_first_step,
              test_cli_errors_keep_the_part_that_names_the_problem):
        try:
            t()
        except Exception:                                        # noqa: BLE001
            traceback.print_exc(); FAILED.append(t.__name__)
    print("\n%s" % ("ALL TESTS PASSED" if not FAILED
                    else "%d FAILURE(S): %s" % (len(FAILED), ", ".join(FAILED))))
    sys.exit(1 if FAILED else 0)

