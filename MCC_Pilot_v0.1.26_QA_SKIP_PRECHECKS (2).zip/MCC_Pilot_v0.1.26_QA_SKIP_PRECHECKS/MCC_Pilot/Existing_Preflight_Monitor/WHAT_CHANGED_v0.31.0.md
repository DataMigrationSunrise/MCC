# v0.31.0 - RO 33 add-on fix, checks from the Manual Touch Points guide, Salesforce re-verification

**RO 33 "Work Order Line Items delivering more units than the source line" - fixed.**
A restroom and the hand sanitizer attached to it are two line items (1 + 1) that share the bundle's parent line (qty 1),
so the check flagged them. Each line item is now compared with the quantity of the subscription it was made from;
only when a subscription cannot be read does it fall back to the source line, and the row says which it used.
The same subscription delivered twice is still flagged. The note counts add-ons that were judged on their own.

**New checks from the guide** (Goose columns are the guide's, not yet confirmed against Goose):
- GOOSE.CUSTOMER_OWNED_FLAG (RO 43, issue 1): is IsCustomerOwned 0 on every staged row?  Evidence is the value groups.
  A batch with no customer-owned units looks the same, so it says so.
- GOOSE.MP_NULL_ACCOUNT (RO 41, issue 2): the guide's step 1 query, scoped to the batch, with the Account each plan
  should have. States that the blank-Account theory is not proven (falsified on UMB-0116).
- Issue 3 already had GOOSE.MP_WEEKDAY_GAP. Issue 4 is already covered by the Order activated/contracted check at RO 26.

**Re-verify in Salesforce** (after the load, each re-asks in Salesforce what its Goose twin asks in Goose):
- MP.SF_NULL_ACCOUNT, MP.SF_WEEKDAY_GAP (uses Day_of_Week__c), QL.SF_CUSTOMER_OWNED.
  Hidden or missing fields give UNPROVEN, never a pass. They run every time (one or two queries each).
