# MCC Pilot v0.1.15 — Preflight warning behavior

## Changed
- A nonblocking/unproven *diagnostic* preflight finding is now logged as a warning rather than mislabeled as a failed Goose identity check.
- The specific Goose batch identity check remains mandatory for live execution.
- An uncertain Goose exclusion write remains a concrete stop until its outcome is reconciled.

## Still not implemented
- There are no verified record-error-to-exclusion rules in preflight_rules.json; exclusion_mode remains disabled.
- Goose error-log writeback mapping is not verified.
- Full downstream run-book interventions are not executable; StopAfter remains TF_30.01 and RequireEndToEnd remains true.
- No live QA execution was performed.

## Testing
- 19 offline pytest tests passed on this package's runner before packaging.
- Re-check connected system credentials, staging keys, SQL predicates, live step mappings, and idempotent retries before live migration.
