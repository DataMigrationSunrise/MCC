"""
Cross-batch baselining.

4.7% is not a finding. 4.7% against 97.4% and 100% is a finding. This module is what
turns a number into one -- and it refuses to judge when it has no basis to.
"""
from __future__ import annotations
from statistics import mean, pstdev

from model import (BaselineComparison, Metric,
                   NORMAL, OUTLIER, FIRST_OF_KIND, REGRESSION, IMPROVED)

MIN_PRIOR_BATCHES = 2      # below this, no judgement is offered at all
MIN_SIGMA_BATCHES = 3      # below this, sigma is meaningless -- two points make almost
                           # anything a 3-sigma event, which would flag every third batch
SIGMA_OUTLIER = 3.0        # when the distribution has spread AND enough points
FLAT_TOLERANCE = 0.02      # prior batches IDENTICAL -> high confidence, any drift is notable
THIN_TOLERANCE = 0.15      # prior batches FEW -> low confidence, demand a large move.
                           # These are opposite situations and must not share a threshold:
                           # 3 identical batches is strong evidence, 2 scattered ones is not.


def compare(metric: Metric | None, history: list[tuple[str, float]],
            higher_is_better: bool = True) -> BaselineComparison | None:
    """
    history: [(batch, value)] for PRIOR batches only -- the caller excludes the current one.
    Returns None when there is no metric at all.
    """
    if metric is None:
        return None

    vals = [v for _, v in history]
    if len(vals) < MIN_PRIOR_BATCHES:
        return BaselineComparison(
            cls=FIRST_OF_KIND,
            detail=("Only %d prior batch(es) have a value for this check. No basis for comparison "
                    "yet -- a threshold invented now would be fiction." % len(vals)),
            prior_n=len(vals),
            prior_mean=(vals[0] if vals else None))

    mu = mean(vals)
    sd = pstdev(vals)
    v = metric.value

    if sd > 1e-9 and len(vals) >= MIN_SIGMA_BATCHES:
        sigma = (v - mu) / sd
        is_out = abs(sigma) >= SIGMA_OUTLIER
        tol = max(FLAT_TOLERANCE, sd)
    elif sd <= 1e-9:
        # Prior batches were IDENTICAL -- strong evidence, so any real drift matters.
        sigma = None
        tol = FLAT_TOLERANCE
        is_out = abs(v - mu) > tol
    else:
        # Too few batches for sigma to mean anything. Demand a LARGE move: a thin history
        # must not manufacture a dramatic-looking outlier out of ordinary variance.
        sigma = None
        tol = THIN_TOLERANCE
        is_out = abs(v - mu) > tol

    worse = (v < mu) if higher_is_better else (v > mu)

    if is_out:
        direction = "below" if v < mu else "above"
        detail = "%s is %s the prior-batch mean of %s across %d batches" % (
            _fmt(v, metric.unit), direction, _fmt(mu, metric.unit), len(vals))
        if sigma is not None:
            detail += " (%.1f sigma)" % abs(sigma)
        else:
            detail += " (prior batches were identical, so any drift is notable)"
        if not worse:
            detail += " -- BETTER than prior batches; confirm why before assuming it is good news"
        return BaselineComparison(cls=OUTLIER, detail=detail, prior_mean=mu,
                                  prior_n=len(vals), sigma=sigma)

    # Movement against the PREVIOUS batch only counts when it is also meaningful against the
    # DISTRIBUTION. Flagging every 2-point wobble as a regression is noise, and a monitor that
    # cries wolf on ordinary variance gets ignored -- which is the failure mode this tool exists
    # to prevent, arrived at from the opposite direction.
    prev = history[-1][1] if history else None
    move_floor = tol
    if (prev is not None and abs(v - prev) > move_floor and abs(v - mu) > max(sd, 1e-9)):
        regressed = (v < prev) if higher_is_better else (v > prev)
        cls = REGRESSION if regressed else IMPROVED
        return BaselineComparison(
            cls=cls,
            detail="%s vs %s in %s -- inside the overall distribution, but moved more than "
                   "its spread" % (_fmt(v, metric.unit), _fmt(prev, metric.unit), history[-1][0]),
            prior_mean=mu, prior_n=len(vals), sigma=sigma)

    return BaselineComparison(
        cls=NORMAL,
        detail="%s, in line with the prior-batch mean of %s across %d batches" % (
            _fmt(v, metric.unit), _fmt(mu, metric.unit), len(vals)),
        prior_mean=mu, prior_n=len(vals), sigma=sigma)


def _fmt(v: float, unit: str) -> str:
    if unit == "ratio":
        return "%.1f%%" % (v * 100)
    if unit == "count":
        return "%d" % round(v)
    return "%g" % v


def matrix(store, check_ids: list[str], batches: list[str]) -> dict:
    """Checks as rows, batches as columns -- the view that makes 4.7% legible."""
    out = {}
    for cid in check_ids:
        row = {}
        for b in batches:
            r = store.latest_result(cid, b)
            if r is None:
                row[b] = None
            else:
                row[b] = {"verdict": r["verdict"],
                          "metric": r["metric_value"],
                          "unit": r["metric_unit"],
                          "count": r["evidence_count"],
                          "baseline": r["baseline_class"]}
        out[cid] = row
    return out
