# v0.23.2 - the predicted-failures check, and no more record limits

**RO 3 "Staged records that will FAIL to load" (7,910 of 1,000).** It read only the first 500 rows
of each staging view, then counted ISSUES as failing records, so 500 rows with many problems each
read as thousands. Now:
- every staged row is read (no TOP 500);
- failing = staged RECORDS that would be rejected, examined = all staged rows, so failing can
  never exceed examined; the per-field detail is in each row's "issues" column;
- the views describe the OPEN batch, so the check first asks Goose for this batch's status. If it
  is not Open, the check says so and counts nothing against this batch;
- if every row fails for 5+ different reasons, it is reported as "does not line up with the
  Salesforce fields", not as hundreds of failures.

**Record limits removed.** Every LIMIT 200 / 50 / 500 / 2000 / 5000 on a record query is gone,
including the object-page list query ("SELECT Id FROM ... LIMIT 200"), the async-job, Log__c,
polygon and territory reads, and the 2,000-row evidence cap. Every offending record is read and
kept. Only lookups of a single row keep LIMIT 1. Very large reads are slower; a run that has
more than ~50,000 records in one query may need the Bulk API (tell me if you hit that).
