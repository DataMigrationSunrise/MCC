"""CONFIGURE_SNAPLOGIC_STAGE - points the MCC Pilot's SnapLogic triggers at USSQA (-> Salesforce Stage).
Run from anywhere:  py -3 CONFIGURE_SNAPLOGIC_STAGE.py

What it does (and nothing else):
  1. Copies your Sunrise_v0.17.151 folder to a NEW sibling folder  Sunrise_v0.17.151_STAGE
     (skips test_run_history). Your original QA copy is NOT changed.
  2. Asks for the USSQA Triggered Task Cloud URL + HTTP Header of PL_05, PL_07, PL_10
     (copy both from the SAME Task Details page in SnapLogic USSQA).
  3. Saves each HTTP Header as a Windows USER env var  SNAPLOGIC_STAGE_PL05_HEADER / _PL07_ / _PL10_
     (typed hidden, never printed or written to a file).
  4. Writes the 3 URLs + header-env names into the COPY's control_center_state.json.
Starts no pipeline. Changes nothing in SnapLogic, Salesforce, Goose or Informatica.
"""
import getpass
import json
import shutil
import sys
import winreg
from pathlib import Path

SRC = Path(r"C:\Users\VChiraf\Downloads\Old\Project\New folder (4)\Sunrise_v0.17.151_RECORD_FACTORY_COMPARE_FIX_WINDOWS (1)\Sunrise_v0.17.151")
DST = SRC.with_name(SRC.name + "_STAGE")
PREFIX = "https://elastic.snaplogic.com/api/1/rest/slsched/feed/USSQA/"
STAGES = (("05", "PL_05_Pre-Process"), ("07", "PL_07_Accounts_and_Contacts"), ("10", "PL_10_AccountContactRelations"))


def fail(msg):
    print("\nSTOPPED: " + msg + "\nNothing further was changed. END")
    sys.exit(1)


if not (SRC / "control_center" / "control_center_state.json").is_file():
    fail("Sunrise QA copy not found at %s" % SRC)

# 1. copy
if DST.exists():
    print("Stage copy already exists, reusing: %s" % DST)
else:
    print("Copying Sunrise to %s ..." % DST)
    shutil.copytree(SRC, DST, ignore=shutil.ignore_patterns("test_run_history"))
    print("Copied.")

# 2-3. URLs + headers
urls = {}
for code, name in STAGES:
    print("\n--- %s (SnapLogic USSQA -> Manager -> Tasks -> the %s triggered task -> Details)" % (name, name))
    url = input("Paste Cloud URL: ").strip().strip('"')
    if not url.startswith(PREFIX):
        fail("%s URL must start with %s  (got: %s)" % (name, PREFIX, url[:120]))
    hdr = getpass.getpass("Paste HTTP Header (hidden, e.g. 'Authorization: Bearer ...'): ").strip()
    if "bearer" not in hdr.lower():
        fail("%s header does not contain 'Bearer'. Copy the HTTP Header from the same Task Details page." % name)
    env = "SNAPLOGIC_STAGE_PL%s_HEADER" % code
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, env, 0, winreg.REG_SZ, hdr)
    print("Saved header to user env var %s (length %d)." % (env, len(hdr)))
    urls[code] = (url, env)

# 4. state file of the COPY only
sp = DST / "control_center" / "control_center_state.json"
state = json.loads(sp.read_text(encoding="utf-8"))
(DST / "control_center" / "control_center_state.before_stage.json").write_text(json.dumps(state, indent=2), encoding="utf-8")
for code, (url, env) in urls.items():
    state["SnapLogicTask%sUrl" % code] = url
    state["SnapLogicTask%sHeaderEnv" % code] = env
    state["SnapLogicTask%sTokenEnv" % code] = "SNAPLOGIC_STAGE_PL%s_TOKEN" % code
    state["SnapLogicTask%sPairFingerprint" % code] = ""
sp.write_text(json.dumps(state, indent=2), encoding="utf-8")

print("\nDONE. Stage copy: %s" % DST)
for code, (url, env) in urls.items():
    print("  PL_%s  %s  header env %s" % (code, url, env))
print("Original QA copy untouched: %s" % SRC)
print("END")
# END
