# v0.19.1 - Goose batch lookup fixed

**Live symptom (v0.18.0 log):** self-test said `Goose OK (362 migration batches)`, then
`Goose batch discovery failed`, so the batch list fell back to the built-in 114 names.

**Cause:** the query asked Goose for a `BatchName` column. Goose's `MigrationBatch` has no such
column. It has `ID`, `BatchStatus`, `AcquisitionCode` and `SalesforceUssMigrationBatchID`
(the last is the join key in Sunrise's own `BUILD_SALESFORCE_MIGRATION_BATCHES_FROM_GOOSE.sql`).
The self-test only counts rows, so it never named a column and passed.

**Fixed (three places):**
- batch discovery now maps Goose rows to batches by `SalesforceUssMigrationBatchID`
  (15- and 18-character forms both match); a Goose batch Salesforce does not know is skipped, not named.
- `GOOSE.BATCH_STATUS` (RO 1) and `GOOSE.BIQ_PARITY` look the batch up by that Salesforce Id.
- if the batch's Salesforce Id cannot be resolved, both report UNPROVEN rather than guess.

**Not verified:** I have no Goose access. The column names come from Goose's own code and
Sunrise's reference SQL, not from a live query. Press Self-test and look for `Goose: N batch(es)`.

Also from v0.19.0 (unchanged): live Informatica is read-only by construction.
