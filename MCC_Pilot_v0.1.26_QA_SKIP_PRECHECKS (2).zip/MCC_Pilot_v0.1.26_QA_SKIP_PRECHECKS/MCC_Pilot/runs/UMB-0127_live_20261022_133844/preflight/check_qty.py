"""Read-only: do the 4 no-WO orders stand out by line quantity / line count vs orders that got WOs? (Sunrise-QA)"""
import sys
from collections import defaultdict
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems

c = systems.build(app.CFG, 'dry', lambda m: None)
c.sf.alias = 'Sunrise-QA'
B = 'aFOVD0000001Swj4AE'
bad = {'801VD00000v8q3qYAA', '801VD00000v9J94YAE', '801VD00000v9KWZYA2', '801VD00000v9OWvYAM'}
tot, mx, n = defaultdict(float), defaultdict(float), defaultdict(int)
for i in c.sf.query("SELECT OrderId, Quantity FROM OrderItem WHERE Order.SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B):
    q = float(i['Quantity'] or 0)
    tot[i['OrderId']] += q; mx[i['OrderId']] = max(mx[i['OrderId']], q); n[i['OrderId']] += 1
rank = sorted(tot, key=lambda o: -tot[o])
print('orders:', len(tot))
for k, o in enumerate(rank[:12], 1):
    print('%2d %s total_qty=%-7d max_line_qty=%-6d lines=%-3d %s' % (k, o, tot[o], mx[o], n[o], 'NO WO' if o in bad else 'has WOs'))
for o in bad:
    print('NO WO', o, 'rank by total qty:', rank.index(o) + 1, 'total=%d max=%d lines=%d' % (tot[o], mx[o], n[o]))
