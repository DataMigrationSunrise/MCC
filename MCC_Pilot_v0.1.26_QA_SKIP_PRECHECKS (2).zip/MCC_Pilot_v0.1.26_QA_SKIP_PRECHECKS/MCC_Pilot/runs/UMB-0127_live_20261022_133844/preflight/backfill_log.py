"""Backfill GOOSE_ErrorLog rows for MCC fixes that were applied but not logged (batch 468)."""
import csv, json, sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, fixlog

B = 468
pre = Path(__file__).parent
c = systems.build(app.CFG, 'dry', lambda m: None)
logged = {(r['SourceObject'], str(r['SourceRecordID'])) for s in c.goose.result_sets(
    "SELECT SourceObject, SourceRecordID FROM dbo.GOOSE_ErrorLog WHERE MigrationBatchID=%d AND ProcessName='MCC_Pilot'" % B)
    for r in s}

entries = []
# 1. Linked accounts/contacts (link_existing journal: LINK_ATTEMPT followed by LINKED).
attempts, linked = {}, set()
for line in (pre / 'link_existing.jsonl').read_text(encoding='utf-8').splitlines():
    j = json.loads(line)
    if j.get('status') == 'LINK_ATTEMPT':
        attempts[str(j['account'])] = j
    elif j.get('status') == 'LINKED':
        linked.add(str(j['account']))
for acct in sorted(linked):
    a = attempts[acct]
    if ('SFDC_Account', acct) not in logged:
        entries.append(fixlog.entry('MCC_FIXED', 'TF_15.L', 'SFDC_Account', acct,
            'MCC FIX existing account: SalesforceAccountID blank -> %s (matched Name+Street+Zip, created by earlier '
            'batch); %d contact(s) linked' % (a['sf_account'], len(a['contacts'])), 'Account'))
    for cid, sfc in a['contacts']:
        if ('SFDC_Contact', str(cid)) not in logged:
            entries.append(fixlog.entry('MCC_FIXED', 'TF_15.L', 'SFDC_Contact', cid,
                'MCC FIX existing contact: SalesforceContactID blank -> %s (matched Account+Name+Email)' % sfc, 'Contact'))

# 2. Filled coordinates (coordinate_fill journal FILLED ids; details from the coord_match report).
filled = set()
for line in (pre / 'coordinate_fill.jsonl').read_text(encoding='utf-8').splitlines():
    j = json.loads(line)
    if j.get('status') == 'FILLED':
        filled.update(str(i) for i in j['ids'])
report = next(pre.glob('coord_match_*.csv'))
detail = {}
with report.open(encoding='utf-8-sig', newline='') as f:
    for r in csv.DictReader(f):
        detail[str(r.get('goose_id'))] = r
for gid in sorted(filled):
    if ('SFDC_USF_Address', gid) in logged:
        continue
    d = detail.get(gid, {})
    entries.append(fixlog.entry('MCC_FIXED', 'TF_15.G', 'SFDC_USF_Address', gid,
        'MCC FIX coordinates: blank -> %s,%s from %s (%s %s; mct07 rule)' % (
            d.get('lat', '?'), d.get('lng', '?'), d.get('source_ids', '?'), d.get('tier', ''), d.get('confidence', '')),
        'USF_Address__c'))

print('to backfill:', len(entries))
n = fixlog.write(c.goose, B, entries, pre / 'goose_fixlog.jsonl') if entries else 0
print('written:', n)
for s in c.goose.result_sets("SELECT LogType, SourceObject, COUNT(*) n FROM dbo.GOOSE_ErrorLog WHERE MigrationBatchID=%d "
                             "AND ProcessName='MCC_Pilot' GROUP BY LogType, SourceObject" % B):
    for r in s:
        print(r)
