# v0.27.1 - issues export: reason, logic and the values that failed

- Each issue tab now also states: why it failed, the rule (the logic), where the rule comes from, what the check proves and what it cannot prove.
- Every record row carries the source values the check read (all its columns) plus a "Why it failed" column.
- Staged-row (PREDICT) findings now keep the failing field values and the reason for each (new in the next run).
