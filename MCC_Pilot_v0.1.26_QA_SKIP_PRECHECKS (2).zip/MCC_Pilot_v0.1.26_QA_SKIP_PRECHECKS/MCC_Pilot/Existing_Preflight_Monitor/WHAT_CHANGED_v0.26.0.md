# v0.26.0 - simpler page, nothing removed

- One-sentence headline at the top: where the batch stopped (or "Clear through RO n"), failing-record count, next step.
- "Records in Salesforce for this batch" tiles now start folded (one click opens them; your open/closed choice is remembered).
- Load all batches / Find batches / Self-test / Spreadsheet moved under a "More" menu. Run checks and Export run book stay visible.
- The run book table, all checks and all numbers are unchanged.
