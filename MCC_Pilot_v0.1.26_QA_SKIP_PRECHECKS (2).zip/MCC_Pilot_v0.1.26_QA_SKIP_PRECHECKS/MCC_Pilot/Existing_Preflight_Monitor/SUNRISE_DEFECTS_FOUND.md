# Defects found in Sunrise, and the one-line fix for each

A code audit of Sunrise v0.17.185 looking specifically for **paths that can report a false
clean** — not missing features. Seven found, all verified by reading the source.

Each one lists the fix **in Sunrise**, because patching yours is better than depending on mine.
The Preflight Monitor mechanism is given only as the alternative.

---

## 1. `wait_for_stable` auto-PASSes 12 of 17 pipeline steps

`sequence_verification.py:118`

```python
names = STABILITY.get(step)
if not names:
    return {'Status':'PASS','Reason':'No asynchronous stabilization wait required for this step.'}
```

`STABILITY` lists **5 steps**: tf_30, tf_35, tf_55, tf_60, tf_80. Every other step takes the
early return and is declared `PASS` — not "not applicable", **PASS**.

The 12 with no wait:

```
tf_02  tf_07  tf_10  tf_15  tf_20  tf_25  tf_40
BIQ_VALIDATION_CUSTOMER_OWNED   FSC_BIQ
tf_85_Zuora_Updates   tf_99_Finish   PL_FINAL_RECONCILIATION
```

**`FSC_BIQ` is on that list.** FSC BIQ creation is Batch Apex — asynchronous by definition — and
it gets an immediate PASS with no settle wait. So does `tf_40` (MP weekday updates, which fire
FSL automation) and `PL_FINAL_RECONCILIATION`, the closing gate.

**Fix in Sunrise** — change the sentinel so "no rule" is not "pass":

```python
if not names:
    return {'Status':'NOT_APPLICABLE',
            'Reason':'No stabilization rule is defined for this step. That is not a pass.'}
```

…then add the missing steps to `STABILITY`. `FSC_BIQ: ['biqs']` and
`tf_40_Update_MP_Days: ['work_orders','service_appointments']` are the two that matter most.

*Monitor equivalent: the evidence invariant — absence of a rule can never produce PASS.*

## 2. `_scalar` swallows a parse failure and returns 0

`sequence_verification.py:14`

```python
for k, v in r.items():
    if k != 'attributes':
        try: return int(v or 0)
        except Exception: pass
return 0
```

A COUNT whose value will not parse returns **0**, and every `zero(...)` assertion built on it
passes. The failure is indistinguishable from a clean result.

**Fix** — distinguish "no rows" from "unparseable":

```python
raise ValueError("COUNT query returned a value that is not numeric: %r" % r)
```

## 3. `_count` does not notice a failed query

`sequence_verification.py:17`

```python
def _count(query_fn, soql):
    rows, _ = query_fn(soql)
    return _scalar(rows)
```

If `query_fn` returns `[]` on error, the count is 0 and the assertion passes. Combined with
defect 2, a broken connection reads as a clean batch.

**Fix** — `query_fn` already returns a second element; check it, and raise rather than return 0.

## 4. `control_center.py` truncates at LIMIT 2000 with no sample flag

`control_center.py:2036, 2038` (and 19 other LIMIT sites)

```python
items,_ = sf_query_records(state, f"SELECT ... FROM OrderItem WHERE OrderId IN ({ids}) LIMIT 2000")
wos,_   = sf_query_records(state, f"SELECT ... FROM WorkOrder WHERE Order__c IN ({ids}) LIMIT 2000")
```

`live_touchpoint_automation.py` **does** flag truncation — `RowsAreSample`,
`OrphanBiqKeyRowsAreSample`, and comments explaining the pattern. `control_center.py` has no
equivalent anywhere. A batch with more than 2,000 WorkOrders is silently truncated and the
resulting counts are presented as complete.

UMB-0116 had 786 Contracts and 889 Asset Locations, so this has probably not bitten yet — it
will on a larger acquisition.

**Fix** — the pattern already exists in your own codebase; apply it:

```python
rows_are_sample = len(wos) >= 2000
```

…and surface it in the summary the way AF60 does.

## 5. 24 swallowed exceptions, 3 of them in run tracking

`run_observability.py:153,160,170`, `control_center.py:255,309`, `engine_runner.py:1833`,
`snaplogic_live.py:140`, `sequence_verification.py:14`

`except Exception: pass` in the module that records what a run did means a failure to record is
itself unrecorded. The ledger can be wrong and nothing says so.

**Fix** — in `run_observability` specifically, log rather than pass. Everywhere else, at minimum
capture the exception type into the artifact so a reader can see something was swallowed.

## 6. 17 `LIVE CLEAN` emitters, only some gated on evidence

`grep -c "LIVE CLEAN"` → 17. AF160's is the one already proven wrong this week: it reports
`LIVE CLEAN` while 18 BIQs sit with a null Effective Date, because its third query is registered
`is_defect=False`.

**Fix** — the `AF160` change is in `32_preflight_optimization/PREFLIGHT_OPTIMIZATION_SPEC.md` P3.
For the rest, apply one rule: a module may only emit `LIVE CLEAN` when it has positively
observed a population. Zero rows plus an unverified scope is `UNPROVEN`.

## 7. No canary anywhere — zero is always read as clean

`grep -rn "canary|could have found|scope is broken"` across all 37 modules → **0 hits**.

This is the general case of defects 1, 2, 3 and 6. Nothing in Sunrise distinguishes *"the query
found nothing because the data is clean"* from *"the query found nothing because the scope is
broken."* Every batch-scoped query reaches its batch through a relationship chain, and a null
link removes records from the population rather than flagging them.

**Fix** — one helper, applied at each checkpoint:

```python
def canary(query_fn, soql, label):
    """Prove the query COULD have found something before calling zero a pass."""
    n = _count(query_fn, soql)
    if n == 0:
        raise AssertionError("Canary '%s' found no records. A zero result from this check "
                             "means BROKEN SCOPE, not clean." % label)
    return n
```

Checkpoint 30 already shows the right instinct — it records `UNPROVEN / NO QUOTE POPULATION
RETURNED` rather than passing. Generalising that one behaviour would close most of this list.

---

## What Sunrise already does right, and should not be changed

Worth stating, because four of the seven above are the same mistake and it would be easy to
conclude the codebase is careless. It is not.

- **`historical_parity_runner.py:165`** guards correctly:
  `"Status": "PASS" if total_compared and total_mismatch==0 and total_untestable==0` — the
  `total_compared and` is exactly the canary idea, written by hand in the right place.
- **`pin_active_batch`** raises rather than guessing when the Processing batch is ambiguous:
  *"Sunrise will not use a floating Batch_Status__c scope."*
- **`pilot_cycle.py:131`** blocks an identical reload when no cleanup audit exists.
- **`validate_readonly_sql`** is a real guard with a banned-token scan over comment- and
  literal-stripped SQL.
- **AF60's boundary note** names a blind spot most codebases would never notice.

The pattern is clear: where someone thought about it, the handling is better than most
production code. The defects are all in the *default* paths — the early return, the fallback,
the `except`. That is a one-helper problem, not a rewrite.

---

## Priority

| | Defect | Effort | Why now |
|---|---|---|---|
| 1 | `wait_for_stable` sentinel (#1) | 2 lines | `FSC_BIQ` is async and auto-passing today |
| 2 | Canary helper (#7) | ~10 lines + per-checkpoint call | Closes #1, #2, #3, #6 as a class |
| 3 | AF160 `is_defect=True` (#6) | 1 query | Already proven to have hidden a live defect |
| 4 | `_scalar` / `_count` (#2, #3) | 3 lines | A broken connection currently reads as clean |
| 5 | Sample flags in control_center (#4) | pattern already in your codebase | Bites on the next large acquisition |

None of these require the Preflight Monitor to exist.
