# v0.25.1 - Export run book button in the header

The v0.25.0 export link only appeared with the run book (above the table), so it was not on screen
while a self-test or run was in progress or before any run existed. There is now an
**Export run book** button in the top bar next to Spreadsheet, always visible, for the batch (and
stored snapshot, if one is picked) currently selected. Same workbook as before.
