# MCC Pilot · v0.1.2

One click takes a new batch from run book row 1 to row 18. It finds the batch, runs every SnapLogic and Informatica job and every check up to **TF_30.01**, applies the fixes, and keeps the evidence.

Built from the MCC run book **v49 (2026-10-18)** and the scripts in your MCC package. It is a **pilot**: it has been tested in simulation, not yet against QA.

## Start

1. Install Python 3.9 or later. Nothing else is needed.
2. Edit `config.json`: `OrgAlias`, `AllowedOrgHosts`, `SunriseAppDir`, `GooseServer`.
3. Double-click **START PILOT.bat**. The browser opens at http://localhost:8765.

Run the offline tests any time with `python -m pilot.test_offline`.

## The three modes

| Mode | Contacts systems | Starts jobs | Applies fixes | Use it to |
|---|---|---|---|---|
| **Simulate** | No | No (simulated) | Simulated | Demo and training |
| **Dry run** | Salesforce and Goose, read only | No | DRY half only | Rehearse a real batch safely |
| **Live** | Yes | Yes | Yes, then re-verified | Run the batch |

For a live run, press **Find new batch**, type the batch name it shows, then press **Run to TF_30**.

## What one click does

1. **Finds the new batch.** It picks the newest Goose `MigrationBatch` that is `Open`, is not a test batch, has a matching `USS_Migration_Batch__c` in Salesforce, and hasn't already been taken through TF_30 by the pilot.
2. **Walks rows 1 to 18 in order:**
   - **PL_05 → PL_07 → PL_10**, then **TF_15 → TF_20 → TF_25 → TF_30**, with every run-book check between them.
   - **Fixes:** rows 10b (TF_15.01 parent address) and 11b (TF_20.05 bundle fractions). Each runs its CHECK or DRY Apex first. If anything needs fixing, it runs the LIVE Apex, confirms the Apex reports COMMITTED, and re-runs the check.
   - **Stops** at the first blocking FAIL or UNPROVEN in live mode, naming the row.
3. **Keeps the evidence** in `runs/<batch>_<mode>_<time>/`: `run.json`, `summary.html`, and the Apex log or Goose result for every step.
4. **Posts to Jira (optional).** It posts the summary as a comment if `Jira.Enabled` is on.

## Safety built in

- **QA only.** Salesforce must report `IsSandbox = true`, and its host must be listed in `AllowedOrgHosts`. Otherwise nothing runs.
- **Hard stop at TF_30.01.** TF_35 and later are not in the step list, so the pilot cannot run them, even by mistake.
- **Live needs the batch name** typed back to confirm.
- **Fix limits.** A fix that would touch more than `MaxFixRecords` (500) records is refused. A fix is also refused if any address has no Salesforce Id.
- **No secrets in files.** Tokens come only from environment variables, and `config.json` holds just their names.
- **Goose is not changed** in this phase. Per run book v49, Goose is the reference up to TF_30, and fixes change Salesforce only.

## What you need to confirm before the first live run

1. **Informatica.** The pilot calls Sunrise's `informatica_live` (`run_and_wait`, or else `start_taskflow` with `get_run_status`). A dry or live run prints the exact function signatures it found. Check that they match, and that the taskflow names in `config.json` are right.
2. **SnapLogic.** `Mode: manual` (the default) pauses at each PL step, so you run it in SnapLogic and press **Continue**. For true one-click, publish PL_05, PL_07 and PL_10 as **Triggered Tasks**, put their URLs in `config.json`, set `Mode: rest`, and put the token in the `SNAPLOGIC_TOKEN` environment variable.
3. **Goose generators.** The generator scripts return the Apex in a result set column named `apex`. The pilot reads every result set that Sunrise's `invoke_query` writes. Run one dry run and check the `logs/` folder to confirm the Apex came through whole.
4. **Missing scripts.** Rows **9a** (TF_15.00 Goose locks), **10a** (TF_20.00) and **11a** (TF_20.01) aren't in the package, so they show as SKIPPED. Drop the files into `scripts/` and they will run.
5. **Rows 16b to 16f and 16h** are batch-specific investigations or business decisions, or have no script yet, so they aren't automated.

## Files

```
START PILOT.bat     double-click to start
config.json         settings (no secrets)
pilot/pipeline.py   the 28 steps, run book v49 rows 1 to 18
pilot/engine.py     the one-click run: scan, run, judge, fix, gate, evidence
pilot/adapters.py   Salesforce (sf CLI), Goose and Informatica (Sunrise), SnapLogic, Jira
pilot/systems.py    builds connections; simulated systems for Simulate mode
pilot/ui.html       the page
scripts/            the run book scripts, copied unchanged
runs/               evidence from every run
```

The MCC Preflight Monitor stays read-only by design. Keep using it as the independent check, and treat this pilot as the tool that does the work.

## Batch discovery diagnostics (v0.1.2)

**Find new batch** now reads the newest 50 `dbo.MigrationBatch` rows, including
non-Open batches, and displays each row's Goose status, linked Salesforce ID,
and exact selection reason. It still selects only a non-test **Open** Goose
batch with a matching QA `USS_Migration_Batch__c` that hasn't been completed
by this pilot. Discovery itself is read-only; this update does not create batch
links or alter Salesforce, Goose, or execution safety requirements.

If all candidates show `no Salesforce match by linked ID`, inspect the Goose
`SalesforceUssMigrationBatchID` values and the corresponding QA batch records.
If the new batch is not listed among the newest 50, investigate the connected
Goose database/schema or increase the query window in `pilot/engine.py`.

The Salesforce lookup scans up to 2,000 latest records; if your QA org exceeds
that count, a linked record outside the window can appear unmatched. The
selected candidate should be verified before running Live.


## v0.1.3 Informatica error reconciliation

Every automatic Informatica taskflow now writes `logs/<step>_error_reconciliation.txt`
containing the complete taskflow status payload, the discovered `GOOSE_ErrorLog`
columns and up to 100 recent log rows. The `run.json` also includes
`reconciliations`. The log rows are **not necessarily batch-scoped**; verify
the migration key before acting on them. The original `taskflow` evidence is retained.

**No automatic source-row deletion or Goose error-log mutation is enabled.**
That requires validated record identifier columns, the precise source/staging
tables, the mapping to Informatica failed rows and a safe retry rule. Without
those facts deleting by an error message can remove unrelated or already-loaded
records. The existing pilot still ends at `TF_30.01`, still pauses for manually
configured SnapLogic jobs, and still stops on actual blocking taskflow failures.
Diagnostic-only checks remain nonblocking. The pilot must not report completion
of TF_35+ jobs it does not implement.

## v0.1.4 — Informatica attempt ledger and controlled retries

- Every Informatica attempt is recorded separately under `runs/<batch>_*/logs/`.
- `informatica_exception_ledger.csv` summarizes each captured result and Goose error-log inspection. The Goose log evidence is NOT conclusively batch-attributed until its real schema and matching keys have been verified.
- A definitively failed taskflow can be retried only if its exact taskflow name is placed in `Informatica.Retry.IdempotentTaskflows` in `config.json`. Confirm idempotence with the data owner before adding a taskflow. Timeouts, unknown states and communication errors are **never automatically restarted**.
- No records are deleted from Goose, no Goose error-log rows are edited, and no taskflow failures are concealed.
- The app currently has only the verified pipeline through TF_30.01. No claim of a complete migration is made by this build. The later run-book tasks need real step definitions, source table keys, and verified actions before end-to-end automatic execution is technically possible.

## v0.1.5 — Full-run coverage and extension validation

The original source archive includes **no verified post-TF_30 run-book code**, so this release does **not** claim a full migration. It adds a validated `runbook_extension.json` facility for later real steps and a `coverage` field in `run.json` and API state; partial TF_30 runs report `INCOMPLETE` and are **never marked fully processed**.

To configure real post-TF_30 stages, add steps with `id`, `ro`, `kind`, `system`, `name`, and `blocking:true` in runbook order. Supported kinds: `informatica` (requires exact Taskflows mapping), `snaplogic` (requires triggered URL), `apex`/`goose_sql`/`goose_gen_check`/`goose_gen_fix` (require the actual script). Add the final required milestone IDs, remove `StopAfter`, and set `RequireEndToEnd:true`. The live runner then validates mappings **before launching any work**. Do not use fictitious taskflow names.

This does not automatically delete Goose rows or update error logs; those changes need real source keys, confirmed Informatica error-to-record lineage, table schema, and transactional verification. With the current evidence there is no safe automatic writeback. Retry and evidence capture remain as in v0.1.4.


## v0.1.6 — Pre-run readiness (no false full-run claims)

Run `CHECK READINESS.bat` before Live, or open `/api/readiness` while the app runs.
This reports missing scripts, disabled/manual automation, the TF_30 pilot limit, and absent post-TF_30 definitions.
Live runs with `RequireEndToEnd=true` are checked before launching migration jobs.
`RequireEndToEnd=false` retains legacy pilot behavior and does not mean the migration is complete.
No scripts, source table mappings, or external taskflow IDs have been fabricated.
