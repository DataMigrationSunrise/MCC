SELECT ID AS SourceRecordId, BatchStatus, IsTestBatch,
  CASE WHEN BatchStatus IS NULL OR BatchStatus <> 'Open'
       THEN 'Batch status changed since discovery'
       ELSE 'Batch identity confirmed' END AS Reason,
  CASE WHEN BatchStatus = 'Open' THEN 1 ELSE 0 END AS IsEligible
FROM dbo.MigrationBatch
WHERE ID = {{GOOSE_BATCH_ID}}
