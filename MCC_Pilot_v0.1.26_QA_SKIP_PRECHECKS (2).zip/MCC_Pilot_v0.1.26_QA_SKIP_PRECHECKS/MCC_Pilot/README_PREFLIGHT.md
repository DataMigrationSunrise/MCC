# Pre-step Goose preflight (v0.1.9)

- On every step (including resumes) the runner scans the **selected Goose batch ID** before executing the step. Findings are logged and exported to `runs/<run>/preflight/preflight_<step>_<timestamp>.csv`, with an entry in `run.json` under `preflight_history`.
- `preflight_rules.json` specifies batch-scoped, read-only SQL checks for all steps or specific step IDs. Add a validated query file under `preflight_rules/` and register it there. It must be a single SELECT and include the required `{{GOOSE_BATCH_ID}}` placeholder. The runner replaces that placeholder with the selected integer Goose batch ID.
- Default rule verifies that `dbo.MigrationBatch` has not changed to a non-Open or test batch. A failed or unprovable identity check prevents a wrong-batch execution. Other rule findings are recorded and do not stop jobs.
- **No automated record exclusion, deletion, or Goose error-log updates are implemented.** Identifying the right source table, batch membership mapping, and safely reversible exclusion mechanism requires validated schema and evidence. A taskflow failure is not proof that its source row may be removed. Do not treat a blank or nonmatching source ID as grounds for deletion.
- Existing `StopAfter: TF_30.01` and incomplete downstream run book remain unchanged; this release does **not** complete an unattended end-to-end run.
- Scan output is read-only and does not imply a source record has been excluded. Per-step checks can be extended with verified step-specific rules without editing the runner.

Test: `python -m pilot.test_offline` from the `MCC_Pilot` directory.
