-- PWSTM-328. Verify staged generator parent lines survive the known inner-join service requirement.
-- Only records belonging to the selected Goose migration batch are considered.
SELECT TOP (1001) L.ID AS SourceRecordId,
       CASE WHEN EXISTS
          (SELECT 1 FROM dbo.STG_OrderLineItemService S
           WHERE S.OrderLineItemID = L.ID AND S.TransformationID = L.TransformationID
             AND COALESCE(S.SFDC_Goose_ExclusionReason, '') = '')
          THEN 'SOURCE_INPUT_PASS' ELSE 'PREDICTED_FAILURE' END AS TestResult,
       CASE WHEN EXISTS
          (SELECT 1 FROM dbo.STG_OrderLineItemService S
           WHERE S.OrderLineItemID = L.ID AND S.TransformationID = L.TransformationID
             AND COALESCE(S.SFDC_Goose_ExclusionReason, '') = '')
          THEN 'Service row exists for generator parent' ELSE 'No eligible service row. Quote-line INNER JOIN may remove generator and associated fuel' END AS Reason,
       L.PreStgID AS SourceKey, L.TransformationID AS TransformationId
FROM dbo.STG_OrderLineItem L
JOIN dbo.TRFM_Transformation T ON T.ID = L.TransformationID
WHERE T.MigrationBatchID = {{GOOSE_BATCH_ID}}
  AND COALESCE(L.SFDC_Goose_ExclusionReason, '') = ''
  AND (L.PreStgID IN ('0-2339712-10000', '0-2390656-10000')
       OR L.ProductCode IN ('P-GENSVC', '700-1038'))
