import sys, json
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, contract_orders

c = systems.build(app.CFG, 'dry', print)
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
print(contract_orders.reconcile(c.sf, c.goose, 'aFOVD0000001Swj4AE', 468, folder, 'TF_90A.C',
                                '2026-10-23T00:30:00Z', say=lambda m: print(m, flush=True)))
rep = json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))
for m, n in sorted(rep['errors'].items(), key=lambda kv: -kv[1])[:8]:
    print(n, '|', m)
print('contracts:', contract_orders.contracted(c.sf, 'aFOVD0000001Swj4AE'))
