import sys
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

B = 'aFOVD0000001Swj4AE'
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
print('orders by status:', [(r['Status'], r['n']) for r in sf.query(
    "SELECT Status, COUNT(Id) n FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s' GROUP BY Status" % B)])
print('quotes in batch:', sf.query("SELECT COUNT(Id) n FROM SBQQ__Quote__c WHERE USS_Migration_Batch__c = '%s'" % B)[0]['n'])
print('quotes ordered:', sf.query("SELECT COUNT(Id) n FROM SBQQ__Quote__c WHERE USS_Migration_Batch__c = '%s' AND SBQQ__Ordered__c = true" % B)[0]['n'])
