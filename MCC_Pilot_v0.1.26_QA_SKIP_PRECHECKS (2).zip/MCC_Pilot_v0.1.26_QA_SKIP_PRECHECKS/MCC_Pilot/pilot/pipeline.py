"""
The pilot pipeline: MCC run book v49 (2026-10-18), Run Order 1 to 18, ending at TF_30.01.

Each step says WHAT it runs and HOW its result is judged. Nothing past TF_30.01 is listed,
so the engine cannot run TF_35 or later even by mistake.

kind
  preflight        built in: batch valid in Goose AND Salesforce (run book row 1)
  apex             run a Salesforce Apex script (batch name substituted), judge its debug log
  goose_sql        run a read-only Goose script, record the result sets (informational)
  goose_gen_check  run a Goose generator, then run every Apex it outputs as a CHECK
  goose_gen_fix    run a Goose generator, run its CHECK/DRY Apex, and if anything needs fixing
                   and the run is LIVE, run its LIVE/APPLY Apex and verify it committed
  snaplogic        run a SnapLogic pipeline (Triggered Task, or wait for the operator)
  informatica      run an Informatica taskflow and wait for it to finish
  note             nothing to run; recorded for the audit trail

blocking  True  = a FAIL stops the run here (the run book treats it as a blocker)
          False = recorded, never stops the run
"""

STEPS = [
    dict(ro="1", id="PREFLIGHT", kind="preflight", system="Goose + Salesforce",
         name="Batch is valid in Goose and Salesforce", blocking=True),

    dict(ro="2", id="TF_00.02", kind="apex", system="Salesforce", blocking=False,
         name="Batch scope blind spot (context only)",
         script="TF_00.02_Check_Batch_Scope_Blind_Spot.apex"),

    dict(ro="3", id="PL_05", kind="snaplogic", system="SnapLogic", blocking=True,
         name="PL_05 Pre-Process"),

    dict(ro="4", id="PL_05.01", kind="goose_sql", system="Goose", blocking=False,
         name="Goose error log after PL_05",
         script="PL_05.01_Verify_Goose_Error_Log.sql"),

    dict(ro="5", id="TF_00.03", kind="apex", system="Salesforce", blocking=True,
         name="Step actually finished",
         # Org-wide failed async jobs are reported as context only: QA has unrelated
         # failures every day, and blocking on them stopped every run at RO 5.
         script="TF_00.03_Check_Step_Actually_Finished.apex"),

    dict(ro="6", id="PL_07", kind="snaplogic", system="SnapLogic", blocking=True,
         name="PL_07 Accounts and Contacts"),

    dict(ro="7", id="PL_07.01", kind="note", system="Salesforce", blocking=False,
         name="Existing account lookup (done inside PL_07, confirm only)"),

    # Field_Gap_Analysis.md: Goose has these, the load never maps them. Fill blanks only, right after
    # the records exist, so later objects and the final gap analysis see them.
    dict(ro="7m", id="PL_07.M", kind="field_fill", system="Goose + Salesforce", blocking=False,
         name="Fill unmapped fields: Account Migration ID",
         fills=[dict(sobject="Account", field="Migration_Id__c", goose_table="SFDC_Account",
                     goose_field="Migration_Id__c", goose_sf_id="SalesforceAccountID", unique=True),
                dict(sobject="Contact", field="Migration_Id__c", goose_table="SFDC_Contact",
                     goose_field="Migration_Id__c", goose_sf_id="SalesforceContactID", unique=True,
                     enabled=False, reason="left blank by decision (2026-10-25): Navision has no contact number; "
                                           "the account carries the customer number.")]),

    dict(ro="8", id="PL_10", kind="snaplogic", system="SnapLogic", blocking=True,
         name="PL_10 Account Contact Relations"),

    dict(ro="9a", id="TF_15.00", kind="goose_sql", system="Goose", blocking=True,
         name="No Goose locks before TF_15",
         script="TF_15.00_Check_No_Goose_Locks.sql", optional=True,
         fail_if_rows=True),

    # Blocking only so an UNKNOWN Goose write outcome stops the run; lookup problems are WARNINGs
    # and unmatched addresses are pushed through (logged MCC_PUSHED_THROUGH).
    dict(ro="9b", id="TF_15.G", kind="coord_match", system="Goose + Salesforce", blocking=True,
         name="Fill blank address coordinates from geocoded Salesforce addresses (logged in GOOSE_ErrorLog)"),

    dict(ro="10", id="TF_15", kind="informatica", system="Informatica", blocking=True,
         name="TF_15 Opportunities to Quotes"),

    # Run book lists this at RO 9, but it reads the batch's Salesforce quotes, which only exist
    # after TF_15. At RO 9 it always returned UNPROVEN and stopped every live run.
    dict(ro="10-", id="TF_02.01", kind="apex", system="Salesforce", blocking=True,
         name="Serviceable zip coverage (after TF_15 creates the quotes)",
         script="TF_02.01_Check_Serviceable_Zip_Coverage.apex"),

    dict(ro="10a", id="TF_20.00", kind="goose_sql", system="Goose", blocking=False,
         name="Bundled quantity in the view, before TF_20",
         script="TF_20.00_Check_View_BundledQuantity_PreLoad.sql", optional=True),

    dict(ro="10b", id="TF_15.01", kind="goose_gen_fix", system="Goose + Salesforce", blocking=True,
         name="FIX: parent address on USF Addresses",
         script="TF_15.01_Parent_Address_Update_Generator.sql",
         check_label="CHECK", live_label="LIVE",
         needs=[r"rows_to_update[^\d]*(\d+)", r"needs_fix=(\d+)", r"to_fix=(\d+)"]),

    dict(ro="10m", id="TF_15.M", kind="field_fill", system="Goose + Salesforce", blocking=False,
         name="Fill unmapped fields: Quote Migration ID / Subdivision, Opportunity name extension, address placement / site name",
         fills=[dict(sobject="SBQQ__Quote__c", field="Migration_Id__c", goose_table="SFDC_Quote",
                     goose_field="Migration_Id__c", goose_sf_id="SalesforceQuoteID"),
                dict(sobject="SBQQ__Quote__c", field="Subdivision_Name__c", goose_table="SFDC_Quote",
                     goose_field="Subdivision_Name__c", goose_sf_id="SalesforceQuoteID"),
                dict(sobject="Opportunity", field="Opportunity_Name_Extension__c", goose_table="SFDC_Opportunity",
                     goose_field="Opportunity_Name_Extension__c", goose_sf_id="SalesforceOpportunityID"),
                dict(sobject="USF_Address__c", field="NF_Placement__c", goose_table="SFDC_USF_Address",
                     goose_field="NF_Placement__c", goose_sf_id="Salesforce_USF_AddressID"),
                dict(sobject="USF_Address__c", field="Site_Name__c", goose_table="SFDC_USF_Address",
                     goose_field="Site_Name__c", goose_sf_id="Salesforce_USF_AddressID")]),

    dict(ro="10c", id="TF_20.03", kind="goose_sql", system="Goose", blocking=False,
         name="Fractional bundle quantities, before TF_20 (fixed at 11b)",
         script="TF_20.03_Check_Fractional_Bundle_Qty_PreLoad.sql"),

    dict(ro="10d", id="TF_20.04", kind="goose_gen_check", system="Goose + Salesforce", blocking=True,
         name="Every product has an active SKU and price book entry",
         script="TF_20.04_Check_Active_SKU_PBE_PreLoad_Generator.sql"),

    dict(ro="11", id="TF_20", kind="informatica", system="Informatica", blocking=True,
         name="TF_20 Quote Lines to Job Sites"),

    dict(ro="11a", id="TF_20.01", kind="goose_gen_check", system="Goose + Salesforce", blocking=True,
         name="Bundle quantity check before orders",
         script="TF_20.01_Generate_Bundle_Quantity_Check_PreOrder.sql", optional=True),

    dict(ro="11b", id="TF_20.05", kind="goose_gen_fix", system="Goose + Salesforce", blocking=True,
         name="FIX: bundle fraction quantities on quote lines",
         script="TF_20.05_FIXBQ_Bundle_Fraction_Fix_Generator.sql",
         check_label="DRY", live_label="LIVE",
         needs=[r"needs_fix=(\d+)"]),

    dict(ro="11c", id="TF_20.06", kind="apex", system="Salesforce", blocking=True,
         name="Quotes untagged by TF_20",
         script="TF_20.06_Check_Untagged_Quotes_PostTF20.apex"),

    dict(ro="12", id="TF_25.04", kind="apex", system="Salesforce", blocking=True,
         name="Quotes with no lines",
         script="TF_25.04_Check_Quotes_With_No_Lines.apex",
         count_fail={"quotes_with_zero_lines": r"Quotes with ZERO lines\s*:\s*(\d+)"}),

    dict(ro="13", id="TF_25", kind="informatica", system="Informatica", blocking=True,
         name="TF_25 Quote Updates"),

    dict(ro="14", id="TF_25.01", kind="goose_sql", system="Goose", blocking=False,
         name="Quote validation tab",
         script="TF_25.01_Verify_Quote_Validation_Tab.sql"),

    dict(ro="15", id="TF_25.02", kind="apex", system="Salesforce", blocking=True,
         name="Jobsite order readiness (geocoding)",
         script="TF_25.02_Verify_Jobsite_Order_Readiness.apex"),

    dict(ro="16", id="TF_25.03", kind="apex", system="Salesforce", blocking=True,
         name="Missing price book entries",
         script="TF_25.03_Check_Missing_PricebookEntry.apex"),

    dict(ro="16a", id="TF_25.06", kind="goose_gen_check", system="Goose + Salesforce", blocking=True,
         name="Pre-TF_30 Goose checks and CHKALL line compare",
         script="TF_25.06_PreTF30_Goose_Checks_and_CHKALL_Generator.sql"),

    dict(ro="16g", id="TF_25.05", kind="goose_gen_check", system="Goose + Salesforce", blocking=True,
         name="Quote fields vs Goose (delivery, branch, bill timing)",
         script="TF_25.05_Stage2_Quote_Fields_Check_Generator.sql"),

    dict(ro="17", id="TF_30", kind="informatica", system="Informatica", blocking=True,
         name="TF_30 Convert Quote to Order"),

    dict(ro="18", id="TF_30.01", kind="apex", system="Salesforce", blocking=True,
         name="Every quote converted to an order",
         script="TF_30.01_Check_Quotes_Not_Ordered.apex",
         count_fail={"not_ordered": r"NOT ORDERED \((\d+)\)"}),
]

# Run book rows 16b to 16f are batch-specific investigations with business decisions
# (UMB-0125). They are deliberately not automated. Row 16h (GEO check) has no script in
# the package yet; drop it into scripts/ and add a step here to include it.
EXCLUDED = ["16b", "16c", "16d", "16e", "16f", "16h"]
