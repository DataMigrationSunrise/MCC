SELECT L.ID AS SourceRecordId,
       'Generator rental bundle line staged as customer-owned (rental lines must be CustomerOwned = false)' AS Reason,
       L.ProductCode
FROM dbo.SFDC_Quote_Line L
WHERE L.MigrationBatchID = {{GOOSE_BATCH_ID}}
  AND L.CustomerOwned__c = 1
  AND ISNULL(L.ProductCode, '') <> '700-5001'
  AND EXISTS (SELECT 1 FROM dbo.SFDC_Quote_Line G
              WHERE G.MigrationBatchID = {{GOOSE_BATCH_ID}}
                AND G.ProductCode = '700-1038'
                AND COALESCE(G.SFDC_Quote_LineID_SBQQ__RequiredBy__c, G.ID)
                  = COALESCE(L.SFDC_Quote_LineID_SBQQ__RequiredBy__c, L.ID))
