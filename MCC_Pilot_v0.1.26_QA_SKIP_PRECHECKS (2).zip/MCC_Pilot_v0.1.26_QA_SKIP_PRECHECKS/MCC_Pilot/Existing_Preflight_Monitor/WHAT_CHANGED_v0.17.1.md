# MCC - Preflight Monitoring Tool — v0.17.1 (patch)

Three defects found by reviewing the stored run history and the source of v0.17.0.
No new checks, no new features, still no write path to Salesforce.

## 1. Two BIQ checks queried a field that does not exist

`BIQ.ERROR_STATUS` and `BIQ.FSC_NULL_EFFECTIVE_DATE` selected `Status__c` on
`Billing_Impacts_Queue__c`. The field is **`Processing_Status__c`**.

- **Observed:** in the stored UMB-0116 run (RUN_20261002_213105) both checks returned UNPROVEN
  with `INVALID_FIELD`. `BIQ.FSC_NULL_EFFECTIVE_DATE` is the finding the example workbook
  headlines, so the tool as shipped could not actually reproduce its own headline.
- **Fixed:** four SOQL sites in `checks.py` (BIQ.FSC_NULL_EFFECTIVE_DATE, `_biq_errors`, and the
  clamp-date query).
- **Why 349 tests did not catch it:** the test double `FakeConn.q()` ignores the SOQL it is given.
  New `RecordingConn` keeps every query; `test_no_check_queries_a_nonexistent_biq_field` runs every
  registered check against it and rejects a bare `Status__c` on that object.
- **Evidence the name is right:** it is used 39 times in Sunrise and the Goose data dictionary,
  and the user's own SOQL selects it. `Processing_Status__c = 'Error'` appears once in Sunrise.
  **Not confirmed by running against the org** — see "Not verified" below.

## 2. `records_blocked` summed a per-row number across rows

`runbook.summary()["records_blocked"]` was `sum(r["held"] ...)`. `held` includes records inherited
from upstream, so one failure was counted at every step it blocks. On the example data that is
**2,334 for 774 real records**.

- **Correction to the earlier review:** the v0.17.0 banner (`report.py:183`) does **not** use this
  number — it uses `errors_total`, which is correct. The "2334 record(s) held" text in the
  shipped example workbook came from an older build. In v0.17.0 the over-count is **latent**:
  computed, but not displayed anywhere. Fixed anyway so nothing can pick it up later.
- **Fixed:** new `distinct_blocking_records()` counts each blocking check once, over a row's own
  failures and the upstream blockers it names. `held` is unchanged as a per-row display value.
- **Test:** `test_records_blocked_counts_each_check_once` reproduces the 2,334 figure to prove it
  is testing the real bug, then asserts 774.

## 3. Every run was stamped version 0.1.0

`runner.TOOL_VERSION` was `"0.1.0"` while `server.VERSION` was `"0.17.0"` — two constants that had
drifted, so every row in `run.tool_version` is wrong.

- **Fixed:** one source. `server.py` now reads `runner.TOOL_VERSION`; value is `0.17.1`.
- **Test:** `test_one_version_source_and_it_matches_the_changelog` fails if the two ever differ, or
  if `TOOL_VERSION` is not the newest `WHAT_CHANGED_v*.md`. Bumping the version therefore requires
  writing a changelog, which is the point.
- Existing rows in `preflight_history.db` keep `0.1.0`. They cannot be corrected after the fact.

## Not verified — read this before trusting the patch

- **Nothing here was run against Salesforce.** The offline suite passes and the three new tests fail
  on the old code, but whether `Processing_Status__c` is queryable *by your user* (field-level
  security) is only known when you run it. If it is FLS-hidden the checks will now report UNPROVEN
  with a clearer reason, not an error.
- The picklist value `'Error'` for `Processing_Status__c` rests on one usage in Sunrise. If
  `BIQ.ERROR_STATUS` returns 0 rows with a healthy canary, check the picklist values first.

## Found in the same review, NOT changed in this patch

- Failure reasons are cut mid-word (`tus__c' on entity…`), which hid defect 1. Likely cause: tail
  slicing `out[-3000:]` in `connections.py:162, 184, 245`.
- `selftest_ok` is 1 on runs where most self-test stages were DEGRADED.
- Four checks are UNPROVEN on field-level security alone: `Account.USF_Department_Code__c`,
  `SBQQ__Quote__c.Bill_Timing__c / Billing_Period__c / Business_Type__c / Serviceable_Zip_Code__c`.
  One permission-set change unlocks all four.
- `example_output/` is not real data (placeholder BIQ keys, sequential contract numbers) and
  predates this build.
- `READ ME FIRST.txt` says 24 checks; 51 are registered. The Baseline banner prints a literal `%%`
  (`report.py:275`).
