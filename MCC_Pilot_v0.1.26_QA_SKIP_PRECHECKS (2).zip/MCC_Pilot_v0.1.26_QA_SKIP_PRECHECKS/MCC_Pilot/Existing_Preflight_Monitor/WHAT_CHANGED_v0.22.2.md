# v0.22.2 - RO 4 and RO 5 no longer say BLOCKED for work that isn't this batch

**RO 4 (Goose error log).** It counted every open row in GOOSE_ErrorLog (54,358, across all
batches) while saying it was scoped to the batch. It now filters to this batch's Goose id
(found through the Salesforce batch Id). If the log has no batch column, or the batch can't be
found in Goose, the check says "cannot tell" instead of failing. That also releases the hold
it put on RO 5, 7 and 8.

**RO 5 (async still running).** AsyncApexJob has no batch, so it counted every job in the
sandbox (41 running, 6 failed) as 47 failing records. It is now a REVIEW item, renamed
"Async Apex still running in the org (not tied to this batch)".

Not verified against live Goose: which column in GOOSE_ErrorLog holds the batch (ID vs
MigrationID) is inferred from the column name.
