"""Every change MCC makes to push a record through is written to dbo.GOOSE_ErrorLog.

Fix-and-log rule (2026-10-22): when MCC can safely fix a record so the migration can carry
on, it fixes it and appends one GOOSE_ErrorLog row saying exactly what it did, so the record
stays identifiable downstream. When it cannot fix a record but the record can still load
without breaking later steps, it lets it through and logs MCC_PUSHED_THROUGH. Fixes that
would break downstream logic are never made; those still stop the run.

    LogType            meaning
    MCC_FIXED          MCC changed the record (before/after in ErrorMessage)
    MCC_PUSHED_THROUGH record loaded as-is with a known gap (reason in ErrorMessage)
    MCC_EXCLUDED       record excluded from the batch

Append-only: original Goose errors are never changed. Entries are journalled locally before
the insert, so an interrupted write is still discoverable.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

LOG_TYPES = ("MCC_FIXED", "MCC_PUSHED_THROUGH", "MCC_EXCLUDED", "MCC_SF_ERROR")


def _lit(v, n) -> str:
    return "N'" + str(v if v is not None else "")[:n].replace("'", "''") + "'"


def entry(log_type: str, step: str, source_object: str, source_id, message: str,
          target_object: str = "") -> dict:
    if log_type not in LOG_TYPES:
        raise ValueError("Unknown MCC log type %s" % log_type)
    return dict(log_type=log_type, step=str(step), source_object=source_object,
                source_id=str(source_id), target_object=target_object, message=str(message))


def write(goose, batch_id: int, entries: list[dict], journal: Path, chunk: int = 25) -> int:
    """Append entries to GOOSE_ErrorLog and verify the inserted count. Returns rows written."""
    batch_id = int(batch_id)
    if batch_id <= 0:
        raise ValueError("A valid Goose batch ID is required")
    journal.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    for n in range(0, len(entries), chunk):
        part = entries[n:n + chunk]
        with journal.open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(time=datetime.now().isoformat(), batch_id=batch_id,
                                    status="LOG_ATTEMPT", entries=part)) + "\n")
        values = ",".join(
            "(GETDATE(), %d, %s, N'MCC_Pilot', %s, %s, %s, %s, %s)" % (
                batch_id, _lit(e["log_type"], 100), _lit(e["step"], 100), _lit(e["target_object"], 100),
                _lit(e["source_object"], 100), _lit(e["source_id"], 100), _lit(e["message"], 255))
            for e in part)
        sql = ("SET XACT_ABORT ON; BEGIN TRANSACTION; "
               "INSERT INTO dbo.GOOSE_ErrorLog (CreatedDate, MigrationBatchID, LogType, ProcessName, ProcessStep, "
               "TargetObject, SourceObject, SourceRecordID, ErrorMessage) VALUES %s; "
               "SELECT @@ROWCOUNT AS Inserted; COMMIT TRANSACTION;" % values)
        got = [r["Inserted"] for s in goose.result_sets(sql) for r in s if "Inserted" in r]
        if not got or int(got[0]) != len(part):
            raise RuntimeError("GOOSE_ErrorLog insert not verified (%s of %d)" % (got, len(part)))
        written += len(part)
        with journal.open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(time=datetime.now().isoformat(), batch_id=batch_id,
                                    status="LOGGED", count=len(part))) + "\n")
    return written
