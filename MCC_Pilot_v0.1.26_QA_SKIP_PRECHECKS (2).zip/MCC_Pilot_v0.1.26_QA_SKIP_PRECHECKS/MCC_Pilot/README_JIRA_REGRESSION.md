# MCC Pilot v0.1.20 — Jira-linked pre-transformation evidence

## New capability

The main MCC page includes a **Jira migration regression checks** registry and **Run Jira preflight (read-only)** button. The registry contains 39 PWSTM-304 child issues supplied in the October 22 snapshot, including 37 not marked Done/Cancelled. Each row has the last supplied Jira status, priority, owner, related step, and a *separate* verified-data prediction. **These are not live Jira status updates.** The Jira API credentials in config.json are still disabled; the registry must not be presented as live Jira sync.

The button selects the newest eligible batch using MCC's existing Goose/Salesforce batch discovery, then runs read-only SQL against the actual Goose `TRFM_Transformation.MigrationBatchID` chain. The results are stored in `runs/jira_preflight/batch_<id>/` (JSON and CSV). It does not trigger, skip or retry any migration step. Results are also captured automatically in `run.json` and in the run's `preflight/jira/` folder at these pipeline checkpoints:

| When | Jira ticket | Verification | What it DOES NOT prove |
|---|---|---|---|
| PREFLIGHT and before TF_20 | PWSTM-328 | The affected staged Generator Rental lines have an eligible `STG_OrderLineItemService` row (required by the previously observed quote-line inner join). Known `PreStgID`s included as anchors. | Fuel SKU 700-1148 selection, code change deployment, or eventual Salesforce Quote Line creation. |
| PREFLIGHT and before TF_35 | PWSTM-356 | Source `STG_OrderLineItem.Quantity` is positive/non-null. | Correct Work Order or WorkOrderLineItem quantities after Salesforce automation. |
| PREFLIGHT and before TF_40 | PWSTM-322 | Recurring service rows in staging have at least one eligible schedule row. | Salesforce future WO service-day parity. |

These tests are **read-only and diagnostic**. No new blocker, exclusion, or write is introduced by this registry. The existing migration preflight and execution rules are not modified. Run-through TF_35, checkpoint selection and resume operate as before.

## Interpreting results

- `PREDICTED_FAILURE`: Current staged records violate the explicitly checked transformation precondition (e.g., generator with no service row).
- `SOURCE_RISK`: Suspicious or missing staged inputs; further investigation required. Not necessarily a definitive ticket failure.
- `SOURCE_INPUT_PASS`: That exact source condition passed for the inspected cohort. **Not a claim the Jira ticket is fixed.**
- `NOT_TESTABLE`: No matching staged cohort or query failed; no pass implied.
- `INCOMPLETE_SAMPLE`: 1001 or more matching rows, so not all rows were inspected and no complete-pass claim is made.
- `NO_EXECUTABLE_CHECK`: Registry metadata exists, but this package does not have a verified predictive rule for the issue.
- `NOT_CHECKED_THIS_STEP`: An available rule did not run at this checkpoint.
- `SIMULATED_NOT_VERIFIED`: Simulation did not contact Goose.

The initial generator finding from transformation 543 and the more recent view changes are prior evidence only; they do **not** count as a current run result. The `PWSTM-328` source check is deliberately narrow because the fuel product mapping and generator parent-less fuel order business decisions cannot be proven by a service-row count. The source quantity and schedule checks likewise cannot close PWSTM-356 or PWSTM-322 without post-load Salesforce comparisons.

## Checks, evidence, and QA

- `jira_issue_registry.json`: snapshot of 39 issues; all `jira_checked_live` false.
- `jira_preflight_rules.json`: verified, step-scoped read-only rules.
- `jira_preflight_rules/*.sql`: single capped SQL SELECT per rule, with the selected numeric batch ID in `TRFM_Transformation.MigrationBatchID`.
- `pilot/jira_preflight.py`: execution, conservative classification and evidence export.
- `pilot/test_jira_preflight.py`: focused unit tests, including missing generator service row, timeout, no cohort, cap, simulation, no false Jira close.

Run offline tests from the extracted MCC_Pilot folder:

```
python -m pilot.test_offline
python -m pilot.test_jira_preflight
```

**Live operation requires an authorized local Goose and Salesforce connection.** The code was inspected and tested offline, not used to update live Goose, Salesforce or Jira. If the connection times out, the issue is NOT_TESTABLE rather than PASS. No Jira status changes are written back.

## Known limits (inherited from pilot v0.1.19)

The full downstream run-book gap and manually triggered SnapLogic pipelines remain. This package adds predictive Jira evidence; it is not an end-to-end migrated batch certification. The `TF_25.02` Apex script's pre-conversion path should be validated separately; a source-input check does not repair it. There are still missing downstream action implementations. Existing exclusion write safeguards remain those of v0.1.19 and require live QA verification.
