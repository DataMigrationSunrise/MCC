"""Batch-scoped preflight fixes in Goose: set one allowlisted column to a known value (never DELETE).

Same shape as goose_exclusions: allowlisted table/column, integer IDs from a preflight SELECT,
one transaction with OUTPUT readback, a second query to verify, and a journal line written before
the write. Only rows that still need the change are touched, so a rerun finds nothing to do.
"""
import json
from datetime import datetime
from pathlib import Path

# (table, column) -> SQL data type the fix is written for. A different type in Goose = no write.
TARGETS = {('SFDC_Quote_Line', 'CustomerOwned__c'): 'bit'}


def _journal(path: Path, **row):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(dict(time=datetime.now().isoformat(), **row), default=str) + '\n')


def fix(goose, audit_file: Path, *, batch_id: int, table: str, column: str, value: int,
        ids: list, step: str, max_records: int = 500):
    if (table, column) not in TARGETS:
        raise ValueError('Fix target %s.%s not allowlisted' % (table, column))
    batch_id, value = int(batch_id), int(value)
    ids = sorted({int(i) for i in ids if int(i) > 0})
    if batch_id <= 0 or not ids:
        raise ValueError('Batch and record IDs must be positive integers')
    if len(ids) > max_records:
        return dict(status='TOO_MANY', fixed=[], detail='%d rows exceed max_records %d' % (len(ids), max_records))
    dtype = [r for g in goose.result_sets(
        "SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'dbo' "
        "AND TABLE_NAME = '%s' AND COLUMN_NAME = '%s'" % (table, column)) for r in g]
    if len(dtype) != 1 or str(dtype[0].get('DATA_TYPE')).lower() != TARGETS[(table, column)]:
        return dict(status='TYPE_MISMATCH', fixed=[], detail='%s.%s is %s, fix written for %s' % (
            table, column, dtype[0].get('DATA_TYPE') if dtype else 'missing', TARGETS[(table, column)]))
    where = 'S.MigrationBatchID = %d AND S.ID IN (%s)' % (batch_id, ','.join(map(str, ids)))
    sql = ('SET XACT_ABORT ON; BEGIN TRANSACTION; DECLARE @U TABLE (ID int); '
           'UPDATE S SET %s = %d OUTPUT inserted.ID INTO @U (ID) FROM dbo.%s S WHERE %s '
           'AND (S.%s IS NULL OR S.%s <> %d); SELECT ID FROM @U; COMMIT TRANSACTION;'
           % (column, value, table, where, column, column, value))
    _journal(audit_file, batch_id=batch_id, table=table, column=column, value=value, ids=ids,
             step=step, status='ATTEMPT_STARTED')
    try:
        result = goose.result_sets(sql)
    except Exception as exc:
        _journal(audit_file, batch_id=batch_id, table=table, step=step, status='WRITE_OUTCOME_UNKNOWN', error=str(exc))
        raise
    changed = sorted({int(r['ID']) for g in result for r in g if 'ID' in r})
    left = [r for g in goose.result_sets('SELECT S.ID FROM dbo.%s S WHERE %s AND (S.%s IS NULL OR S.%s <> %d)'
                                          % (table, where, column, column, value)) for r in g]
    status = 'FIXED' if not left else 'NOT_CHANGED_OR_UNVERIFIED'
    _journal(audit_file, batch_id=batch_id, table=table, column=column, value=value, step=step,
             status=status, changed=changed, still_wrong=[r.get('ID') for r in left])
    return dict(status=status, fixed=changed, detail='%d row(s) set %s = %d' % (len(changed), column, value))
