# v0.22.0 - filter the run book

Above the run book table, three rows of buttons. They combine (all three apply at once) and each
chip shows how many steps it holds.

- **Show:** Full process / Data-moving jobs (the Informatica and SnapLogic RUN steps, the ones
  that actually move data) / Informatica / SnapLogic / Goose / Salesforce. A step in two systems
  ("Goose + Salesforce") appears under both. Steps for Multi / All systems appear under Full
  process only.
- **Type:** Any / Run / Run Automation / Validation / Auto-Fix / Manual Review.
- **Status:** Any / Needs attention (Blocked, Held, Review, Unproven) / Blocked / Held / Review /
  Unproven / Ready / Not run or not checked.
- **Reset**, and a live "Showing N of 61 steps". The choice is remembered for next time.

Done in the browser over rows already drawn: no query, works on a snapshot, nothing stored or
counted changes. If a combination matches nothing it says so.

## Tested
Clicked through in a real browser (every button, combinations, reload, reset): counts matched.

## Not changed
The Excel export always carries the full run book.
