"""Check registry with import-time validation. A malformed check fails at startup, not mid-run."""
from __future__ import annotations
from model import Check
import checks as _checks


class RegistryError(Exception):
    pass


import dataclasses

_BOUND: list[Check] | None = None


# check id -> a distinctive fragment of its run book Step name. Resolved against
# runbook.json at load, so renumbering the run book cannot mis-point a binding.
STEP_BY_CHECK = {
 "SCOPE.WO_NO_CONTRACT": "TF_00.02", "SCOPE.BIQ_NO_PARENT": "TF_00.02",
 "SCOPE.MP_NO_CONTRACT": "TF_00.02", "SCOPE.CONTRACT_NO_BATCH": "TF_00.02",
 "RAN.STEP_NOT_FINISHED": "TF_00.03", "RAN.GOOSE_ERRORLOG": "PL_05.01",
 "QUOTE.SERVICEABLE_ZIP": "TF_02.01", "QUOTE.NO_LINES": "TF_25.04",
 "QUOTE.MISSING_PRICEBOOK_ENTRY": "TF_25.03", "QUOTE.NOT_ORDERED": "TF_30.01",
 "CONTRACT.LASTBILLINGDATE_RULE": "TF_60.0b",
 "CONTRACT.NONMONTHLY_NULL_LASTBILLINGDATE": "TF_60.01a",
 "BIQ.COVERAGE": "TF_60.06", "BIQ.FSC_NULL_EFFECTIVE_DATE": "TF_60.04_",
 "WO.ORDERS_MISSING_WOS": "TF_90A.04", "WO.DEAD_POLYGON": "TF_90A.05",
 "WO.MP_NO_GENERATION": "TF_90A.08", "WO.SERVICE_COVERAGE": "TF_55.0y",
 "RAN.PL_07_ACCOUNTS": "PL_07_Accounts", "RAN.PL_07_CONTACTS": "PL_07_Accounts",
 "RAN.PL_10_ACR": "PL_10_", "RAN.TF_15_QUOTES": "TF_15_",
 "RAN.TF_20_QUOTELINES": "TF_20_", "RAN.TF_30_ORDERS": "TF_30_Convert",
 "RAN.TF_35_CONTRACTS": "TF_35_Activate", "RAN.TF_40_MPS": "TF_40_Update",
 "RAN.TF_55_WORKORDERS": "TF_55_Complete", "RAN.TF_55_WOLIS": "TF_55_Complete",
 "RAN.TF_60_APPOINTMENTS": "TF_60_FSL", "RAN.TF_60_BIQS": "TF_60_FSL",
}


def _order_for(check_id, fallback):
    frag = STEP_BY_CHECK.get(check_id)
    if not frag:
        return fallback
    try:
        import runbook
        for s in runbook.steps():
            if frag in str(s.get("step") or ""):
                return s["order"]
    except Exception:
        pass
    return fallback


def all_checks() -> list[Check]:
    """
    Checks with their run book bindings applied, IN RUN BOOK ORDER.

    Definitions stay grouped by subject in checks.py because that is how they are read and
    maintained; the binding table carries Run Order, what each failure blocks, and the
    remediation. Execution and reporting follow the RUN BOOK, not the source file.

    They used to run in definition order, so the progress log jumped 2, 2, 18, 51, 50, 54,
    55, 28... and PREDICT.LOAD_FAILURES -- Run Order 3 -- ran 23rd of 48. That changed no
    answer: checks are independent and readiness is computed from the stored results
    afterwards. But it made the log unreadable while it ran, and a broken pre-flight was
    only discovered after minutes spent checking Run Order 55.

    An unbound check sorts LAST, so one that nobody remembered to bind cannot quietly jump
    the queue and look like a pre-flight.
    """
    global _BOUND
    if _BOUND is None:
        out = []
        for c in _checks.CHECKS:
            b = _checks.BINDINGS.get(c.id)
            if b:
                b = dict(b)
                b["runbook_order"] = _order_for(c.id, b.get("runbook_order"))
                rem = b.get("remediation")
                if rem is not None and rem.runbook_order is not None:
                    rem.runbook_order = _order_for(c.id, rem.runbook_order)
                out.append(dataclasses.replace(c, **b))
            else:
                out.append(c)
        out.sort(key=lambda c: (c.runbook_order if c.runbook_order else 10_000,
                                c.sequence, c.id))
        _BOUND = out
    return list(_BOUND)


def validate() -> list[str]:
    errs, seen = [], set()
    for c in all_checks():
        errs += c.validate()
        if c.id in seen:
            errs.append("duplicate check id: %s" % c.id)
        seen.add(c.id)
    return errs


def require_valid():
    errs = validate()
    if errs:
        raise RegistryError("Check registry is invalid:\n  - " + "\n  - ".join(errs))


def by_stage(stage: str = "") -> list[Check]:
    cs = all_checks()
    return [c for c in cs if c.stage == stage] if stage else cs


def by_id(cid: str) -> Check | None:
    return next((c for c in all_checks() if c.id == cid), None)


def stages() -> list[str]:
    return sorted({c.stage for c in all_checks()})


def rules():
    return list(_checks.RULES)


def spine():
    return list(_checks.SPINE)


def fixtures():
    return list(_checks.FIXTURES)
