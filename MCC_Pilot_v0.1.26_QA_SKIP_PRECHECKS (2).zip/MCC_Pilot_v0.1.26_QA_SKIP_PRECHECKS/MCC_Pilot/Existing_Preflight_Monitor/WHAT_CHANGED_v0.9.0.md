# Preflight Monitor v0.9.0

Three new sections above the run book, in the order you actually read them.

## 1. Records in Salesforce for this batch

One card per Salesforce object, in migration order, with **two numbers that are not the
same thing**: how many records of that object belong to this batch, and how many of them a
check found wrong.

**An object whose load step has not run yet is dimmed and counts ZERO errors.** That was
the point of the request and it matters: `Billing_Impacts_Queue__c` is created at Run Order
48, so on a batch stopped at Run Order 2 its emptiness is not a defect. Counting it as one
made every early run look like a catastrophe. Three states are distinguished:

- **PENDING** — the producing step has not been reached. Dimmed, zero errors, says so.
- **loaded but empty** — the producing step *has* run and the object is still empty. A real
  gap, and the note says which Run Order should have filled it.
- **UNSCOPED** — no reliable batch path exists (only `AssignedResource`). Reported as
  UNSCOPED, never as a zero, because a zero that means "I could not ask" is the failure
  mode this tool exists to prevent.

Accounts, Contacts, ACRs and Addresses are reached through the batch's **Quotes**, because
in an acquisition onboarding they already exist and are never tagged with the batch. For
those, "loaded" means **touched by this batch**, not created by it — their `CreatedDate` is
old by design, and last-modified is what shows the batch touched them.

## 2. Current step

Derived from **run times**, not guessed. A step counts as having run only on its own
evidence — a reported Informatica/SnapLogic run window, or a check there that actually
measured records. The current step is the earliest blocked one, or the first step after the
furthest one that ran. **That row is highlighted in the run book below.**

Being BLOCKED is not evidence a step ran. A step forty orders ahead is marked BLOCKED purely
because something upstream failed; an earlier draft treated that as progress and reported
the batch at Run Order 51 when it had not passed Run Order 2.

## 3. All issues

Every error and every unproven check in one list, worst first, with the records behind each
and what to do about it. Issues on not-yet-loaded objects are excluded.

The headline and this list are computed from **the same filtered set**, so they always quote
the same number. Two panels on one screen disagreeing by two records is how a dashboard
stops being believed.

## Does this analyse SOURCE data and warn before loading?

**Mostly no, and you should know exactly where the line is.**

Of 48 checks, **3** touch Goose (the source). There are 70 Salesforce query sites against 4
Goose ones. The tool overwhelmingly validates **what already landed**.

The one real pre-load check is `PREDICT.LOAD_FAILURES` at Run Order 3: it reads staged Goose
rows and validates them against the **live** Salesforce schema — active picklist values,
field lengths, types, createable flags, required fields — and rolls failures up into
patterns, because one inactive picklist value was 84% of 1,459 errors on the 2026-09-18
baseline. One decision clears that kind of pattern.

**It is currently switched off.** It needs Goose, which needs `SunriseAppDir` in
`config.json`, which is blank — so it reports UNPROVEN and does nothing. Set that path and
it runs.

Even then it predicts **platform rejections only**. It cannot predict trigger or
validation-rule rejections, and it says nothing about whether values are business-correct.
The jobsite and billing gaps at Run Order 15 are the clearest example: every one of those
records loads perfectly and is still wrong.

## Also

- The spreadsheet gains **Objects Loaded** and **All Issues** tabs.
- Snapshots carry the object tally, so a stored run shows all three sections with no query.
- Existing history databases migrate in place.
- ~130 regression tests. `python test_offline.py`.
