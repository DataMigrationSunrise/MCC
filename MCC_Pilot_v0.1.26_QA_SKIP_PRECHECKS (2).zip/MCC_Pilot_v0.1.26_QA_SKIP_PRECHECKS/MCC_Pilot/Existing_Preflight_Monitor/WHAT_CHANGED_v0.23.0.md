# v0.23.0 - the tool now checks its own answers against Salesforce

Nothing about a verdict changes. Beside each result there is now a second opinion on whether
the number can be trusted, shown on the records page, on a new **Verified against Salesforce**
page, and as a one-line strip above the run book.

What it looks at:
- **Scope.** Every query a check sends is kept. A failing check where none of them mentioned the
  batch is flagged "not tied to this batch" (this is what RO 4 and RO 5 were doing).
- **Query limits.** A query that returns exactly its LIMIT is flagged: records past it were never seen.
- **Duplicates and impossible counts.** Same record counted twice; more failing than examined.
- **Sample re-read.** Five of each failing check's record Ids are looked up in Salesforce again
  (on the object their Id prefix names). Missing ones are flagged; all found = VERIFIED.
- **Fields.** Every custom field a check's code names is checked against the org: MISSING (not in
  the org) or HIDDEN (deployed, but your login can't see it, so it reads as empty). A PASS that
  depends on one of these is flagged, because an empty column looks clean.

Not done, said plainly: this cannot recount a check a second, independent way (that needs
per-check logic), and the field scan reads each check's source text, so a field built by string
concatenation is not seen. Not yet run against your org; the first run is the real test.
Verification adds a few Salesforce calls (about 30 object describes, one metadata query, one
lookup per failing check) and is skipped, never fatal, if it can't run.
