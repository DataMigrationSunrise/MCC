# v0.23.4 - checks for steps done by hand or script that leave no trace if skipped

A skipped step (like TF_60.01 or the weekday fix) writes nothing down, so the only sign is its
effect being absent in the data. Two parts:

**1. Every writing step now says whether its work is done.** Under the status of RO 26, 27, 29, 30,
37, 38, 42, 49, 51, 53 and 57 the run book shows one of: "work still undone -- step skipped or not
finished" (a check on its effect fails), "cannot confirm the work was done" (that check is
unproven), or "nothing left for this step to do" (all pass). Hover for the checks it used.
TF_60.01 (RO 49) is judged by its three effects: LastBillingDate on Monthly Contracts, FSC BIQs
existing, and the Fuel Surcharge flag on Subscriptions. "Nothing left to do" is not proof the step
ran -- a step with nothing to fix passes the same way, and the tag says so.

**2. Two new checks for steps nothing else could see:**
- GOOSE.MP_WEEKDAY_GAP (RO 37): Maintenance Plans in Goose still missing New_Day_of_Week__c or
  New_StartDate, using the run book's own query and columns.
- BATCH.PRESNAPSHOT_FILE (RO 42): a JSON file is attached to the batch (TF_55.01's pre-change
  snapshot). Matches on file type only; the file name isn't documented.

Not done, and why: RO 43 (bulk complete) and RO 45 (Asset Locations / BIQs from WOLIs). The run book
doesn't say how to tell an eligible record or a "Delivery" line item, so a check would be a guess.
Tell me the rule and I'll add them. Both new checks use column names from the run book text and
are not yet confirmed against your org or Goose.
