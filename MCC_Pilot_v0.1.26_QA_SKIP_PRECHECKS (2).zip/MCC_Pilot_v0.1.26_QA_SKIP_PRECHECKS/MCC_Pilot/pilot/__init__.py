"""MCC Pilot: one click from a new batch to TF_30."""
__version__ = "0.1.1"
