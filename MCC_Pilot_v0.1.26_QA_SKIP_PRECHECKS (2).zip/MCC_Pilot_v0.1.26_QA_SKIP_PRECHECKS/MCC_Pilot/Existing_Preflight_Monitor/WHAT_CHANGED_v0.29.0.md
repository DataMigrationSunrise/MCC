# v0.29.0 - the self-test has its own page

- The run log and the main page no longer show self-test output. A run says nothing about it unless it cannot go ahead,
  and then the message names the failing stage and points to the page.
- New page: **More > Self-test results**. It shows the last result stage by stage (problems open, healthy ones folded),
  what each stage means, what to do, and - next to each problem a setting can fix - the setting itself
  (Salesforce alias/URL, Goose server/database, Informatica, Sunrise folder).
- Field-permission problems say an admin must grant read access; no setting can fix those.
- A Settings box holds Parallel queries, Full self-test on every run, and the legacy-Id field per object (for Export issues).
- Saving writes config.json (old copy kept as config.json.bak), checks the values, and applies on the next run without a restart.
- Pressing Self-test now takes you to that page. Each run's connection check refreshes stages 1, 2, 3 and 5 there;
  schema and canary lines are from the last full self-test, with its date.
