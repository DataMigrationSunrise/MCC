SELECT L.ID AS SourceRecordId,
       'Generator rental line staged as customer-owned (rental lines must be CustomerOwned = false)' AS Reason,
       COALESCE(NULLIF(L.SFDC_Goose_ExclusionReason, ''), NULLIF(O.SFDC_Goose_ExclusionReason, ''), '') AS ExclusionReason,
       O.Phase AS Phase,
       O.SourceObjectID AS SourceKey,
       L.OrderID AS ParentId,
       L.ProductCode,
       L.SourceProductCode
FROM dbo.STG_OrderLineItem L
LEFT JOIN dbo.STG_Order O ON O.ID = L.OrderID
WHERE L.TransformationID = {{TRANSFORMATION_ID}}
  AND L.IsCustomerOwned = 1
  AND (L.ProductCode = '700-1038' OR L.SourceProductCode = 'P-GEN')
