"""
MCC - Preflight Monitoring Tool -- entry point.

    python monitor.py selftest
    python monitor.py populate              backfill every batch, build the baseline
    python monitor.py gate   --batch UMB-0117
    python monitor.py report --batch UMB-0117
    python monitor.py serve  [--port 8899]
    python monitor.py seed-fixtures         record this week's proven defects

Read-only throughout. SELECT-only against Salesforce and Goose.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import actions
import registry
import runner
from store import Store

HERE = Path(__file__).resolve().parent
DEFAULT_CFG = HERE / "config.json"


def load_cfg(path=None) -> dict:
    p = Path(path or DEFAULT_CFG)
    if not p.is_file():
        print("No config at %s -- writing a template. Fill it in and re-run." % p)
        p.write_text(json.dumps({
            "OrgAlias": "USS_QA",
            "GooseServer": "D1DVSQL16",
            "GooseDatabase": "Goose",
            "SunriseAppDir": "",
            "DbPath": "preflight_history.db",
            "SeverityProfile": "QA"
        }, indent=2), encoding="utf-8")
        sys.exit(2)
    return json.loads(p.read_text(encoding="utf-8"))


def _say(msg, percent=None):
    print("  " + str(msg)[:160])


def cmd_selftest(args, cfg, store):
    r = actions.run_selftest(cfg, store, args.batch or "", _say)
    print("\nSELF-TEST %s" % ("PASSED" if r["ok"] else "FAILED -- refusing to report results"))
    return 0 if r["ok"] else 1


def cmd_populate(args, cfg, store):
    only = [x for x in (args.only or "").split(",") if x.strip()] or None
    actions.run_populate(cfg, store, only, _say)
    return 0


def cmd_gate(args, cfg, store):
    if not args.batch:
        print("--batch is required for gate"); return 2
    r = actions.run_gate(cfg, store, args.batch, args.stage, _say)
    return 1 if r["summary"]["failed"] else 0


def cmd_seed_fixtures(args, cfg, store):
    actions.seed_fixtures(store, _say)
    return 0


def cmd_issues(args, cfg, store):
    print(actions.run_issues_export(cfg, store, args.batch, args.out or ".", _say))


def cmd_runbook(args, cfg, store):
    print(actions.run_runbook_export(cfg, store, args.batch, args.out or ".", _say))
    return 0


def cmd_report(args, cfg, store):
    print(actions.run_report(cfg, store, args.batch, args.out or ".", _say))
    return 0


def cmd_serve(args, cfg, store):
    import server
    server.serve(cfg, store, args.port, args.config or DEFAULT_CFG)
    return 0


def main():
    ap = argparse.ArgumentParser(prog="monitor.py")
    ap.add_argument("command", choices=["selftest", "populate", "gate", "report", "runbook", "issues",
                                        "serve", "seed-fixtures"])
    ap.add_argument("--batch", default="")
    ap.add_argument("--stage", default="")
    ap.add_argument("--only", default="", help="populate: comma-separated batch names")
    ap.add_argument("--config", default="")
    ap.add_argument("--out", default="")
    ap.add_argument("--port", type=int, default=8899)
    args = ap.parse_args()

    cfg = load_cfg(args.config)
    try:
        registry.require_valid()
    except registry.RegistryError as e:
        print(e); return 1
    store = Store(cfg.get("DbPath", "preflight_history.db"), cfg.get("EvidenceCap", 0))
    try:
        return {"selftest": cmd_selftest, "populate": cmd_populate, "gate": cmd_gate,
                "report": cmd_report, "runbook": cmd_runbook, "issues": cmd_issues, "serve": cmd_serve,
                "seed-fixtures": cmd_seed_fixtures}[args.command](args, cfg, store)
    finally:
        store.close()


if __name__ == "__main__":
    sys.exit(main())
