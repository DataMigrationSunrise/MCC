"""SQLite history. One file, no server, queryable by hand. Accumulates across batches."""
from __future__ import annotations
import json, sqlite3, threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from model import Result, Metric, BaselineComparison

SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS batch(
  name TEXT PRIMARY KEY, sf_batch_id TEXT, goose_batch_id TEXT,
  sf_status TEXT, goose_status TEXT, status_agrees INTEGER,
  activated_contracts INTEGER, first_seen TEXT, last_seen TEXT, note TEXT);

CREATE TABLE IF NOT EXISTS run(
  run_id TEXT PRIMARY KEY, batch TEXT, mode TEXT, started TEXT, finished TEXT,
  tool_version TEXT, sf_alias TEXT, goose_server TEXT, goose_ok INTEGER,
  sunrise_run TEXT, selftest_ok INTEGER);

CREATE TABLE IF NOT EXISTS result(
  run_id TEXT, check_id TEXT, batch TEXT, verdict TEXT, reason TEXT,
  evidence_count INTEGER,            -- ERRORS found
  processed INTEGER,                  -- records EXAMINED
  metric_name TEXT, metric_value REAL, metric_unit TEXT,
  metric_num INTEGER, metric_den INTEGER,
  baseline_class TEXT, baseline_detail TEXT, duration_ms INTEGER, ran_at TEXT,
  ran_from TEXT, ran_to TEXT, run_status TEXT, run_source TEXT,
  PRIMARY KEY(run_id, check_id));
CREATE INDEX IF NOT EXISTS ix_result_check_batch ON result(check_id, batch);

CREATE TABLE IF NOT EXISTS evidence(
  run_id TEXT, check_id TEXT, seq INTEGER, payload TEXT);
CREATE INDEX IF NOT EXISTS ix_evidence ON evidence(run_id, check_id);

CREATE TABLE IF NOT EXISTS fixture(
  check_id TEXT, batch TEXT, expected_count INTEGER, state TEXT,
  last_confirmed TEXT, note TEXT, PRIMARY KEY(check_id, batch));

CREATE TABLE IF NOT EXISTS rule(
  rule_id TEXT PRIMARY KEY, sobject TEXT, rule_field TEXT,
  assertion TEXT, source TEXT, registered_by TEXT);

CREATE TABLE IF NOT EXISTS object_tally(
  run_id TEXT, sequence INTEGER, sobject TEXT, label TEXT,
  loaded INTEGER, state TEXT, first_created TEXT, last_created TEXT, last_modified TEXT,
  errors INTEGER, error_checks TEXT, note TEXT, produced_at INTEGER, pending INTEGER,
  PRIMARY KEY(run_id, sobject));

CREATE TABLE IF NOT EXISTS verification(
  run_id TEXT, check_id TEXT, status TEXT, payload TEXT,
  PRIMARY KEY(run_id, check_id));

CREATE TABLE IF NOT EXISTS selftest(
  run_id TEXT, stage TEXT, status TEXT, detail TEXT);
"""

EVIDENCE_CAP = 1000000         # rows stored per check per run; the COUNT is always exact
# 200 was too few to be useful: a 906-record failure stored 200 and the other 706 were
# gone, so "show me the records that failed" could not be answered from history. The count
# has always been exact regardless -- only the retained sample was short. Override with
# "EvidenceCap" in config.json.


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_run_id() -> str:
    return datetime.now(timezone.utc).strftime("RUN_%Y%m%d_%H%M%S_%f")


class Store:
    """
    Thread-safe by construction, via one connection PER THREAD.

    The browser UI reads history on the request thread while a job writes on a worker
    thread, and sqlite3 refuses cross-thread use of a single connection. WAL mode (set in
    SCHEMA) lets a reader and a writer coexist. jobs.py allows only one job at a time, so
    there is never writer-vs-writer contention.
    """

    def __init__(self, path: str | Path = "preflight_history.db", evidence_cap: int = 0):
        self.path = Path(path)
        self.evidence_cap = int(evidence_cap or EVIDENCE_CAP)
        self._lock = threading.RLock()
        self.db = sqlite3.connect(str(self.path), check_same_thread=False, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self._migrate()
        self.db.commit()

    # Added columns must reach databases that already exist -- CREATE TABLE IF NOT EXISTS
    # does nothing to a table that is already there, so a fresh schema alone would leave
    # every existing install writing into columns that are not present.
    _ADDED = (("result", "processed", "INTEGER"),
              ("result", "ran_from", "TEXT"),
              ("result", "ran_to", "TEXT"),
              ("result", "run_status", "TEXT"),
              ("result", "run_source", "TEXT"),
              ("object_tally", "produced_at", "INTEGER"),
              ("object_tally", "pending", "INTEGER"))

    def _migrate(self):
        for table, col, typ in self._ADDED:
            try:
                have = {r["name"] for r in
                        self.db.execute("PRAGMA table_info(%s)" % table).fetchall()}
            except Exception:                                # noqa: BLE001
                continue
            if have and col not in have:
                try:
                    self.db.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table, col, typ))
                except Exception:                            # noqa: BLE001
                    pass

    def close(self):
        with self._lock:
            self.db.close()

    # ---------------- batches
    def upsert_batch(self, name, sf_id="", goose_id="", sf_status="", goose_status="",
                     activated=None, note=""):
        agrees = None
        if sf_status and goose_status:
            agrees = 1 if str(sf_status).strip().lower() == str(goose_status).strip().lower() else 0
        cur = self.db.execute("SELECT name FROM batch WHERE name=?", (name,)).fetchone()
        if cur:
            self.db.execute(
                """UPDATE batch SET sf_batch_id=COALESCE(NULLIF(?,''),sf_batch_id),
                   goose_batch_id=COALESCE(NULLIF(?,''),goose_batch_id),
                   sf_status=COALESCE(NULLIF(?,''),sf_status),
                   goose_status=COALESCE(NULLIF(?,''),goose_status),
                   status_agrees=COALESCE(?,status_agrees),
                   activated_contracts=COALESCE(?,activated_contracts),
                   last_seen=?, note=COALESCE(NULLIF(?,''),note) WHERE name=?""",
                (sf_id, goose_id, sf_status, goose_status, agrees, activated, utcnow(), note, name))
        else:
            self.db.execute(
                """INSERT INTO batch(name,sf_batch_id,goose_batch_id,sf_status,goose_status,
                   status_agrees,activated_contracts,first_seen,last_seen,note)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (name, sf_id, goose_id, sf_status, goose_status, agrees, activated,
                 utcnow(), utcnow(), note))
        self.db.commit()

    def batches(self) -> list[sqlite3.Row]:
        with self._lock:
            return self.db.execute("SELECT * FROM batch ORDER BY name").fetchall()

    # ---------------- runs
    def start_run(self, run_id, batch, mode, version, alias, goose_server, goose_ok, sunrise_run):
        with self._lock:
            self.db.execute(
                """INSERT OR REPLACE INTO run(run_id,batch,mode,started,tool_version,sf_alias,
                   goose_server,goose_ok,sunrise_run) VALUES(?,?,?,?,?,?,?,?,?)""",
                (run_id, batch, mode, utcnow(), version, alias, goose_server,
                 1 if goose_ok else 0, str(sunrise_run or "")))
            self.db.commit()

    def finish_run(self, run_id, selftest_ok=True):
        with self._lock:
            self.db.execute("UPDATE run SET finished=?, selftest_ok=? WHERE run_id=?",
                            (utcnow(), 1 if selftest_ok else 0, run_id))
            self.db.commit()

    def save_tally(self, run_id, rows):
        """One row per Salesforce object for this run. Replaces any previous tally."""
        with self._lock:
            self.db.execute("DELETE FROM object_tally WHERE run_id=?", (run_id,))
            for r in rows:
                self.db.execute(
                    """INSERT OR REPLACE INTO object_tally(run_id,sequence,sobject,label,loaded,
                       state,first_created,last_created,last_modified,errors,error_checks,note,
                       produced_at,pending)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (run_id, r.get("sequence"), r.get("sobject"), r.get("label"),
                     r.get("loaded"), r.get("state"), r.get("first"), r.get("last"),
                     r.get("modified"), r.get("errors"), r.get("error_checks"), r.get("note"),
                     r.get("produced_at"), 1 if r.get("pending") else 0))
            self.db.commit()

    def tally(self, run_id) -> list[dict]:
        with self._lock:
            try:
                rows = self.db.execute(
                    "SELECT * FROM object_tally WHERE run_id=? ORDER BY sequence",
                    (run_id,)).fetchall()
            except Exception:                                # noqa: BLE001
                return []
        out = []
        for r in rows:
            d = dict(r)
            d["first"], d["last"] = d.pop("first_created", ""), d.pop("last_created", "")
            d["modified"] = d.pop("last_modified", "")
            d["pending"] = bool(d.get("pending"))
            out.append(d)
        return out

    def record_selftest(self, run_id, stage, status, detail=""):
        with self._lock:
            self.db.execute("INSERT INTO selftest(run_id,stage,status,detail) VALUES(?,?,?,?)",
                            (run_id, stage, status, str(detail)[:4000]))
            self.db.commit()

    LAST_FULL = "_LAST_FULL"

    def save_last_selftest(self, stages, full=True):
        """Remember the latest self-test for the Self-test page. A quick connection check replaces
        stages 1, 2, 3 and 5 only, so the schema and canary lines of the last FULL test survive."""
        with self._lock:
            now = utcnow()
            if full:
                self.db.execute("DELETE FROM selftest WHERE run_id=?", (self.LAST_FULL,))
                self.db.execute("INSERT INTO selftest(run_id,stage,status,detail) VALUES(?,?,?,?)",
                                (self.LAST_FULL, "_taken", "OK", now))
            else:
                self.db.execute("DELETE FROM selftest WHERE run_id=? AND substr(stage,1,1) IN ('1','2','3','5')",
                                (self.LAST_FULL,))
            self.db.execute("DELETE FROM selftest WHERE run_id=? AND stage='_conn'", (self.LAST_FULL,))
            self.db.execute("INSERT INTO selftest(run_id,stage,status,detail) VALUES(?,?,?,?)",
                            (self.LAST_FULL, "_conn", "OK", now))
            for x in stages:
                self.db.execute("INSERT INTO selftest(run_id,stage,status,detail) VALUES(?,?,?,?)",
                                (self.LAST_FULL, x["stage"], x["status"], str(x["detail"])[:4000]))
            self.db.commit()

    def last_selftest_conn_time(self):
        with self._lock:
            r = self.db.execute("SELECT detail FROM selftest WHERE run_id=? AND stage='_conn'",
                                (self.LAST_FULL,)).fetchone()
        return r["detail"] if r else ""

    def last_selftest(self):
        """-> (taken_at, [stage rows]) of the last full self-test, or ("", [])."""
        with self._lock:
            rows = self.db.execute("SELECT stage,status,detail FROM selftest WHERE run_id=?",
                                   (self.LAST_FULL,)).fetchall()
        taken = next((r["detail"] for r in rows if r["stage"] == "_taken"), "")
        return taken, [dict(stage=r["stage"], status=r["status"], detail=r["detail"])
                       for r in rows if not r["stage"].startswith("_")]

    # ---------------- results
    def save_result(self, run_id: str, r: Result):
        with self._lock:
            m = r.metric
            b = r.baseline
            self.db.execute(
                """INSERT OR REPLACE INTO result(run_id,check_id,batch,verdict,reason,evidence_count,
                   processed,metric_name,metric_value,metric_unit,metric_num,metric_den,
                   baseline_class,baseline_detail,duration_ms,ran_at,
                   ran_from,ran_to,run_status,run_source)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (run_id, r.check_id, r.batch, r.verdict, r.reason, r.evidence_count,
                 r.processed,
                 m.name if m else None, m.value if m else None, m.unit if m else None,
                 m.numerator if m else None, m.denominator if m else None,
                 b.cls if b else None, b.detail if b else None, r.duration_ms, r.ran_at or utcnow(),
                 r.ran_from, r.ran_to, r.run_status, r.run_source))
            self.db.execute("DELETE FROM evidence WHERE run_id=? AND check_id=?", (run_id, r.check_id))
            for i, row in enumerate(r.evidence_sample[:self.evidence_cap]):
                self.db.execute("INSERT INTO evidence(run_id,check_id,seq,payload) VALUES(?,?,?,?)",
                                (run_id, r.check_id, i, json.dumps(row, default=str)[:8000]))
            self.db.commit()

    def evidence(self, run_id, check_id) -> list[dict]:
        """The actual offending records this check found, in the order it found them."""
        with self._lock:
            rows = self.db.execute(
                "SELECT payload FROM evidence WHERE run_id=? AND check_id=? ORDER BY seq",
                (run_id, check_id)).fetchall()
        out = []
        for r in rows:
            try:
                d = json.loads(r["payload"])
            except Exception:                                # noqa: BLE001
                d = {"raw": r["payload"]}
            out.append(d if isinstance(d, dict) else {"value": d})
        return out

    def save_verification(self, run_id: str, items: dict):
        with self._lock:
            self.db.execute("DELETE FROM verification WHERE run_id=?", (run_id,))
            for cid, v in items.items():
                self.db.execute("INSERT INTO verification(run_id,check_id,status,payload) VALUES(?,?,?,?)",
                                (run_id, cid, v.get("status", ""), json.dumps(v, default=str)[:60000]))
            self.db.commit()

    def verification(self, run_id: str) -> dict:
        """{check_id: verification dict}. Empty for runs that predate verification."""
        with self._lock:
            rows = self.db.execute("SELECT check_id, payload FROM verification WHERE run_id=?",
                                   (run_id,)).fetchall()
        out = {}
        for r in rows:
            try:
                out[r["check_id"]] = json.loads(r["payload"])
            except Exception:                                # noqa: BLE001
                pass
        return out

    def results_for_run(self, run_id) -> list[sqlite3.Row]:
        with self._lock:
            return self.db.execute(
                "SELECT * FROM result WHERE run_id=? ORDER BY check_id", (run_id,)).fetchall()

    def latest_run_id(self, batch: str = "", mode: str = "") -> Optional[str]:
        with self._lock:
            sql = "SELECT run_id FROM run WHERE finished IS NOT NULL"
            args = []
            if batch:
                sql += " AND batch=?"; args.append(batch)
            if mode:
                sql += " AND mode=?"; args.append(mode)
            sql += " ORDER BY started DESC LIMIT 1"
            row = self.db.execute(sql, args).fetchone()
            return row["run_id"] if row else None

    # ---------------- baseline source
    def metric_history(self, check_id: str, exclude_batch: str = "") -> list[tuple[str, float]]:
        with self._lock:
            """Latest metric per batch for one check. One row per batch -- re-runs do not skew it."""
            rows = self.db.execute(
                """SELECT batch, metric_value FROM result
                   WHERE check_id=? AND metric_value IS NOT NULL AND verdict != 'UNPROVEN'
                     AND ran_at IN (SELECT MAX(ran_at) FROM result r2
                                    WHERE r2.check_id=result.check_id AND r2.batch=result.batch)
                   ORDER BY batch""", (check_id,)).fetchall()
            return [(r["batch"], float(r["metric_value"])) for r in rows
                    if r["batch"] != exclude_batch]

    def latest_result(self, check_id: str, batch: str) -> Optional[sqlite3.Row]:
        with self._lock:
            return self.db.execute(
                """SELECT * FROM result WHERE check_id=? AND batch=?
                   ORDER BY ran_at DESC LIMIT 1""", (check_id, batch)).fetchone()

    # ---------------- fixtures
    def upsert_fixture(self, check_id, batch, expected, state="PRESENT", note=""):
        with self._lock:
            self.db.execute(
                """INSERT OR REPLACE INTO fixture(check_id,batch,expected_count,state,
                   last_confirmed,note) VALUES(?,?,?,?,?,?)""",
                (check_id, batch, expected, state, utcnow(), note))
            self.db.commit()

    def fixtures(self) -> list[sqlite3.Row]:
        with self._lock:
            return self.db.execute("SELECT * FROM fixture ORDER BY check_id,batch").fetchall()

    def set_fixture_state(self, check_id, batch, state):
        with self._lock:
            self.db.execute("UPDATE fixture SET state=?, last_confirmed=? WHERE check_id=? AND batch=?",
                            (state, utcnow(), check_id, batch))
            self.db.commit()

    # ---------------- rules
    def register_rule(self, r):
        with self._lock:
            self.db.execute(
                """INSERT OR REPLACE INTO rule(rule_id,sobject,rule_field,assertion,source,registered_by)
                   VALUES(?,?,?,?,?,?)""",
                (r.rule_id, r.sobject, r.rule_field, r.assertion, r.source, r.registered_by))
            self.db.commit()

    def contradictions(self) -> list[dict]:
        with self._lock:
            """Two or more DIFFERENT assertions on one object+field is a contradiction."""
            rows = self.db.execute(
                "SELECT sobject, rule_field, assertion, source, registered_by FROM rule").fetchall()
            by = {}
            for r in rows:
                by.setdefault((r["sobject"], r["rule_field"]), []).append(dict(r))
            out = []
            for (obj, fld), lst in by.items():
                if len({x["assertion"].strip().lower() for x in lst}) > 1:
                    out.append({"sobject": obj, "field": fld, "rules": lst})
            return out
