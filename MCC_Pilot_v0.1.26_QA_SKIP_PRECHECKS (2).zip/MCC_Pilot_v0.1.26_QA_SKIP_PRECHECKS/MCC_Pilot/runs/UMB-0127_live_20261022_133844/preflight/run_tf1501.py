"""Run MCC step TF_15.01 (parent address fix) on its own, with MCC's own step code and logging."""
import sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems
from pilot.engine import Run
from pilot.pipeline import STEPS

c = systems.build(app.CFG, 'dry', print)
r = Run(app.CFG, 'live', systems.build)
r.folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
r.batch = dict(name='UMB-0127', goose_id=468, sf_id='aFOVD0000001Swj4AE')
r.say = print
step = next(s for s in STEPS if s['id'] == 'TF_15.01')
print(r._k_goose_gen_fix(c, step))
