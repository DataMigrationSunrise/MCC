"""Read-only: order line quantities and start dates, stuck vs succeeded."""
import json, sys, collections
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

B = 'aFOVD0000001Swj4AE'
folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = {o['id'][:15] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']}
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
rows = sf.query("SELECT Id, EffectiveDate, Type, (SELECT Quantity, ServiceDate, SBQQ__QuoteLine__c, SBQQ__RequiredBy__c, CustomerOwned__c "
                "FROM OrderItems) FROM Order WHERE SBQQ__Quote__r.USS_Migration_Batch__c = '%s'" % B)
out = collections.defaultdict(collections.Counter)
for r in rows:
    g = 'stuck' if r['Id'][:15] in stuck else 'succeeded'
    items = (r.get('OrderItems') or {}).get('records') or []
    bundles = [i for i in items if not i.get('SBQQ__RequiredBy__c')]
    out[g]['orders'] += 1
    out[g]['type ' + str(r.get('Type'))] += 1
    out[g]['no positive-qty line'] += not any((i.get('Quantity') or 0) > 0 for i in items)
    out[g]['bundle line qty <= 0'] += any((i.get('Quantity') or 0) <= 0 for i in bundles)
    out[g]['line with null ServiceDate'] += any(not i.get('ServiceDate') for i in items)
    out[g]['line without quote line'] += any(not i.get('SBQQ__QuoteLine__c') for i in items)
    out[g]['effective date in past'] += (r.get('EffectiveDate') or '9') < '2026-10-22'
for g in ('stuck', 'succeeded'):
    print(g, dict(out[g]))
