"""Read-only: on the 62 stuck orders, which lines are CustomerOwned = true (type + product)?"""
import json, sys, collections
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import adapters as ad, app

folder = Path(r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot\runs\UMB-0127_live_20261022_133844')
stuck = [o['id'] for o in json.loads((folder / 'logs' / 'TF_90A.C_error_reconciliation.json').read_text(encoding='utf-8'))['stuck']]
sf = ad.Salesforce(app.CFG['OrgAlias'], [])
ids = "','".join(stuck)
items = sf.query("SELECT OrderId, Product_Type__c, CustomerOwned__c, Is_Power_Ancillary_Asset__c, Product2.Name, Product2.Family "
                 "FROM OrderItem WHERE OrderId IN ('%s')" % ids)
by = collections.Counter((i.get('Product_Type__c'), bool(i.get('CustomerOwned__c'))) for i in items)
print('lines on stuck orders by (type, customer-owned):')
for k, v in sorted(by.items(), key=lambda kv: (str(kv[0][0]), kv[0][1])):
    print('   %-20s CO=%-5s %d' % (k[0], k[1], v))
co_names = collections.Counter(((i.get('Product2') or {}).get('Name'), i.get('Product_Type__c')) for i in items if i.get('CustomerOwned__c'))
print('customer-owned lines by product:')
for (n, t), v in co_names.most_common(12):
    print('   %4d  %-40s %s' % (v, n, t))
orders_with_co_pnd = {i['OrderId'] for i in items if i.get('CustomerOwned__c') and i.get('Product_Type__c') == 'P n D'}
orders_with_any_pnd = {i['OrderId'] for i in items if i.get('Product_Type__c') == 'P n D'}
print('stuck orders with P n D lines:', len(orders_with_any_pnd), '| of which customer-owned:', len(orders_with_co_pnd))
