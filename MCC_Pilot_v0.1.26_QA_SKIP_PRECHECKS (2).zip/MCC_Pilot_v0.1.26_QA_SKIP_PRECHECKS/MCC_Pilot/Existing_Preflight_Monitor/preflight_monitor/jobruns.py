"""
WHEN did the Informatica / SnapLogic step actually run?

Two sources, in order of authority:

  1. THE JOB'S OWN API RECORD, as already captured by the Sunrise MCC app.
     informatica_live.py writes  test_run_history/informatica_live/*_result_<name>.json
       -> Taskflow, RunId, Status, Succeeded, StartedAtUtc, CompletedAtUtc, Monitor
     snaplogic_live.py  writes  test_run_history/snaplogic_live/<stamp>/executions.csv
       -> RUUID, Pipeline, ProjectPath, Status, StartTime, EndTime, Snaplex, User
     This is the authoritative answer: it is the orchestrator's own statement of when it
     ran and whether it succeeded. We READ what Sunrise already captured and never touch
     a credential -- no API call, no token, no connection string in this tool.

  2. RECORD STAMPS in Salesforce, as a fallback.
     MIN/MAX CreatedDate and MAX LastModifiedDate of the records the step produces.
     This is a PROXY, not the job clock: it tells you when rows were written, which is
     inside the run window but is not the run window. It is labelled as such everywhere
     it is displayed, because a step that ran and wrote nothing has no stamps at all --
     and that is exactly the case we are trying to detect.

Source 1 answers "did the job run and did it succeed". Source 2 answers "when did rows
land". Neither substitutes for the other, so both are reported.
"""
from __future__ import annotations
import csv, json, re
from pathlib import Path

# A step's run-book name ("TF_15_OpportunitiesToQuotes", "PL_07_Accounts_and_Contacts")
# has to be matched against whatever the orchestrator called the taskflow/pipeline. The
# stable part is the prefix token -- TF_15, PL_07, TF_90A -- so that is what we match on.
# NOT \b at the end: "TF_15_Opportunities" has no word boundary between "15" and "_",
# because "_" is a word character. A trailing \b silently matched NOTHING here.
_TOKEN = re.compile(r"(?<![A-Za-z0-9])((?:TF|PL)_\d+[A-Za-z]?(?:\.\d+[a-z]?)?)", re.I)


def tokens(text: str) -> set[str]:
    """The TF_/PL_ step tokens in a string, upper-cased. 'TF_15 Opportunities' -> {'TF_15'}"""
    return {m.group(1).upper() for m in _TOKEN.finditer(str(text or ""))}


def _base(token: str) -> str:
    """TF_60.04b -> TF_60. The parent step a sub-step belongs to."""
    return str(token or "").split(".")[0].upper()


def _first(d: dict, *keys):
    for k in keys:
        v = (d or {}).get(k)
        if v not in (None, "", "null"):
            return str(v)
    return ""


# --------------------------------------------------------------------- Informatica
def informatica_runs(sunrise_dir) -> list[dict]:
    """Every taskflow result Sunrise has captured, newest first."""
    if not sunrise_dir:
        return []
    root = Path(sunrise_dir) / "test_run_history" / "informatica_live"
    if not root.is_dir():
        return []
    out = []
    for p in sorted(root.glob("*_result_*.json"), reverse=True):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:                                    # noqa: BLE001
            continue
        if not isinstance(d, dict):
            continue
        name = _first(d, "Taskflow", "Name", "TaskName")
        mon = d.get("Monitor") if isinstance(d.get("Monitor"), dict) else {}
        out.append(dict(
            system="Informatica",
            job=name,
            tokens=tokens(name),
            status=_first(d, "Status") or _first(mon, "status", "state", "jobStatus"),
            succeeded=bool(d.get("Succeeded")),
            started=_first(d, "StartedAtUtc") or _first(mon, "startTime", "startTimeUtc"),
            ended=_first(d, "CompletedAtUtc") or _first(mon, "endTime", "endTimeUtc"),
            run_id=_first(d, "RunId"),
            rows_processed=_first(mon, "successRows", "totalSuccessRows", "rowsProcessed"),
            rows_failed=_first(mon, "failedRows", "totalFailedRows", "errorRows"),
            source=str(p.name),
        ))
    return out


# ------------------------------------------------- Informatica, LIVE from the API
def live_informatica_runs(rows) -> list[dict]:
    """
    Normalise IDMC activityLog / activityMonitor entries into the same shape as the
    captured-from-disk rows, so find() and the UI cannot tell them apart except by
    `source`, which says "live API" so provenance stays visible.

    Field names are read tolerantly: the v2 activity resources differ between the log
    and the monitor, and between pods. An entry whose name cannot be read is skipped
    rather than guessed at -- a run attributed to the wrong step is worse than a blank.
    """
    out = []
    for d in (rows or []):
        if not isinstance(d, dict):
            continue
        name = _first(d, "taskName", "assetName", "objectName", "name", "Taskflow")
        if not name:
            continue
        status = _first(d, "state", "status", "jobStatus", "runStatus")
        out.append(dict(
            system="Informatica",
            job=name,
            tokens=tokens(name),
            status=status,
            succeeded=str(status).upper() in ("SUCCESS", "SUCCEEDED", "COMPLETED"),
            started=_first(d, "startTime", "startTimeUtc", "StartedAtUtc"),
            ended=_first(d, "endTime", "endTimeUtc", "CompletedAtUtc"),
            run_id=_first(d, "runId", "runID", "id"),
            rows_processed=_first(d, "successRows", "totalSuccessRows", "rowsProcessed"),
            rows_failed=_first(d, "failedRows", "totalFailedRows", "errorRows"),
            source="live API",
        ))
    # newest first, blank timestamps last so they never win over a dated run
    out.sort(key=lambda x: (x["started"] or ""), reverse=True)
    return out


# --------------------------------------------------------------------- SnapLogic
def snaplogic_runs(sunrise_dir) -> list[dict]:
    """The latest SnapLogic runtime snapshot Sunrise captured, newest execution first."""
    if not sunrise_dir:
        return []
    root = Path(sunrise_dir) / "test_run_history" / "snaplogic_live"
    if not root.is_dir():
        return []
    snaps = sorted([p for p in root.iterdir()
                    if p.is_dir() and (p / "executions.csv").is_file()], reverse=True)
    if not snaps:
        return []
    out = []
    try:
        with (snaps[0] / "executions.csv").open(encoding="utf-8-sig", newline="") as fh:
            for r in csv.DictReader(fh):
                name = "%s %s" % (r.get("Pipeline", ""), r.get("ProjectPath", ""))
                out.append(dict(
                    system="SnapLogic",
                    job=str(r.get("Pipeline") or "").strip(),
                    tokens=tokens(name),
                    status=str(r.get("Status") or "").strip(),
                    succeeded=str(r.get("Status") or "").strip().lower() in
                              ("completed", "success", "succeeded"),
                    started=str(r.get("StartTime") or "").strip(),
                    ended=str(r.get("EndTime") or "").strip(),
                    run_id=str(r.get("RUUID") or "").strip(),
                    rows_processed="", rows_failed="",
                    source=str(snaps[0].name),
                ))
    except Exception:                                        # noqa: BLE001
        return []
    out.sort(key=lambda x: x["started"], reverse=True)
    return out


class JobHistory:
    """
    Loaded once per run from whatever Sunrise captured. Absent history is NORMAL -- it
    means nobody has run the Sunrise live-ops capture, not that the job did not run, so
    a miss here never turns into a failing verdict. It turns into a blank Time cell.
    """

    def __init__(self, sunrise_dir="", live_rows=None, live_note=""):
        self.dir = str(sunrise_dir or "")
        self.runs: list[dict] = []
        self.error = ""
        self.live_count = 0
        self.live_note = str(live_note or "")
        try:
            live = live_informatica_runs(live_rows)
            captured = informatica_runs(self.dir) + snaplogic_runs(self.dir)
            # LIVE FIRST. find() returns the first match, so when the API and a captured
            # file both describe a step, the API wins -- it is the newer of the two by
            # definition, and the captured file may be days old.
            self.runs = live + captured
            self.live_count = len(live)
        except Exception as e:                               # noqa: BLE001
            self.error = str(e)[:200]

    @property
    def live(self) -> bool:
        """True when at least one run came from the API rather than from disk."""
        return self.live_count > 0

    @property
    def available(self) -> bool:
        return bool(self.runs)

    def find(self, job_label: str) -> dict | None:
        """
        The most recent captured run matching this step. Exact token match first
        (TF_60.04b), then the parent step (TF_60), because a sub-step's work is done by
        its parent taskflow and that parent's run window is the honest answer.
        """
        want = tokens(job_label)
        if not want:
            return None
        for r in self.runs:                                   # exact token
            if want & r["tokens"]:
                return r
        bases = {_base(t) for t in want}
        for r in self.runs:                                   # parent step
            if bases & {_base(t) for t in r["tokens"]}:
                return r
        return None


def window_from_stamps(conn, soql_count: str) -> dict:
    """
    Fallback: when did the records this step produces actually get written?

    Turns `SELECT COUNT() FROM X WHERE ...` into an aggregate that returns the count AND
    the write window in ONE round trip. Note the aliased aggregate -- `SELECT COUNT()`
    alone returns an EMPTY records array (only totalSize), which is precisely the trap
    that made every count in this tool read zero before it was fixed.
    """
    out = dict(count=None, first="", last="", modified="", source="")
    m = re.match(r"\s*SELECT\s+COUNT\(\s*\)\s+(FROM\s+.*)$", soql_count, re.I | re.S)
    if not m:
        return out
    rest = m.group(1)
    agg = ("SELECT COUNT(Id) c, MIN(CreatedDate) mn, MAX(CreatedDate) mx, "
           "MAX(LastModifiedDate) lm " + rest)
    try:
        rows = conn.q(agg)
    except Exception:                                        # noqa: BLE001
        return out
    if not rows:
        return out
    r = rows[0] or {}
    try:
        out["count"] = int(r.get("c") or 0)
    except (TypeError, ValueError):
        out["count"] = None
    out["first"] = str(r.get("mn") or "")
    out["last"] = str(r.get("mx") or "")
    out["modified"] = str(r.get("lm") or "")
    out["source"] = "record stamps"
    return out


def pretty(started: str, ended: str) -> str:
    """'2026-10-01T14:05:11Z' + end -> '10-01 14:05 -> 14:52 (47m)'. Display only."""
    def parse(x):
        s = str(x or "").strip().replace("Z", "+00:00")
        if not s:
            return None
        s = s.replace(" ", "T", 1) if ("T" not in s and " " in s) else s
        from datetime import datetime
        for cut in (s, s[:19]):
            try:
                return datetime.fromisoformat(cut)
            except ValueError:
                continue
        return None
    a, b = parse(started), parse(ended)
    if a is None and b is None:
        return ""
    if a is None:
        return b.strftime("%m-%d %H:%M")
    if b is None:
        return a.strftime("%m-%d %H:%M")
    mins = int(max(0, (b - a).total_seconds()) // 60)
    dur = ("%dm" % mins) if mins < 90 else ("%.1fh" % (mins / 60.0))
    same = a.date() == b.date()
    return "%s → %s (%s)" % (a.strftime("%m-%d %H:%M"),
                                  b.strftime("%H:%M" if same else "%m-%d %H:%M"), dur)
