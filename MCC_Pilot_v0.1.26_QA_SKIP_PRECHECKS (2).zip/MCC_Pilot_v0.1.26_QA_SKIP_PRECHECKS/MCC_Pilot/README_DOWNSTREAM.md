# Downstream taskflow expansion (v0.1.8)

Source: MCC archive, latest available runbook from Preflight Monitor v0.32.0.

Added exact run-book positions for TF_35, TF_90A, TF_40, TF_55, TF_60, TF_75 and TF_80, with candidate Informatica taskflow mappings. **Names are run-book-derived, not API-verified.**

The run book has 43 rows from RO 19 through RO 61; only seven taskflow rows are mapped here. The remaining intermediate validations and recovery actions are recorded in `downstream_runbook_inventory.json` and explicitly diagnosed as missing. Some are potentially destructive and require batch-specific checks, dry-run/live scripting, and API access.

`RequireEndToEnd` is on and `StopAfter` remains TF_30.01. The readiness test deliberately refuses to characterize this as an unattended full migration. Run `CHECK READINESS.bat` to see the missing rows. Use the original v0.1.7 for pilot-only work if needed.

Do not simply delete the StopAfter setting or disable readiness enforcement to run the seven taskflows consecutively; that would bypass vital intermediate verifications.
