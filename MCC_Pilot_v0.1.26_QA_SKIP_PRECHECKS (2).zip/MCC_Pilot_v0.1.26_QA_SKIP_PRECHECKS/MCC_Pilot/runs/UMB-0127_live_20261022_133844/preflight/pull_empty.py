"""Pull the 2 zero-line quotes from batch UMB-0127 (Salesforce batch tag + Goose) and log MCC_EXCLUDED."""
import json, sys
from datetime import datetime
from pathlib import Path
sys.path.insert(0, r'C:\Users\VChiraf\Downloads\MCC_Pilot_v0.1.26_QA_SKIP_PRECHECKS\MCC_Pilot')
from pilot import app, systems, fixlog

B, SF_BATCH = 468, 'aFOVD0000001Swj4AE'
QUOTES = {'Q-1267040': (404515, 'a6OVD000001GEwE2AW'), 'Q-1266280': (405218, 'a6OVD000001GE5E2AW')}
pre = Path(__file__).parent
journal = pre / 'link_existing.jsonl'
c = systems.build(app.CFG, 'dry', lambda m: None)

ids = "','".join(v[1] for v in QUOTES.values())
apex = """
Map<String, Id> want = new Map<String, Id>{%s};
List<SBQQ__Quote__c> qs = [SELECT Id, Name, USS_Migration_Batch__c, (SELECT Id FROM SBQQ__LineItems__r LIMIT 1)
                           FROM SBQQ__Quote__c WHERE Id IN :want.values()];
Integer ok = 0;
for (SBQQ__Quote__c q : qs) {
  Boolean match = want.get(q.Name) == q.Id && q.USS_Migration_Batch__c == '%s' && q.SBQQ__LineItems__r.isEmpty();
  System.debug(LoggingLevel.ERROR, 'EMPTYQ ' + q.Name + ' ' + q.Id + ' match=' + match);
  if (match) { q.USS_Migration_Batch__c = null; ok++; }
}
if (ok != want.size()) { System.debug(LoggingLevel.ERROR, 'EMPTYQ STOP: ' + ok + ' of ' + want.size() + ' verified, nothing changed'); return; }
update qs;
System.debug(LoggingLevel.ERROR, 'EMPTYQ COMMITTED untagged=' + ok);
""" % (", ".join("'%s' => '%s'" % (k, v[1]) for k, v in QUOTES.items()), SF_BATCH)

with journal.open('a', encoding='utf-8') as f:
    f.write(json.dumps(dict(time=datetime.now().isoformat(), status='EMPTYQ_ATTEMPT', quotes=QUOTES)) + '\n')
res = c.sf.run_apex(apex)
debug = "\n".join(res['debug'])
print(debug or res['error'])
if 'EMPTYQ COMMITTED' not in debug:
    sys.exit('Salesforce untag not committed; Goose not changed.')

c.goose.result_sets("SET XACT_ABORT ON; BEGIN TRANSACTION; UPDATE dbo.SFDC_Quote SET MigrationBatchID = NULL "
                    "WHERE MigrationBatchID = %d AND ID IN (%s); SELECT 1 AS Done; COMMIT TRANSACTION;"
                    % (B, ",".join(str(v[0]) for v in QUOTES.values())))
with journal.open('a', encoding='utf-8') as f:
    f.write(json.dumps(dict(time=datetime.now().isoformat(), status='EMPTYQ_PULLED', quotes=QUOTES)) + '\n')
n = fixlog.write(c.goose, B, [fixlog.entry(
    'MCC_EXCLUDED', 'TF_25.04', 'SFDC_Quote', row,
    'MCC EXCLUDED %s (%s) from batch %d / UMB-0127: zero quote lines in source; USS_Migration_Batch__c cleared in '
    'Salesforce. Restore: MigrationBatchID = %d and USS_Migration_Batch__c = %s' % (name, sfid, B, B, SF_BATCH),
    'Quote') for name, (row, sfid) in QUOTES.items()], pre / 'goose_fixlog.jsonl')
print('logged', n)
