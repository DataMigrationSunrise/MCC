# v0.27.0 - export issues, one tab per issue

New "Export issues" button (header) and `monitor.py issues --batch UMB-xxxx` command.

- One tab per failing check, headed by its run book step (RO n + step name), the issue, count, priority, why, fix, and whether it was checked against Salesforce.
- Under the heading: every record or staged row that had the issue. No cap (spreadsheet limit 1,000,000 rows, said on the tab).
- Salesforce Ids are first and are hyperlinks to the record (needs InstanceUrl in config.json).
- Legacy / source Ids sit next to them: read from Salesforce at export time, from `LegacyIdFields` in config.json
  (e.g. {"Account": "Legacy_Id__c"}) or, if not set, from visible fields named like legacy / external_id / source_id.
  The tab says when none was found. If Salesforce is unreachable the export still works, without them.
- Staged-row (PREDICT) findings now keep the staged row's own source Id (new in the next run).
- A Summary tab lists every issue with a link to its tab. Unproven checks are not exported (nothing true to list).
- Pure addition: nothing else changed.
