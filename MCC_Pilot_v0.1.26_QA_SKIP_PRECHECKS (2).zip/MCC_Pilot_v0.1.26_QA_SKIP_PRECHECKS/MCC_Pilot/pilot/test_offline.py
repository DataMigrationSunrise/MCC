"""Offline tests: python -m pilot.test_offline"""
from pathlib import Path
from . import adapters as ad, systems
from .engine import Run, SCRIPTS
import json

ROOT = Path(__file__).resolve().parent.parent
CFG = json.loads((ROOT / "config.json").read_text())

def test_substitute():
    a = (SCRIPTS / "TF_30.01_Check_Quotes_Not_Ordered.apex").read_text()
    assert "'UMB-0116'" in a
    b = ad.substitute(a, "UMB-0999", 999, "aFOX")
    assert "'UMB-0999'" in b and "'UMB-0116'" not in b
    g = ad.substitute((SCRIPTS / "TF_20.05_FIXBQ_Bundle_Fraction_Fix_Generator.sql").read_text(), "UMB-0999", 999, "aFOVD0000001ZZZ")
    assert "DECLARE @batch int = 999" in g and "N'aFOVD0000001ZZZ'" in g

def test_debug_lines():
    log = ("12:00:00.1 (1)|USER_DEBUG|[3]|DEBUG|first\ncontinued\n12:00:00.2 (2)|CODE_UNIT_FINISHED\n"
           "12:00:00.3 (3)|USER_DEBUG|[9]|ERROR|NOT ORDERED (3)\n")
    assert ad.debug_lines(log) == ["first\ncontinued", "NOT ORDERED (3)"]

def test_normalize_sets():
    assert ad.normalize_sets([{"a": 1}]) == [[{"a": 1}]]
    assert ad.normalize_sets([[{"a": 1}], [{"b": 2}]]) == [[{"a": 1}], [{"b": 2}]]
    assert ad.normalize_sets({"Tables": [{"Rows": [{"a": 1}]}]}) == [[{"a": 1}]]

def test_simulated_run_completes_and_fixes():
    r = Run(CFG, "simulate", systems.build); r.execute()
    st = {s["id"]: s["status"] for s in r.steps}
    assert r.state == "TARGET_REACHED", r.log[-5:]
    assert st["TF_15.01"] == "FIXED" and st["TF_20.05"] == "FIXED" and st["TF_30.01"] == "PASS"
    assert st["TF_35"] == "PENDING"

def test_blocking_failure_stops_run():
    orig = systems.SIM_APEX[:]
    systems.SIM_APEX.insert(0, ("TF_25.04", ["Quotes with ZERO lines      : 3"]))
    try:
        r = Run(CFG, "simulate", systems.build); r.execute()
    finally:
        systems.SIM_APEX[:] = orig
    st = {s["id"]: s["status"] for s in r.steps}
    assert r.state == "BLOCKED" and st["TF_25.04"] == "FAIL" and st["TF_25"] == "PENDING" and st["TF_30"] == "PENDING"

def test_live_needs_confirmation():
    r = Run(CFG, "live", lambda c, m, say: systems._sim(say))
    r.execute(confirm_name="WRONG")
    assert r.state == "BLOCKED" and all(s["status"] == "PENDING" for s in r.steps)



def test_retry_only_verified_idempotent():
    class Inf:
        def __init__(self): self.n = 0
        def run(self, *args):
            self.n += 1
            if self.n == 1:
                return dict(done=True, ok=False, status="FAILED", detail="transient")
            return dict(done=True, ok=True, status="SUCCEEDED", detail="good")
    class Goose:
        def result_sets(self, sql): return [[], []]
    class C: pass
    c = C(); c.inf = Inf(); c.goose = Goose()
    cfg = json.loads(json.dumps(CFG))
    cfg["Informatica"]["Retry"] = {"MaxRetries": 1, "DelaySeconds": 0, "IdempotentTaskflows": ["tf_15_OpportunitiesToQuotes"]}
    r = Run(cfg, "live", None); r.batch = {"name": "UMB-TEST", "goose_id": 42, "sf_id": "123"}
    status, detail = r._k_informatica(c, {"id": "TF_15", "ro": "10"})
    assert status == "DONE" and c.inf.n == 2
    assert len(r.reconciliations) == 2


def test_timeout_never_retries():
    class Inf:
        def __init__(self): self.n = 0
        def run(self, *args):
            self.n += 1
            return dict(done=False, ok=False, status="TIMEOUT", detail="still running")
    class Goose:
        def result_sets(self, sql): return [[], []]
    class C: pass
    c = C(); c.inf = Inf(); c.goose = Goose()
    cfg = json.loads(json.dumps(CFG))
    cfg["Informatica"]["Retry"] = {"MaxRetries": 3, "DelaySeconds": 0, "IdempotentTaskflows": ["tf_15_OpportunitiesToQuotes"]}
    r = Run(cfg, "live", None); r.batch = {"name": "UMB-TEST", "goose_id": 42, "sf_id": "123"}
    status, _ = r._k_informatica(c, {"id": "TF_15", "ro": "10"})
    assert status == "FAIL" and c.inf.n == 1

def test_extension_rejects_unknown_steps():
    from .extensions import validate_extension
    broken = {"steps": [{"id": "TF_35", "kind": "magic", "blocking": True}], "required_milestones": ["TF_35"]}
    assert any("unsupported" in e for e in validate_extension(broken, SCRIPTS, CFG))

def test_unfinished_not_marked_processed():
    r = Run(CFG, "simulate", systems.build); r.execute()
    assert not r.coverage["complete"]
    assert "TF_35" in r.coverage["missing"]


def test_readiness_finds_partial_pipeline():
    from .readiness import inspect
    result = inspect(CFG, ROOT)
    assert not result["ready_for_full_run"]
    assert any("Downstream run book incomplete" in x for x in result["errors"])
    assert any("StopAfter" in x for x in result["errors"])
    assert result["extension_steps"] == 13

def test_step_preflight_reads_batch_and_writes_evidence():
    from .step_preflight import scan
    import tempfile
    class Goose:
        def result_sets(self, sql):
            assert "ID = 123" in sql
            return [[{"SourceRecordId": 123, "IsEligible": 0, "Reason": "Closed batch"}]]
    with tempfile.TemporaryDirectory() as tmp:
        result = scan(Goose(), ROOT, Path(tmp), "TF_15", 123, "dry")
        assert result["status"] == "FINDINGS"
        assert result["issues"][0]["severity"] == "unproven"
        assert Path(result["file"]).is_file()

def test_missing_batch_cannot_look_clear():
    from .step_preflight import scan
    import tempfile
    class Goose:
        def result_sets(self, sql): return [[]]
    with tempfile.TemporaryDirectory() as tmp:
        result = scan(Goose(), ROOT, Path(tmp), "TF_15", 123, "live")
        assert result["status"] == "FINDINGS"
        assert result["issues"][0]["severity"] == "unproven"
        assert "missing or ambiguous" in result["issues"][0]["reason"]

def test_eligible_batch_does_not_create_issue():
    from .step_preflight import scan
    import tempfile
    class Goose:
        def result_sets(self, sql): return [[{"SourceRecordId": 123, "IsEligible": 1, "Reason": "Batch identity confirmed"}]]
    with tempfile.TemporaryDirectory() as tmp:
        result = scan(Goose(), ROOT, Path(tmp), "TF_15", 123, "live")
        assert result["status"] == "CLEAR" and result["issues"] == []


def test_step_preflight_cannot_execute_mutating_rule():
    from .step_preflight import scan
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "preflight_rules").mkdir()
        (root / "preflight_rules" / "unsafe.sql").write_text("DELETE FROM X WHERE ID = {{GOOSE_BATCH_ID}}")
        (root / "preflight_rules.json").write_text(json.dumps({"rules": [{"id": "unsafe", "steps": ["*"], "file": "unsafe.sql"}]}))
        class Goose:
            def result_sets(self, sql):
                raise AssertionError("unsafe SQL executed")
        result = scan(Goose(), root, root / "out", "TF_15", 123, "live")
        assert result["issues"][0]["severity"] == "unproven"


def test_exclusion_scoped_and_audited():
    from tempfile import TemporaryDirectory
    from .goose_exclusions import exclude
    class GooseMock:
        def __init__(self): self.queries=[]
        def result_sets(self, sql):
            self.queries.append(sql)
            if 'UPDATE S SET' in sql:
                return [[{'ID':55,'OldReason':'','NewReason':'MCC TF_15: invalid'}]]
            return [[{'ID':55,'CurrentReason':'MCC TF_15: invalid'}]]
    mock=GooseMock()
    with TemporaryDirectory() as td:
        path=Path(td)/'audit.jsonl'
        record=exclude(mock,path,batch_id=12,stage_table='STG_Order',record_id=55,reason='invalid',step='TF_15')
        assert record['status']=='EXCLUDED'
        assert 'T.MigrationBatchID = 12' in mock.queries[0]
        assert 'S.ID = 55' in mock.queries[0]
        assert any(item['record_id']==55 and item['status']=='EXCLUDED' for item in map(json.loads, path.read_text().splitlines()))
        try:
            exclude(mock,path,batch_id=12,stage_table='STG_Unknown',record_id=55,reason='invalid',step='TF_15')
            assert False
        except ValueError: pass

def test_monitor_fields_and_verified_metrics():
    class Inf:
        def run(self, *args):
            return dict(ok=True, done=True, status='SUCCEEDED', processed=23, successful=22, failed=1, run_id='real-taskflow-run')
    class Goose:
        def result_sets(self, sql): return [[], []]
    class C: pass
    c=C(); c.inf=Inf(); c.goose=Goose()
    r=Run(CFG,'live',None)
    r.batch={'name':'TEST','goose_id':42,'sf_id':'test'}
    status,_=r._k_informatica(c,{'id':'TF_15','ro':'10'})
    assert status=='DONE'
    snap=r.snapshot()
    assert snap['informatica_last_result']['metrics']['processed']==23
    assert snap['informatica_last_result']['metrics']['run_id']=='real-taskflow-run'
    assert snap['records']['processed'] == 23  # last reported Informatica metric, NOT a fabricated aggregate

def test_monitor_does_not_guess_missing_counts():
    class Inf:
        def run(self,*args): return dict(ok=True,done=True,status='SUCCEEDED')
    class Goose:
        def result_sets(self,sql): return [[], []]
    class C: pass
    c=C();c.inf=Inf();c.goose=Goose()
    r=Run(CFG,'live',None)
    r.batch={'name':'TEST','goose_id':42,'sf_id':'test'}
    r._k_informatica(c,{'id':'TF_15','ro':'10'})
    assert r.snapshot()['informatica_last_result']['metrics']=={}


def test_exclusions_withheld_on_missing_identity():
    from .step_preflight import scan
    from tempfile import TemporaryDirectory
    import json
    with TemporaryDirectory() as td:
        base=Path(td); (base/'preflight_rules').mkdir()
        (base/'preflight_rules'/'identity.sql').write_text('SELECT ID AS SourceRecordId FROM dbo.MigrationBatch WHERE ID = {{GOOSE_BATCH_ID}}')
        (base/'preflight_rules'/'bad.sql').write_text('SELECT ID AS SourceRecordId FROM dbo.STG_Order WHERE TransformationID = {{GOOSE_BATCH_ID}}')
        (base/'preflight_rules.json').write_text(json.dumps({'exclusion_mode':'enabled','rules':[
            {'id':'goose_batch_identity','file':'identity.sql','steps':['*']},
            {'id':'bad','file':'bad.sql','steps':['*'],'action':'exclude','verified_nonblocking':True,'stage_table':'STG_Order'}]}))
        class Goose:
            def result_sets(self,sql):
                assert 'UPDATE' not in sql
                return [[]] if 'MigrationBatch' in sql else [[{'SourceRecordId':55,'Reason':'bad'}]]
        result=scan(Goose(),base,base/'out','TF_15',99,'live')
        assert result['status']=='FINDINGS'
        assert any('withheld' in x['reason'] for x in result['issues'])
        assert not (base/'out'/'goose_exclusions.jsonl').exists()


def test_uncertain_exclusion_is_explicit_not_warning():
    from .step_preflight import scan
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as td:
        base=Path(td); (base/'preflight_rules').mkdir()
        (base/'preflight_rules'/'identity.sql').write_text('SELECT ID AS SourceRecordId FROM dbo.MigrationBatch WHERE ID = {{GOOSE_BATCH_ID}}')
        (base/'preflight_rules'/'bad.sql').write_text('SELECT ID AS SourceRecordId FROM dbo.STG_Order WHERE TransformationID = {{GOOSE_BATCH_ID}}')
        (base/'preflight_rules.json').write_text(json.dumps({'exclusion_mode':'enabled','rules':[
            {'id':'goose_batch_identity','file':'identity.sql','steps':['*']},
            {'id':'bad','file':'bad.sql','steps':['*'],'action':'exclude','verified_nonblocking':True,'stage_table':'STG_Order'}]}))
        class Goose:
            def result_sets(self, sql):
                if 'UPDATE S SET' in sql: return [[]]
                if 'CurrentReason' in sql: return [[{'ID':55,'CurrentReason':''}]]
                if 'MigrationBatch' in sql: return [[{'SourceRecordId':99,'IsEligible':1}]]
                return [[{'SourceRecordId':55,'Reason':'Known invalid'}]]
        res=scan(Goose(),base,base/'out','TF_15',99,'live')
        assert any(i['action']=='NOT_CHANGED_OR_UNVERIFIED' for i in res['issues'])


def test_goose_error_exact_batch_and_exact_source_record():
    from tempfile import TemporaryDirectory
    from .error_reconcile import reconcile
    class Fake:
        def __init__(self): self.queries=[]
        def result_sets(self, q):
            self.queries.append(q)
            if 'FROM dbo.GOOSE_ErrorLog E' in q:
                assert 'MigrationBatchID = 456' in q
                return [[{'ErrorLogID': 18, 'LogType': 'ERROR', 'SourceObject': 'STG_CustomerContact',
                          'SourceRecordID': 'SOURCE-ABC', 'ErrorMessage': 'REQUIRED_FIELD_MISSING: LastName'}]]
            if 'FROM dbo.STG_CustomerContact S' in q and 'UPDATE S SET' not in q and 'CurrentReason' not in q:
                assert 'T.MigrationBatchID = 456' in q and "SourceObjectID = N'SOURCE-ABC'" in q
                return [[{'ID': 123, 'TransformationID': 8, 'SourceObjectID':'SOURCE-ABC'}]]
            if 'UPDATE S SET' in q:
                assert 'T.MigrationBatchID = 456' in q and 'S.ID = 123' in q
                return [[{'ID': 123, 'OldReason': '', 'NewReason': 'MCC PL_07: Goose error 18: REQUIRED_FIELD_MISSING: LastName'}]]
            if 'CurrentReason' in q:
                return [[{'ID': 123, 'CurrentReason': 'MCC PL_07: Goose error 18: REQUIRED_FIELD_MISSING: LastName'}]]
            if "INSERT INTO dbo.GOOSE_ErrorLog" in q:
                assert "LogType = 'MCC_EXCLUDED'" in q
                return [[{'ResolutionID': 22}]]
            raise AssertionError(q[:100])
    with TemporaryDirectory() as td:
        f=Fake(); report=reconcile(f,ROOT,Path(td)/'recon.csv',batch_id=456,step='PL_07',mode='live')
        assert report['excluded']==1 and report['uncertain']==0, report
        assert report['rows'][0]['resolution_id']==22
        assert Path(report['evidence']).is_file()
        assert (Path(td).parent/'no_file').exists() is False


def test_goose_error_ambiguous_staging_never_written():
    from tempfile import TemporaryDirectory
    from .error_reconcile import reconcile
    class Fake:
        def result_sets(self, q):
            if 'FROM dbo.GOOSE_ErrorLog E' in q:
                return [[{'ErrorLogID': 31, 'LogType':'ERROR', 'SourceObject':'STG_CustomerContact',
                          'SourceRecordID':'DUP', 'ErrorMessage':'REQUIRED_FIELD_MISSING'}]]
            if 'FROM dbo.STG_CustomerContact S' in q and 'UPDATE S SET' not in q and 'CurrentReason' not in q:
                return [[{'ID': 1}, {'ID': 2}]]
            raise AssertionError('No update/log write allowed')
    with TemporaryDirectory() as td:
        report=reconcile(Fake(),ROOT,Path(td)/'r.csv',batch_id=12,step='PL_07',mode='live')
        assert report['excluded']==0
        assert report['rows'][0]['action']=='AMBIGUOUS_OR_ALREADY_EXCLUDED'


def test_non_allowlisted_error_never_excluded():
    from tempfile import TemporaryDirectory
    from .error_reconcile import reconcile
    class Fake:
        def result_sets(self, q):
            if 'FROM dbo.GOOSE_ErrorLog E' in q:
                return [[{'ErrorLogID': 31, 'LogType':'ERROR', 'SourceObject':'STG_Order',
                          'SourceRecordID':'111', 'ErrorMessage':'REQUIRED_FIELD_MISSING'}],
                        [{'ErrorLogID':32,'LogType':'ERROR','SourceObject':'STG_CustomerContact',
                          'SourceRecordID':'222','ErrorMessage':'NETWORK_ERROR: SSL expired'}]]
            raise AssertionError('Nonallowlisted errors must not cause writes')
    with TemporaryDirectory() as td:
        report=reconcile(Fake(),ROOT,Path(td)/'r.csv',batch_id=12,step='TF_15',mode='live')
        assert report['excluded']==0 and report['scanned']==2


def test_dry_mode_never_mutates_goose():
    from tempfile import TemporaryDirectory
    from .error_reconcile import reconcile
    class Fake:
        def result_sets(self, q):
            if 'FROM dbo.GOOSE_ErrorLog E' in q:
                return [[{'ErrorLogID': 9, 'LogType': 'ERROR', 'SourceObject': 'STG_CustomerContact',
                          'SourceRecordID': 'XYZ', 'ErrorMessage': 'REQUIRED_FIELD_MISSING'}]]
            if 'FROM dbo.STG_CustomerContact S' in q and 'UPDATE S SET' not in q and 'CurrentReason' not in q:
                return [[{'ID': 30}]]
            raise AssertionError('Dry mode did a write')
    with TemporaryDirectory() as td:
        report=reconcile(Fake(),ROOT,Path(td)/'r.csv',batch_id=8,step='PL_07',mode='dry')
        assert report['rows'][0]['action']=='READY_TO_EXCLUDE'


def test_goose_resolution_failure_requires_reconciliation():
    from tempfile import TemporaryDirectory
    from .error_reconcile import reconcile
    class Fake:
        def result_sets(self, q):
            if 'FROM dbo.GOOSE_ErrorLog E' in q:
                return [[{'ErrorLogID': 9, 'LogType':'ERROR', 'SourceObject':'STG_CustomerContact',
                          'SourceRecordID':'XYZ', 'ErrorMessage':'REQUIRED_FIELD_MISSING'}]]
            if 'FROM dbo.STG_CustomerContact S' in q and 'UPDATE S SET' not in q and 'CurrentReason' not in q:return [[{'ID':10}]]
            if 'UPDATE S SET' in q:
                return [[{'ID':10,'OldReason':'','NewReason':'MCC PL_07: Goose error 9: REQUIRED_FIELD_MISSING'}]]
            if 'CurrentReason' in q:
                return [[{'ID':10,'CurrentReason':'MCC PL_07: Goose error 9: REQUIRED_FIELD_MISSING'}]]
            if 'INSERT INTO dbo.GOOSE_ErrorLog' in q: raise ConnectionError('lost after log INSERT')
            raise AssertionError(q)
    with TemporaryDirectory() as td:
        report=reconcile(Fake(),ROOT,Path(td)/'r.csv',batch_id=8,step='PL_07',mode='live')
        assert report['uncertain']==1 and report['rows'][0]['action']=='WRITE_OUTCOME_UNKNOWN'




def test_pre_pl07_missing_lastname_autoclassified_and_excluded():
    from tempfile import TemporaryDirectory
    from .step_preflight import scan
    class Fake:
        def __init__(self): self.queries=[]
        def result_sets(self, q):
            self.queries.append(q)
            if 'UPDATE S SET' in q:
                assert 'T.MigrationBatchID = 123' in q and 'S.ID = 5' in q
                return [[{'ID':5,'OldReason':'',
                          'NewReason':'MCC PL_07: Contact missing required LastName'}]]
            if 'CurrentReason' in q:
                return [[{'ID':5,'CurrentReason':'MCC PL_07: Contact missing required LastName'}]]
            if 'FROM dbo.MigrationBatch' in q:
                return [[{'SourceRecordId':123,'IsEligible':1,'Reason':'Batch identity confirmed'}]]
            if 'FROM dbo.STG_CustomerContact CC' in q:
                assert 'T.MigrationBatchID = 123' in q
                return [[{'SourceRecordId':5,'Reason':'Contact missing required LastName'}]]
            if 'INSERT INTO dbo.GOOSE_ErrorLog' in q:
                assert "N'MCC_EXCLUDED'" in q and "N'5'" in q and ', 123,' in q
                return [[{'Inserted':1}]]
            raise AssertionError(q)
    with TemporaryDirectory() as td:
        f=Fake();report=scan(f,ROOT,Path(td)/'preflight','PL_07',123,'live')
        issues=[i for i in report['issues'] if i['rule']=='contact_missing_lastname']
        assert len(issues)==1 and issues[0]['action']=='EXCLUDED', report
        assert (Path(td)/'preflight'/'goose_exclusions.jsonl').is_file()
        assert any('UPDATE S SET' in q for q in f.queries)
        assert any('INSERT INTO dbo.GOOSE_ErrorLog' in q for q in f.queries)   # fix-and-log

def test_coordinate_fill_logs_every_blank_address():
    from tempfile import TemporaryDirectory
    from .coord_match import fill, log_entries
    from .fixlog import write
    items = [dict(goose_id=11, result="MATCH", lat=34.19131, lng=-118.13338, source_ids="a8x1", tier="ACCOUNT",
                  confidence="EXACT_STREET"),
             dict(goose_id=12, result="NO_MATCH", lat=None, lng=None, source_ids="", tier="", confidence="")]
    class Fake:
        def __init__(self): self.q = []
        def result_sets(self, q):
            self.q.append(q)
            if "UPDATE AD SET" in q:
                assert "AD.Address_Latitude_Longitude__Latitude__s IS NULL" in q and "MigrationBatchID = 468" in q
                return [[{"FilledId": "11"}]]
            if "INSERT INTO dbo.GOOSE_ErrorLog" in q:
                return [[{"Inserted": q.count("(GETDATE()")}]]
            raise AssertionError(q)
    with TemporaryDirectory() as td:
        g = Fake()
        filled = set(fill(g, items, 468, Path(td) / "fill.jsonl"))
        assert filled == {"11"}
        logs = log_entries(items, filled, "TF_15.G")
        assert [e["log_type"] for e in logs] == ["MCC_FIXED", "MCC_PUSHED_THROUGH"]
        assert write(g, 468, logs, Path(td) / "log.jsonl") == 2

def test_select_tf35_executes_prefix_only():
    r = Run(CFG, "simulate", systems.build, stop_after="TF_35")
    r.execute()
    assert r.state == "TARGET_REACHED", r.log[-5:]
    assert {x["id"]: x["status"] for x in r.steps}["TF_35"] == "DONE"
    assert {x["id"]: x["status"] for x in r.steps}["TF_90A"] == "PENDING"
    assert r.snapshot()["stop_after"] == "TF_35"
    saved = json.loads((r.folder / "run.json").read_text())
    assert saved["stop_after"] == "TF_35"
    assert r.batch["name"] not in r._processed(), "Partial run cannot mark batch fully processed"


def test_saved_run_can_extend_target_without_replaying():
    r = Run(CFG, "simulate", systems.build, stop_after="TF_30.01")
    r.execute()
    assert r.state == "TARGET_REACHED"
    try:
        Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_30.01")
        raise AssertionError("Cannot resume to the same finished checkpoint")
    except Exception as exc:
        assert "later" in str(exc)
    resumed = Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_35")
    assert resumed.stop_after == "TF_35"
    assert resumed.steps[0]["status"] == "PASS"
    resumed.execute()
    assert resumed.state == "TARGET_REACHED"
    assert next(x for x in resumed.steps if x["id"] == "TF_35")["status"] == "DONE"
    assert next(x for x in resumed.steps if x["id"] == "TF_90A")["status"] == "PENDING"
    assert any("Resuming saved checkpoint" in x for x in resumed.log)


def test_unrecognized_target_rejected_before_launch():
    from .targets import validate_target, all_steps, target_readiness
    try:
        validate_target(all_steps(ROOT), "TF_9999")
        raise AssertionError("Unknown target should be rejected")
    except ValueError:
        pass
    ready = target_readiness(CFG, ROOT, "TF_35")
    assert ready["ready"], ready
    assert ready["planned_steps"] > len(__import__("pilot.pipeline", fromlist=["STEPS"]).STEPS)
    assert ready["full_run"] is False



def test_resume_from_selected_later_step_logs_omissions():
    from .engine import Stop
    r = Run(CFG, "simulate", systems.build, stop_after="TF_35")
    r.execute()
    try:
        Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_40", start_from="TF_40")
        raise AssertionError("Unexecuted intermediary steps need explicit skip")
    except Stop as exc:
        assert "bypass unexecuted" in str(exc), str(exc)
    continued = Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_40",
                                    start_from="TF_40", skip_intermediate=True)
    assert continued.resume_from == "TF_40"
    assert next(s for s in continued.steps if s["id"] == "TF_90A")["status"] == "BYPASSED"
    continued.execute()
    assert continued.state == "TARGET_REACHED", continued.log[-5:]
    assert next(s for s in continued.steps if s["id"] == "TF_40")["status"] == "DONE"
    assert not continued.coverage["complete"]
    assert "TF_90A" in continued.coverage["bypassed"]
    assert any("OPERATOR BYPASSED" in line for line in continued.log)
    assert continued.resume_history[-1]["bypassed"]


def test_resume_from_completed_step_requires_intent_and_archives():
    from .engine import Stop
    r = Run(CFG, "simulate", systems.build, stop_after="TF_35")
    r.execute()
    try:
        Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_35", start_from="TF_35")
        raise AssertionError("Completed step cannot replay without explicit request")
    except Stop as exc:
        assert "intentional rerun" in str(exc), str(exc)
    replay = Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_35",
                                 start_from="TF_35", replay_completed=True)
    assert next(s for s in replay.steps if s["id"] == "TF_35")["status"] == "PENDING"
    replay.execute()
    assert replay.state == "TARGET_REACHED"
    assert (r.folder / "resume_history").is_dir()
    archive = next((r.folder / "resume_history").iterdir())
    assert (archive / "prior_run.json").exists()
    assert (archive / "prior_logs").is_dir()
    assert replay.resume_history[-1]["rerun"] == ["TF_35"]


def test_unknown_external_outcome_remains_protected_on_resume():
    from .engine import Stop
    import json
    r = Run(CFG, "simulate", systems.build, stop_after="TF_35")
    r.execute()
    file = r.folder / "run.json"
    snap = json.loads(file.read_text())
    item = next(s for s in snap["steps"] if s["id"] == "TF_90A")
    item["status"] = "RUNNING"
    file.write_text(json.dumps(snap))
    try:
        Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_40",
                            start_from="TF_90A", replay_completed=True)
        raise AssertionError("In-flight external work cannot restart")
    except Stop as exc:
        assert "external outcome requires review" in str(exc), str(exc)


def test_resume_start_and_stop_must_be_in_order():
    from .engine import Stop
    r = Run(CFG, "simulate", systems.build, stop_after="TF_35")
    r.execute()
    try:
        Run.from_checkpoint(CFG, systems.build, r.folder, stop_after="TF_35",
                            start_from="TF_40", skip_intermediate=True)
        raise AssertionError("End point must be at or after start")
    except Stop as exc:
        assert "later Run Through" in str(exc), str(exc)


def test_tf2502_judged_on_quote_side_jobsites():
    # Debug lines in the shapes TF_25.02 prints (FAIL / UNPROVEN text taken from a QA run on UMB-0123).
    r = Run(CFG, "simulate", systems.build)
    s = next(x for x in r.steps if x["id"] == "TF_25.02")
    def judge(lines):
        return r._judge_apex(s, {"ok": True, "error": "", "debug": lines})[0]
    unproven = ["Jobsites on batch quotes: 0",
                "UNPROVEN -- no NF_Quoted_Jobsite__c reaches this batch through NF_Quote__r.USS_Migration_Batch__c."]
    assert judge(unproven) == "UNPROVEN"
    fail = ["Jobsites on batch quotes: 949", "=== VERDICT ===",
            "FAIL -- of 949 jobsites: 424 no coordinates; 2 blank Site Name. Fix before TF_30."]
    assert judge(fail) == "FAIL"
    warn = ["Jobsites on batch quotes: 949", "=== VERDICT ===",
            "PASS WITH WARNINGS -- 942 of 949 jobsites not Order Ready (942 Placement blank); ORDER_READY_BLOCKS=false."]
    st, detail = r._judge_apex(s, {"ok": True, "error": "", "debug": warn})
    assert st == "PASS" and "942 of 949" in detail
    # A customer address that happens to contain a verdict word is printed defanged.
    named = warn[:1] + ['  NO COORDINATES | QJ-1 | quote Q-1 | addr=a8x "A_BORT RD - U_NPROVEN F_AIL CO"'] + warn[1:]
    assert judge(named) == "PASS"
    assert judge(warn[:1] + ['  addr "ABORT RD"'] + warn[1:]) == "FAIL"  # why the script defangs names
    text = (SCRIPTS / "TF_25.02_Verify_Jobsite_Order_Readiness.apex").read_text()
    assert "No Orders yet" not in text and "FROM NF_Quoted_Jobsite__c" in text
    assert "Boolean ORDER_READY_BLOCKS = false;" in text and "safe(a.Name)" in text
    for f in ("NF_Order_Ready__c", "NF_Placement__c", "Site_Name__c"):
        assert f in text

def test_coordinate_match_tiers_precision_and_ambiguity():
    from .coord_match import match
    g = [dict(Id=1, USF_Street__c="692 E Pine St", USF_City__c="Altadena", USF_State__c="CA",
              USF_Zip_Code__c="91001", SalesforceAccountID="001A"),
         dict(Id=2, USF_Street__c="10 Oak Avenue", USF_City__c="X", USF_State__c="CA", USF_Zip_Code__c="90000"),
         dict(Id=3, USF_Street__c="FRENCH CAMP", USF_City__c="Manteca", USF_State__c="CA", USF_Zip_Code__c="95336")]
    def sf(i, street, lat, lng, acct="", city="ALTADENA", z="91001"):
        return dict(Id=i, USF_Account__c=acct, USF_Street__c=street, USF_City__c=city, USF_State__c="CA",
                    USF_Zip_Code__c=z, Address_Latitude_Longitude__Latitude__s=lat,
                    Address_Latitude_Longitude__Longitude__s=lng)
    rows = [sf("a", "692 EAST PINE STREET", 34.1897, -118.1312, "001A"),        # coarse centroid copy
            sf("b", "692 E Pine St", 34.19131, -118.13338, "001A"),
            sf("c", "692 E Pine St", 34.19131, -118.13338, "001A"),
            sf("d", "10 Oak Ave", 34.10001, -118.10001, city="X", z="90000"),
            sf("e", "10 Oak Ave", 34.20001, -118.20001, city="X", z="90000")]
    out = {i["goose_id"]: i for i in match(g, rows)}
    assert out[1]["result"] == "MATCH" and out[1]["tier"] == "ACCOUNT" and out[1]["lat"] == 34.19131
    assert out[2]["result"] == "AMBIGUOUS" and out[2]["lat"] is None      # copies disagree: never guess
    assert out[3]["result"] == "NOT_MATCHABLE"                             # no house number

def test_run_folders_unique_within_same_second():
    a = Run(CFG, "simulate", systems.build); a.execute()
    b = Run(CFG, "simulate", systems.build); b.execute()
    assert a.folder != b.folder

def test_test_batch_allowed_only_by_config():
    r = Run(CFG, "simulate", systems.build)
    r.batch = dict(goose_id=468, goose_status="Open", is_test=1, name="UMB-0127", sf_status="Open")
    s = next(x for x in r.steps if x["id"] == "PREFLIGHT")
    assert r._k_preflight(None, s)[0] == "PASS"
    r.cfg = dict(CFG, AllowTestBatchesInSandbox=False)
    assert r._k_preflight(None, s)[0] == "FAIL"

def test_tf0003_org_wide_failed_jobs_do_not_block():
    # QA always has unrelated failed async jobs; they are context, not a verdict.
    r = Run(CFG, "simulate", systems.build)
    s = next(x for x in r.steps if x["id"] == "TF_00.03")
    out = ["   Org-wide async jobs that did not complete in the last day (context): 12",
           "     F_ailed  PriceEngineCallouts  errors=0  First error: callout F_AILED, A_BORT",
           "===== VERDICT =====", "LOOKS FINISHED. No async jobs, nothing created in the last 5 minutes.",
           "Context only: 12 org-wide async job(s) did not complete in the last day.",
           "They are not attributed to this batch and do not stop the run. Read the list above."]
    assert r._judge_apex(s, {"ok": True, "error": "", "debug": out})[0] == "PASS"
    text = (SCRIPTS / "TF_00.03_Check_Step_Actually_Finished.apex").read_text()
    assert "FAILED or were ABORTED" not in text and "safe(j.ExtendedStatus)" in text


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_") and callable(f):
            f(); print("ok ", n)
